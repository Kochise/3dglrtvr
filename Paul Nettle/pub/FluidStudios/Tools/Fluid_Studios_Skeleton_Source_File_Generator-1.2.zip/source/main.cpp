// --------------------------------------------------------------------------------------------------------------------------------
//                  _                            
//                 (_)                           
//  _ __ ___   __ _ _ _ __       ___ _ __  _ __  
// | '_ ` _ \ / _` | | '_ \     / __| '_ \| '_ \ 
// | | | | | | (_| | | | | | _ | (__| |_) | |_) |
// |_| |_| |_|\__,_|_|_| |_|(_) \___| .__/| .__/ 
//                                  | |   | |    
//                                  |_|   |_|    
// Command-line interface functions (Linux version)
// --------------------------------------------------------------------------------------------------------------------------------
// Originally created on 10/23/2000 by Paul Nettle (midnight@FluidStudios.com)
//
// You are given permission to use, modify & redistribute this source free of charge for non-commercial use only provided that the
// copyright notice (below) is left as part of the file's contents. The author would also like to politely request that any
// significant improvements to this source code be shared with him.
//
// Copyright 2000, Fluid Studios, Inc., all rights reserved.
// --------------------------------------------------------------------------------------------------------------------------------

#include "skelgen.h"

// --------------------------------------------------------------------------------------------------------------------------------

void	printUsage()
{
	cerr << "Usage: skelgen <base_output_filename> [options]" << endl;
	cerr << endl;
	cerr << "    -annn  Set [class] macro to nnn" << endl;
	cerr << "    -c     Don't generate C file (even if matching template exists)" << endl;
	cerr << "    -cpp   Don't generate CPP file (even if matching template exists)" << endl;
	cerr << "    -dnnn  Set [description] macro to nnn" << endl;
	cerr << "    -h     Don't generate H file (even if matching template exists)" << endl;
	cerr << "    -hpp   Don't generate HPP file (even if matching template exists)" << endl;
	cerr << "    -help  This help text" << endl;
	cerr << "    -knnn  Set bubble-font kerning to nnn" << endl;
	cerr << "    -o     Force overwrite of existing files" << endl;
	cerr << "    -p     Set prefix for location of macro and template directories" << endl;
	cerr << "    -tnnn  Use template file nnn located within the template directory" << endl;
	cerr << "    -uXnnn Set user macro X (i.e. [user1] ... [user5]) to nnn" << endl;
	cerr << endl;
	cerr << "Default usage looks like:" << endl;
	cerr << endl;
	cerr << "    skelgen -k-1 -p. -tdefault" << endl;
	cerr << endl;
	cerr << "Environment variables:" << endl;
	cerr << endl;
	cerr << "    * skelgen_prefix - changes the default of the -p parameter" << endl;
	cerr << endl;
	cerr << "Other notes:" << endl;
	cerr << endl;
	cerr << "    * You'll never learn how to use this if you don't read the README. :)" << endl;
	cerr << "    * Contact author at: midnight@FluidStudios.com" << endl;
	cerr << endl;
}

// --------------------------------------------------------------------------------------------------------------------------------

int	main(int argc, char *argv[])
{
	string	fname;
	string	user1, user2, user3, user4, user5;
	string	className;
	string	description;
	string	prefix(".");
	string	templateFile("default");
	bool	genC = true, genH = true, genCPP = true, genHPP = true;
	bool	overwriteFlag = false;
	int	kerning = -1;

	// Check for the environment variable

	char	*env = getenv("skelgen_prefix");
	if (env) prefix = env;

	for (int i = 1; i < argc; i++)
	{
		if (argv[i][0] == '-')
		{
			switch(tolower(argv[i][1]))
			{
				case 'a':
					className = argv[i] + 2;
					break;
				case 'c':
					if (argv[i][2] == 'p' && argv[i][3] == 'p') genCPP = false;
					else genC = false;
					break;
				case 'd':
					description = argv[i] + 2;
					break;
				case 'h':
					if (argv[i][2] == 'p' && argv[i][3] == 'p') genHPP = false;
					else if (argv[i][2] == 'e' && argv[i][3] == 'l' && argv[i][4] == 'p')
					{
						printUsage();
						return 0;
					}
					else genH = false;
					break;
				case 'k':
					kerning = atoi(argv[i] + 2);
					break;
				case 'o':
					overwriteFlag = true;
					break;
				case 'p':
					prefix = argv[i] + 2;
					break;
				case 't':
					templateFile = argv[i] + 2;
					break;
				case 'u':
					     if (argv[i][2] == '1') user1 = argv[i] + 3;
					else if (argv[i][2] == '2') user2 = argv[i] + 3;
					else if (argv[i][2] == '3') user3 = argv[i] + 3;
					else if (argv[i][2] == '4') user4 = argv[i] + 3;
					else                        user5 = argv[i] + 3;
					break;
				default:
					cerr << "Unknown parameter: " << argv[i] << endl;
					printUsage();
					return 0;
			}
		}
		else
		{
			if (fname.length())
			{
				cerr << "Unknown parameter: " << argv[i] << endl;
				printUsage();
				return 0;
			}
			fname = argv[i];
		}
	}

	if (!fname.length())
	{
		cerr << "No filename given" << endl;
		printUsage();
		return 0;
	}

	string err = generate(	fname, templateFile, prefix, className, description,
				user1, user2, user3, user4, user5,
				kerning,
				genC, genH, genCPP, genHPP,
				overwriteFlag);
	if (err.length())
	{
		cerr << err << endl;
		return 0;
	}

	return 1;
}

// --------------------------------------------------------------------------------------------------------------------------------
// main.cpp - End of file
// --------------------------------------------------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------------------------------------------------
//      _         _                      _ _                            
//     | |       | |                    | | |                           
//  ___| | __ ___| | __ _  ___ _ __   __| | | __ _      ___ _ __  _ __  
// / __| |/ // _ \ |/ _` |/ _ \ '_ \ / _` | |/ _` |    / __| '_ \| '_ \ 
// \__ \   <|  __/ | (_| |  __/ | | | (_| | | (_| | _ | (__| |_) | |_) |
// |___/_|\_\\___|_|\__, |\___|_| |_|\__,_|_|\__, |(_) \___| .__/| .__/ 
//                   __/ |                    __/ |        | |   | |    
//                  |___/                    |___/         |_|   |_|    
// Primary SkelGen interface dialog (Windows version)
//
// Best viewed with 8-character tabs and (at least) 132 columns
//
// ---------------------------------------------------------------------------------------------------------------------------------
//
// Restrictions & freedoms pertaining to usage and redistribution of this software:
//
//  * This software is 100% free
//  * If you use this software (in part or in whole) you must credit the author.
//  * This software may not be re-distributed (in part or in whole) in a modified
//    form without clear documentation on how to obtain a copy of the original work.
//  * You may not use this software to directly or indirectly cause harm to others.
//  * This software is provided as-is and without warrantee. Use at your own risk.
//
// For more information, visit HTTP://www.FluidStudios.com
//
// --------------------------------------------------------------------------------------------------------------------------------
// Originally created on 10/23/2000 by Paul Nettle (midnight@FluidStudios.com)
//
// Copyright 2000, Fluid Studios, Inc., all rights reserved.
// --------------------------------------------------------------------------------------------------------------------------------

#include "skelgen.h"

// --------------------------------------------------------------------------------------------------------------------------------

static	void	getTemplateFlags(CComboBox &cb, bool &c, bool &h, bool &cpp, bool &hpp)
{
	c = false;
	h = false;
	cpp = false;
	hpp = false;

	char	temp[256];
	memset(temp, 0, sizeof(temp));
	cb.GetLBText(cb.GetCurSel(), temp);
	char	*ptr = strchr(temp, '(');
	if (!ptr) return;
	char	*zzz;
	if (zzz = strstr(ptr, "CPP")) cpp = true, *zzz = 'x';
	if (zzz = strstr(ptr, "HPP")) hpp = true, *zzz = 'x';
	if (zzz = strstr(ptr, "C")) c = true;
	if (zzz = strstr(ptr, "H")) h = true;
}

// --------------------------------------------------------------------------------------------------------------------------------

static	void	loadMacroFiles(Template &t)
{
	_finddata_t	fd;
	long	handle = _findfirst(".\\macros\\*.macro", &fd);
	if (handle < 0) return;

	do
	{
		Macros	c(string(".\\macros\\") + fd.name);
		char	temp[256];
		strcpy(temp, fd.name);
		temp[strlen(temp) - 6] = 0;
		c.addMacros(t, temp);
	}
	while(_findnext(handle, &fd) >= 0);
}

// --------------------------------------------------------------------------------------------------------------------------------

static	void	populateTemplates(CComboBox &cb)
{
	// Wipe it out

	while(cb.GetCount()) cb.DeleteString(0);

	StringList	cList;
	StringList	hList;
	StringList	cppList;
	StringList	hppList;
	StringList	fullList;

	// C files
	{
		_finddata_t	fd;
		long	handle = _findfirst(".\\templates\\*.c", &fd);
		if (handle >= 0)
		do
		{
			char	temp[256];
			strcpy(temp, fd.name);
			temp[strlen(temp) - 2] = 0;
			cList.push_back(string(temp));
			fullList.push_back(string(temp));
		}
		while(_findnext(handle, &fd) >= 0);
	}

	// H files
	{
		_finddata_t	fd;
		long	handle = _findfirst(".\\templates\\*.h", &fd);
		if (handle >= 0)
		do
		{
			char	temp[256];
			strcpy(temp, fd.name);
			temp[strlen(temp) - 2] = 0;
			hList.push_back(string(temp));
			fullList.push_back(string(temp));
		}
		while(_findnext(handle, &fd) >= 0);
	}

	// CPP files
	{
		_finddata_t	fd;
		long	handle = _findfirst(".\\templates\\*.cpp", &fd);
		if (handle >= 0)
		do
		{
			char	temp[256];
			strcpy(temp, fd.name);
			temp[strlen(temp) - 4] = 0;
			cppList.push_back(string(temp));
			fullList.push_back(string(temp));
		}
		while(_findnext(handle, &fd) >= 0);
	}

	// HPP files
	{
		_finddata_t	fd;
		long	handle = _findfirst(".\\templates\\*.hpp", &fd);
		if (handle >= 0)
		do
		{
			char	temp[256];
			strcpy(temp, fd.name);
			temp[strlen(temp) - 4] = 0;
			hppList.push_back(string(temp));
			fullList.push_back(string(temp));
		}
		while(_findnext(handle, &fd) >= 0);
	}

	// Get a complete list with duplicates removed

	fullList.sort();
	fullList.unique();

	for (StringList::iterator it = fullList.begin(); it != fullList.end(); ++it)
	{
		string	s = *it;
		s += " (";

		// Is there a C file?

		{
			for (StringList::iterator jt = cList.begin(); jt != cList.end(); ++jt)
			{
				if (*it == *jt)
				{
					s += "C, ";
					break;
				}
			}
		}

		// Is there a H file?

		{
			for (StringList::iterator jt = hList.begin(); jt != hList.end(); ++jt)
			{
				if (*it == *jt)
				{
					s += "H, ";
					break;
				}
			}
		}

		// Is there a CPP file?

		{
			for (StringList::iterator jt = cppList.begin(); jt != cppList.end(); ++jt)
			{
				if (*it == *jt)
				{
					s += "CPP, ";
					break;
				}
			}
		}

		// Is there a HPP file?

		{
			for (StringList::iterator jt = hppList.begin(); jt != hppList.end(); ++jt)
			{
				if (*it == *jt)
				{
					s += "HPP, ";
					break;
				}
			}
		}

		s.erase(s.length() - 2);
		s += ")";
		cb.AddString(s.c_str());
	}

	cb.SetCurSel(0);
}

// --------------------------------------------------------------------------------------------------------------------------------

	CSkelGenDlg::CSkelGenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSkelGenDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSkelGenDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSkelGenDlg)
	DDX_Control(pDX, IDC_OVERWRITE, overwrite);
	DDX_Control(pDX, IDC_USER5, user5);
	DDX_Control(pDX, IDC_USER4, user4);
	DDX_Control(pDX, IDC_USER3, user3);
	DDX_Control(pDX, IDC_USER2, user2);
	DDX_Control(pDX, IDC_USER1, user1);
	DDX_Control(pDX, IDC_GEN_C, genC);
	DDX_Control(pDX, IDC_DESCRIPTION, description);
	DDX_Control(pDX, IDC_TEMPLATES, templateList);
	DDX_Control(pDX, IDC_CLASS, classname);
	DDX_Control(pDX, IDC_KERNING, kerning);
	DDX_Control(pDX, IDC_GEN_HPP, genHPP);
	DDX_Control(pDX, IDC_GEN_H, genH);
	DDX_Control(pDX, IDC_GEN_CPP, genCPP);
	DDX_Control(pDX, IDC_DEST, dest);
	//}}AFX_DATA_MAP
}

// --------------------------------------------------------------------------------------------------------------------------------

BEGIN_MESSAGE_MAP(CSkelGenDlg, CDialog)
	//{{AFX_MSG_MAP(CSkelGenDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, OnGenerate)
	ON_BN_CLICKED(IDCANCEL, OnExit)
	ON_BN_CLICKED(IDC_BROWSE_DEST, OnBrowseDest)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_BN_CLICKED(IDC_VIEW_MACROS, OnViewMacros)
	ON_BN_CLICKED(IDC_VIEW_TEMPLATES, OnViewTemplates)
	ON_BN_CLICKED(IDC_HLP, OnHlp)
	ON_EN_KILLFOCUS(IDC_DEST, OnLeaveEdit)
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	ON_CBN_SELCHANGE(IDC_TEMPLATES, OnSelchangeTemplates)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// --------------------------------------------------------------------------------------------------------------------------------

BOOL	CSkelGenDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	dest.SetWindowText(theApp.GetProfileString("Settings", "Dest", ""));
	classname.SetWindowText(theApp.GetProfileString("Settings", "Class", ""));
	description.SetWindowText(theApp.GetProfileString("Settings", "Description", ""));
	user1.SetWindowText(theApp.GetProfileString("Settings", "user1", ""));
	user2.SetWindowText(theApp.GetProfileString("Settings", "user2", ""));
	user3.SetWindowText(theApp.GetProfileString("Settings", "user3", ""));
	user4.SetWindowText(theApp.GetProfileString("Settings", "user4", ""));
	user5.SetWindowText(theApp.GetProfileString("Settings", "user5", ""));
	kerning.SetWindowText(theApp.GetProfileString("Settings", "Kerning", "-1"));
	genCPP.SetCheck(theApp.GetProfileInt("Settings", "GenCPP", 1) == 0 ? FALSE:TRUE);
	genHPP.SetCheck(theApp.GetProfileInt("Settings", "GenHPP", 0) == 0 ? FALSE:TRUE);
	genH.SetCheck(theApp.GetProfileInt("Settings", "GenH", 1) == 0 ? FALSE:TRUE);
	overwrite.SetCheck(theApp.GetProfileInt("Settings", "Overwrite", 0) == 0 ? FALSE:TRUE);
	populateTemplates(templateList);
	templateList.SetCurSel(theApp.GetProfileInt("Settings", "TemplateIndex", 1));
	OnSelchangeTemplates();
	return TRUE;
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// --------------------------------------------------------------------------------------------------------------------------------

HCURSOR	CSkelGenDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnGenerate()
{
	// Destination file

	char	fname[1024];
	memset(fname, 0, sizeof(fname));
	dest.GetWindowText(fname, sizeof(fname) - 1);

	// Creation flags

	bool	c, h, cpp, hpp;
	getTemplateFlags(templateList, c, h, cpp, hpp);

	// Get the kerning

	char	temp[256];
	memset(temp, 0, sizeof(temp));
	kerning.GetWindowText(temp, sizeof(temp) - 1);
	int	kern = atoi(temp);

	// Dynamic macros

	classname.GetWindowText(temp, sizeof(temp) - 1);
	string	cname(temp);
	description.GetWindowText(temp, sizeof(temp) - 1);
	string	descrip(temp);
	user1.GetWindowText(temp, sizeof(temp) - 1);
	string	u1(temp);
	user2.GetWindowText(temp, sizeof(temp) - 1);
	string	u2(temp);
	user3.GetWindowText(temp, sizeof(temp) - 1);
	string	u3(temp);
	user4.GetWindowText(temp, sizeof(temp) - 1);
	string	u4(temp);
	user5.GetWindowText(temp, sizeof(temp) - 1);
	string	u5(temp);

	// Which template file?

	memset(temp, 0, sizeof(temp));
	templateList.GetLBText(templateList.GetCurSel(), temp);
	char	*paren = strstr(temp, " (");
	if (!paren)
	{
		AfxMessageBox("Cannot get the template file name from the entry in the list", MB_ICONEXCLAMATION);
		return;
	}
	*paren = 0;
	string	templateFile = temp;

	// GENERATE!

	string err = generate(	fname, templateFile, ".", cname, descrip, u1, u2, u3, u4, u5,
				kern,
		        	genC.GetCheck() && c, genH.GetCheck() && h, genCPP.GetCheck() && cpp, genHPP.GetCheck() && hpp,
				overwrite.GetCheck() == TRUE ? true:false);

	if (err.length())
		AfxMessageBox(err.c_str(), MB_ICONINFORMATION);
	else
		AfxMessageBox("Skeleton files generated successfully.", MB_ICONINFORMATION);
	return;
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnExit() 
{
	char	temp[256];
	memset(temp, 0, sizeof(temp));

	dest.GetWindowText(temp, sizeof(temp) - 1);
	theApp.WriteProfileString("Settings", "Dest", temp);

	classname.GetWindowText(temp, sizeof(temp) - 1);
	theApp.WriteProfileString("Settings", "Class", temp);

	description.GetWindowText(temp, sizeof(temp) - 1);
	theApp.WriteProfileString("Settings", "Description", temp);

	user1.GetWindowText(temp, sizeof(temp) - 1);
	theApp.WriteProfileString("Settings", "User1", temp);

	user2.GetWindowText(temp, sizeof(temp) - 1);
	theApp.WriteProfileString("Settings", "User2", temp);

	user3.GetWindowText(temp, sizeof(temp) - 1);
	theApp.WriteProfileString("Settings", "User3", temp);

	user4.GetWindowText(temp, sizeof(temp) - 1);
	theApp.WriteProfileString("Settings", "User4", temp);

	user5.GetWindowText(temp, sizeof(temp) - 1);
	theApp.WriteProfileString("Settings", "User5", temp);

	kerning.GetWindowText(temp, sizeof(temp) - 1);
	theApp.WriteProfileString("Settings", "Kerning", temp);

	theApp.WriteProfileInt("Settings", "GenC",   genC.GetCheck()   == 0 ? 0:1);
	theApp.WriteProfileInt("Settings", "GenH",   genH.GetCheck()   == 0 ? 0:1);
	theApp.WriteProfileInt("Settings", "GenCPP", genCPP.GetCheck() == 0 ? 0:1);
	theApp.WriteProfileInt("Settings", "GenHPP", genHPP.GetCheck() == 0 ? 0:1);
	theApp.WriteProfileInt("Settings", "Overwrite",   overwrite.GetCheck() == 0 ? 0:1);
	theApp.WriteProfileInt("Settings", "TemplateIndex", templateList.GetCurSel() == -1 ? 0:templateList.GetCurSel());
	OnCancel();
	
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnBrowseDest() 
{
	// Get the filename

	char		fname[_MAX_PATH] = "";
	char		filters[] = "All files (*.*)\0*.*\0\0";
	OPENFILENAME	of;
	memset(&of, 0, sizeof(OPENFILENAME));
	of.lStructSize        = sizeof(OPENFILENAME);
	of.hwndOwner          = GetSafeHwnd();
	of.lpstrFilter        = filters;
	of.lpstrCustomFilter  = NULL;
	of.nFilterIndex       = 1;
	of.lpstrFile          = fname;
	of.nMaxFile           = 256;
	of.lpstrTitle         = "Save as";
	of.Flags              = OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_CREATEPROMPT | OFN_OVERWRITEPROMPT | OFN_EXPLORER;
	of.lpstrDefExt        = "";
	if (!GetSaveFileName(&of)) return;

	// Strip the extension from the filename (if any)

	char	*dot = strrchr(fname, '.');
	if (dot && (stricmp(dot, ".cpp") || stricmp(dot, ".hpp") || stricmp(dot, ".c") || stricmp(dot, ".h"))) *dot = '\0';

	dest.SetWindowText(fname);
	return;
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnAbout() 
{
	About	dlg;
	dlg.DoModal();
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnHlp() 
{
	Help	dlg;
	dlg.DoModal();
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnViewMacros() 
{
	::ShellExecute(GetDesktopWindow()->GetSafeHwnd(), "open", ".\\macros", NULL, NULL, SW_SHOWNORMAL);
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnViewTemplates() 
{
	::ShellExecute(GetDesktopWindow()->GetSafeHwnd(), "open", ".\\templates", NULL, NULL, SW_SHOWNORMAL);
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnLeaveEdit() 
{
	// Strip the extension from the filename (if any)

	char		fname[_MAX_PATH];
	memset(fname, 0, sizeof(fname));
	dest.GetWindowText(fname, sizeof(fname) - 1);

	char	*dot = strrchr(fname, '.');
	if (dot && (stricmp(dot, ".cpp") || stricmp(dot, ".hpp") || stricmp(dot, ".c") || stricmp(dot, ".h")))
	{
		*dot = '\0';
		dest.SetWindowText(fname);
	}
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnRefresh() 
{
	populateTemplates(templateList);
	OnSelchangeTemplates();
}

// --------------------------------------------------------------------------------------------------------------------------------

void	CSkelGenDlg::OnSelchangeTemplates() 
{
	bool	c, h, cpp, hpp;
	getTemplateFlags(templateList, c, h, cpp, hpp);
	genC.EnableWindow(c);
	genH.EnableWindow(h);
	genCPP.EnableWindow(cpp);
	genHPP.EnableWindow(hpp);
}

// --------------------------------------------------------------------------------------------------------------------------------
// skelgendlg.cpp - End of file
// --------------------------------------------------------------------------------------------------------------------------------

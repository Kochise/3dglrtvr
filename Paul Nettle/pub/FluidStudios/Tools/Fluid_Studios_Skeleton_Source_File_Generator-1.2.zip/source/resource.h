//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SkelGen.rc
//
#define IDD_SKELGEN_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_ABOUT_DIALOG                129
#define IDD_HELP                        130
#define IDC_KERNING                     1006
#define IDC_GEN_CPP                     1007
#define IDC_VIEW_MACROS                 1008
#define IDC_GEN_HPP                     1009
#define IDC_DOWNLOAD                    1009
#define IDC_VIEW_TEMPLATES              1010
#define IDC_GEN_H                       1011
#define IDC_HLP                         1012
#define IDC_ABOUT                       1013
#define IDC_DEST                        1014
#define IDC_BROWSE_DEST                 1015
#define IDC_EMAIL                       1015
#define IDC_CLASS                       1016
#define IDC_GEN_C                       1017
#define IDC_DESCRIPTION                 1018
#define IDC_EDIT                        1019
#define IDC_TEMPLATES                   1020
#define IDC_REFRESH                     1021
#define IDC_OVERWRITE                   1022
#define IDC_USER1                       1023
#define IDC_USER2                       1024
#define IDC_USER3                       1025
#define IDC_USER4                       1026
#define IDC_USER5                       1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

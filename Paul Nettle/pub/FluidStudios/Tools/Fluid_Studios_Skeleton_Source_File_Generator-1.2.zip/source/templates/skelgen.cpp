// --------------------------------------------------------------------------------------------------------------------------------
// [bubble1:filebase][bubble1:.][bubble1:fileext]
// [bubble2:filebase][bubble2:.][bubble2:fileext]
// [bubble3:filebase][bubble3:.][bubble3:fileext]
// [bubble4:filebase][bubble4:.][bubble4:fileext]
// [bubble5:filebase][bubble5:.][bubble5:fileext]
// [bubble6:filebase][bubble6:.][bubble6:fileext]
// [bubble7:filebase][bubble7:.][bubble7:fileext]
// [bubble8:filebase][bubble8:.][bubble8:fileext]
// [description]
// --------------------------------------------------------------------------------------------------------------------------------
// Originally created on [month]/[day]/[year] by [common.author] ([common.author_email])
//
// You are given permission to use, modify & redistribute this source free of charge for non-commercial use only provided that the
// copyright notice (below) is left as part of the file's contents. The author would also like to politely request that any
// significant improvements to this source code be shared with him.
//
// Copyright [year], [work.company], all rights reserved.
// --------------------------------------------------------------------------------------------------------------------------------

#include "skelgen.h"

// --------------------------------------------------------------------------------------------------------------------------------
// [filebase].[fileext] - End of file
// --------------------------------------------------------------------------------------------------------------------------------

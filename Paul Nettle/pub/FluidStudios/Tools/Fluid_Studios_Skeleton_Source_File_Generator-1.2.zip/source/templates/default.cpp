// -----------------------------------------------------------------------------
// [bubble1:filebase][bubble1:.][bubble1:fileext]
// [bubble2:filebase][bubble2:.][bubble2:fileext]
// [bubble3:filebase][bubble3:.][bubble3:fileext]
// [bubble4:filebase][bubble4:.][bubble4:fileext]
// [bubble5:filebase][bubble5:.][bubble5:fileext]
// [bubble6:filebase][bubble6:.][bubble6:fileext]
// [bubble7:filebase][bubble7:.][bubble7:fileext]
// [bubble8:filebase][bubble8:.][bubble8:fileext]
//
// [description]
//
// -----------------------------------------------------------------------------
// Originally created on [month]/[day]/[year] by [common.author]
//
// Copyright [year], [work.company], all rights reserved.
// -----------------------------------------------------------------------------

#include "[filebase].h"

// -----------------------------------------------------------------------------

	[class]::[class]()
{
}

// -----------------------------------------------------------------------------

	[class]::~[class]()
{
}

// -----------------------------------------------------------------------------
// [filebase].[fileext] - End of file
// -----------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------------------------------------
// [bubble1:filebase][bubble1:.][bubble1:fileext]
// [bubble2:filebase][bubble2:.][bubble2:fileext]
// [bubble3:filebase][bubble3:.][bubble3:fileext]
// [bubble4:filebase][bubble4:.][bubble4:fileext]
// [bubble5:filebase][bubble5:.][bubble5:fileext]
// [bubble6:filebase][bubble6:.][bubble6:fileext]
// [bubble7:filebase][bubble7:.][bubble7:fileext]
// [bubble8:filebase][bubble8:.][bubble8:fileext]
//
// [description]
//
// Best viewed with 8-character tabs and (at least) 132 columns
//
// ---------------------------------------------------------------------------------------------------------------------------------
//
// Restrictions & freedoms pertaining to usage and redistribution of this software:
//
//  * This software is 100% free
//  * If you use this software (in part or in whole) you must credit the author.
//  * This software may not be re-distributed (in part or in whole) in a modified
//    form without clear documentation on how to obtain a copy of the original work.
//  * You may not use this software to directly or indirectly cause harm to others.
//  * This software is provided as-is and without warrantee. Use at your own risk.
//
// For more information, visit HTTP://www.FluidStudios.com
//
// ---------------------------------------------------------------------------------------------------------------------------------
// Originally created on [month]/[day]/[year] by [common.author]
//
// Copyright [year], [work.company], all rights reserved.
// ---------------------------------------------------------------------------------------------------------------------------------

#include "stdafx.h"
#include "[filebase].h"

// ---------------------------------------------------------------------------------------------------------------------------------

	[class]::[class]()
{
}

// ---------------------------------------------------------------------------------------------------------------------------------

	[class]::~[class]()
{
}

// ---------------------------------------------------------------------------------------------------------------------------------
// [filebase].[fileext] - End of file
// ---------------------------------------------------------------------------------------------------------------------------------


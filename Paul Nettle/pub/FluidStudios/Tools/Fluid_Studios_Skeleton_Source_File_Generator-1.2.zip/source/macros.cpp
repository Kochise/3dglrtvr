// --------------------------------------------------------------------------------------------------------------------------------
//                                                           
//                                                           
//  _ __ ___   __ _  ___ _ __  ___  ___      ___ _ __  _ __  
// | '_ ` _ \ / _` |/ __| '__|/ _ \/ __|    / __| '_ \| '_ \ 
// | | | | | | (_| | (__| |  | (_) \__ \ _ | (__| |_) | |_) |
// |_| |_| |_|\__,_|\___|_|   \___/|___/(_) \___| .__/| .__/ 
//                                              | |   | |    
//                                              |_|   |_|    
// Macro management
//
// Best viewed with 8-character tabs and (at least) 132 columns
//
// ---------------------------------------------------------------------------------------------------------------------------------
//
// Restrictions & freedoms pertaining to usage and redistribution of this software:
//
//  * This software is 100% free
//  * If you use this software (in part or in whole) you must credit the author.
//  * This software may not be re-distributed (in part or in whole) in a modified
//    form without clear documentation on how to obtain a copy of the original work.
//  * You may not use this software to directly or indirectly cause harm to others.
//  * This software is provided as-is and without warrantee. Use at your own risk.
//
// For more information, visit HTTP://www.FluidStudios.com
//
// --------------------------------------------------------------------------------------------------------------------------------
// Originally created on 10/23/2000 by Paul Nettle (midnight@FluidStudios.com)
//
// Copyright 2000, Fluid Studios, Inc., all rights reserved.
// --------------------------------------------------------------------------------------------------------------------------------

#include "skelgen.h"

// --------------------------------------------------------------------------------------------------------------------------------

static	void    stripLeadingWS(string &s)
{
	while(s.length())
	{
		if (isspace(s[0])) s.erase(0,1);
		else                    break;
	}
}

// --------------------------------------------------------------------------------------------------------------------------------

static	void    stripTrailingWS(string &s)
{
	for (int i = s.length()-1; i >= 0; i--)
	{
		if (isspace(s[i]))      s.erase(i);
		else                    break;
	}
}

// --------------------------------------------------------------------------------------------------------------------------------

	Macros::Macros(const string &filename)
{
	// Open the file

	if (!filename.length()) return;
	ifstream	stream(filename.c_str(), ios::in);
	if (!stream) return;

	// Read & parse each line in the file

	for(;;)
	{
		// A line of text...

		string	line;

		// Read the line

		getline(stream, line);
		if (stream.bad() || stream.fail()) break;

		stripLeadingWS(line);
		stripTrailingWS(line);

		// Blank?

		if (!line.length()) continue;

		// Is it a '#' comment?

		if (line[0] == '#') continue;

		// Is it a '//' comment?

		if (line[0] == '/' && line[1] == '/') continue;

		// It's a valid value, parse it

		string	title = line;

		// Find the '='

		string::size_type idx = title.find("=");
		if (idx == string::npos) continue;

		// Get the value

		string	value = title.substr(idx);
		value.erase(0, 1);

		// Terminate at the '='

		title.erase(idx, title.length());

		// Trim the results (only the end of the title, and the start of the value are necessary)

		stripTrailingWS(title);
		stripLeadingWS(value);

		// Add it to the list

		_data[title] = value;
	}
}

// --------------------------------------------------------------------------------------------------------------------------------
// macros.cpp - End of file
// --------------------------------------------------------------------------------------------------------------------------------
				

// --------------------------------------------------------------------------------------------------------------------------------
//                                                             
//                                                             
//  _ __ ___   __ _ _ __  _ __   ___ _ __      ___ _ __  _ __  
// | '_ ` _ \ / _` | '_ \| '_ \ / _ \ '__|    / __| '_ \| '_ \ 
// | | | | | | (_| | |_) | |_) |  __/ |    _ | (__| |_) | |_) |
// |_| |_| |_|\__,_| .__/| .__/ \___|_|   (_) \___| .__/| .__/ 
//                 | |   | |                      | |   | |    
//                 |_|   |_|                      |_|   |_|    
// A simple STL map of string pairs
//
// Best viewed with 8-character tabs and (at least) 132 columns
//
// ---------------------------------------------------------------------------------------------------------------------------------
//
// Restrictions & freedoms pertaining to usage and redistribution of this software:
//
//  * This software is 100% free
//  * If you use this software (in part or in whole) you must credit the author.
//  * This software may not be re-distributed (in part or in whole) in a modified
//    form without clear documentation on how to obtain a copy of the original work.
//  * You may not use this software to directly or indirectly cause harm to others.
//  * This software is provided as-is and without warrantee. Use at your own risk.
//
// For more information, visit HTTP://www.FluidStudios.com
//
// --------------------------------------------------------------------------------------------------------------------------------
// Originally created on 10/23/2000 by Paul Nettle (midnight@FluidStudios.com)
//
// Copyright 2000, Fluid Studios, Inc., all rights reserved.
// --------------------------------------------------------------------------------------------------------------------------------

#include "skelgen.h"

// --------------------------------------------------------------------------------------------------------------------------------

	Mapper::Mapper()
{
}

// --------------------------------------------------------------------------------------------------------------------------------

	Mapper::~Mapper()
{
}

// --------------------------------------------------------------------------------------------------------------------------------

bool	Mapper::exist(const string &title) const
{
	// Find the title

	MapperMap::const_iterator pos = _data.find(title);
	if (pos == _data.end()) return false;
	return true;
}

// --------------------------------------------------------------------------------------------------------------------------------

const	string	&Mapper::getString(const string &title) const
{
	// Find the title & return the value

	MapperMap::const_iterator pos = _data.find(title);
	static string	empty;
	if (pos == _data.end()) return empty;
	return pos->second;
}

// --------------------------------------------------------------------------------------------------------------------------------

const	int	Mapper::getInteger(const string &title) const
{
	// Get the value from the title

	const string	&value = getString(title);

	// If not found, return "blank" value

	if (!value.length()) return 0;

	// Is it hexidecimal?

	if (value[0] == '0' && value[1] == 'x')
	{
		int	temp = 0;
		sscanf(value.substr(2).c_str(), "%x", &temp);
		return temp;
	}

	// The value

	return (int) atol(value.c_str());
}


// --------------------------------------------------------------------------------------------------------------------------------

const	float	Mapper::getFloat(const string &title) const
{
	// Get the value from the title

	const string	&value = getString(title);

	// If not found, return "blank" value

	if (!value.length()) return 0.0f;

	// The value

	return (float) atof(value.c_str());
}

// --------------------------------------------------------------------------------------------------------------------------------

void	Mapper::addMacros(Template &t, const string &prefix)
{
	// Add all macros

	MapperMap::iterator pos;
	for (pos = _data.begin(); pos != _data.end(); ++pos)
	{
		t.addMacro(prefix + "." + pos->first, pos->second);
	}
}

// --------------------------------------------------------------------------------------------------------------------------------
// mapper.cpp - End of file
// --------------------------------------------------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------------------------------------------------
//                                   _                             
//                                  | |                            
//   __ _  ___ _ __   ___ _ __  __ _| |_  ___      ___ _ __  _ __  
//  / _` |/ _ \ '_ \ / _ \ '__|/ _` | __|/ _ \    / __| '_ \| '_ \ 
// | (_| |  __/ | | |  __/ |  | (_| | |_|  __/ _ | (__| |_) | |_) |
//  \__, |\___|_| |_|\___|_|   \__,_|\__|\___|(_) \___| .__/| .__/ 
//   __/ |                                            | |   | |    
//  |___/                                             |_|   |_|    
// The primary control procedure for SkelGen. Here we generate the output files.
//
// Best viewed with 8-character tabs and (at least) 132 columns
//
// ---------------------------------------------------------------------------------------------------------------------------------
//
// Restrictions & freedoms pertaining to usage and redistribution of this software:
//
//  * This software is 100% free
//  * If you use this software (in part or in whole) you must credit the author.
//  * This software may not be re-distributed (in part or in whole) in a modified
//    form without clear documentation on how to obtain a copy of the original work.
//  * You may not use this software to directly or indirectly cause harm to others.
//  * This software is provided as-is and without warrantee. Use at your own risk.
//
// For more information, visit HTTP://www.FluidStudios.com
//
// --------------------------------------------------------------------------------------------------------------------------------
// Originally created on 10/23/2000 by Paul Nettle (midnight@FluidStudios.com)
//
// Copyright 2000, Fluid Studios, Inc., all rights reserved.
// --------------------------------------------------------------------------------------------------------------------------------

#include "skelgen.h"

// --------------------------------------------------------------------------------------------------------------------------------

#ifdef	_MSC_VER
const string	slash("\\");
#else
const string	slash("/");
#define	_access(a,b)	access(a,b)
#endif

// --------------------------------------------------------------------------------------------------------------------------------

static	void	loadMacroFiles(Template &t, const string &prefix)
{
#ifdef	_MSC_VER
	_finddata_t	fd;
	long	handle = _findfirst(".\\macros\\*.macro", &fd);
	if (handle < 0) return;

	do
	{
		string	fname(prefix + slash + "macros" + slash + fd.name);
		Macros	c(fname);
		fname = string(fd.name);
		fname.erase(fname.length() - 6);
		c.addMacros(t, fname);
	}
	while(_findnext(handle, &fd) >= 0);
#else
	// Open the directory

	string	dirname(prefix + slash + "macros" + slash);
	DIR	*dir = opendir(dirname.c_str());

	if (!dir) return;

	// Scan the files

	for(;;)
	{
		// Go get a file

		struct	dirent	*de = readdir(dir);
		if (!de) break;

		// Do we have a name?

		if (!de || !de->d_name || !*de->d_name) continue;

		// Skip '.' and '..'

		if (de->d_name[0] == '.') continue;

		// The actual file...

		string	fname(dirname + de->d_name);
		Macros	c(fname);
		fname = string(de->d_name);
		fname.erase(fname.length() - 6);
		c.addMacros(t, fname);
	}

	// Close the directory

	closedir(dir);
#endif
}

// --------------------------------------------------------------------------------------------------------------------------------

string	generate(const string &fname, const string &templateFile, const string &prefix,
		const string &classname, const string &description, const string &user1, const string &user2,
		const string &user3, const string &user4, const string &user5, const int kern, const bool genC, const bool genH,
		const bool genCPP, const bool genHPP, const bool overwriteFlag)
{
	// Test for overwrite

	bool	exists = false;

	if (!exists && genC)
	{
		if (_access(string(fname + ".c").c_str(), 0) != -1) exists = true;
	}
	if (!exists && genH)
	{
		if (_access(string(fname + ".h").c_str(), 0) != -1) exists = true;
	}
	if (!exists && genCPP)
	{
		if (_access(string(fname + ".cpp").c_str(), 0) != -1) exists = true;
	}
	if (!exists && genHPP)
	{
		if (_access(string(fname + ".hpp").c_str(), 0) != -1) exists = true;
	}
	if (exists && !overwriteFlag)
	{
		#ifdef	_MSC_VER
		if (AfxMessageBox("One or more files exist, are you sure you want to overwrite these files?", MB_YESNO|MB_ICONQUESTION) == IDNO)
		{
			return "Skeleton files will not be generated.";
		}
		#else
		return "One or more files exist, use -o to overwrite.\n";
		#endif
	}

	// Setup our page & template

	LCache		lc;
	Template	t(lc, kern);

	// Load the macro files

	loadMacroFiles(t, prefix);

	// Add the input (dynamic) macros

	t.addMacro("class", classname);
	t.addMacro("description", description);
	t.addMacro("user1", user1);
	t.addMacro("user2", user2);
	t.addMacro("user3", user3);
	t.addMacro("user4", user4);
	t.addMacro("user5", user5);

	// Add the filename macros

	string	filebase = fname;
	string	filepath = fname;
	string::size_type idx = fname.rfind(slash);
	if (idx != string::npos)
	{
		filebase.erase(0, idx+1);
		filepath.erase(idx);
	}
	t.addMacro("filebase", filebase);
	t.addMacro("filepath", filepath);

	// Add the time/date macros

	time_t	tx = time(NULL);
	tm	*ts = localtime(&tx);
	string	atime = asctime(ts);
	t.addMacro("asctime", atime.c_str());

	t.addMacro("dayname", atime.substr(0, 3));
	t.addMacro("monthname", atime.substr(4, 3));
	t.addMacro("day", atime.substr(8, 2));
	t.addMacro("hour", atime.substr(11, 2));
	t.addMacro("minute", atime.substr(14, 2));
	t.addMacro("second", atime.substr(17, 2));
	t.addMacro("year", atime.substr(20, 4));
	char	temp[5];
	sprintf(temp, "%02d", ts->tm_mon + 1);
	t.addMacro("month", temp);

	// Generate

	if (genC)
	{
		t.addMacro("fileext", "c");
		string err = t.expandTemplateFile(prefix + slash + "templates" + slash + templateFile + ".c");
		if (err == " ") {}
		else if (err.length()) return err;
		else
		{
			FILE	*fp = fopen(string(fname + ".c").c_str(), "w");
			if (fp)
			{
				lc.write(fp);
				lc.reset();
				fclose(fp);
				cerr << fname << ".c generated successfully" << endl;
			}
		}
	}
	if (genH)
	{
		t.addMacro("fileext", "h");
		string err = t.expandTemplateFile(prefix + slash + "templates" + slash + templateFile + ".h");
		if (err == " ") {}
		else if (err.length()) return err;
		else
		{
			FILE	*fp = fopen(string(fname + ".h").c_str(), "w");
			if (fp)
			{
				lc.write(fp);
				lc.reset();
				fclose(fp);
				cerr << fname << ".h generated successfully" << endl;
			}
		}
	}
	if (genCPP)
	{
		t.addMacro("fileext", "cpp");
		string err = t.expandTemplateFile(prefix + slash + "templates" + slash + templateFile + ".cpp");
		if (err == " ") {}
		else if (err.length()) return err;
		else
		{
			FILE	*fp = fopen(string(fname + ".cpp").c_str(), "w");
			if (fp)
			{
				lc.write(fp);
				lc.reset();
				fclose(fp);
				cerr << fname << ".cpp generated successfully" << endl;
			}
		}
	}
	if (genHPP)
	{
		t.addMacro("fileext", "hpp");
		string err = t.expandTemplateFile(prefix + slash + "templates" + slash + templateFile + ".hpp");
		if (err == " ") {}
		else if (err.length()) return err;
		else
		{
			FILE	*fp = fopen(string(fname + ".hpp").c_str(), "w");
			if (fp)
			{
				lc.write(fp);
				lc.reset();
				fclose(fp);
				cerr << fname << ".hpp generated successfully" << endl;
			}
		}
	}

	return "";
}

// --------------------------------------------------------------------------------------------------------------------------------
// generate.cpp - End of file
// --------------------------------------------------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------------------------------------------------
//                                                 _     
//                                                | |    
//   ___  ___  _ __ ___  _ __ ___   ___  _ __     | |__  
//  / __|/ _ \| '_ ` _ \| '_ ` _ \ / _ \| '_ \    | '_ \ 
// | (__| (_) | | | | | | | | | | | (_) | | | | _ | | | |
//  \___|\___/|_| |_| |_|_| |_| |_|\___/|_| |_|(_)|_| |_|
//                                                       
//                                                       
// Header file common to all application modules
//
// Best viewed with 8-character tabs and (at least) 132 columns
//
// ---------------------------------------------------------------------------------------------------------------------------------
//
// Restrictions & freedoms pertaining to usage and redistribution of this software:
//
//  * This software is 100% free
//  * If you use this software (in part or in whole) you must credit the author.
//  * This software may not be re-distributed (in part or in whole) in a modified
//    form without clear documentation on how to obtain a copy of the original work.
//  * You may not use this software to directly or indirectly cause harm to others.
//  * This software is provided as-is and without warrantee. Use at your own risk.
//
// For more information, visit HTTP://www.FluidStudios.com
//
// --------------------------------------------------------------------------------------------------------------------------------
// Originally created on 10/23/2000 by Paul Nettle (midnight@FluidStudios.com)
//
// Copyright 2000, Fluid Studios, Inc., all rights reserved.
// --------------------------------------------------------------------------------------------------------------------------------

#ifndef	_H_COMMON
#define	_H_COMMON

// --------------------------------------------------------------------------------------------------------------------------------
// This is SO necessary...
// --------------------------------------------------------------------------------------------------------------------------------

#ifdef	_MSC_VER
#pragma warning(disable : 4786)
#endif

// --------------------------------------------------------------------------------------------------------------------------------
// We'll add these here to speed up compiles
// --------------------------------------------------------------------------------------------------------------------------------

#include <string>
#include <list>
#include <map>
#include <vector>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <strstream>
#include <cstdlib>
#include <cstdio>
#include <ctime>

// --------------------------------------------------------------------------------------------------------------------------------
// This is a small app, so we'll save ourselves a headache
// --------------------------------------------------------------------------------------------------------------------------------

using namespace std;

// --------------------------------------------------------------------------------------------------------------------------------
// Handy types
// --------------------------------------------------------------------------------------------------------------------------------

typedef list<string>		StringList;
typedef	map<string, string>	MapperMap;

// --------------------------------------------------------------------------------------------------------------------------------
// Common project includes (for small projects, this is nice and handy)
// --------------------------------------------------------------------------------------------------------------------------------

#ifdef	_MSC_VER
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#include <afxwin.h>		// MFC core and standard components
#include <afxext.h>		// MFC extensions
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls

#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>		// MFC support for Windows Common Controls
#endif	// _AFX_NO_AFXCMN_SUPPORT

#include <io.h>
#include "resource.h"
#include "About.h"
#include "Help.h"
#include "SkelGenDlg.h"

#else // _MSC_VER

#include <unistd.h>
#include <dirent.h>
#endif // _MSC_VER

#include "mapper.h"
#include "lcache.h"
#include "macros.h"
#include "template.h"

extern	char		*fontData[102][8];

// --------------------------------------------------------------------------------------------------------------------------------
// This is the workhorse
// --------------------------------------------------------------------------------------------------------------------------------

extern	string	generate(const string &fname,
			const string &templateFile,
			const string &prefix,
			const string &classname,
			const string &description,
			const string &user1,
			const string &user2,
			const string &user3,
			const string &user4,
			const string &user5,
			const int kern,
			const bool genC,
			const bool genH,
			const bool genCPP,
			const bool genHPP,
			const bool overwriteFlag);

#endif // _H_COMMON
// --------------------------------------------------------------------------------------------------------------------------------
// common.h - End of file
// --------------------------------------------------------------------------------------------------------------------------------


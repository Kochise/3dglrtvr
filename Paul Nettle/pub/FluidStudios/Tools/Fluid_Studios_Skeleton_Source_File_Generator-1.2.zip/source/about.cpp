// --------------------------------------------------------------------------------------------------------------------------------
//        _                 _                        
//       | |               | |                       
//   __ _| |__   ___  _   _| |_      ___ _ __  _ __  
//  / _` | '_ \ / _ \| | | | __|    / __| '_ \| '_ \ 
// | (_| | |_) | (_) | |_| | |_  _ | (__| |_) | |_) |
//  \__,_|_.__/ \___/ \__,_|\__|(_) \___| .__/| .__/ 
//                                      | |   | |    
//                                      |_|   |_|    
// SkelGen about box (Windows version)
//
// Best viewed with 8-character tabs and (at least) 132 columns
//
// ---------------------------------------------------------------------------------------------------------------------------------
//
// Restrictions & freedoms pertaining to usage and redistribution of this software:
//
//  * This software is 100% free
//  * If you use this software (in part or in whole) you must credit the author.
//  * This software may not be re-distributed (in part or in whole) in a modified
//    form without clear documentation on how to obtain a copy of the original work.
//  * You may not use this software to directly or indirectly cause harm to others.
//  * This software is provided as-is and without warrantee. Use at your own risk.
//
// For more information, visit HTTP://www.FluidStudios.com
//
// --------------------------------------------------------------------------------------------------------------------------------
// Originally created on 10/23/2000 by Paul Nettle (midnight@FluidStudios.com)
//
// Copyright 2000, Fluid Studios, Inc., all rights reserved.
// --------------------------------------------------------------------------------------------------------------------------------

#include "skelgen.h"

// --------------------------------------------------------------------------------------------------------------------------------

	About::About(CWnd* pParent /*=NULL*/)
	: CDialog(About::IDD, pParent)
{
	//{{AFX_DATA_INIT(About)
	//}}AFX_DATA_INIT
}

// --------------------------------------------------------------------------------------------------------------------------------

void	About::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(About)
	//}}AFX_DATA_MAP
}

// --------------------------------------------------------------------------------------------------------------------------------

BEGIN_MESSAGE_MAP(About, CDialog)
	//{{AFX_MSG_MAP(About)
	ON_BN_CLICKED(IDC_DOWNLOAD, OnDownload)
	ON_BN_CLICKED(IDC_EMAIL, OnEmail)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// --------------------------------------------------------------------------------------------------------------------------------
// Message handlers
// --------------------------------------------------------------------------------------------------------------------------------

void	About::OnDownload() 
{
	::ShellExecute(GetDesktopWindow()->GetSafeHwnd(), NULL, "http://www.FluidStudios.com/publications.html", NULL, NULL, 0);
}

// --------------------------------------------------------------------------------------------------------------------------------

void	About::OnEmail() 
{
	::ShellExecute(GetDesktopWindow()->GetSafeHwnd(), NULL, "mailto:midnight@FluidStudios.com", NULL, NULL, 0);
}

// --------------------------------------------------------------------------------------------------------------------------------
// about.cpp - End of file
// --------------------------------------------------------------------------------------------------------------------------------


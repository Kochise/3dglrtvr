// --------------------------------------------------------------------------------------------------------------------------------
//  _                        _       _                             
// | |                      | |     | |                            
// | |_  ___ _ __ ___  _ __ | | __ _| |_  ___      ___ _ __  _ __  
// | __|/ _ \ '_ ` _ \| '_ \| |/ _` | __|/ _ \    / __| '_ \| '_ \ 
// | |_|  __/ | | | | | |_) | | (_| | |_|  __/ _ | (__| |_) | |_) |
//  \__|\___|_| |_| |_| .__/|_|\__,_|\__|\___|(_) \___| .__/| .__/ 
//                    | |                             | |   | |    
//                    |_|                             |_|   |_|    
// Automatic macro replacement of macros within files
//
// Best viewed with 8-character tabs and (at least) 132 columns
//
// ---------------------------------------------------------------------------------------------------------------------------------
//
// Restrictions & freedoms pertaining to usage and redistribution of this software:
//
//  * This software is 100% free
//  * If you use this software (in part or in whole) you must credit the author.
//  * This software may not be re-distributed (in part or in whole) in a modified
//    form without clear documentation on how to obtain a copy of the original work.
//  * You may not use this software to directly or indirectly cause harm to others.
//  * This software is provided as-is and without warrantee. Use at your own risk.
//
// For more information, visit HTTP://www.FluidStudios.com
//
// --------------------------------------------------------------------------------------------------------------------------------
// Originally created on 10/23/2000 by Paul Nettle (midnight@FluidStudios.com)
//
// Copyright 2000, Fluid Studios, Inc., all rights reserved.
// --------------------------------------------------------------------------------------------------------------------------------

#include "skelgen.h"

// --------------------------------------------------------------------------------------------------------------------------------

static	StringList	buildBubbleString(const string &in, const int kerning = -1)
{
	int		soff = 0;
	StringList	out;

	out.push_back("");
	out.push_back("");
	out.push_back("");
	out.push_back("");
	out.push_back("");
	out.push_back("");
	out.push_back("");
	out.push_back("");

	for (unsigned int i = 0; i < in.length(); i++)
	{
		char	chr = in[i] < 32 ? 0 : in[i] - 32;
		int	csz = strlen(fontData[chr][0]);
		StringList::iterator it = out.begin();
		for (int j = 0; j < 8; j++, ++it)
		{
			int	off = soff;// + kerning;
			if (off < 0) off = 0;
			string	&str = *it;
			if ((int) str.length() < off + csz) str.resize(off + csz, ' ');
			char	*ptr = fontData[chr][j];
			bool	overwrite = false;
			for (int k = 0; k < csz; k++, off++, ptr++)
			{
				if ((*ptr != ' ' && (str[off] == '|' || str[off] == ' ')) || overwrite)
				{
					overwrite = true;
					str[off] = *ptr;
				}
			}
		}
		soff = soff + kerning + csz;
	}
	return out;
}

// --------------------------------------------------------------------------------------------------------------------------------

	Template::Template(LCache &lcache, const int kerning)
	: _lcache(lcache), _kerning(kerning)
{
}

// --------------------------------------------------------------------------------------------------------------------------------

	Template::~Template()
{
}

// --------------------------------------------------------------------------------------------------------------------------------

void	Template::addMacro(const string &macro, const string &expansion)
{
	_data[macro] = expansion;
}

// --------------------------------------------------------------------------------------------------------------------------------

string	Template::expandTemplateFile(const string &filename)
{
	// Open the file

	ifstream        stream(string(filename).c_str(), ios::in);
	if (!stream) return " ";

	// Read & parse each line in the file

	for(;;)
	{
		// A line of text...

		string	line;

		// Read the line

		getline(stream, line);
		if (stream.bad() || stream.fail()) break;

		// Blank?

		if (!line.length())
		{
			_lcache += "";
			continue;
		}

		// We'll parse it into this string

		string	outputLine;

		// Keep parsing macros from this line until it's empty

		while (line.length())
		{
			// Find the macro brace (if any)

			string::size_type idx = line.find("[");
			if (idx == string::npos)
			{
				outputLine += line;
				break;
			}
                        else if (idx > 0 && line[idx-1] == '\\')
                        {
                                outputLine += line.substr(0, idx-1);
                                outputLine += "[";
                                line.erase(0, idx+1);
                                continue;
                        }

			// Erase the beginning brace

			outputLine += line.substr(0, idx);
			line.erase(0, idx + 1);

			// Find the terminating brace

			idx = line.find("]");
			if (idx == string::npos)
			{
				return "Tag is not properly terminated (missing ']'): " + line.substr(0, 10);
			}

			// Get the macro name

			string	macro(line.substr(0, idx));
			line.erase(0, idx + 1);

			// Comment?

			if (macro.length() > 8 && macro.substr(0, 8) == "comment:") continue;

			// Is this an include macro?

			if (macro.length() > 8 && macro.substr(0, 8) == "include:")
			{
				macro.erase(0, 8);
				string	err = expandTemplateFile(macro);
				if (err.length()) return err;
				continue;
			}

			// Is this an upper- or lower-cased string?

			bool	upperFlag = false;
			bool	lowerFlag = false;

			if (macro.length() > 6 && macro.substr(0, 6) == "upper:")
			{
				macro.erase(0, 6);
				upperFlag = true;
			}
			else if (macro.length() > 6 && macro.substr(0, 6) == "lower:")
			{
				macro.erase(0, 6);
				lowerFlag = true;
			}

			// Is this a bubbletext macro?

			int	bubbleLine = -1;
			if (macro.length() > 6 && macro.substr(0, 6) == "bubble")
			{
				macro.erase(0, 6);
				bubbleLine = macro[0] - '0';
				macro.erase(0, 2);
			}

			// Is there an expansion for this macro?

			string	expansion;

			if (exist(macro))
			{
				expansion = _data[macro];
			}
			else
			{
				expansion = macro;
			}

			// Should we upper-case it?

			if (upperFlag)
			{
				for (unsigned int i = 0; i < expansion.length(); i++)
				{
					expansion[i] = toupper(expansion[i]);
				}
			}

			// Should we lower-case it?

			if (lowerFlag)
			{
				for (unsigned int i = 0; i < expansion.length(); i++)
				{
					expansion[i] = tolower(expansion[i]);
				}
			}

			// Should we bubble it?

			if (bubbleLine >= 0)
			{
				StringList	bubble = buildBubbleString(expansion.c_str(), _kerning);
				StringList::iterator it = bubble.begin();
				for (int i = 0; i < bubbleLine-1; i++, ++it);
				expansion = *it;
			}

			// Add the expansion to the line

			outputLine += expansion;
		}

		_lcache += outputLine;
	}

	return "";
}

// --------------------------------------------------------------------------------------------------------------------------------
// template.cpp - End of file
// --------------------------------------------------------------------------------------------------------------------------------


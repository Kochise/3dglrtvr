// ---------------------------------------------------------------------------------------------------------------------------------
//  _     _ _                                              
// | |   | (_)                                             
// | |   | |_  _____      __ ___ _ __      ___ _ __  _ __  
//  \ \ / /| |/ _ \ \ /\ / // _ \ '__|    / __| '_ \| '_ \ 
//   \ V / | |  __/\ V  V /|  __/ |    _ | (__| |_) | |_) |
//    \_/  |_|\___| \_/\_/  \___|_|   (_) \___| .__/| .__/ 
//                                            | |   | |    
//                                            |_|   |_|    
//
// Best viewed with 8-character tabs and (at least) 132 columns
//
// ---------------------------------------------------------------------------------------------------------------------------------
//
// Restrictions & freedoms pertaining to usage and redistribution of this software:
//
//  * This software is 100% free
//  * If you use this software (in part or in whole) you must credit the author.
//  * This software may not be re-distributed (in part or in whole) in a modified
//    form without clear documentation on how to obtain a copy of the original work.
//  * You may not use this software to directly or indirectly cause harm to others.
//  * This software is provided as-is and without warrantee. Use at your own risk.
//
// For more information, visit HTTP://www.FluidStudios.com
//
// ---------------------------------------------------------------------------------------------------------------------------------
// Originally created on 12/22/2000 by Paul Nettle
//
// Copyright 2000, Fluid Studios, Inc., all rights reserved.
// ---------------------------------------------------------------------------------------------------------------------------------

#include "stdafx.h"

// ---------------------------------------------------------------------------------------------------------------------------------

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// ---------------------------------------------------------------------------------------------------------------------------------

CViewerApp theApp;

// ---------------------------------------------------------------------------------------------------------------------------------

BEGIN_MESSAGE_MAP(CViewerApp, CWinApp)
	//{{AFX_MSG_MAP(CViewerApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

// ---------------------------------------------------------------------------------------------------------------------------------

	CViewerApp::CViewerApp()
{
}

// ---------------------------------------------------------------------------------------------------------------------------------

BOOL	CViewerApp::InitInstance()
{
	Enable3dControlsStatic();
	CViewerDlg dlg;
	dlg.DoModal();
	return FALSE;
}

// ---------------------------------------------------------------------------------------------------------------------------------
// Viewer.cpp - End of file
// ---------------------------------------------------------------------------------------------------------------------------------

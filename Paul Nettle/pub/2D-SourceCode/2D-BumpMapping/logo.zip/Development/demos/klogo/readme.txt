
		       Silly little logo program

----------------------------------------------------------------------------
USAGE:
----------------------------------------------------------------------------

	Logo [BitDepth]

	[BitDepth] - Causes the program to locate the closest bit-depth to
	given value (the resulting mode may be more or less colors if an
	exact match cannot be made).


----------------------------------------------------------------------------
REQUIRES:
----------------------------------------------------------------------------

	This program requires VESA 2.0 with an available resolution of
	320x400.  To achieve this mode (since many cards are incapable of
	displaying this mode natively), you may need Scitech Display Doctor
	(SDD).

	SDD (previously known as UniVBE) can be found at:

		HTTP://www.scitechsoft.com

	This program will work with 15, 16, 24 or 32 bit depths.  My card (an
	ATI Mach64) is not capable of 32-bit modes, yet SDD does make them
	available.  However, they do not display color, they are the
	monocrome equivalents.  So for my card, I must specify the closest
	mode as 24.

	So, if you do not see color, try different bit depths.

----------------------------------------------------------------------------
BUGS:
----------------------------------------------------------------------------

	Please e-mail pauln@terminalreality.com if you find there are any bugs
	while trying to use this program.

	Before you e-mail me, please look for a file called KAGE.LOG in the
	current directory.  If you find one, copy the contents in the e-mail.


	Thanks!

	Paul Nettle (aka MidNight / Simplicity)
	Terminal Reality Inc.

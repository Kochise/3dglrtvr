// ----------------------------------------------------------------------------
// -
// -	Copyright (c) 1996 Paul D. Nettle.  All Rights Reserved.
// -
// -	[LOGO.CPP] - Cool 3D view of a bumpy 2D surface.
// -
// -	Revision History
// -
// -	09/02/96 PDN Initial version
// -
// ----------------------------------------------------------------------------

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !
// !	This source makes use of an external library.  So without it, it won't
// !	compile.
// !
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <stddef.h>
#include <string.h>
#include <limits.h>
#include <conio.h>

#include "kagemain.h"

// ----------------------------------------------------------------------------

#define	WIDTH		320
#define	HEIGHT		400
#define	PHONG_SIZE	256
#define	PIX_RANGE	256.0
#define	PIX_MAX		255.0
#define	I_SIZE		(HEIGHT * WIDTH)

// ----------------------------------------------------------------------------

cInit	init;

cVScreen	*vsImage;
unsigned char	*fbImage;

cVScreen	*vsMono;
unsigned char	*fbMono;

cVScreen	*vsBump;
unsigned short	*fbBump;

cVScreen	*vsOutput;
unsigned char	*fbOutput;

// ----------------------------------------------------------------------------

void	loadImage( char *name, unsigned char *buffer )
{
	FILE	*fp = fopen( name, "rb" );

	if (!fp) fatalError( "Unable to open image file" );

	fread( buffer, 1, 4, fp );
	fread( buffer, 3, I_SIZE, fp );

	fclose( fp );
}

// ----------------------------------------------------------------------------

void	makeMono( cVScreen *vscreen )
{
	int		width  = vscreen->getWidth();
	int		height = vscreen->getHeight();
	unsigned char	*in  = *vscreen->getFrameBuffer();
	unsigned char	*out = *vscreen->getFrameBuffer();

	for( int i = 0; i < width * height; i++ )
	{
		unsigned char	r = *(in++);
		unsigned char	g = *(in++);
		unsigned char	b = *(in++);
		*(out++) = MAX(r, MAX(g, b));
	}
}

// ----------------------------------------------------------------------------

void	makeRange( cVScreen *vscreen, int divisor, int adder )
{
	int		width  = vscreen->getWidth();
	int		height = vscreen->getHeight();
	unsigned char	*in  = *vscreen->getFrameBuffer();
	unsigned char	*out = *vscreen->getFrameBuffer();

	for( int i = 0; i < width * height; i++ )
	{
		unsigned char	b = *(in++);
		unsigned char	g = *(in++);
		unsigned char	r = *(in++);

		*(out++) = (unsigned char) (r / divisor + adder);
		*(out++) = (unsigned char) (g / divisor + adder);
		*(out++) = (unsigned char) (b / divisor + adder);
	}
}

// ----------------------------------------------------------------------------

void	makeBumpy( cVScreen *vsBump, cVScreen *vsMono )
{
	int		width  = vsBump->getWidth();
	int		height = vsBump->getHeight();
	unsigned char	*in  = *vsMono->getFrameBuffer();
	unsigned short	*out = (unsigned short *) *vsBump->getFrameBuffer();
	float		piRange = PI / 2;
	float		range = 32768.0;

	memset( out, range, height * width * 2 );

	// Need to do this for 24-bit RGB

	float	fdx = PI / (width);
	float	fdy = PI / (height);

	float	fy = -PI/2;
	for (int y = 0; y < height - 1; y++ )
	{
		fy += fdy;

		float	fx = -PI/2;
		for (int x = 0; x < width - 1; x++ )
		{
			fx += fdx;

			int	curPix   = in[(y+0) * width + (x+0)]; 
			int	nextXPix = in[(y+0) * width + (x+1)];
			int	nextYPix = in[(y+1) * width + (x+0)];

         		float	xDiff    = (curPix - nextXPix) / PIX_RANGE;
         		float	yDiff    = (curPix - nextYPix) / PIX_RANGE;

			// Correct for angles

			xDiff = sin(xDiff * piRange) * range + range;
			yDiff = sin(yDiff * piRange) * range + range;

			xDiff += sin(fx) * 25000.0;
			yDiff += sin(fy) * 25000.0;

			if (xDiff > 65535.0) xDiff = 65535.0;
			if (xDiff <     0.0) xDiff =     0.0;
			if (yDiff > 65535.0) yDiff = 65535.0;
			if (yDiff <     0.0) yDiff =     0.0;

			// Store the differences

			*(out++) = (unsigned short) xDiff;
			*(out++) = (unsigned short) yDiff;
		}

		out += 2;
	}
}

// ----------------------------------------------------------------------------

void	makePhong( char *phongTable, float Ka, float Kd, float Ks )
{
	float	delta = 1.0 / (PHONG_SIZE / 2.0);
	float	intensity;

	float	curY = -1.0;
	for( int y = 0; y < PHONG_SIZE; curY += delta, y++ )
	{
		float	curX = -1.0;
		for (int x = 0; x < PHONG_SIZE; curX += delta, x++)
		{
			float val = 1.0 - (curX*curX + curY*curY);

			if (val > 0.0)
			{
				intensity  = Ka;
				intensity += val * Kd;
				intensity += pow(val, Ks);
				intensity *= PIX_RANGE;
				if (intensity > PIX_MAX) intensity = PIX_MAX;
			}
			else
			{
				intensity = 0;
			}

			phongTable[y * PHONG_SIZE + x] = (char) intensity;
		}
	}
}

// ----------------------------------------------------------------------------

void	main( int argc, char *argv[] )
{
	// Let the user specify a closest match mode

	unsigned char	tryDepth = 32;

	if (argc > 1) tryDepth = (unsigned char) atoi(argv[1]);

	// Load the image and put it into range

	vsImage = new cVScreen( WIDTH, HEIGHT, 24 );
	if (!vsImage) fatalError( "Unable to allocate frame buffer RAM" );
	fbImage = *vsImage->getFrameBuffer();
	loadImage( "back.ipi", fbImage );
	makeRange( vsImage, 2, 0 );

	// Load the bump map image into a local buffer mono-chrome buffer

	vsMono = new cVScreen( WIDTH, HEIGHT, 24 );
	if (!vsMono) fatalError( "Unable to allocate frame buffer RAM" );
	fbMono = *vsMono->getFrameBuffer();
	loadImage( "bump.ipi", fbMono );
	makeMono( vsMono );

	// Make it bumpy (stored into a 2-byte buffer)

	vsBump = new cVScreen( WIDTH, HEIGHT, 32 );
	if (!vsBump) fatalError( "Unable to allocate frame buffer RAM" );
	fbBump = (unsigned short *) *vsBump->getFrameBuffer();
	makeBumpy( vsBump, vsMono );

	// Find the closest available mode

	cDisplay *display = new cDisplay;
	modeInfoStruct *mi = display->findClosestMode(WIDTH, HEIGHT, tryDepth);

	if (mi->width != WIDTH && mi->height != HEIGHT)
		fatalError( "Unable to locate a 320x400 mode" );

	unsigned char	bitDepth = mi->bitDepth;

	// Setup our output buffer (we build our displayed image into this)

	vsOutput = new cVScreen( WIDTH, HEIGHT, bitDepth );
	if (!vsOutput) fatalError( "Unable to allocate frame buffer RAM" );
	fbOutput = *vsOutput->getFrameBuffer();

	// Make the phong table

	char	*phongTable = new char[PHONG_SIZE*PHONG_SIZE];
	if (!phongTable) fatalError( "Unable to allocate phong table RAM" );
	makePhong( phongTable, 0.0, 0.5, 250.0 );

	// Setup the graphics using KAGE's stuffs...

	display->setGraphicsMode(mi->modeNumber);

	// Make a saturation table

	unsigned char	*saturationTable = new unsigned char[256*3];
	unsigned char	*satTable = &saturationTable[256];

	memset( saturationTable, 255, 256*3 );

	for( int i = 0; i < 256; i++ )  satTable[i] = (unsigned char) i;

	// Now animate our effect

	float	xtheta = 0.0, ytheta = 0.0, r = 15000;

	while(!kbhit())
	{
		// This offset moves our "light" around

		int	xOff = (int) (r * cos(xtheta));
		int	yOff = (int) (r * sin(ytheta));

		xtheta += 0.08;
		ytheta += 0.16;

		unsigned short	*bmp = fbBump;
		unsigned char	*out = fbOutput;
		unsigned char	*img = fbImage;
		int		i;

		switch(bitDepth)
		{
		    	case 15:
			for( i = 0; i < I_SIZE; i++ )
			{
				int xBump = satTable[(*(bmp++) + xOff) >> 8];
				int yBump = satTable[(*(bmp++) + yOff) >> 8] << 8;
				int bump  = phongTable[yBump + xBump];
				int  r = satTable[*(img++) + bump];
				int  g = satTable[*(img++)];
				int  b = satTable[*(img++)];
				int color = ((r&0xf8)>>3)|((g&0xf8)<<2)|((b&0xf8)<<8);
				*(out++) = (unsigned char) (color & 0xff);
				*(out++) = (unsigned char) (color >> 8);
			}
			break;

		    	case 16:
			for( i = 0; i < I_SIZE; i++ )
			{
				int xBump = satTable[(*(bmp++) + xOff) >> 8];
				int yBump = satTable[(*(bmp++) + yOff) >> 8] << 8;
				int bump  = phongTable[yBump + xBump];
				int  r = satTable[*(img++) + bump];
				int  g = satTable[*(img++)];
				int  b = satTable[*(img++)];
				int color = ((r&0xf8)>>3)|((g&0xfc)<<3)|((b&0xf8)<<8);
				*(out++) = (unsigned char) (color & 0xff);
				*(out++) = (unsigned char) (color >> 8);
			}
			break;

		    	case 24:
			for( i = 0; i < I_SIZE; i++ )
			{
				int xBump = satTable[(*(bmp++) + xOff) >> 8];
				int yBump = satTable[(*(bmp++) + yOff) >> 8] << 8;
				int bump  = phongTable[yBump + xBump];
				*(out++) = satTable[*(img++) + bump];
				*(out++) = satTable[*(img++)];
				*(out++) = satTable[*(img++)];
			}
			break;

		    	case 32:
			for( i = 0; i < I_SIZE; i++ )
			{
				int xBump = satTable[(*(bmp++) + xOff) >> 8];
				int yBump = satTable[(*(bmp++) + yOff) >> 8] << 8;
				int bump  = phongTable[yBump + xBump];
				*(out++) = satTable[*(img++) + bump];
				*(out++) = satTable[*(img++)];
				*(out++) = satTable[*(img++)];
				out++;
			}
			break;

			default:
			fatalError( "invalid bit depth" );
			break;
		}

		display->copyToDisplay( (char *) fbOutput );
	}

	// Cleanup

	if (!getch()) getch();

	display->setTextMode();

	delete	display;
	delete	vsOutput;
	delete	vsImage;
	delete	vsBump;
	delete	vsMono;
	delete	phongTable;
	delete	saturationTable;

	return;
}

// ----------------------------------------------------------------------------
// -	[LOGO.CPP] - End Of File
// ----------------------------------------------------------------------------

This zip contains my personal collection of pentium optimisation docs that
i have found on the internet. Special thanks goes to HeadSoft, about half
of the docs in here come from his collection ;)

Please note that all the docs included in this zip ASSUME that you already know
how to program in assembly language, they are quite advanced! This is definately 
_NOT_ a "how to code in ASM" tute *8)

<stupid legal crap> 
i did NOT write any of the docs here, i just found 'em and think that
making them available in one nice zip is a cool idea :)
</stupid legal crap>


cya!
--
Gaffer/PRoMETHEUS
email: gaffer@ar.com.au
homepage: http://www.ar.com.au/~gaffer

PS: if you have any good p5 docs that arent in here, let me know! :)
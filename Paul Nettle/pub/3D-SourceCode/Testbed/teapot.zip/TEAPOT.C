/****************************************************************************
                  INTERNATIONAL AVS CENTER
	(This disclaimer must remain at the top of all files)

WARRANTY DISCLAIMER

This module and the files associated with it are distributed free of charge.
It is placed in the public domain and permission is granted for anyone to use,
duplicate, modify, and redistribute it unless otherwise noted.  Some modules
may be copyrighted.  You agree to abide by the conditions also included in
the AVS Licensing Agreement, version 1.0, located in the main module
directory located at the International AVS Center ftp site and to include
the AVS Licensing Agreement when you distribute any files downloaded from 
that site.

The International AVS Center, MCNC, the AVS Consortium and the individual
submitting the module and files associated with said module provide absolutely
NO WARRANTY OF ANY KIND with respect to this software.  The entire risk as to
the quality and performance of this software is with the user.  IN NO EVENT
WILL The International AVS Center, MCNC, the AVS Consortium and the individual
submitting the module and files associated with said module BE LIABLE TO
ANYONE FOR ANY DAMAGES ARISING FROM THE USE OF THIS SOFTWARE, INCLUDING,
WITHOUT LIMITATION, DAMAGES RESULTING FROM LOST DATA OR LOST PROFITS, OR ANY
SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES.

This AVS module and associated files are public domain software unless
otherwise noted.  Permission is hereby granted to do whatever you like with
it, subject to the conditions that may exist in copyrighted materials. Should
you wish to make a contribution toward the improvement, modification, or
general performance of this module, please send us your comments:  why you
liked or disliked it, how you use it, and most important, how it helps your
work. We will receive your comments at avs@ncsc.org.

Please send AVS module bug reports to avs@ncsc.org.

AUTHOR : Stardent Computer, Inc.
******************************************************************************/
/*
 * Teapot Generator - David Kamins, Stardent Computers
 */

#include <stdio.h>

#include <avs/avs_math.h>

#include "teapot.h"
#include <avs/flow.h>
#include <avs/field.h>
#include <avs/geomdata.h>

#define MAX_RES 16

int NPatches[] = {
    0,
    4,
    12,
    16,
    20,
    28
};

#define CROSS(a,b,c) (*(c)     = a[1]*b[2]-a[2]*b[1],\
		      *((c)+1) = a[2]*b[0]-a[0]*b[2],\
		      *((c)+2) = a[0]*b[1]-a[1]*b[0])

static float	u_partial[MAX_RES][MAX_RES][3], v_partial[MAX_RES][MAX_RES][3];
static float	c0[MAX_RES][3], c1[MAX_RES][3], c2[MAX_RES][3], c3[MAX_RES][3];
static float	d0[MAX_RES][3], d1[MAX_RES][3], d2[MAX_RES][3], d3[MAX_RES][3];

static float	p0[MAX_RES], p1[MAX_RES], p2[MAX_RES], p3[MAX_RES];
static float	del_p0[MAX_RES], del_p1[MAX_RES], del_p2[MAX_RES], del_p3[MAX_RES];

static float 
  Points[MAX_RES * MAX_RES][3],
  Normals[MAX_RES * MAX_RES][3];

static char *PartName[] = {
    "TEAPOTrim",
    "TEAPOTbody",
    "TEAPOThandle",
    "TEAPOTspout",
    "TEAPOTlid",
    "TEAPOTbottom"
};

/******************************************************************************/
/*
 * initialization for modules contained in this file.
 */
/******************************************************************************/
int teapot_desc();

static int ((*teapot_mod_list[])()) = {
	teapot_desc,
};

#define NMODS sizeof(teapot_mod_list) / sizeof(char *) 

AVSinit_modules()
{
	AVSinit_from_module_list(teapot_mod_list, NMODS);
}

/******************************************************************************/
 static
teapot_desc()
{
   int teapot_compute();

   AVScreate_output_port("geometry", "geom", REQUIRED);

   AVSset_module_name("teapot", MODULE_DATA);

   AVSadd_float_parameter("Offset", 0.0, -1.0, 1.0);
   AVSadd_float_parameter("Twist",  0.0, -1.0, 1.0);
   AVSadd_parameter("Mesh Res", "integer", 8, 2, MAX_RES);
   AVSadd_parameter("Axis", "choice", "Z_twist", "X_twist Y_twist Z_twist", " " );

   AVSset_compute_proc(teapot_compute);
}

/******************************************************************************/ 
 static
teapot_compute(output, in_offset, in_twist, n, axistr)
    GEOMedit_list **output;
    float *in_offset, *in_twist;
    char *axistr;
    int n;
{ 
    GEOMobj *obj;
    int	i, j, k, patch_number, npts, axis;
    float patch[4][4][3], offset, inv_offset;
    float *normals;
    char name[128];

    /********************************/
    /* Set incoming parameters      */
    /********************************/
    if (*axistr == 'X') axis = 0;
    else if (*axistr == 'Y') axis = 1;
    else if (*axistr == 'Z') axis = 2;
    offset = *in_offset;
    inv_offset = (1.0 - offset);
    init_params(n);
    
    /********************************/
    /* Start Edit List              */
    /********************************/
    *output = (GEOMedit_list *)GEOMinit_edit_list(*output);

    for(patch_number = 0; patch_number < NUM_PATCHES; ++patch_number) {
	/********************************/
	/* Tesselate                    */
	/********************************/
      	for(i = 0; i < 4; ++i) {
	    for(j = 0; j < 4; ++j) { 
		int vind = vertex_index[patch_number][i][j]-1;
		int rj = 3 - j;
		patch[i][rj][0] =  vertex[vind][0] / 2.0;
		patch[i][rj][1] =  vertex[vind][1] / 2.0;
		patch[i][rj][2] =  (vertex[vind][2] - 2.0) / 2.0;
	    }
	}
	tesselate_patch(n, patch);

	/********************************/
	/* Offset                       */
	/********************************/
	if (offset != 0.0) {
	    for (i = 0; i < n*n; ++i) 
	      for (j = 0; j < 3; ++j) 
		Points[i][j] = Points[i][j] * inv_offset + offset * Normals[i][j];
	}
	    
	/********************************/
	/* Rotate                       */
	/********************************/
	if (*in_twist != 0.0)
	  rotate(n, axis, in_twist);

	/********************************/
	/* Build Object                 */
	/********************************/
	if (offset == 0.0 && *in_twist == 0.0) normals = (float *)Normals;
	else normals = NULL;
	obj = 
	  GEOMcreate_mesh_with_data(NULL,             /* extent */
				    Points,           /* verts */
				    normals,          /* normals */
				    NULL,             /* colors */
				    n, n,             /* dimen */
				    GEOM_COPY_DATA);  /* god */ 

	if (offset != 0.0 || *in_twist != 0.0)
	  GEOMgen_normals(obj, 0);
	
	GEOMcvt_mesh_to_polytri(obj, GEOM_SURFACE | GEOM_WIREFRAME);
	for (i = 0; i < 6; ++i) {
	    if (patch_number == NPatches[i]) 
	      sprintf(name, "%s", PartName[i]);
	}
	GEOMedit_geometry(*output, name, obj);
	GEOMdestroy_obj(obj);
    }
}

/******************************************************************************/
 static
rotate(n, axis, in_twist)
    int n, axis;
    float *in_twist;
{
    int i;
    float twist, inv_twist, x, y, z, nx, ny, nz;
    
    twist = *in_twist;
    inv_twist = 1.0 - twist;

    switch (axis) {
      case 0:
	for (i = 0; i < n*n; ++i) {
	    x = Points[i][0];
	    y = Points[i][1];
	    z = Points[i][2];

	    ny =  (y *  cos(x)) + (z * sin(x));
	    nz =  (y * -sin(x)) + (z * cos(x));
	    
	    Points[i][0] = x;
	    Points[i][1] = y * inv_twist + twist * ny;
	    Points[i][2] = z * inv_twist + twist * nz;
	}
	break;
      case 1:
	for (i = 0; i < n*n; ++i) {
	    x = Points[i][0];
	    y = Points[i][1];
	    z = Points[i][2];

	    nx =  (x *  cos(y)) + (z * sin(y));
	    nz =  (x * -sin(y)) + (z * cos(y));
	    
	    Points[i][0] = x * inv_twist + twist * nx;
	    Points[i][1] = y;
	    Points[i][2] = z * inv_twist + twist * nz;
	}
	break;
      case 2:
	for (i = 0; i < n*n; ++i) {
	    x = Points[i][0];
	    y = Points[i][1];
	    z = Points[i][2];
	    
	    nx =  (x *  cos(z)) + (y * sin(z));
	    ny =  (x * -sin(z)) + (y * cos(z));
	    
	    Points[i][0] = x * inv_twist + twist * nx;
	    Points[i][1] = y * inv_twist + twist * ny;
	    Points[i][2] = z;
	}
	break;
    }
}
	
/******************************************************************************/
 static
init_params(n)
    int	n;
{ 
    float t, t_step;
    int	i;

    /* p0-p3 are the bezier knots.  del_p0-del_p3 are the knots for the first partials */
    t_step = 1.0 / (float)(n-1);
    for(i=0;i<n;++i) {
    	t = (float)i*t_step;
	p0[i] = t*t*t;
	p1[i] = 3.0*t*t*(1.0-t);
	p2[i] = 3.0*t*(1.0-t)*(1.0-t);
	p3[i] = (1.0-t)*(1.0-t)*(1.0-t);
	
	del_p0[i] = 3.0*t*t;
	del_p1[i] = 6.0*t - 9.0*t*t;
	del_p2[i] = 3.0 - 12.0*t + 9.0*t*t;
	del_p3[i] = -3.0 + 6.0*t - 3.0*t*t;
    }
}

/******************************************************************************/
 static
tesselate_patch(n, control_points)
    int	n;
    float  control_points[4][4][3];
{ 
    int i, j, k;
    
    for(i=0;i<n;++i) {
    	for(j=0;j<3;++j) {
	    c0[i][j] = p0[i]*control_points[0][0][j]
	      + p1[i]*control_points[0][1][j]
		+ p2[i]*control_points[0][2][j]
		  + p3[i]*control_points[0][3][j];
	    c1[i][j] = p0[i]*control_points[1][0][j]
	      + p1[i]*control_points[1][1][j]
		+ p2[i]*control_points[1][2][j]
		  + p3[i]*control_points[1][3][j];
	    c2[i][j] = p0[i]*control_points[2][0][j]
	      + p1[i]*control_points[2][1][j]
		+ p2[i]*control_points[2][2][j]
		  + p3[i]*control_points[2][3][j];
	    c3[i][j] = p0[i]*control_points[3][0][j]
	      + p1[i]*control_points[3][1][j]
		+ p2[i]*control_points[3][2][j]
		  + p3[i]*control_points[3][3][j];
	    
	    d0[i][j] = p0[i]*control_points[0][0][j]
	      + p1[i]*control_points[1][0][j]
		+ p2[i]*control_points[2][0][j]
		  + p3[i]*control_points[3][0][j];
	    d1[i][j] = p0[i]*control_points[0][1][j]
	      + p1[i]*control_points[1][1][j]
		+ p2[i]*control_points[2][1][j]
		  + p3[i]*control_points[3][1][j];
	    d2[i][j] = p0[i]*control_points[0][2][j]
	      + p1[i]*control_points[1][2][j]
		+ p2[i]*control_points[2][2][j]
		  + p3[i]*control_points[3][2][j];
	    d3[i][j] = p0[i]*control_points[0][3][j]
	      + p1[i]*control_points[1][3][j]
		+ p2[i]*control_points[2][3][j]
		  + p3[i]*control_points[3][3][j];
	}
    }
 
    /* Compute the points, and the first partials */
    for(i=0;i<n;++i) {
	for(j=0;j<n;++j) {
	    for(k=0;k<3;++k) { 
		Points[i*n+j][k] = c0[i][k]*p0[j]
		  + c1[i][k]*p1[j]
		    + c2[i][k]*p2[j]
		      + c3[i][k]*p3[j];
		u_partial[i][j][k]  = -(c0[i][k]*del_p0[j]
		  + c1[i][k]*del_p1[j]
		    + c2[i][k]*del_p2[j]
		      + c3[i][k]*del_p3[j]);
		v_partial[i][j][k]  = d0[j][k]*del_p0[i]
		  + d1[j][k]*del_p1[i]
		    + d2[j][k]*del_p2[i]
		      + d3[j][k]*del_p3[i];
	    }
	}
    }
  
    /* Now get the surface normals by crossing the two first partials */
    for(i=0;i<n;++i) {
	for(j=0;j<n;++j) {
	    CROSS(v_partial[i][j],u_partial[i][j],Normals[i*n+j]);
	    /* If the normal was degenerate, take one from a nearby mesh point */
	    if(!normalize(Normals[i*n+j])) {
		if(i==0) {
		    if(j==0)
		      CROSS(v_partial[i+1][j+1],u_partial[i+1][j+1],Normals[i*n+j]);
		    else
		      CROSS(v_partial[i+1][j-1],u_partial[i+1][j-1],Normals[i*n+j]);
		}
		else {
		    if(j==0)
		      CROSS(v_partial[i-1][j+1],u_partial[i-1][j+1],Normals[i*n+j]);
		    else
		      CROSS(v_partial[i-1][j-1],u_partial[i-1][j-1],Normals[i*n+j]);
		}
		normalize(Normals[i*n+j]);
	    }
	}
    }
}

#define EPSILON 1.0e-6
/******************************************************************************/
 static int
normalize(a)
    float *a;
{ 
    float tmp;
  
    tmp = *(a) * *(a) + *(a+1) * *(a+1) + *(a+2) * *(a+2);
    
    tmp = sqrt(tmp);
    
    /* If degenerate, return error so surface tessalator can fix it */
    if(tmp < EPSILON)
      return 0;
    
    *a     /= tmp;
    *(a+1) /= tmp;
    *(a+2) /= tmp;
    
    return 1;
}


/*
	File:			SubMat.cc

	Function:		Implements SubMat.h

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

*/


#include "SubMat.h"
#include "Mat.h"
#include "Copy.h"


// --- SubMat Constructors & Destructors ---------------------------------------


TSubMat::TSubMat(Int m, Int n, Int span, TMReal data[]) :
		rows(m), cols(n),
		span(span), data(data)
{
}

TSubMat::TSubMat(const TSubMat &m) :
		rows(m.rows), cols(m.cols),
		span(m.span), data(m.data)
{
}


// --- SubMat Assignment Operators ---------------------------------------------


TSubMat &TSubMat::operator = (const TSubMat &m)
{	
    return(CopyMat(SELF, m));
}
	  
TSubMat &TSubMat::operator = (const TMat &m)
{
    return(CopyMat(SELF, m));
}


// --- Submatrix functions --------------------------------------------------


TSubMat sub(const TMat &m, Int top, Int left, Int height, Int width)
{
	Assert(left >= 0 && width > 0 && left + width <= m.Cols(), "(sub(Mat)) illegal subset of matrix");
	Assert(top >= 0 && height > 0 && top + height <= m.Rows(), "(sub(Mat)) illegal subset of matrix");

	TSubMat result(height, width, m.Cols(), m.Ref() + top * m.Cols() + left);

	return(result);
}

TSubMat sub(const TMat &m, Int nrows, Int ncols)
{
	Assert(ncols > 0 && nrows > 0 && nrows <= m.Rows() && ncols <= m.Cols(), 
		"(sub(Mat)) illegal subset of matrix");

	TSubMat result(nrows, ncols, m.Cols(), m.Ref());

	return(result);
}

TMSubVec col(const TMat &m, Int i)
{
	CheckRange(i, 0, m.Cols(), "(col(Mat)) illegal column index");

	return(TMSubVec(m.Rows(), m.Ref() + i, m.Cols()));
}

TMSubVec diag(const TMat &m, Int diagNum)
{
	if (diagNum == 0)
		return(TMSubVec(Min(m.Rows(), m.Cols()), m.Ref(), m.Cols() + 1));
	else if (diagNum < 0)
		return(TMSubVec(Min(m.Rows() + diagNum, m.Cols()), m.Ref() - diagNum 
			* m.Cols(), m.Cols() + 1));
	else
		return(TMSubVec(Min(m.Cols() - diagNum, m.Rows()), m.Ref() + diagNum,
			m.Cols() + 1));
}



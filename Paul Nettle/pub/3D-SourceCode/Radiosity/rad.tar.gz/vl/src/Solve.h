/*
	File:			Solve.h

	Function:		Contains routines for:
						solving a system of linear equations (Ax = b) using overrelaxation
						solving a system of linear equations using conjugate-gradient method
					for both normal and sparse matrices.

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Solve__
#define __Solve__

TMReal SolveOverRelax(const TMat &A, TVec &x, const TVec &b,
			TMReal epsilon, TMReal omega = 1.0, Int *steps = 0);
TMReal SolveOverRelax(const TSparseMat &A, TVec &x, const TVec &b, 
			TMReal epsilon, TMReal omega = 1.0, Int *steps = 0);

TMReal SolveConjGrad(const TMat &A, TVec &x, const TVec &b,
			TMReal epsilon, Int *steps = 0); 
TMReal SolveConjGrad(const TSparseMat &A, TVec &x, const TVec &b,
			TMReal epsilon, Int *steps = 0);

#endif


// Include headers | templates

#define VL_V_REAL Double
#define VL_V_SUFF(X) X ## s
#define VL_M_REAL Double
#define VL_M_SUFF(X) X ## s

#include "Vec2.cc"
#include "Vec3.cc"
#include "Vec4.cc"
#include "Vec.cc"
#include "SparseVec.cc"
#include "SubVec.cc"
#include "SubSVec.cc"

#include "Mat2.cc"
#include "Mat3.cc"
#include "Mat4.cc"
#include "Mat.cc"
#include "SparseMat.cc"
#include "Solve.cc"

#include "SubMat.cc"
#include "SubSMat.cc"

#include "VLUndef.h"
#define VL_V_REAL Float
#define VL_V_SUFF(X) X ## r
#define VL_M_REAL Double
#define VL_M_SUFF(X) X ## s

#include "Vec2.cc"
#include "Vec3.cc"
#include "Vec4.cc"
#include "Vec.cc"
#include "SparseVec.cc"
#include "SubVec.cc"
#include "SubSVec.cc"
#include "Mixed.cc"
#include "Solve.cc"


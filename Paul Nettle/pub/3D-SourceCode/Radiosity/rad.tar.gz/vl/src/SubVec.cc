/*
	File:			SubVec.cc

	Function:		Implements SubVec.h

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

*/


#include "SubVec.h"
#include "Vec.h"
#include "Copy.h"


// --- Vector Memory Management -----------------------------------------------


TSubVec::TSubVec(Int n, TVReal data[], Int span) : elts(n), span(span), data(data)
{
}

TSubVec::TSubVec(const TSubVec &v) : elts(v.elts), span(v.span), data(v.data)
{
}

TSubVec &TSubVec::operator = (const TSubVec &v)
{
	return(CopyVec((SELF), v));
}

TSubVec &TSubVec::operator = (const TVec &v)
{
	return(CopyVec((SELF), v));
}


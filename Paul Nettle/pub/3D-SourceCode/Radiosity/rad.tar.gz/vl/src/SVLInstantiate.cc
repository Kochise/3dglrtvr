/*
	File:		SVLInstantiate.cc
	
	Purpose:	(Attempt to) instantiate templates used by functions in the
				SVL library.
	
	Author:		Andrew Willmott
*/

#include "VLConfig.h"
#include "Basics.h"
#include "Array.h"

// instantiate float/double array, if possible.

#ifdef VL_FLOAT
typedef Float _Blat;
#else
typedef Double _Blat;
#endif

#ifdef VL_SGI_INST
// Way to go SGI! You bastards.
#pragma instantiate Array<_Blat>

#elif defined(VL_NO_INST_TMPL)

// compiler broken: don't bother

#else
// Ansi C++ compiler! Astounding!
template class Array<_Blat>;
// (You'd be bitter too, if you'd spent as much time
// hacking templates as I have.)

#endif

/*
	File:		LibSVL.cc
	
	Purpose:	Compiles all code necessary for SVL.h.
	
	Author:		Andrew Willmott
*/

#include "Vec2.cc"
#include "Vec3.cc"
#include "Vec4.cc"
#include "Vec.cc"
#include "SubVec.cc"

#include "Mat2.cc"
#include "Mat3.cc"
#include "Mat4.cc"
#include "Mat.cc"
#include "SubMat.cc"
#include "Transform.cc"

/*
	File:			Copy.h

	Function:		Templates for copying between different vector/matrix types.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */



#ifndef __Copy__
#define __Copy__


template<class TA, class TB> TA &CopyVec(TA &a, const TB &b)
{
	Assert(a.Elts() == b.Elts(), "(CopyVec::=) Vector sizes don't match");
	
	Int i;
	
	for (i = 0; i < a.Elts(); i++)
		a[i] = b[i];

	return(a);
}

template<class TA, class TB> TA &CopyMat(TA &m, const TB &n)
{
	Int		i, j;
	
	Assert(m.Rows() == n.Rows(), "(CopyMat::=) Matrix rows don't match");
	Assert(m.Cols() == n.Cols(), "(CopyMat::=) Matrix columns don't match");

	for (i = 0; i < m.Rows(); i++) 
		for (j = 0; j < m.Cols(); j++)
			m[i][j] = n[i][j];
		
	return(m);
}

#endif

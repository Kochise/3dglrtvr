/*
	File:			SubVec.h

	Function:		Defines a scatter-gather vector, i.e., a subvector of another vector, 
					or the row, column or diagonal of a matrix.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __SubVec__
#define __SubVec__

#include "VL.h"

class TVec;
 
class TSubVec
{
public:

					TSubVec(Int n, TVReal data[], Int span);
					TSubVec(const TSubVec &v);
	
	inline Int		Elts() const { return(elts); };

	inline TVReal	&operator [] (Int i);		    		// v[1] - Has no index 
	inline TVReal	operator [] (Int i) const;				//        check			  

	TSubVec			&operator = (const TSubVec &v);
	TSubVec			&operator = (const TVec &v);

protected:
	
	Int		elts;
	Int		span;
	TVReal	*data; 
};


// --- Inlines ---------------------------------------------------


inline TVReal &TSubVec::operator [] (Int i)
{
	CheckRange(i, 0, elts, "Vec::[i]");
	
    return(data[i * span]);
}

inline TVReal TSubVec::operator [] (Int i) const
{
	CheckRange(i, 0, elts, "Vec::[i]");

    return(data[i * span]);
}

#endif

/*
	File:			SubMat.h

	Function:		Defines a scatter-gather matrix, i.e., a submatrix of another matrix.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __SubMat__
#define __SubMat__

#include "VL.h"
#include "SubVec.h"

// --- SubMat Class ------------------------------------------------------------

class TMat;
class TVec;

class TSubMat
{
public:
	
	// Constructors
	
						TSubMat(Int m, Int n, Int span, TMReal data[]);
						TSubMat(const TSubMat &m);			
  	
	// Accessor functions
	
	Int					Rows() const { return rows; };
	Int					Cols() const { return cols; };

	inline TMVec		operator [] (Int i);
	inline const TMVec	operator [] (Int i) const;		  

	inline TMReal		&Elt(Int i, Int j);
	inline TMReal		Elt(Int i, Int j) const;

	// Assignment operators
	
	TSubMat				&operator = (const TSubMat &m);	// Assignment of a matrix
	TSubMat				&operator = (const TMat &m);	

protected:

	Int			rows;
	Int			cols;
	Int			span;
	TMReal		*data; 
};


// --- Submatrix functions --------------------------------------------------
	
TSubMat 	sub(const TMat &m, Int top, Int left, Int height, Int width);
TSubMat 	sub(const TMat &m, Int rows, Int cols);
TMSubVec	col(const TMat &m, Int i);		
TMSubVec	diag(const TMat &m, Int diagNum);
//	-i = diag. starting on row i, +i = diag. starting on col i


// --- SubMat Inlines ----------------------------------------------------------


#include "Vec.h"

inline TMVec TSubMat::operator [] (Int i)
{
	CheckRange(i, 0, Rows(), "(SubMat::(i)) index out of range");
    return(TMVec(cols, data + i * span));
}

inline const TMVec TSubMat::operator [] (Int i) const
{
	CheckRange(i, 0, Rows(), "(SubMat::(i)) index out of range");
    return(TMVec(cols, data + i * span));
}

inline TMReal &TSubMat::Elt(Int i, Int j)
{
	CheckRange(i, 0, Rows(), "(SubMat::(i,j)) i index out of range");
	CheckRange(j, 0, Cols(), "(SubMat::(i,j)) j index out of range");
    return(data[i * span + j]);
}

inline TMReal TSubMat::Elt(Int i, Int j) const
{
	CheckRange(i, 0, Rows(), "(SubMat::(i,j)) i index out of range");
	CheckRange(j, 0, Cols(), "(SubMat::(i,j)) j index out of range");
    return(data[i * span + j]);
}

#endif


/*
	File:		VLInstantiate.cc
	
	Purpose:	(Attempt to) instantiate templates used by functions in the
				VL library.
	
	Author:		Andrew Willmott
*/

#include "Basics.h"
#include "Array.h"

// Instantiate float and double arrays, if possible.
// (Unfortunately, many C++ compilers don't yet support the
// ANSI syntax for doing this. It's not a disaster if they
// don't, as, unless the compiler is really broken, it
// should automatically instantiate the templates at
// compile time.

#ifdef VL_SGI_INST
// Way to go SGI! You bastards.
#pragma instantiate Array<Float>
#pragma instantiate Array<Double>

#elif VL_NO_INST_TMPL

// compiler broken: don't bother

#else
// Ansi C++ compiler! Astounding!
template class Array<Float>;
template class Array<Double>;
// (You'd be bitter too, if you'd spent as much time
// hacking templates as I have.)

#endif

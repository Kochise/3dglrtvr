/*
	File:			VLTest.cc

	Function:		Test program for the VL class.
	
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			
*/

#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <iomanip.h>

#include "VLTest.h"
  
// --- Prototypes -------------- 

Void TestBasics();

Void Test2DStuff();
Void Test3DStuff();
Void Test4DStuff();

Void TestHStuff2D();
Void TestHStuff3D();

Void TestND();
Void TestNDSub();
Void TestNDNumerical();
	
Void TestSparse();
Void TestSparseSub();
Void TestSparseNumerical();


Void TestInit();
Void ComplexTest();	

#define TYPE_NAME(X) type_name((X*)0)
inline char *type_name(Float*) { return("Float"); };
inline char *type_name(Double*) { return("Double"); };
inline char *type_name(Int*) { return("Int"); };


int main(int, char **)
{
	cout << "Testing VL library, version " << VL_VERSION << endl;
	cout << "Real type: " << TYPE_NAME(Real) << endl;

	cout << "----------------------------------" << endl;

	Test2DStuff();
	Test3DStuff();
	Test4DStuff();

	TestHStuff2D();
	TestHStuff3D();

	TestND();
	TestNDSub();
	TestNDNumerical();

	TestSparse();
	TestNDSub();
	TestSparseSub();
	TestSparseNumerical();

//	ComplexTest();	
	TestInit();

	cout << "\n\n--- Finished! ---" << endl;

	return(0);
}


Void TestHStuff2D()
{
	Vec2r x;
	Vec3r y;
	Mat2s M;
	
	cout << "\n+ TestHStuff2D\n\n";
	
	x = Vec2r(1,2);
	cout << "x is: " << x << endl;	
	M = Rot2s(vl_halfPi);
	cout << "rot(pi/2) is: " <<  Rot2s(vl_halfPi) << endl;
	x = Rot2s(vl_halfPi) * x;
	cout << "x after rot(pi/2) is: " << x << endl;
	x = Scale2s(Vec2s(0.3, 0.2)) * x;
	cout << "x after scale(0.3, 0.2) is: " << x << endl;
	
	y = Vec3r(x, 0.5);
	cout << "y is: " << y << endl;
	x = proj(y);
	cout << "proj(y) is: " << x << endl;

	x = proj(HRot3s(1.3) * HTrans3s(Vec2s(1,1)) * HScale3s(Vec2s(1,2)) * Vec3r(x, 1));
	cout << "HRot3s(1.3) * HTrans3s(Vec2s(1,1)) * HScale3s(Vec2s(1,2)) * y = " << x << endl;
}

Void TestHStuff3D()
{
	Vec3r x;
	Vec4r y;
	Mat4s z;
	
	cout << "\n+ TestHStuff3D\n\n";
	
	x = Vec3r(1,2,3);

	cout << "rot(pi/2, vl_x) is: " <<  Rot3s(vl_x, vl_halfPi) << endl;
	x = x * Rot3s(vl_x, vl_halfPi);
	cout << "x after rot(pi/2, vl_x) is: " << x << endl;
	x = x * Scale3s(Vec3s(0.3, 0.2, 0.3));
	cout << "x after scale(0.3, 0.2, 0.3) is: " << x << endl;

	y = Vec4r(x, 0.5);
	cout << "y is: " << y << endl;
	x = proj(y);
	cout << "proj(y) is: " << x << endl;

	x = proj(HRot4s(vl_x, 1.3) * HTrans4s(vl_1) * HScale4s(Vec3s(1,2,1)) * y);
	cout << "HRot4s(vl_x, 1.3) * HTrans4s(vl_1) * HScale4s(Vec3s(1,2,1)) * y = " << x;
}


Void Test2DStuff()
{
	Vec2r x(1,2);
	Vec2r y(5,6);

	cout << "\n+ Test2DStuff\n\n";
	
	cout << "x: " << x << ", y: " << y << "\n\n";

	cout << "x + y * (y * x * 2) : " << x + y * (y * x * 2) << endl;
	cout << "x dot y               : " << dot(x, y) << endl;
	
	cout << "cross(x)    : " << cross(x) << endl;
	cout << "len         : " << len(x) << endl;
	cout << "sqrlen      : " << sqrlen(x) << endl;
	cout << "norm        : " << norm(x) << endl;
	cout << "len of norm : " << len(norm(x)) << "\n\n";
	
	Mat2s M(1,2,3,4);
	Mat2s N; N.MakeDiag(2.0);
	Mat2s I = vl_I; 
	
	cout << "M       : " << M << endl;

	cout << "M * x   : " << M * x << endl;
	cout << "x * M   : " << x * M << endl;
	
	cout << "adj     : " << adj(M) << endl;
	cout << "det     : " << det(M) << endl;
	cout << "trace   : " << trace(M) << endl;
	cout << "inv     : \n" << inv(M) << endl;
	cout << "M * inv : \n" << clamped(M * inv(M)) << "\n" << endl;
	
	cout << "Vec2 consts: " << Vec2r(vl_0) << Vec2r(vl_x) << Vec2r(vl_y) << Vec2r(vl_1) << endl;	
	cout << "Mat2 consts:\n" << Mat2s(vl_Z) << endl << Mat2s(vl_I) << endl << Mat2s(vl_B) << "\n\n";
	
	M = Rot2s(1.3) * Scale2s(Vec2s(2,1));
	
	cout << "M       : \n" << M << endl;

	cout << "M * x   : " << M * x << endl;
	cout << "x * M   : " << x * M << endl;
	
	cout << "adj     : " << adj(M) << endl;
	cout << "det     : " << det(M) << endl;
	cout << "trace   : " << trace(M) << endl;
	cout << "inv     : \n" << inv(M) << endl;
	cout << "M * inv : \n" << clamped(M * inv(M)) << "\n" << endl;
}

Void Test3DStuff()
{
	Vec3r x(1,2,3);
	Vec3r y(5,6,7);

	cout << "\n+ Test3DStuff\n\n";
	
	cout << "x: " << x << ", y: " << y << "\n\n";

	cout << "x + y * (y * x * 2) : " << x + y * (y * x * 2) << endl;
	cout << "x dot y               : " << dot(x, y) << endl;
	
	cout << "cross(x,y)  : " << cross(x,y) << endl;
	cout << "cross(x, y) . x : " << dot(cross(x, y), x) << endl;
	cout << "cross(x, y) . y : " << dot(cross(x, y), y) << endl;
	cout << "len         : " << len(x) << endl;
	cout << "sqrlen      : " << sqrlen(x) << endl;
	cout << "norm        : " << norm(x) << endl;
	cout << "len of norm : " << len(norm(x)) << "\n\n";
	
	Mat3s M(1,2,3,3,2,1,2,1,3);
	Mat3s N; N.MakeDiag(2.0);
	Mat3s I = vl_I; 
	
	cout << "M       : \n" << M << endl;

	cout << "M * x   : " << M * x << endl;
	cout << "x * M   : " << x * M << endl;
	
	cout << "adj     : " << adj(M) << endl;
	cout << "det     : " << det(M) << endl;
	cout << "trace   : " << trace(M) << endl;
	cout << "inv     : \n" << inv(M) << endl;
	cout << "M * inv : \n" << clamped(M * inv(M)) << endl;

	cout << "Vec3 consts: " << Vec3r(vl_0) << Vec3r(vl_x) << Vec3r(vl_y) << Vec3r(vl_z) << Vec3r(vl_1) << endl;	
	cout << "Mat3 consts:\n" << Mat3s(vl_Z) << endl << Mat3s(vl_I) << endl << Mat3s(vl_B) << "\n\n";
	
	M = Rot3s(vl_y, 1.3) * Scale3s(Vec3s(2,4,2));
	
	cout << "M       :\n" << M << endl;

	cout << "M * x   : " << M * x << endl;
	cout << "x * M   : " << x * M << endl;
	
	cout << "adj     : " << adj(M) << endl;
	cout << "det     : " << det(M) << endl;
	cout << "trace   : " << trace(M) << endl;
	cout << "inv     : \n" << inv(M) << endl;
	cout << "M * inv : \n" << clamped(M * inv(M)) << endl;
}

Void Test4DStuff()
{
	Vec4r x(1,2,3,4);
	Vec4r y(5,6,7,8);
	Vec4r z(1,0,0,0);

	cout << "\n+ Test4DStuff\n\n";
	
	cout << "x: " << x << ", y: " << y << ", z: " << z << "\n\n";

	cout << "x + y * (z * x * 2) : " << x + y * (z * x * 2) << endl;
	cout << "x dot y               : " << dot(x, y) << "\n\n";
	
	cout << "cross(x,y,z)   : " << cross(x,y,z) << endl;
	cout << "cross(x,y,z).x : " << dot(cross(x,y,z), x) << endl;
	cout << "cross(x,y,z).y : " << dot(cross(x,y,z), y) << endl;
	cout << "cross(x,y,z).z : " << dot(cross(x,y,z), z) << endl;
	cout << "len            : " << len(x) << endl;
	cout << "sqrlen         : " << sqrlen(x) << endl;
	cout << "norm           : " << norm(x) << endl;
	cout << "len of norm    : " << len(norm(x)) << "\n\n";
	
	
	Mat4s M(1,2,3,0, 2,3,0,5, 3,0,5,6, 0,5,6,7);
	Mat4s N; N.MakeBlock(2.0);
	Mat4s I = vl_I; 
	
	cout << "M       : \n" << M << endl;

	cout << "M * x   : " << M * x << endl;
	cout << "x * M   : " << x * M << endl;
	
	cout << "adj     : " << adj(M) << endl;
	cout << "det     : " << det(M) << endl;
	cout << "trace   : " << trace(M) << endl;
	cout << "inv     : \n" << inv(M) << endl;
	cout << "M * inv : \n" << clamped(M * inv(M)) << endl;
	
	cout << "Vec4 consts: " << Vec4r(vl_0) << Vec4r(vl_x) << Vec4r(vl_y) << Vec4r(vl_z) << Vec4r(vl_w) << Vec4r(vl_1) << endl;	
	cout << "Mat4 consts:\n" << Mat4s(vl_Z) << endl << Mat4s(vl_I) << endl << Mat4s(vl_B) << "\n\n";
	
	M = HScale4s(Vec3s(2,3,4));
	M *= HRot4s(vl_y, 1.256);
	
	cout << "M       : " << M << endl;

	cout << "M * x   : " << M * x << endl;
	cout << "x * M   : " << x * M << endl;
	
	cout << "adj     : " << adj(M) << endl;
	cout << "det     : " << det(M) << endl;
	cout << "trace   : " << trace(M) << endl;
	cout << "inv     : \n" << inv(M) << endl;
	cout << "M * inv : \n" << clamped(M * inv(M)) << endl;

}

ostream		&operator << (ostream &s, const TVec &v);

Void TestND()
{
	cout << "\n+ TestND\n\n";

	Vecr x(4, 1.0, 2.0, 3.0, 4.0);
	Vecr sx(3, 1.0, 2.0, 3.0);
	Vecr y(4, 5.0, 6.0, 7.0, 8.0);
	Vecr z(4, 4.0, 3.0, 2.0, 1.0);
	
	Mats M(4, 3, 4.0, 3.0, 2.0, 1.0, 4.0, 3.0, 2.0, 1.0, 5.0, 2.0, 1.0, 4.0, 3.0, 2.0, 1.0, 5.0);
	Mats N(4, 3, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0);

	cout << "M:\n" << M;
	cout << "\nN:\n" << N;
	cout << "\ntrans(N):\n" << trans(N);
	cout << "\nM + N:\n" << M + N;
	cout << "\nM * trans(N):\n" << M * trans(N);
	cout << "x: " << x << ", sx: " << sx << endl;

	z = x + y;
	cout << "z: " << z << endl;
	
	cout << "M * sx   : " << (M * sx) << endl;
	cout << "x * M   : " << x * M << endl;
		
	cout << "x: " << x << ", y: " << y << ", z: " << z << endl;

	cout << "x + y: " << x + y << endl;
	cout << "x * y: " << x * y << endl;
	cout << "x dot y: " << dot(x, y) << endl;
	cout << "x + (y dot z) * x * 2 : " << x + (dot(y, z) * x * 2.0) << endl;
	cout << "x + (y dot z) * x * 2 : " << ((float)2.0 * dot(y, z)) * x << endl;
	cout << "x + (y dot z) * x * 2 : " << x + dot(y, z) * x << endl;
	
	cout << "len : " << len(x) << endl;
	cout << "sqrlen : " << sqrlen(x) << endl;
	cout << "norm : " << norm(x) << endl;
	cout << "len of norm : " << len(norm(x)) << endl;
}


Void TestNDSub()
{
	cout << "\n+ TestNDSub\n\n";

	Vecr x(8, 1.0, 2.0, 3.0, 4.0, 1.0, 2.0, 3.0, 4.0);
	Vecr y(16, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0);
	Vecr z;
	
	cout << "x: " << x << ", y: " << y << endl;

	cout << "sub(y, 3, 3): " << sub(y, 3, 3) << endl;
	z = sub(x, 2, 6) + sub(y, 10, 6);
	cout << "sub(x, 2, 6) + sub(y, 10, 6): " << z << endl;

	sub(y, 5, 6) = Vecr(6, 88.0, 77.0, 66.0, 55.0, 44.0, 33.0);
	sub(x, 0, 2) = Vecr(2, 22.0, 11.0);
	
	cout << "x: " << x << ", y: " << y << endl;

	z = z + sub(y, 5, 6);
	sub(y, 5, 6) =  sub(y, 5, 6) + z;
	 
	cout << "z: " << z << ", y: " << y << endl;

	cout << "\n\n";

	Mats M(10, 10, vl_I);
	Mats N(4, 3, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0);

	cout << "sub(N, 1, 1, 2, 2): " << endl << sub(N, 1, 1, 2, 2);
	
	sub(M, 5, 3, 4, 3) = N;
	
	cout << "\nM:\n" << M;

	cout << "\nDiagonals of M: \n\n";
	
	Int i;
	
	for (i = 1 - M.Rows(); i < M.Cols(); i++)
		cout << diag(M, i) << endl;

	cout << "\nCol 4 of M: \n" << col(M, 4);
		
	diag(M, 0) = Vecs(10, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0);
	diag(M, 1) = Vecs(9, vl_1) * 2.0;
	diag(M, -1) = diag(M, 1) * 3.0;

	cout << "\nM:\n" << M << endl;
}

Void TestNDNumerical()
{
	Mats	P(4, 4,
				1.0, 2.0, 3.0, 0.0,
				2.0, 3.0, 0.0, 5.0,
				3.0, 0.0, 5.0, 6.0,
				0.0, 5.0, 6.0, 7.0
			);
	Mats	Q;
	Mat4s	P1(
				1.0, 2.0, 3.0, 0.0,
				2.0, 3.0, 0.0, 5.0,
				3.0, 0.0, 5.0, 6.0,
				0.0, 5.0, 6.0, 7.0
			);
	Mat4s	Q1;
	
	cout << "\n+ TestNDNumerical\n" << endl;

	cout << "P:\n";
	cout << P;
	
	cout << "\ninv(P):" << endl;
	Q = inv(P);
	cout << Q;
	
	cout << "\nP * inv(P):\n";
	cout << clamped(P * Q);

	cout << "\n\nReal:\n";
		
	cout << "P1: " << P1 << endl;
	cout << "\ninv(P1):\n";
	Q1 = inv(P1);
	cout << Q1 << endl;

	cout << "\nP1 * inv(P1): " << endl << clamped(P1 * Q1) << endl;
	cout << "\ninv(P) - inv(P1): " << endl << clamped(inv(P) - inv(P1));
	cout << endl << endl;
	
	// --- SolveOverRelax --------------------------------------------------------
	
	Mats	A(4, 4, 
				29.0,   2.0,  3.0,  0.0,
				 2.0,  29.0,  0.0,  5.0,
				 3.0,   0.0, 29.0,  6.0,
				 0.0,   5.0,  6.0, 29.0);
				 
	Vecr	x;
	Vecr	b;
	Real	error = 1.0;
	Int		i = 0;
	
	b.SetSize(4);
	b = A * Vecr(Vec4r(1.0, 2.0, 3.0, 4.0));
	
	x = b;
	cout << "Solving Ax = b with over-relaxation..." << endl;
	cout << "A: \n" << A << endl;
	cout << "b: " << b << endl;
	cout << "start x: " << x << endl;

	error = SolveOverRelax(A, x, b, 1e-8, 1.1);
	
//	cout << "iterations: " << i << endl;
	cout << "x: " << x << endl;
	cout << "Ax - b: " << A * x - b << endl;
	cout << "Returned error: " << error << ", real error: " << sqrlen(A * x - b) << endl;
	cout << endl;
	
	// --- SolveConjGrad ---------------------------------------------------------
		
	x = b;
	
	cout << "Solving Ax = b with conjugate-gradient..." << endl;
	cout << "A:\n" << A;
	cout << "b: " << b << endl;
	cout << "start x: " << x << endl;

	error = SolveConjGrad(A, x, b, 1e-8, &i);
	
	cout << "iterations: " << i << endl;
	cout << "x: " << x << endl;
	cout << "Ax - b: " << A * x - b<< endl;
	cout << "Returned error: " << error << ", real error: " << sqrlen(A * x - b) << endl;
}


Void TestSparse()
{
	cout << "\n+ TestSparse\n" << endl;

	SparseVecr 	v(30);
	SparseVecr 	z(30);
	SparseVecs 	w(Vecs(6, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0));
	Vecr 		x(30);
	Vecr 		y(30);
	Int 		i;
	Int			i1[] = { 3, 4, 7, 19, VL_SV_END };
	Real		e1[] = { 4.0, 5.0, 6.0, 7.0 };

	for (i = 0; i < 30; i++)
	{
		x[i] =  1.0;
		y[i] =  2.0;
	}

	v.Clear();
	v.AddElt(1, 3);
	v.AddElt(4, 2);
	v.AddElt(11, 3);
	v.AddElt(20, 2);
	v.Done();
	
	cout << v << endl; 
	z = v;

	v.SetElts(1, 4.0, 4, 0.0, 20, 3.0, 14, 6.0, VL_SV_END);

	cout << v << endl; 
	
	v.Clear();
	for (i = 0; i < 100; i++)
		v.AddElt(i, i);
	v.Done();
	
	v.SetCompactPrint(true);
	cout << "compact: " << v << endl;
	v.SetCompactPrint(false);
			
	cout << "v: " << v << endl; 
	cout << "w: " << w << endl;
	cout << "x: " << x << endl;
	cout << "y: " << y << endl;
	cout << "z: " << z << endl;
	
	v = 2 * v + x - z;
		
	cout << "2 * v + x - z: " << v << endl;
	cout << "v * x: " << v * x << endl;
		
	SparseMats M(20, 20, vl_I);
	SparseMats N(20, 20, vl_I);
	SVIters j;
	
	w.SetElts(20);
	w.SetElts(5, 3.96, 10, 2.0, 15, 8.0, 19, 2.0, VL_SV_END);
	
	M[10] = M[10].Overlay(w);
	M[15].Set(5, 6.0);

	cout << M[15].Get(5) << endl;
	
	cout << SparseVecr(20, 5, 15.0, 9, 21.0, 14, 20.0, VL_SV_END) << endl;
	cout << SparseVecs(20, i1, e1) << endl;

	M[8].Overlay(SparseVecs(20, 5, 15.0, 9, 21.0, 14, 20.0, VL_SV_END));
	cout << M[8] << endl;
	
	cout << "M:\n" << M;

	N = M * M;
	
	cout << "N = M^2:\n" << N;
	cout << "N - M:\n" << N - M;
	
}

Void TestSparseSub()
{
	cout << "\n+ TestSparseSub\n\n";

	SparseVecr x(Vecr(8, 1.0, 2.0, 3.0, 4.0, 1.0, 2.0, 3.0, 4.0));
	SparseVecr y(Vecr(16, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0));
	SparseVecr z;
	
	cout << "x: " << x << ", y: " << y << endl;

	cout << "sub(y, 3, 3): " << sub(y, 3, 3) << endl;
	z = sub(x, 2, 6) + sub(y, 10, 6);
	cout << "z = sub(x, 2, 6) + sub(y, 10, 6): " << z << endl;

	sub(y, 5, 6) = Vecr(6, 88.0, 77.0, 66.0, 55.0, 44.0, 33.0);
	sub(x, 0, 2) = Vecr(2, 22.0, 11.0);
	
	cout << "x: " << x << ", y: " << y << endl;

	z = z + sub(y, 5, 6);
	sub(y, 5, 6) =  sub(y, 5, 6) + z;
	 
	cout << "z: " << z << ", y: " << y << endl;

	cout << "\n\n";

	SparseMats M(10, 10, vl_I);
	SparseMats N(Mats(4, 3, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0));
	
	cout << "sub(N, 1, 1, 2, 2): " << endl << sub(N, 1, 1, 2, 2);

	sub(M, 5, 3, 4, 3) = N;
	
	cout << "\nM:\n" << M;

	cout << "\nDiagonals of M: \n\n";
	
	Int i;
	
	for (i = 1 - M.Rows(); i < M.Cols(); i++)
		cout << diag(M, i) << endl;

	cout << "\nCol 4 of M: \n" << col(M, 4);
		
	diag(M, 0) = Vecs(10, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0, 3.0);
	diag(M, 1) = Vecs(9, vl_1) * 2.0;
	diag(M, -1) = diag(M, 1) * 3.0;

	cout << "\nM:\n" << M << endl;
}

Void TestSparseNumerical()
{
#if 0
XXX
	static Real sparseData[] =
	{
		0, 1, 1.0, 2, 2.0, 3, 4.0, VL_SV_END,
		1, 1, 2.0, 2, 3.0, 4, 4.0, VL_SV_END,
		2, 1, 3.0, 2, 4.0, 3, 6.0, VL_SV_END,
		3, 1, 5.0, 2, 6.0, 3, 7.0, VL_SV_END,
		VL_SV_END
	}
	static Real sparseData[] =
	{
		0, 1, 1.0, 2, 2.0, 3, 4.0, VL_SV_END,
		1, 1, 2.0, 2, 3.0, 4, 4.0, VL_SV_END,
		2, 1, 3.0, 2, 4.0, 3, 6.0, VL_SV_END,
		3, 1, 5.0, 2, 6.0, 3, 7.0, VL_SV_END,
		VL_SV_END
	}
#endif

	SparseMats P = Mats(4, 4, 1.0, 2.0, 3.0, 0.0,
				2.0, 3.0, 0.0, 5.0,
				3.0, 0.0, 5.0, 6.0,
				0.0, 5.0, 6.0, 7.0);
	SparseMats Q;
	

	cout << "\n+ TestSparseNumerical\n" << endl;

	cout << "P:\n";
	cout << P;
	
	cout << "\ninv(P):" << endl;
	Q = inv(P);
	cout << Q;
	
	cout << "\nP * inv(P):\n";
	cout << P * Q;

	cout << "\n\nReal:\n";
	
	Mat4s P1(1,2,3,0, 2,3,0,5, 3,0,5,6, 0,5,6,7);
	Mats Q1;
	
	cout << "P1: " << P1 << endl;
	
	cout << "\ninv(P1):\n";
	Q1 = inv(Mats(P1));
	cout << Q1 << endl;
	
	cout << "\nP1 * inv(P1): " << endl << clamped(P1 * Q1) << endl;
	
	
	cout << "\ninv(P) - inv(P1): " << endl << setprecision(4) << Q - SparseMats(Q1);
	
	cout << endl << 
	"---------------------------------------------------------" << endl;

	// --- SolveOverRelax --------------------------------------------------------
	
	SparseMats A = Mats(4, 4, 
				29.0,  2.0,  3.0,  0.0,
				 2.0, 29.0,  0.0,  5.0,
				 3.0,  0.0, 29.0,  6.0,
				 0.0,  5.0,  6.0, 29.0);
				 
	Vecr x, b = A * Vecr(4, 1.0, 2.0, 3.0, 4.0);
	Real error = 1;
	Int i = 0;
	
	x = b;
	
	cout << "Solving Ax = b with over-relaxation..." << endl;
	cout << "A: \n" << A << endl;
	cout << "b: " << b << endl;
	
	error = SolveOverRelax(A, x, b, 1e-8, 1.1);
	
//	cout << "iterations: " << i << endl;
	cout << "x: " << x << endl;
	cout << "Ax: " << A * x << endl;
	cout << "Ax - b: " << A * x - b << endl;
	cout << "Returned error: " << error << ", real error: " << sqrlen(A * x - b) << endl;
	cout << endl;
	
	// --- SolveConjGrad ---------------------------------------------------------
	
	x = b;
	
    cout << "A:\n" << A;
    cout << "b: " << b << endl;
    cout << "x: " << x << endl;

	cout << "Solving Ax = b with conjugate-gradient..." << endl;
	
	error = SolveConjGrad(A, x, b, 1e-8, &i);
	
	cout << "iterations: " << i << endl;
	cout << "x: " << x << endl;
	cout << "Ax - b: " << A * x - b<< endl;
	cout << "Returned error: " << error << ", real error: " << sqrlen(A * x - b) << endl;
}


Void TestBasics()
{
	cout << "\n+ TestBasics\n\n";

	Assert(false, "Bogus assertion");
	Expect(false, "This is true");

	cout << "max is: " << Max(2.0, 5.0) << endl;
	cout << "min is: " << Min((Int) 2, (Int) 5) << endl;
}

Void TestInit()
{
	Vecr	v00(10, vl_zero);
	Vecr	v01(10, vl_one);
	Vecr	v02(10, vl_x);
	Vecr	v03(10, vl_axis(5));
	Vecr	v04(10); v04.MakeBlock(5.0);

	Mats	m00(5, 5, vl_zero);
	Mats	m01(5, 5, vl_one);
	Mats	m02(5, 5); m02.MakeDiag(4.0);
	Mats	m03(5, 5); m03.MakeBlock(2.2);
	Mats	m04(5, 5); m04.MakeBlock(8.8);

	SparseVecr	sv00(10, vl_zero);
//	SparseVecr	sv01(10, vl_one);  illegal
	SparseVecr	sv02(10, vl_x);
	SparseVecr	sv03(10, vl_axis(5));

	SparseMats	sm00(5, 5, vl_zero);
	SparseMats	sm01(5, 5, vl_one);
	SparseMats	sm02(5, 5); sm02.MakeDiag(4.0);
//	SparseMats	sm03(5, 5); sm03.MakeBlock(2.2); illegal

	sub(m04, 2, 2, 2, 2) = Mat2s(vl_B) * 111.0; 
	
	cout << "--- Test init code -------------------------------------------" << endl << endl;
	
	cout << v00 << endl;
	cout << v01 << endl;
	cout << v02 << endl;
	cout << v03 << endl;
	cout << v04 << endl;
	
	cout << endl;
	
	cout << m00 << endl;
	cout << m01 << endl;
	cout << m02 << endl;
	cout << m03 << endl;
	cout << m04 << endl;
	cout << endl;
	
	cout << sv00 << endl;
	cout << sv02 << endl;
	cout << sv03 << endl;
	
	cout << endl;
	
	cout << sm00 << endl;
	cout << sm01 << endl;
	cout << sm02 << endl;
	cout << endl;
	
	cout << "testing comparisons..." << endl;
	cout << endl;
	cout << (Mat2s(vl_0) == vl_0) << endl;
	cout << (Mat3s(vl_0) == vl_0) << endl;
	cout << (Mat4s(vl_0) == vl_0) << endl;
	cout << (Mats(8, 8, vl_0) == Mats(8, 8, vl_0)) << endl;

	cout << (Mat2s(vl_1) == vl_0) << endl;
	cout << (Mat3s(vl_1) == vl_0) << endl;
	cout << (Mat4s(vl_1) == vl_0) << endl;
	cout << (Mats(8, 8, vl_1) == Mats(8, 8, vl_0)) << endl;
}


#if 0

#include "VLc.h"
Void ComplexTest()
{
	cout << "\n+ Test Complex\n\n";

	SparseMatc a(4, 6);
	SparseVecc b(6);

	a.MakeDiag(float_complex(0.5, 0.8) * 2.5);
	cout << "a:\n" << a << endl;	
	b = vl_y;
	cout << "b: " << b << endl;
	
	cout << "a * b = " << a * b << endl;
	
	SparseMatc na(4, 6);
	na.MakeDiag(5.1);
	
	cout << "na:\n" << na << endl;
	cout << "na * b = " <<  na * b << endl;

	a = vl_Z;
	b = vl_0;
	a = vl_I;
	b = vl_x;

	Mat4c c;
	Vec4c d;

	c = vl_1;
	d = vl_y;
	
	cout << "c:\n" << c << endl;	
	cout << "d:" << d << endl;	
	
	cout << "ca * cb = " << c * d  + d << endl;
}
#endif


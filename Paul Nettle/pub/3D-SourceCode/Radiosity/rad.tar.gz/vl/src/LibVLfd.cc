/*
	File:		LibVLfd.cc
	
	Purpose:	Compiles mixed float/double code.
	
	Author:		Andrew Willmott

*/


#include "VLd.h"

#include "VLUndef.h"
#define VL_V_REAL Float
#define VL_V_SUFF(X) X ## f
#define VL_M_REAL Double
#define VL_M_SUFF(X) X ## d

#include "Vec2.h"
#include "Vec3.h"
#include "Vec4.h"
#include "Vec.h"
#include "SparseVec.h"

#include "Mixed.cc"
#include "Solve.cc"


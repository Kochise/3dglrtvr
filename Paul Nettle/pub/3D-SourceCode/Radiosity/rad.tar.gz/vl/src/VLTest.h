/*
	File:			VLTest.h

	Function:		Header file for Test.cc.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

// 	Remember: We stress your compiler so you don't have to!

#ifndef __VLTEST__
#define __VLTEST__

// Include headers | templates

#define VL_V_REAL Double
#define VL_V_SUFF(X) X ## s
#define VL_M_REAL Double
#define VL_M_SUFF(X) X ## s

/*#include "Vec2.h"
#include "Vec3.h"
#include "Vec4.h"
#include "Vec.h"
#include "SparseVec.h"
*/

#include "Mat2.h"
#include "Mat3.h"
#include "Mat4.h"
#include "Mat.h"
#include "SparseMat.h"
#include "Solve.h"

#include "Transform.h"

#include "VLUndef.h"
#define VL_V_REAL Float
#define VL_V_SUFF(X) X ## r
#define VL_M_REAL Double
#define VL_M_SUFF(X) X ## s

#include "Vec2.h"
#include "Vec3.h"
#include "Vec4.h"
#include "Vec.h"
#include "SparseVec.h"
#include "Mixed.h"
#include "Solve.h"

#endif

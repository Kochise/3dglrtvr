#include "Parse.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "Scene.h"
#include "SceneObjects.h"
#include "Avars.h"
#include "SceneLang.h"
#include "GCLConfig.h"

scScenePtr ParseObjFile(istream &s);
#ifdef GCL_PARSE_SC
void ParseSCFile(char *filename);
#endif
#ifdef GCL_MGF
scScenePtr ParseMGFFile(const Char *filename);
#endif

#if 0
typedef (scObject**)SceneParser(const Char *filename);
struct SceneParserEntry
{
	const Char	*extension;
	SceneParser	parser;
	const Char	*description;
};

scScenePtr ParseObjFile(const Char *filename);
scScenePtr ParseSLFile(const Char *filename);
scScenePtr ParseSCFile(const Char *filename);
scScenePtr ParseMGFFile(const Char *filename);

SceneParserEntry *scSceneParserTable = 
{
	".sl",	ParseSL,		"gcl's scene language.",
	".obj",	ParseObj,		"Wavefront .obj file",
	".smf",	ParseObj,		"garland's .smf",
	".sc",	ParseSC,		"Heckbert's .sc",
	".mgf",	ParseSC,		"Ward et al.'s .mgf",
	0
};

void PrintSupportedSceneFormats(ostream &s)
{
	SceneParserEntry *sp = scSceneParserTable;
	s << "Supported scene file extensions: "

	while (*sp)
	{
		s << sp->extension << ": " << sp->description << endl;
		sp++;
	}
}
#endif

scScenePtr ReadSceneFile(FileName &filename)
// Reads scene file. filename.name may be altered if it has a gzip extension.
{
	scScenePtr	result;
	ifstream 	inFile;
	String		oldPath;
	String		gunzipFile, oldFile;
	Char		cmd[256];
	Bool		gzipFile = false;
	
	oldPath = filename.path;
	
	// gzip file?

#ifdef GCL_GZIP
	if (filename.extension == "gz")
	{
		// decompress it...
		
		oldFile = filename.GetPath();
		filename.ChopExtension();
		filename.path = "/tmp";
		
		gunzipFile = filename.GetPath();
		
		sprintf(cmd, "gzcat %s > %s", oldFile.Ref(), gunzipFile.Ref());
		system(cmd);
		gzipFile = true;
	}
#endif
	
	result = 0;

	do
	{
		if (filename.extension == "sl")
		{
			inFile.open(filename.GetPath().Ref());
			if (!inFile)
			{
				cerr << "Couldn't read file " << filename.GetPath() << endl;
				break;
			}
			result = (scScenePtr) scParseObject(inFile);
			inFile.close();
		}
		else if (filename.extension == "obj" || filename.extension == "smf")
		{
			inFile.open(filename.GetPath().Ref());
			if (!inFile)
			{
				cerr << "Couldn't read file " << filename.GetPath() << endl;
				break;
			}
			result = slBeginObject(filename.name.Ref());
			slCamera();
			slColour(cBlue);
			ParseObjFile(inFile);
			slEndObject();
			inFile.close();
		}
#ifdef GCL_MGF
		else if (filename.extension == "mgf")
		{
			result = ParseMGFFile(filename.GetPath().Ref());
		}		
#endif
#ifdef GCL_PARSE_SC
		else if (filename.extension == "sc")
		{
			result = slBeginObject(filename.name.Ref());
			slCamera();
			ParseSCFile(filename.GetPath().Ref());
			slEndObject();
		}		
#endif
		else
			cerr << "scene file " << filename.GetPath() << " has an unknown extension." << endl;
		
		inFile.close();
		
		filename.path = oldPath;
	}
	while (0);

	if (gzipFile)
		unlink(gunzipFile.Ref());
	
	return(result);
}


scObject *scParseObject(istream &s)
// Need a tokenizer...
{
	String		str;
	scObject	*object;

	str.ReadWord(s);

// attributes
	
	if (str == "objectfile")
	{
		FileName filename;
		
		str.ReadString(s);
		cout << "including " << str << endl;
		filename.SetPath(str.Ref());
		return(ReadSceneFile(filename));
	}	
	if (str == "camera")
		object = new scCamera;
	else if (str == "avar")
	{
		str.ReadWord(s);
		
		if (str == "colour")
			object = new scAvarColour(Avar("dummy"), vl_z);
		else if (str == "emittance")
			object = new scAvarEmittance(Avar("dummy"), vl_z);
		else if (str == "shift")
			object = new scAvarShift(Avar("dummy"), vl_z);
		else if (str == "rotate")
			object = new scAvarRotation(Avar("dummy"), vl_z);
		else if (str == "scale")
			object = new scAvarScale(Avar("dummy"), vl_z);
	}
	else if (str == "points")
		object = new scPoints;
	else if (str == "indexes")
		object = new scIndexes;
	else if (str == "colour")
		object = new scColour;
	else if (str == "emittance")
		object = new scEmittance;
	else if (str == "transform")
		object = new scTransform;
	else if (str == "shift")
	{
		object = new scTransform; // XXX
		
		return(object);
	}
	else if (str == "rotate")
		object = new scTransform;
	else if (str == "scale")
		object = new scTransform;

// primitives

	else if (str == "poly")
		object = Clone(slGetLibrary()->Member("poly"));
	else if (str == "radpoly")
		object = Clone(slGetLibrary()->Member("poly"));
	else if (str == "object")
		object = Clone(slGetLibrary()->Member("group"));
	else if (str == "end")
		return(0);
	else if (str == "define")
	{
		scGroup *group;
		
		group = (scGroup *) Clone(slGetLibrary()->Member("group"));
		group->Parse(s);
		if (group)
			slGetLibrary()->AddMember(group);
		return(scParseObject(s));
	}
	else if (object = slGetLibrary()->Member(str.Ref()))
		return(object);
	else
	{
		cerr << "Unknown keyword: " << str << endl;
		return(0);
	}
	
	object->Parse(s);
		
	return(object);
}


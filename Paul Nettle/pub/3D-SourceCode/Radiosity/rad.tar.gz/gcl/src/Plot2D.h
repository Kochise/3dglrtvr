/*
	File:			Plot2D.h

	Function:		Defines a scene object which provides a 2d plot of a given
					function.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Plot2d__
#define __Plot2d__

#include "SceneObjects.h"


class Plot2D : public scPrimitive
{
public:

	Plot2D();

	void		Draw(Renderer &r, Context *context);
	Char 		*Label() const;

	Object		*Clone() const { return new Plot2D(*this); };

	Matd		samples;
	Bool		isStep;		// sample in the middle of each element and assume constant value?
};


#endif


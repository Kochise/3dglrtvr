/*
	File:			List.h
	
	Function:		Provides linked list primitives.

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __List__
#define __List__

#include "Basics.h"


// --- Simple Linked List ---------------------------------------------------


//	A node in the list.

class Node
{
public:
	Node	*next;			// Next item in the list
	
	Node() : next(0) {};

	void			InsertAfter(Node *node) { node->next = next; next = node;};

	void			FreeAfter();
	
	virtual Node	*Clone();
	Node			*CloneList();
};


//	A list : essentially a (Node *) with associated methods. Imitates Lisp/Prolog lists,
//	in that it has head & tail methods.
//	Has pointer semantics: you must call Clone() to copy it, and Free() to delete it.

class List
{
public:
	Node		*first;		// Pointer to the first node in the list.
	
				List() : first(0) {};
	
	Bool		IsEmpty()	{ return first == 0; };
	Node		&Head()		{ return *first; };
	List		&Tail()		{ return (List &) first->next; };
	
	void		Prepend(Node *node) { node->next = first; first = node; };
	void		Prepend(List list);
	void		Append(Node *node);
	void		Append(List list);
	
	void		Free()		{ first->FreeAfter(); delete first; };
	List		Clone()		{ List result; result.first = first->CloneList(); return(result); };

	void		DeleteFirst()
				{ Node *t = first; first = first->next; delete t; }; 
	Node		*DisconnectFirst()
				{ Node *t = first; first = first->next; return(t); }; 
};

template <class T> 
	class TypedList : public List
{
public:
	T				&Head()		{ return (T &) *first; };
	TypedList<T>	&Tail()		{ return (TypedList<T> &) first->next; };
};

template <class T> ostream &operator << (ostream &s, TypedList<T> list);

//	Associated iterator. 

template <class T> class Iter
{
public:
	List	*cursor;
	
	void	Begin(List &list)		{ cursor = &list; };
	void	Inc()					{ Assert(!cursor->IsEmpty(), "Moved past end of list");
											cursor = (List *) cursor->first; };
											
	Bool	AtEnd()					{ return cursor->first == 0; };
	T		&Data()					{ return (T &) cursor->Head(); };
	
	void	Delete()				{ cursor->DeleteFirst();};
	void	InsertBefore(Node *node) { cursor->Prepend(node); cursor = (List *) cursor->first;};
	void	InsertAfter(Node *node)	{ cursor->Tail().Prepend(node);};
};


// --- Doubly-linked list ------------------------------------------------------


class DblNode
{
public:
	DblNode	*prev;			// Previous item in the list
	DblNode	*next;			// Next item in the list
	
	DblNode() : prev(0), next(0) {};

	void			InsertAfter(DblNode *node)
		{ node->next = next; node->prev = this; if (next) next->prev = node;
			next = node; };
	void			InsertBefore(DblNode *node)
		{ node->next = this; node->prev = prev; if (prev) prev->next = node;
			prev = node;};
	void			Delete()
		{ prev->next = next; next->prev = prev; delete this;};
	DblNode			*Disconnect()
		{ prev->next = next; next->prev = prev; return(this);};
	
	Bool			AtStart()		{ return(prev == 0); };
	Bool			AtEnd()			{ return(next == 0); };

	void			FreeAfter();
	void			FreeBefore();
	void			FreeList()		{ FreeAfter(); FreeBefore(); delete this; }
	
	virtual DblNode	*Clone()		{ return new DblNode(SELF); };
	
	DblNode			*CloneAfter();
	DblNode			*CloneBefore();
	DblNode			*CloneList();
};

// Associated iterator

template <class T> class DblIter
{
public:
	DblNode	*cursor;
	
	void	Begin(DblNode *list)	{ cursor = list; };
	void	Inc()					{ Assert(!cursor->AtEnd(), "Moved past end of list");
											cursor = cursor->next; };
	void	Dec()					{ Assert(!cursor->AtStart(), "Moved past end of list");
											cursor = cursor->prev; };
											
	Bool	AtEnd()					{ return cursor == 0; };
	
	T		&Data()					{ return (T &) *cursor; };
	
	void	Delete()				{ DblNode *t = cursor; cursor->Delete(); cursor = t;};
	void	InsertBefore(DblNode *node)
									{ cursor->InsertBefore(node); };
	void	InsertAfter(DblNode *node)
									{ cursor->InsertAfter(node); };
};


// --- Templated functions ----------------------------------------------------

template <class T> 
	ostream &operator << (ostream &s, TypedList<T> list)
{
	s << "(";
	
	if (!list.IsEmpty())
	{
		s << list.Head();
		list = list.Tail();

		while (!list.IsEmpty())
		{
			s << " " << list.Head();
			list = list.Tail();
		}
	}
		
	s << ")";
	return(s);
};


#endif

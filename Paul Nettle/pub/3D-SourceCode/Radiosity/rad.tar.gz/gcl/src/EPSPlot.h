/*
	File:		EPSPlot.h

	Purpose:	Defines vanilla class for doing 2D plotting and producing eps output.
				adopted from Paul Heckbert's libplo/ps.c
	
	Author:		Paul Heckbert, Andrew Willmott
*/

#ifndef __EPSPlot__
#define __EPSPlot__

#include "Basics.h"
#include <stdio.h>


enum { lineDashed, lineDotted, lineSolid };

class EPSPlot
{
public:
	EPSPlot();
	
	void	Open(Char *filename);
	void	Close();
	
	void	MoveTo(Real x, Real y);
	void	LineTo(Real x, Real y);
	void	SetWidth(Real width);
	void	LineStyle(Int style);
	void	Dot(Real x, Real y, Real r);
	void	Circle(Real x, Real y, Real r);
	void	DrawText(Real x, Real y, Char *string);

//	void	SetColour(const Colour &c);
	void	SetGrey(Real level);
	
	//void	TextPos(Real x, Real y, Real xjust, Real yjust, Char *string);
	//void	CharSize(Real size);
	//void	CharTransform(const Mat3r &m);

	void	SetOutputSize(Real size);		// measured in 1/72 of an inch.
			// Must be called before an 'Open'.
	void	SetPort(Real left, Real bottom, Real right, Real top, Bool centred);
			// If 'centred' is true, the origin will be at the centre of the port,
			// otherwise it will be placed at the bottom-left. Other positions
			// for the origin can be achieved by using 'Translate' after calling
			// SetPort.
			// If you want more than one view setup,
			// you must Push/Pop around the previous one.
			
	void	Push();
	void	Pop();
	void	Translate(Real tx, Real ty);
	void	Scale(Real sx, Real sy);
	void	Rotate(Real angle);

	void	Comment(Char *string);

protected:
	void	Stroke();

	FILE	*file;
	Bool	drawn;
	Real	scale;
	Char	*font;
	Real	width;
	Real	worldScale;
};

#endif

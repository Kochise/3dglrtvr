/*
	File:			Camera.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

	Change History:
		31/01/96	ajw		Started
*/

#include "Camera.h"


Camera::Camera(Bool useOrtho) : 
	position(0, 0, 4),
	fov(60.0), zoom(1.0),
	clipNear(1.0), clipFar(100.0),
	up(vl_y), dir(Vector(vl_z) * -4),
	lhand(0), ortho(useOrtho)
{
	sceneOrient = vl_I;
	sceneOffset = vl_I;
}

void Camera::SetClipping(Real nearPlane, Real farPlane)
{
	clipNear = nearPlane;
	clipFar = farPlane;
}

void Camera::SetPerspective(Real fieldOfView)
{
	fov = fieldOfView;
}

void Camera::SetPosition(Point pos)
{
	Point at = position + dir;
	position = pos;
	dir = at - position;
}

void Camera::SetLookat(Point at)
{
	dir = at - position;
}

void Camera::SetViewUp(Vector vup)
{
	up = norm(vup);
}

void Camera::SetZoom(Real zoomFactor)
{
	if (zoomFactor > 0)
		zoom = zoomFactor;
	else
		zoomFactor = 0;
}

const Real kProjEpsilon = 0.01;

#define BACK_COMPAT
Transform Camera::ModelMatrix() const
{
	Vector		xAxis, yAxis, zAxis;
	Transform	result, align;

	if (ortho)
		return(Scale(Vector(zoom, zoom, 1)) * sceneOffset);

	zAxis = -norm(dir);
	xAxis = cross(up, zAxis);
	
	if (len(xAxis) < kProjEpsilon)
		xAxis = norm(cross(vl_z, zAxis));
	else
		xAxis = norm(xAxis);
	
	yAxis = norm(cross(zAxis, xAxis));
		
	// Create a matrix which will align scene with the xAxis, yAxis, zAxis
	align[0] = Vec4d(xAxis, 0);
	align[1] = Vec4d(yAxis, 0);
	align[2] = Vec4d(zAxis, 0);
	align[3] = vl_w;
#ifndef VL_ROW_ORIENT
	align = trans(align);
#endif

	//result = align * setup * sceneOrient * sceneOffset * HTransMat4d(len(position - pdir) * Vector(0, 0, -zoom)) * project; 
	//bf: Shift(Vector(0, 0, len(dir) * -zoom) * sceneOffset * sceneOrient * align
	
	// first: translate lookat to origin, rotate so camera lies on +ve z axis, and apply
	// rotation and offset around lookat. We apply rotations first, because we want
	// translations to be specified in the camera's coordinate system.
	// second: translate camera position to origin.
	
#ifdef BACK_COMPAT
	// Ever have that experience of looking at old code, and thinking,
	// "what was I smoking?"
	result = sceneOffset * sceneOrient * align;
	result = Shift(Vector(0, 0, -zoom * len(dir))) * result;
#else
	result = sceneOffset * sceneOrient * align * Shift(-(position + dir));
	result = Shift(Vector(0, 0, -len(dir))) * result;
#endif		
	return(result);
}

Transform Camera::ProjMatrix() const
{
	Transform	project(vl_I);
		
	if (ortho)
		return(vl_I);

	if (lhand)
	{
		project[3][3] = 0;
		project[2][2] = -(clipFar + clipNear) / (clipFar - clipNear);
#ifndef VL_ROW_ORIENT
		project[2][3] = - 2 * clipFar * clipNear / (clipFar - clipNear);
		project[3][2] = -1;
#else
		project[3][2] = - 2 * clipFar * clipNear / (clipFar - clipNear);
		project[2][3] = -1;
#endif
			
		project[0][0] = zoom / tan(DegsToRads(fov) / 2.0);
		project[1][1] = project[0][0];
	}
	else
	{
		project[3][3] = 0;
		project[2][2] = -(clipFar + clipNear) / (clipFar - clipNear);
#ifndef VL_ROW_ORIENT
		project[2][3] = - 2 * clipFar * clipNear / (clipFar - clipNear);
		project[3][2] = -1;
#else
		project[3][2] = - 2 * clipFar * clipNear / (clipFar - clipNear);
		project[2][3] = -1;
#endif
			
#ifdef BACK_COMPAT
		project[0][0] = 1.0 / tan(DegsToRads(fov) / 2.0);
#else
		project[0][0] = zoom / tan(DegsToRads(fov) / 2.0);
#endif
		project[1][1] = project[0][0];
	}

	return(project);
}

void Camera::SetSceneOrient(Transform &t)
{
	sceneOrient = t;
}

void Camera::SetSceneOffset(Transform &t)
{
	sceneOffset = t;
}

ostream &operator << (ostream &s, Camera &c)
{
	s << c.ProjMatrix() << endl << c.ModelMatrix();
	
	return(s);
}

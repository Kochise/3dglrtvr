/*
	File:			Timer.c

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			Any other useful timing calls?
					Might be nice to have a C++ version of this
					with a stopwatch class.	
*/


#include "Timer.h"
#include <stdio.h>
#include <math.h>


/* --- Unix Time ----------------------------------------------------- */


#if (defined(UNIX_USR_TIME) || defined(UNIX_SYS_TIME) || defined(UNIX_TOT_TIME))

/* Use the times() call */

#include <sys/types.h>
#include <unistd.h>
#include <sys/times.h>
#include <limits.h>

static float			gStartTime = 0.0;
static float			gStopTime = 0.0;
static float			gLapTime = 0.0;

float CurrentTime()
{
    struct tms tb;
	float result;
	
    times(&tb);
#ifdef UNIX_USR_TIME
    result = (float)(tb.tms_utime) / CLK_TCK;
#endif
#ifdef UNIX_SYS_TIME
    result = (float)(tb.tms_stime) / CLK_TCK;
#endif
#ifdef UNIX_TOT_TIME
    result = (float)(tb.tms_utime + tb.tms_stime) / CLK_TCK;
#endif	

	return(result);
}

void StartTimer()
{
    gStartTime = CurrentTime();
}

float GetTimer()
{
    return(CurrentTime() - gStartTime);
}

float DeltaTime()
{     
	float oldLapTime = gLapTime;
	
    gLapTime = CurrentTime();
	
    return(gLapTime - oldLapTime);
}

void StopTimer()	/* Stops timer */
{
	gStopTime = CurrentTime();
}

void ContTimer()	/* Restarts timer */
{
	float temp;

	temp = CurrentTime();
	temp -= gStopTime;
	gStartTime += temp;
	gLapTime += temp;
}

#else


/* --- Ansi Time ------------------------------------------------------ */


#ifdef ANSI_TIME				/* Use clock() */

#include <time.h>

static clock_t gTime = 0;
static clock_t gLapTime = 0;

void StartTimer()
{
    gTime = clock();
    gLapTime = clock();
}

float GetTimer()
{     
    return(((float) (clock() - gTime)) / ((float) CLOCKS_PER_SEC));
}

float DeltaTime()
{     
	clock_t temp = gLapTime;
	
	gLapTime = clock();
	
    return(((float) (gLapTime - temp)) / ((float) CLOCKS_PER_SEC));
}


#else


/* --- Sgi Time ------------------------------------------------------ */


#ifdef SGI_TIME

#include <dmedia/dmedia.h>

typedef unsigned long long UST;

static UST gStarttime;
static UST gLaptime;
static UST gStopTime;

void StartTimer()	/* Starts timer */
{
	dmGetUST(&gStarttime);
	gLaptime = gStarttime;
}

void StopTimer()	/* Stops timer */
{
	dmGetUST(&gStopTime);
}

void ContTimer()	/* Restarts timer */
{
	UST temp;

	dmGetUST(&temp);
	temp -= gStopTime;
	gStarttime += temp;
	gLaptime += temp;
}

float GetTimer()	/* Returns time in microseconds since timer was started */
{
	UST temp;
	
	dmGetUST(&temp);
	
	return(((float) (temp - gStarttime)) / 1e9);
}


float DeltaTime()	/* returns time delta since Delta time was last called. */
{
	UST temp = gLaptime;
	
	dmGetUST(&gLaptime);
	
	return(((float) (gLaptime - temp)) / 1e9);
}

#else

/* used to have rusage code. resurrect? */

#endif
#endif
#endif


/*
	File:			Image.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
*/

#include "Image.h"
#include "GCLConfig.h"
#include <iostream.h>
#include <stdio.h>

Colour RGBAToColour(RGBAPixel rgba)
{
	Colour result;
	result[0] = rgba.ch[rgba_R] / 255.0;
	result[1] = rgba.ch[rgba_G] / 255.0;
	result[2] = rgba.ch[rgba_B] / 255.0;
	return(result);	
}

RGBAPixel ColourToRGBA(const Colour &c)
{
	RGBAPixel result;
	result.ch[rgba_R] = c[0] * 255.0;
	result.ch[rgba_G] = c[1] * 255.0;
	result.ch[rgba_B] = c[2] * 255.0;
	return(result);	
}

// --- Image class ------------------------------------------------------------

Void Image::CopyFrom(Int x, Int y, Image &img)
{
	Int test = img.Width();
	Int		copyWidth = Min(img.Width(), width - x);
	Int 	copyHeight = Min(img.Height(), height - y);
	Colour 	*buffer = new Colour[copyWidth];
	Int 	i;
	
	for (i = 0; i < copyHeight; i++)
	{
		img.GetSpan(i, x, copyWidth, buffer);
		SetSpan(y++, 0, copyWidth, buffer);
	} 
	
	delete[] buffer;
}

Void Image::SetRGBASpan(Int row, Int start, Int length, const RGBAPixel *src) 
{
	Int		i;
	Colour	*buffer = new Colour[length];
	for (i = 0; i < length; i++)
		buffer[i] = RGBAToColour(src[i]);
	SetSpan(row, start, length, buffer);
	delete[] buffer;
}

Void Image::GetRGBASpan(Int row, Int start, Int length, RGBAPixel *dst) 
{
	Int		i;
	Colour	*buffer = new Colour[length];

	GetSpan(row, start, length, buffer);

	for (i = 0; i < length; i++)
		dst[i] = ColourToRGBA(buffer[i]);

	delete[] buffer;
}

#if 0
Void Image::SetFloatSpan(ImgChannel channel, Int row, Int start, Int length, const Byte *src)
{
}

Void Image::GetFloatSpan(ImgChannel channel, Int row, Int start, Int length, Byte *dst) 
{
}

Void Image::SetByteSpan(ImgChannel channel, Int row, Int start, Int length, const Byte *src) 
{
}

Void Image::GetByteSpan(ImgChannel channel, Int row, Int start, Int length, Byte *dst) 
{
}
#endif

// --- File methods --------------------------------------

Int Image::SavePPM(const Char *filename)
{
    int			i, j;
	FILE		*ppm;
	RGBAPixel	*p, *buffer = new RGBAPixel[width];
	
	ppm = fopen(filename, "w");
	if (!ppm)
		return(-1);
	
	fprintf(ppm, "P6 %u %u 255\n", width, height);

    for (j = height - 1; j >= 0; j--)
    {
    	GetRGBASpan(j, 0, width, buffer);
    	p = buffer;
        for (i = 0; i < width; i++, p++)
 		{
            fputc(p->ch[rgba_R], ppm);
            fputc(p->ch[rgba_G], ppm);
            fputc(p->ch[rgba_B], ppm);
        }
		
    }

	delete[] buffer;
    return(fclose(ppm));
}

Int Image::LoadPPM(const Char *filename)
{
    int			i, j;
	Int			x, y, level;
	char		lineBuf[32];
	FILE		*ppm;
	RGBAPixel	*p, *buffer = new RGBAPixel[width];
	
	ppm = fopen(filename, "r");
	if (!ppm)
		return(-1);

	fscanf(ppm, "%s %d %d %d", lineBuf, &x, &y, &level);

	if (level == 255)
	{
		_Error("Can't handle non-8 bit ppm components.");
		return(-1);
	}
	
	SetSize(x, y);
	
    for (j = height - 1; j >= 0; j--)
    {
    	p = buffer;
        for (i = 0; i < width; i++, p++)
 		{
            p->ch[rgba_B] = fgetc(ppm);
            p->ch[rgba_R] = fgetc(ppm);
        	p->ch[rgba_G] = fgetc(ppm);
        }
        SetRGBASpan(j, 0, width, buffer);
	}
	
	return(fclose(ppm));
}

#pragma mark -
// --- TIFF read/write ------------------------------------------------------


#ifdef GCL_TIFF

#include "tiffio.h"

Int Image::SaveTIFF(const Char *filename)
{
    TIFF	*tif;
    UInt32	samples_per_pixel = 3;
    UInt32	w = Width();
    UInt32	h = Height();
    UInt32	scanline_size = samples_per_pixel * w;
    UInt32	y, i, k;
    Char	*scanline_buf;
	RGBAPixel *rgba_buf;

    tif = TIFFOpen(filename, "w");
    if (!tif)
		return(-1);

    TIFFSetField(tif, TIFFTAG_IMAGEWIDTH, w);
    TIFFSetField(tif, TIFFTAG_IMAGELENGTH, h);

    /* These are the charateristics of our Pic data */
    TIFFSetField(tif, TIFFTAG_ORIENTATION, ORIENTATION_LEFTBOT);
    TIFFSetField(tif, TIFFTAG_SAMPLESPERPIXEL, samples_per_pixel);
    TIFFSetField(tif, TIFFTAG_BITSPERSAMPLE, 8);
    TIFFSetField(tif, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);
    TIFFSetField(tif, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_RGB);
    TIFFSetField(tif, TIFFTAG_COMPRESSION, COMPRESSION_LZW);
    /*
     * Predictors:
     *     1 (default) -- No predictor
     *     2           -- Horizontal differencing
     */
    TIFFSetField(tif, TIFFTAG_PREDICTOR, 2);
    
    if( TIFFScanlineSize(tif) != scanline_size )
    {
		fprintf(stderr,
			"TIFF: Mismatch with library's expected scanline size!\n");
		return(-1);
    }
    
    TIFFSetField(tif, TIFFTAG_ROWSPERSTRIP, TIFFDefaultStripSize(tif, 0));

    scanline_buf = new Char[scanline_size];
    rgba_buf = new RGBAPixel[scanline_size];

    if (!scanline_buf)
	{
		fprintf(stderr, "TIFF: Can't allocate scanline buffer!\n");
		return(-1);
    }
	
    for(y = 0; y < h; y++)
    {
		GetRGBASpan(y, 0, w, rgba_buf);
		k = 0;
		for (i = 0; i < w; i++)
		{
			scanline_buf[k++] = rgba_buf[i].ch[rgba_R];
			scanline_buf[k++] = rgba_buf[i].ch[rgba_G];
			scanline_buf[k++] = rgba_buf[i].ch[rgba_B];
		}
		
		TIFFWriteScanline(tif, scanline_buf, y, 0);
		/* note that TIFFWriteScanline modifies the buffer you pass it */
    }
    delete[] scanline_buf;
	delete[] rgba_buf;
	TIFFClose(tif);
    return(0);
}

Int Image::LoadTIFF(const Char *filename)
{
    TIFF		*tif;
    Int			result;
	UInt32		w, h;
	
    tif = TIFFOpen(filename, "r");
    if (!tif)
		return(-1);

    TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &w);
    TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &h);

	SetSize(h, w);

	result = TIFFReadRGBAImage(tif, w, h, (UInt32*) Ref(), 0);
    
	TIFFClose(tif);

    return(result);
}
#endif


// --- RGBAImage methods -------------------------------------


Void RGBAImage::SetSize(Int width, Int height)
{
	delete[] data;
	data = new RGBAPixel[width * height];
	SELF.width = width;
	SELF.height = height;
}

Void RGBAImage::Clear(const Colour &c)
{
	RGBAPixel	*p = data, bc = ColourToRGBA(c);
	Int			i;
	cout << "Clear colour: " << (UInt32&) bc << endl;		
	for (i = 0; i < width * height; i++, p++)
		*p = bc;
}

Void RGBAImage::SetPixel(Int x, Int y, const Colour &c)
{
	Assert(x >= 0 && y >= 0 && x < width && y < height, "illegal pixel access.");
	data[x + y * width] = ColourToRGBA(c);
}

Colour RGBAImage::GetPixel(Int x, Int y)
{
	Assert(x >= 0 && y >= 0 && x < width && y < height, "illegal pixel access.");
	return(RGBAToColour(data[x + y * width]));
}

Void RGBAImage::SetSpan(Int row, Int start, Int length, const Colour *src)
{
	Assert(row >= 0 && row < height && start >= 0 && start + length <= width, "(RGBAImage::GetSpan) illegal span access.");
	Int				i;
	RGBAPixel		*p = data + row * width + start;
	const Colour	*cp = src;
	
	for (i = 0; i < length; i++, p++, cp++)
		*p = ColourToRGBA(*cp);
}

Void RGBAImage::GetSpan(Int row, Int start, Int length, Colour *dst)
{
	Assert(row >= 0 && row < height && start >= 0 && start + length <= width, "(RGBAImage::GetSpan) illegal span access.");
	Int			i;
	RGBAPixel	*p = data + row * width + start;
	Colour		*cp = dst;
	
	for (i = 0; i < length; i++, p++, cp++)
		*cp = RGBAToColour(*p);
}


// --- ChannelImage methods -------------------------

#if 0
ChannelImage::ChannelImage() : tag('chan') {}
{
}
#endif

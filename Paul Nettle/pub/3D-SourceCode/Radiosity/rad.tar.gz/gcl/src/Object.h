/*
	File:			Object.h

	Function:		Definition of a polymorphic object. 
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

/*
	File:			Object.h

	Function:		Definition of the root class for . You can build polymorphic
					lists from such objects.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Object__
#define __Object__

#include <iostream.h>


class Object
{
public:
	virtual void	Print(ostream &s) const	{ s << "unknown"; };
	virtual void	Parse(istream &s)		{};
	virtual Object 	*Clone() const			{ return new Object; };
	virtual void	Free()					{ delete this; };
};

typedef Object *ObjectPtr;


// --- stream operators -----------------------------------------


inline ostream &operator << (ostream &s, ObjectPtr objPtr);
inline istream &operator >> (istream &s, ObjectPtr objPtr);
inline ostream &operator << (ostream &s, Object &obj);
inline istream &operator >> (istream &s, Object &obj);


// --- Utility routines -----------------------------------------


void ChompSpace(istream &s);


// --- Inlines ----------------------------------------------------------------


inline ostream &operator << (ostream &s, ObjectPtr objPtr)
{
	objPtr->Print(s);
	return(s);
}

inline istream &operator >> (istream &s, ObjectPtr objPtr)
{
	objPtr->Parse(s);
	return(s);
}

inline ostream &operator << (ostream &s, Object &obj)
{
	obj.Print(s);
	return(s);
}

inline istream &operator >> (istream &s, Object &obj)
{
	obj.Parse(s);
	return(s);
}


// --- Templates -----------------------------------------------------


template <class T> T *Clone(T *t)
{
	return((T *) t->Clone());
}

#endif

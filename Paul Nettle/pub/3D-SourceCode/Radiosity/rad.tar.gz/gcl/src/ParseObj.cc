#include "Parse.h"

#include <string.h>
#include <unistd.h>
#include "Scene.h"
#include "SceneObjects.h"
#include "Avars.h"
#include "SceneLang.h"

scScenePtr ParseObjFile(istream &s);

static void ReadPair(istream &s, Int &idx, Int &tidx)
{
	s >> idx;
	idx--;
	if (s.peek() == '/')
	{
		s.get();
		s >> tidx;
		tidx--;
	}
	else
		tidx = -1;
}

scScenePtr ParseObjFile(istream &s)
// Parses wavefront-style .obj file.
/*
	Format is: 'function args' on each line.
	
	v x y z				add vertex
	vt u v				add texture vert.
	fo 1 5 3 2			define poly
	fo 1/2 5/7 3/4		define poly with texture vertices...
	g group1 group2... 	set group names for following fo's.
	usemtl material		set material name for ...
*/
{
	String		func;
	Point		vtx;
	scScenePtr	result;
	Int			idx,  tidx;
	Int			vertices, faces;
	
	vertices = faces = 0;
	result = slBeginObject("untitled");
	slColour(cRed);
	slBeginPoints();

	while (s)
	{
		if (func.ReadWord(s))
		{
			if (func == "v")
			{
				s >> vtx[0] >> vtx[1] >> vtx[2];
				slPoint(vtx);
				func.ReadLine(s);
				vertices++;
			}
			else if (func == "fo" || func == "f")
			{
				slBeginIndexes();
				while(!IsEndOfLine(s))
				{
					ReadPair(s, idx, tidx);
					slIndex(idx);
				}
				slEndIndexes();
				slPoly();			
				func.ReadLine(s);
				faces++;
			}
			else if (func == "usemtl")
			{
				String material;
				
				material.ReadWord(s);
				
				if (material == "light")
				{
					slAttribute(new scAvarEmittance(Avar("light", 20, 5, 50), cWhite));
					scColour(cBlack);
				}
				else if (material == "red")
				{ slEmittance(cBlack); slColour(cRed);   }
				else if (material == "blue")
				{ slEmittance(cBlack); slColour(cBlue);   }
				else if (material == "green")
				{ slEmittance(cBlack); slColour(cGreen);   }
				else if (material == "grey")
				{
					slEmittance(cBlack); 
					slAttribute(new scAvarColour(Avar("tubeCol", 0.5, 0, 1), cWhite));
				}
				else
				{
					cerr << "*** Warning: unrecognized material: " << material << endl;
					slEmittance(cBlack); slColour(cGrey);
				}
				func.ReadLine(s);
			}
		}
	}
	
	slEndObject();
	
	cerr << "Read " << vertices << " vertices and " << faces << " faces." << endl;
	
	return(result);
}

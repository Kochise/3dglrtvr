/*
	File:			Geometry.cc

	Function:		Implements Geometry.h

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

	Change History:
		31/01/96	ajw		Started
*/

#include "Geometry.h"
#include <stdarg.h>

IndexList Indexes(Int first, ...)
{
	IndexList result;
	va_list ap;
	
	va_start(ap, first);
	
	while (first != IDX_END)	
	{
		result.Append(first);
		first = va_arg(ap, int);
	}
	
	va_end(ap);
	
	return(result);
}

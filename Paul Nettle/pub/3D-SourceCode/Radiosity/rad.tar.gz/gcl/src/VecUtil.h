/*
	File:		VecUtil.h
	
	Function:	Contains a grab-bag of useful graphics
				vector routines.

	Author:		Andrew Willmott, (c) 1996
 */
 
#ifndef __VecUtil__
#define __VecUtil__

#include "Geometry.h"


// --- Min & Max routines -------------------------------------


inline Real	MaxElt(Vector &v);
inline Real	MinElt(Vector &v);

inline Int	MaxEltIndex(Vector &v);
inline Int	MinEltIndex(Vector &v);

inline void FindMaxElts(Vector &a,  Vector &b, Vector &c);
inline void FindMinElts(Vector &a,  Vector &b, Vector &c);

inline void FindMaxCmpts(Colour &a, Colour &b, Colour &c);
inline void FindMinCmpts(Colour &a, Colour &b, Colour &c);

// --- Bounding box utility routines -------------------

inline Real BoxVol(Vector &min, Vector &max);
void UpdateBounds(const Point& pt, Point& min, Point& max);

// --- Inlines ---------------------------------------------------

inline Real MaxElt(Vector &v)
{
	return(Max(Max(v[0], v[1]), v[2]));
}

inline Real MinElt(Vector &v)
{
	return(Min(Min(v[0], v[1]), v[2]));
}

inline Int MinEltIndex(Vector &v)
{
	if (v[0] < v[1])
		if (v[0] < v[2])
			return(0);
		else
			return(2);
	else
		if (v[1] < v[2])
			return(1);
		else
			return(2);
}

inline Int MaxEltIndex(Vector &v)
{
	if (v[0] > v[1])
		if (v[0] > v[2])
			return(0);
		else
			return(2);
	else
		if (v[1] > v[2])
			return(1);
		else
			return(2);
}

inline void FindMaxElts(Vector &a,  Vector &b, Vector &c)
{
	c[0] = Max(a[0], b[0]);
	c[1] = Max(a[1], b[1]);
	c[2] = Max(a[2], b[2]);
}

inline void FindMinElts(Vector &a, Vector &b, Vector &c)
{
	c[0] = Min(a[0], b[0]);
	c[1] = Min(a[1], b[1]);
	c[2] = Min(a[2], b[2]);
}

inline void FindMaxCmpts(Colour &a, Colour &b, Colour &c)
{
	c[0] = Max(a[0], b[0]);
	c[1] = Max(a[1], b[1]);
	c[2] = Max(a[2], b[2]);
}

inline void FindMinCmpts(Colour &a, Colour &b, Colour &c)
{
	c[0] = Min(a[0], b[0]);
	c[1] = Min(a[1], b[1]);
	c[2] = Min(a[2], b[2]);
}

inline Real BoxVol(Vector &min, Vector &max)
{
	Vector t = max;

	t -= min;

	return(t[0] * t[1] * t[2]);
}


// --- Miscellaneous --------------------------------------


inline Bool PlaneIntersection(const Point& start, const Vector &direction,
			 Real d, const Vector &normal, Real &t)
//	returns true if given ray intersects the plane specified
//	by d and normal. (Plane eqn. is P.normal + d = 0)
//	If there is an intersection, t is set.
{
	Real normDotDirection = dot(normal, direction);
	
	if (normDotDirection == 0.0)
		return(false);

	t = (d + dot(normal, start)) / -normDotDirection;

	return(true);
}


inline Vector FindOrthoVector(const Vector &v)
{
	Vector u;
	
	// we choose the axis that is most orthogonal to v,
	// and return the cross product of it and v. Really!

	if (abs(v[0]) < abs(v[1]))
		if (abs(v[0]) < abs(v[2]))
		{	u[0] =     0; u[1] =  v[2]; u[2] = -v[1]; }
		else
		{	u[0] =  v[1]; u[1] = -v[0]; u[2] =     0; }
	else
		if (abs(v[1]) < abs(v[2]))
		{	u[0] = -v[2]; u[1] =     0; u[2] =  v[0]; }
		else
		{	u[0] =  v[1]; u[1] = -v[0]; u[2] =     0; }
		
	return(u);
}

Bool Refract(
		Real			fromIndex, 
		Real			toIndex,
		const Vector	&v,
		const Vector	&n, 
		Real			cosNV,
		Vector			&refractDir
	);
// Calculates the refraction vector for the given parameters. Returns true
// if total internal reflection occurs.

void CalcTriNonUnitNormal(Point& a, Point& b, Point& c, Vector& n);
// Sets n to the (unnormalised) normal of the triangle defined by points 
// a, b and c. Effectively returns the sum of the three possible edge 
// cross-products, for stability.
// <Note> the length of this vector is of course the area of the triangle. 

#endif

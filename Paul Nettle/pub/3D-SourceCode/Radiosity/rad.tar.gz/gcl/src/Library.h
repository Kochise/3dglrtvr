/*
	File:			Library.h

	Function:		A library for scene objects: objects can be added and 
					retrieved by name. Different libraries can be handed to
					scene construction / reading code in order to build
					scenes with an internal structure specific to a particular
					rendering / illumination method.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */


#ifndef __Library__
#define __Library__

#include "Basics.h"
#include "Array.h"
#include "SceneObjects.h"
#include "iostream.h"

class LibNode
{
	public:
		
	LibNode() : name(0), object(0) {};
	LibNode(Char *name, scPrimitive *objectPtr) : name(name), object(objectPtr) {};
	
	const char 	*name;
	scPrimitive	*object;
};

ostream &operator << (ostream &s, const LibNode &ln);

class Library
{
	public:
	
	Library();
	
	Int				AddMember(scScenePtr objectPtr);
	Int				AddMember(Char *name, scPrimitive *objectPtr);
	Bool			MemberExists(Char *name);
	scPrimitive		*Member(Char *name);
	scPrimitive		*Member(Int index);	
	
	virtual void	Create();	// must call this before using the library
	
	Array<LibNode>	members;
	
	Char *name;
};

ostream &operator << (ostream &s, const Library &library);

#endif

/*
	File:			Colour.h
	
	Function:		Definitions and classes for handling Colour

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */
 
#ifndef __Colour__
#define __Colour__

#ifndef CLR_DOUBLE
#include "VLf.h"
typedef Vec3f Colour;
typedef Vec3f Colour4;
typedef Mat3f CMat;
typedef Mat4f ClrTrans;
#else
#include "VLd.h"
typedef Vec3d Colour;
typedef Vec3d Colour4;
typedef Mat3d CMat;
typedef Mat4d ClrTrans;
#endif

#include "Array.h"

//	A Colour is a normal tri-stimulus colour.
//	Colour4 includes transparency/intensity info.

inline Colour	RGBCol(Real r, Real g, Real b)
				{ return(Colour(r, g, b)); }
Colour			HSVCol(Real hue, Real saturation, Real value);

typedef Colour Reflectance;
typedef Array<Colour> ColourList;
typedef Array<Colour4> Colour4List;
typedef Array<Reflectance> ReflList;

void ClipColour(Colour &c);
// Clips colour for display

// Useful conversion factors

const Reflectance cRGBToNTSCLum(0.299, 0.587, 0.114);	
// Converts RGB to greyscale, assuming we're in an NTSC colourspace with
// gamma = 2.2

const Reflectance cRGBToLum(0.3086, 0.6094, 0.0820);	
// Convert RGB to greyscale, assuming a linear colour space.
// From Haeberli's colour notes

const CMat	cNTSCToCIE(
				0.67, 0.21, 0.14,			// From Sillion & Puesch
				0.33, 0.71, 0.08,			// "Radiosity", pp 211.
				0.00, 0.08, 0.78); 

const CMat	cCIEToNTSC(
				1.730, -0.482, -0.261,
			   -0.814,  1.652, -0.023,
				0.083, -0.169,  1.284); 

const Colour cBlack(0, 0, 0);
const Colour cWhite(1, 1, 1);

const Colour cGrey(cWhite * 0.5);
const Colour cGrey25(cWhite * 0.25);
const Colour cGrey50(cWhite * 0.5);
const Colour cGrey75(cWhite * 0.75);

const Colour cRed(1, 0, 0);
const Colour cOrange(1, 0.5, 0);
const Colour cYellow(1, 1, 0);
const Colour cGreen(0, 1, 0);
const Colour cCyan(0, 1, 1);
const Colour cBlue(0, 0, 1);
const Colour cPurple(1, 0, 1);

// HSV constants

const Int hsvRed    =    0;
const Int hsvOrange =   30;
const Int hsvYellow =   60;
const Int hsvGreen  =  120;
const Int hsvCyan   =  180;
const Int hsvBlue   =  240;
const Int hsvPurple =  300;

// --- Colour transformations ----------------------------------------

ClrTrans	RGBScale(Real rscale, Real gscale, Real bscale);
ClrTrans	RGBOffset(const Colour &c);
ClrTrans	RGBSaturate(Real sat);
ClrTrans	RGBHueRotate(Real degrees);
ClrTrans	RGBToLum();

#endif

/*
	File:			XGraphicsSystem.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			Obsoletes GraphicsSystem.cc

					The BackedPane still isn't completely sorted out; it would
					be nice if when you treated it as an XPane, you got the
					backing pane, rather than having to do:
					CopyPane(a.backBuffer, b.backBuffer);

*/

#include "XGraphicsSystem.h"

#include <unistd.h>
#include <iostream.h>


//	Attributes for a normal, 24-bit, z-buffered window
 
static int attributeList[] = 
			{GLX_RGBA, GLX_DEPTH_SIZE, 12, GLX_RED_SIZE, 8, None};

//	Attributes for a normal, 24-bit, z-buffered and double-buffered window 

static int dblAttributeList[] = 
			{GLX_RGBA, GLX_DEPTH_SIZE, 12, GLX_DOUBLEBUFFER, None};


// --- XWindows-specific Graphics System... -----------------------------------


Bool GraphicsSystem::finished = 0; 

GraphicsSystem::GraphicsSystem() : hasGC(0)
//	Initialise the system
{
	itsEventsMask = 
		StructureNotifyMask | KeyPressMask | ButtonPressMask | ExposureMask;

	display = XOpenDisplay(0);
	
	Assert(display != 0, "Can't open connection to X W**dows server.");
	
	visualInfo = 
		glXChooseVisual(display, DefaultScreen(display), attributeList);

	Assert(visualInfo != 0, "Can't obtain true-colour/z-buffered display");
	
	dblVisualInfo = 
		glXChooseVisual(display, DefaultScreen(display), dblAttributeList);	
	
	Expect(dblVisualInfo != 0, "*** Warning: can't get double-buffered display");
	
	if (dblVisualInfo == 0)				// If we can't grab a double-buffered 
		dblVisualInfo = visualInfo;		// display, default to single-buffered.
}

GraphicsSystem::~GraphicsSystem()
{
}

void GraphicsSystem::Spin()
{
	XEvent		event;
	Int			i;
	
	for (i = 0; i < paneList.NumItems(); i++)
		if (XCheckWindowEvent(display, paneList[i]->paneXID, 
				ButtonPressMask | KeyPressMask | ExposureMask, &event))
			paneList[i]->HandleEvent(&event);
}

void GraphicsSystem::Run()
{
	while (!finished)
		Spin();
	finished = false;
}

void GraphicsSystem::GetMouse(XEventPane *xpane,
	Int *x, Int *y, UInt *keyState)
{
	Int 	x1, x2;
	Window 	d1, d2;
	
	XQueryPointer(display, xpane->paneXID, &d1, &d2, &x1, &x2, x, y, keyState);
}

void XEventPane::GetMouse(Int *x, Int *y, UInt *keyState)
{
	parent->GetMouse(this, x, y, keyState);
};

static int WaitForNotify(Display *display, XEvent *event, char *arg)
{
	return((event->type == MapNotify) && (event->xmap.window == (Window) arg));
}

void GraphicsSystem::CreateWindow(XEventPane *xpane, Char *title, 
		Int width, Int height)
{
	XSetWindowAttributes	windowAttributes;
	XEvent					event;
	Colormap				colourMap;
	XVisualInfo				*theVisualInfo;
		
	if (xpane->doubleBuffered)
		theVisualInfo = dblVisualInfo;
	else
		theVisualInfo = visualInfo;
		
	colourMap = XCreateColormap(display,
		RootWindow(display, theVisualInfo->screen), theVisualInfo->visual, 
		AllocNone);

	windowAttributes.colormap = colourMap;
	windowAttributes.border_pixel = 0;
	
	windowAttributes.event_mask = itsEventsMask; 

	xpane->paneXID = XCreateWindow(display,
		RootWindow(display, theVisualInfo->screen), 0, 0, width, height,
		0, theVisualInfo->depth, InputOutput, theVisualInfo->visual,
		CWBorderPixel | CWColormap | CWEventMask, &windowAttributes);

	XMapWindow(display, xpane->paneXID);

	//	Wait for notify...

	XIfEvent(display, &event, WaitForNotify, (char *) xpane->paneXID);

	xpane->width = width;
	xpane->height = height;
	xpane->parent = this;
	
	//	Create a graphics context if it hasn't been done before...
	
	if (!hasGC)	
		theGC = XCreateGC(display, xpane->paneXID, 0, 0);

	XStoreName(display, xpane->paneXID, title);
	XSetIconName(display, xpane->paneXID, title);
	
	paneList.Append(xpane);
	
	xpane->Init();
}

void GraphicsSystem::CreateSubwindow(XEventPane *xpane, Window parent,
		Int x, Int y, Int width, Int height)
//	Create a sub-window in the parent window.
{
	XSetWindowAttributes	windowAttributes;
	XEvent					event;
	Colormap				colourMap;
	XVisualInfo				*theVisualInfo;
	
	if (xpane->doubleBuffered)
	      theVisualInfo = dblVisualInfo;
	else
	      theVisualInfo = visualInfo;
		
	colourMap = XCreateColormap(display,
		RootWindow(display, theVisualInfo->screen), theVisualInfo->visual,
		AllocNone);

	windowAttributes.colormap = colourMap;
	windowAttributes.border_pixel = 0;
	windowAttributes.event_mask = itsEventsMask;

	xpane->paneXID = XCreateWindow(display,
		parent, x, y, width, height,
		0, theVisualInfo->depth, InputOutput, theVisualInfo->visual,
		CWBorderPixel | CWColormap | CWEventMask, &windowAttributes);

	XMapWindow(display, xpane->paneXID);

	//	Wait for notify...

	XIfEvent(display, &event, WaitForNotify, (char *) xpane->paneXID);

	xpane->width = width;
	xpane->height = height;
	xpane->parent = this;
	
	//	Create a graphics context if it hasn't been done before...
	
	if (!hasGC)	
		theGC = XCreateGC(display, xpane->paneXID, 0, 0);

	xpane->Init();
}

void GraphicsSystem::CreateOffscreen(XPane *xpane, Int width, Int height)
//	Create an offscreen buffer.
{
	XSetWindowAttributes	windowAttributes;
	XEvent					event;
	Colormap				colourMap;	

	//	Create the Pixmap
	
	xpane->paneXID = XCreatePixmap(display, RootWindow(display,
		visualInfo->screen), width, height, visualInfo->depth);
						    	
	xpane->doubleBuffered = 0;
	xpane->width = width;
	xpane->height = height;
	xpane->parent = this;
	
	xpane->Init();
}

void CopyPane(XPane &from, XPane &to)
{
	XCopyArea(from.parent->display, from.paneXID, to.paneXID,
		from.parent->theGC, 0, 0, from.width, from.height, 0, 0);
}


#pragma mark -
// --- XPane class ------------------------------------------------------------


XPane::XPane(Bool doubleBuffer) : parent(0), doubleBuffered(doubleBuffer)
{
}

void XPane::Init()
{
}

XPane::~XPane()
{
	if (parent)
		XFreePixmap(parent->display, paneXID);
}


#pragma mark -
// --- XEventPane class -------------------------------------------------------


void XEventPane::HandleEvent(XEvent *event)
{	
	if (event->type == KeyPress)	// terminate whole system on an escape...
	{
		char temp[4];
		
		XLookupString((XKeyEvent *) event, temp, sizeof(temp) - 1, NULL, NULL);
		if (temp[0] == 0x1B)
			parent->finished = 1;
	}
}

XEventPane::~XEventPane()
{	
	if (parent)
	{
		Int i;
		
		for (i = 0; i < parent->paneList.NumItems(); i++)
			if (parent->paneList[i] == this)
				parent->paneList.Delete(i, 1);
				
		XDestroyWindow(parent->display, paneXID);
	}
}

#pragma mark -
// --- GSPane class -----------------------------------------------------------

static void SetGLOptions()
{
	glMatrixMode(GL_MODELVIEW);
	glEnable(GL_DEPTH_TEST);
	glCullFace(GL_BACK);
	glEnable(GL_CULL_FACE);
}

void GSPane::Init()
//	Attach GL context to a drawing environment
{
	XVisualInfo		*theVisualInfo;
	
	if (doubleBuffered)
		theVisualInfo = parent->dblVisualInfo;
	else
		theVisualInfo = parent->visualInfo;

	context = glXCreateContext(parent->display, theVisualInfo, 0, GL_TRUE);
	glXMakeCurrent(parent->display, paneXID, context);
	
	glWidth = width; 
	glHeight = height;

	SetGLOptions();
}

void GSPane::MakeCurrent()
{
	Assert(parent != 0, "Tried to manipulate a non-attached renderer");

	if (!glXMakeCurrent(parent->display, paneXID, context))	
		Assert(0, "Couldn't swap graphics context");
}

void GSPane::Show()
{
	GLRenderer::Show();
	
	if (doubleBuffered)
		glXSwapBuffers(parent->display, paneXID);
}

#pragma mark -
// --- GSOffscreenPane class --------------------------------------------------

void GSOffscreenPane::Init()
//	Attach GL context to a drawing environment
{
	pixmap = glXCreateGLXPixmap(parent->display, parent->visualInfo, paneXID);
	context = 
		glXCreateContext(parent->display, parent->visualInfo, 0, GL_FALSE);
		
	glXMakeCurrent(parent->display, pixmap, context);

	glWidth = width; 
	glHeight = height;
	
	SetGLOptions();
}

void GSOffscreenPane::MakeCurrent()
{
	Assert(parent != 0, "Tried to manipulate a non-attached renderer");

	if (!glXMakeCurrent(parent->display, pixmap, context))
		Assert(0, "Couldn't swap graphics context");
}

GSOffscreenPane::~GSOffscreenPane()
{
	if (parent)
		glXDestroyGLXPixmap(parent->display, pixmap);
}

#pragma mark -
// --- GSBackedPane class -----------------------------------------------------

void GSBackedPane::Init()
//	Attach GL context to a drawing environment
{
	parent->CreateOffscreen(&backBuffer, width, height);

	pixmap = glXCreateGLXPixmap(parent->display, parent->visualInfo, 
		backBuffer.paneXID);
	context = glXCreateContext(parent->display, parent->visualInfo,
		0, GL_FALSE);
	glXMakeCurrent(parent->display, pixmap, context);
	
	glWidth = width; 
	glHeight = height;
	
	SetGLOptions();
}

void GSBackedPane::MakeCurrent()
{
	Assert(parent != 0, "Tried to manipulate a non-attached renderer");

	if (!glXMakeCurrent(parent->display, pixmap, context))
		Assert(0, "Couldn't swap graphics context");
}

void GSBackedPane::Show()
//	Attach GL context to a drawing environment
{
	GLRenderer::Show();
	
	CopyPane(backBuffer, SELF);
}

void GSBackedPane::HandleEvent(XEvent *event)
{
	if (event->type == Expose)
		Show();
	else
		XEventPane::HandleEvent(event);
}


GSBackedPane::~GSBackedPane()
{
	if (parent)
		glXDestroyGLXPixmap(parent->display, pixmap);
}



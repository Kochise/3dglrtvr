/*
	File:			EPSRenderer.h

	Function:		Renders line drawings to a .eps file.
	
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __EPSRenderer__
#define __EPSRenderer__

#include "Renderer.h"
#include "EPSPlot.h"

// --- The EPSRenderer class -----------------------------------------------------


class EPSRenderer : public Renderer
{
public:
	EPSRenderer();

	void				Attach(Char *epsFilename);
	
	virtual void		Show();
	virtual void 		MakeCurrent();
	virtual void 		Print(ostream &s);

	virtual Renderer	&Begin(RenderStyle style);
	virtual Renderer	&End();

	virtual Renderer	&SetPoint(const Point &p);
	virtual Renderer	&SetNormal(const Vector &p);
	virtual Renderer	&SetCoord(const Coord &c);
	virtual Renderer	&SetColour(const Colour &c);

	virtual Renderer	&SetTransform(const Transform &t);
	virtual Renderer	&SetCamera(const Camera &c);

	virtual Renderer	&Clear();
	virtual Renderer	&Pop();
	virtual Renderer	&Push();

	virtual Renderer	&Rect(Real left, Real up, Real right, Real down); 								
	virtual Renderer	&GetImage(Image &image) {return SELF;};
	virtual Renderer	&PutImage(Image &image, Int x = 0, Int y = 0) {return SELF;};

	// short-cuts

protected:
	void MoveTo(Real x, Real y);
	void LineTo(Real x, Real y);

	Array<Transform>	matrixStack;
	RenderStyle			style;
	Bool				start;
	Point				firstPoint;
	Point				lastPoint;
	EPSPlot				itsPlot;
	Char				*itsFilename;
};

#endif

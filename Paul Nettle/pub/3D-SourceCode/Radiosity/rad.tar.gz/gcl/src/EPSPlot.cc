/*
 * ps.c: device dependent code for libplot output in postscript.
 * Tuned for Apple Laser Writer
 *
 * device coordinates (viewport) is in inches
 */

#include "EPSPlot.h"
#include "Geometry.h"
#include <string.h>

// --- eps header ------------------------------

static char header[] = "\
%%!PS-Adobe-3.0 EPSF-3.0\n\
%%%%BoundingBox: %d %d %d %d\n\
%%%%Title: %s\n\
%%%%Creator: PSPlot class\n\
";

// --- our little ps library  ------------------------------

static char definitions[] = "\
/m {moveto} def\n\
/d {lineto} def\n\
/t {moveto show} def\n\
/p {stroke} def\n\
/dot {newpath 0 360 arc closepath fill} def\n\
/cir {newpath 0 360 arc closepath stroke} def\n\
\n\
/defaultfontmatrixinv       % inverse of matrix for unscaled font\n\
/Helvetica findfont /FontMatrix get matrix invertmatrix\n\
def\n\
\n\
% showpos: draw string with character-relative positioning\n\
% input: x y fx fy str\n\
%\n\
% where (x,y) is point in user space at which to position (fx,fy) of char space\n\
% where char space has (0,0) at origin of string,\n\
% (0,1) is interline spacing vector\n\
% and (length(str),0) is end of string vector\n\
%\n\
% e.g.  (fx,fy)=(0,0) lower-left justifies,\n\
%       (.5*length(str),.5) centers,\n\
%       (length(str),1) upper-right justifies\n\
%\n\
/showpos {\n\
                                    % x y fx fy str\n\
    dup 6 1 roll                    % str x y fx fy str\n\
    dup length                      % str x y fx fy str len\n\
    4 -1 roll exch div              % str x y fy str fx/len (relative fx)\n\
    3 1 roll                        % str x y fx' fy str\n\
\n\
    % find vector (hx,hy) along width of string and scale it by fx':\n\
    stringwidth                     % str x y fx' fy hx hy\n\
    3 index mul exch                % str x y fx' fy fx'*hy hx\n\
    4 -1 roll mul                   % str x y fy fx'*hy fx'*hx\n\
\n\
    % find vector (vx,vy) along height of string and scale it by fy:\n\
    0 1                     % str x y fy hy' hx' 0 1\n\
    currentfont /FontMatrix get     % .. FD     (font to device transform)\n\
    defaultfontmatrixinv matrix     % .. FD DU mat  (times device to user transform)\n\
    concatmatrix                    % .. FU (equals relative,font to user transform)\n\
                                    % str x y fy hy' hx' 0 1 FU\n\
    transform                       % str x y fy hy' hx' vx vy\n\
    4 index mul exch                % str x y fy hy' hx' fy*vy vx\n\
    5 -1 roll mul                   % str x y hy' hx' fy*vy fy*vx\n\
                                    % str x y hy hx vy vx   (drop the primes)\n\
\n\
    % add the displacement vectors (hx,hy) and (vx,vy):\n\
    3 -1 roll add                   % str x y hy vy hx+vx\n\
    3 1 roll add                    % str x y hx+vx hy+vy\n\
                                    % str x y dx dy     (abbrev)\n\
\n\
    % subtract from reference point:\n\
    3 -1 roll exch sub              % str x dx y-dy\n\
    3 1 roll sub exch               % str x-dx y-dy\n\
    moveto show                     %           (yay!)\n\
} def\n\
\n";


// --- EPSPlot class ---------------------------------------


EPSPlot::EPSPlot() : 
	file(0),
	drawn(false),
	font("Helvetica"),
	width(1),
	scale(144)		// default 2" x 2"
{
}

void EPSPlot::Open(Char *filename)
{
    if (strcmp(filename, ".") == 0)
    	file = stdout;
    else if ((file = fopen(filename, "w")) == NULL)
    {
		fprintf(stderr, "plot_ps_open: Can't write %s\n", filename);
		return;
    }
    
    fprintf(file, header, 0, 0, (int) scale, (int) scale, "plot");
    fputs(definitions, file);
	
	// border
	
	fprintf(file, "0.1 setlinewidth\n");
	fprintf(file, "%g %g %g %g rectstroke\n", 0.0, 0.0, scale, scale);
	
	// make sure everything outside viewport is clipped.
	
	fprintf(file, "%g %g %g %g rectclip\n", 0.0, 0.0, scale, scale);
    
	// scale down so coord. sys. is [0,1].
	
	fprintf(file, "%g %g scale\n", scale, scale);
}

void EPSPlot::Close()
{
    if (drawn)
    	Stroke();
    fprintf(file, "showpage\n");
    fclose(file);
}

// --- Drawing commands ------------------------------

void EPSPlot::MoveTo(Real x, Real y)
{
    if (drawn)
    	Stroke();
    fprintf(file, "%.4g %.4g m\n", x, y);
}

void EPSPlot::LineTo(Real x, Real y)
{
    drawn = 1;
    fprintf(file, "%.4g %.4g d\n", x, y);
}

void EPSPlot::Stroke()
{
    fprintf(file, "p\n");
    drawn = 0;
}

void EPSPlot::SetWidth(Real width)
{
	if (drawn)
		Stroke();
	fprintf(file, "%g setlinewidth\n", width);
}

void EPSPlot::LineStyle(Int style)
{
    if (drawn)
    	Stroke();
    switch (style)
    {
	case lineDashed:
		fprintf(file, "[.06 .04] 0 setdash\n");
		break;
	case lineDotted:
		fprintf(file, "[.015 .03] 0 setdash\n");
		break;
	default:
	    fprintf(stderr, "ps_line_style: don't know style %d\n", style);
	    /* fall through */
	case lineSolid:
		fprintf(file, "[] 0 setdash\n");
		break;
    }
}

//void PSPlot::SetColour(Colour c)
//{
//	fprintf("%g %g %g setcolor\n", c[0], c[1], c[2]);	// XXX need to specify colour space in prefix?
//}

void EPSPlot::SetGrey(Real level)
{
	fprintf(file, "%g setgray\n", level);
}

/*------------------------------ GRAPHICS ------------------------------*/


void EPSPlot::Dot(Real x, Real y, Real r)
{
    if (drawn)
    	Stroke();
    fprintf(file, "%.4g %.4g %.4g dot\n", x, y, r);
}

void EPSPlot::Circle(Real x, Real y, Real r)
{
    if (drawn)
    	Stroke();
    fprintf(file, "%.4g %.4g %.4g cir\n", x, y, r);
}

/*------------------------------ TEXT ------------------------------*/

void EPSPlot::DrawText(Real x, Real y, Char *string)
{
    fprintf(file, "(%s) %.4g %.4g t\n", string, x, y);
}

#if 0
/*
 * ps_text_pos: position string str so that a specified point relative to
 * the string is at (x,y)
 * xjust controls x justification: 0.=left, .5*n=center, 1.*n=right
 *		where n=strlen(str)
 * yjust controls y justification: -.3=descender, 0.=baseline, .5=center, 1.=top
 *
 * EXAMPLE: to center at (x,y):
 *	plot_text_pos(p, x, y, .5*strlen(str), .5, str);
 */
 
void EPSPlot::TextPos(Real x, Real y, Real xjust, Real yjust, Char *string)
{
    fprintf(file, "%.4g %.4g %.4g %.4g (%s) showpos\n",
		x, y, xjust, yjust, string);
}

/*
 * ps_char_size: set character size
 * size is inter-line spacing (leading) in world units
 */
 
void EPSPlot::CharSize(Real size)
{
    if (active)
		fprintf(file, "/%s findfont %g scalefont setfont\n",
		    font, size * scale);	/* convert to device units */
    mx3d_scale_mat(size, size, p->charmap);
}

/*
 * EPSPlot::char_transform: set the character space-to-world space mapping to m
 */
void EPSPlot::char_transform(p, m)
Plot *p;
Mx3d m;
{
    double s;

    if (p->active) {
	s = p->worldscale;
	fprintf(file, "/%s findfont [%g %g %g %g %g %g] makefont setfont\n",
	    FONT, s*m[0][0], s*m[0][1], s*m[1][0], s*m[1][1], m[2][0], m[2][1]);
    }
    mx3d_copy(m, p->charmap);
}

#endif

/*------------------------------ TRANSFORMATION ------------------------------*/

void EPSPlot::SetOutputSize(Real size)
{
	scale = size;
}

void EPSPlot::SetPort(Real left, Real bottom, Real right, Real top, Bool centred)
{
	Scale(1.0 / (right - left), 1.0 / (top - bottom));
	if (centred)
		Translate((right - left) / 2.0, (top - bottom) / 2.0);
	else
		Translate(-left, -bottom);
}

void EPSPlot::Push()
{
    if (drawn)
    	Stroke();
    fprintf(file, "gsave\n");
}

void EPSPlot::Pop()
{
    if (drawn)
    	Stroke();
    fprintf(file, "grestore\n");
}

void EPSPlot::Translate(Real tx, Real ty)
{
    fprintf(file, "%.4g %.4g translate\n", tx, ty);
}

void EPSPlot::Scale(Real sx, Real sy)
{
    fprintf(file, "%.4g %.4g scale\n", sx, sy);
}

void EPSPlot::Rotate(Real angle)
{
    fprintf(file, "%.4g rotate\n", RadsToDegs(angle));
}

/*------------------------------ MISC ------------------------------*/

void EPSPlot::Comment(Char *string)
{
    fprintf(file, "%% %s\n", string);
}



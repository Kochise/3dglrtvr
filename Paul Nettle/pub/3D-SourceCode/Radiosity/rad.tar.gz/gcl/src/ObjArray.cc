/*
	File:			ObjArray.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			Parse routines yet to be finished
					Object may have to be split out.

	Change History:
		25/02/96	ajw		Started
		04/03/96	ajw		Split out object to Object.h
*/

#include "ObjArray.h"
#include <ctype.h>


ObjArray::ObjArray(Int size, Int alloc) : items(size),
					allocated(alloc)
{
	Assert(size > 0, "(ObjArray) Initial array size must be positive!");
	Assert(alloc >= size, "(ObjArray) Initial array allocation must be >= size!");
	
	item = new ObjectPtr[allocated];
	Assert(item != 0, "(ObjArray) Out of memory");
}

ObjArray::ObjArray(const ObjArray &array) : items(array.items), allocated(array.allocated)
{
	Int i;
	
	if (allocated)
	{
		item = new ObjectPtr[allocated];
		Assert(item != 0, "(ObjArray) Out of memory");
	}
	else
		item = 0;
		
	
	for (i = 0; i < array.items; i++)
		item[i] = array.item[i]->Clone();
}

ObjArray::~ObjArray()
{
}


// --- ObjArray operators ----------------------------------------


ObjArray &ObjArray::operator >> (Action<ObjectPtr> &a)
{
	Int i;
	
	a.Start();
	
	for (i = 0; i < items; i++)
		a.Process(item[i]);
		
	a.Stop();
	
	return(SELF);
}

ObjArray &ObjArray::operator = (const ObjArray &array)
{
	Int i;

	Clear();

	if (allocated < array.allocated)
	{
		delete[] item;
		allocated = array.allocated;	
		item = new ObjectPtr[allocated];	
		Assert(item != 0, "(ObjArray) Out of memory");
	}
			
	for (i = 0; i < array.items; i++)
		item[i] = array.item[i]->Clone();

	items = array.items;
	
	return(SELF);
}

void ObjArray::Print(ostream &s)
{	
	Int i;

	s << '[';
	
	if (NumItems() > 0)
	{
		item[0]->Print(s);

		for (i = 1; i < NumItems(); i++)
			item[i]->Print(s << ' ');
	}
	
	s << ']';
}

void ObjArray::Parse(istream &s)
{
    Char	c;
	
	//	Expected format: [a b c d ...]
	
	ChompSpace(s);
		
    if (s.peek() == '[')						
    {
    	s.get(c);
    	Clear();
    	
		ChompSpace(s);
    	
		while (s.peek() != ']')
		{			
			Add(1);
			Top()->Parse(s);				//	read an item
    	
			if (!s)
			{
				Expect(false, "Couldn't read array component");
				return;
			}
	
			ChompSpace(s);
		}			
		s.get(c);
	}
    else
	{
	    s.clear(ios::failbit);
	    Expect(false, "Error: Expected '[' while reading array");
	}
}


// --- ObjArray Methods --------------------------------------------


void ObjArray::Clear()
{	
	Int i;
	
	for (i = 0; i < items; i++)
		item[i]->Free();

	items = 0;
}

void ObjArray::Free()
{	
	Clear();
	delete item;
}

ObjectPtr ObjArray::Clone()
{	
	ObjectPtr result = new ObjArray(SELF);
	
	return(result);
}

void ObjArray::SetSize(Int newSize)
{
	Int	i;
	ObjectPtr	*newObjArray;
	
	if (newSize > allocated)
	{
		if (allocated == 0)
			allocated = kFirstObjAlloc;
		else
			allocated *= 2;	
		
		while (newSize > allocated)
			allocated *= 2;	
		
		newObjArray = new ObjectPtr[allocated];
	
		for (i = 0; i < items; i++)
			newObjArray[i] = item[i];	
		
		delete[] item;
		item = newObjArray;
	}
	items = newSize;
}

void ObjArray::Add(Int n)
{
	SetSize(items + n);
}

void ObjArray::Shrink(Int n)
//	take away n items.
{
	items -= n;
}

void ObjArray::Insert(Int i, Int n)
//	Make space at position i for n items.
{
	Assert(i >= 0 && i <= items, "(ObjArray:InsertSpace) Illegal index");

	Int j;
	
	Add(n);
	
	for (j = items - 1; j >= i + n; j--)	// XXX should clear new slots to 0
		item[j] = (item - n)[j];
}

void ObjArray::Delete(Int i, Int n)
//	Delete n items at position i.
{
	Assert(i >= 0 && i <= items, "(ObjArray:InsertSpace) Illegal index");

	Int j;
	
	for (j = i; j < i + n; j++)
		item[j]->Free();
	
	items -= n;
		
	for (j = i; j < items; j++)
		item[j] = (item + n)[j];	
}

void ObjArray::ShrinkWrap()
//	Shrink allocated space to be only the current size of array
{
	// There is no realloc version of new in C++, so this involves another copy...
	
	Int	i;
	ObjectPtr	*newObjArray;
	
	allocated = items;	
	
	newObjArray = new ObjectPtr[allocated];

	for (i = 0; i < items; i++)
		newObjArray[i] = item[i];	
	
	delete[] item;
	item = newObjArray;
}

void ObjArray::Grow()
//	Allocate more space for the array. Used internally prior to an items++.
{
	Int	i;
	ObjectPtr	*newObjArray;
	
	if (allocated == 0)
		allocated = kFirstObjAlloc;
	else
		allocated *= 2;	
	
	newObjArray = new ObjectPtr[allocated];

	for (i = 0; i < items; i++)
		newObjArray[i] = item[i];	
	
	delete[] item;
	item = newObjArray;
}

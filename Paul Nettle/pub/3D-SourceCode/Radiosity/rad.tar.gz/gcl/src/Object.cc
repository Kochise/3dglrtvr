/*
	File:			Object.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

	Change History:
		04/03/96	ajw		Started
*/

#include "Object.h"
#include <ctype.h>

void ChompSpace(istream &s)
{
	char	c;
	
    while (isspace(s.peek()))				// 	chomp white space
		s.get(c);
}

/*
	File:			XGraphicsSystem.h

	Function:		Provides an XWindows-based implementation of the
					Renderer object. See Renderer.h
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __XGraphicsSystem__
#define __XGraphicsSystem__

#include <iostream.h>
#include <GL/gl.h>
#include <GL/glx.h>
#include <GL/glu.h>

#undef Bool			// The X cruft #defines Bool to be nothing(!), so we undef it.
					// Oh for a world without X Windows.

#include "Basics.h"
#include "Geometry.h"
#include "Colour.h"
#include "Camera.h"
#include "GLRenderer.h"
#include "Image.h"

class XEventPane;
class XPane;


// --- Graphics System class --------------------------------------------------

// List of all panes under our control.
typedef Array<XEventPane *> PaneList; 

class GraphicsSystem
{
public:
					GraphicsSystem();
					~GraphicsSystem();
	 
	void			CreateWindow(XEventPane *xpane, 
						Char *title = "OpenGL window", Int width = 400,
						Int height = 400);
	void			CreateSubwindow(XEventPane *xpane, Window parent, Int x = 0,
						Int y = 0, Int width = 400, Int height = 400);
	void			CreateOffscreen(XPane *xpane,
						Int width = 400, Int height = 400);

	virtual void 	Spin();
	virtual void 	Run();
	
	static Bool		finished;		// True when the system should quit.

	friend void		CopyPane(XPane &from, XPane &to);
	virtual void	GetMouse(XEventPane *xpane, Int *x, Int *y, UInt *keyState);
	
	//	Private...
	
	Display			*display;
	XVisualInfo		*visualInfo;
	XVisualInfo		*dblVisualInfo;
	long			itsEventsMask;
	Bool			hasGC;
	GC				theGC;
	PaneList		paneList;
};


// --- X window panes ---------------------------------------------------------

class XPane
{
public:
					XPane(Bool doubleBuffered = 0);
					~XPane();
					
	virtual void 	Init();

	XID				paneXID;
	Int				width, height;
	GraphicsSystem	*parent;
	Bool			doubleBuffered;
};

class XEventPane : public virtual XPane
//	can handle events...
{
public:

					XEventPane(Bool doubleBuffer = 0) : XPane() {doubleBuffered = doubleBuffer;};

					~XEventPane();
	
	virtual void	HandleEvent(XEvent *event);
	void			GetMouse(Int *x, Int *y, UInt *keyState);
};


// --- Pane classes -----------------------------------------------------------


// event-handling canvas you can draw into

class GSPane : public GLRenderer, public XEventPane
{
public:
					GSPane(Bool doubleBuffer = 0) : XEventPane(doubleBuffer),  \
						GLRenderer(100, 100) {};

	void			Init();
	void			MakeCurrent();
	void			Show();

protected:	
	GLXContext		context;
};

// offscreen canvas you can draw into 

class GSOffscreenPane : public GLRenderer, public XPane
{
public:
	
					GSOffscreenPane() : XPane(0),  GLRenderer(100, 100) {};
					~GSOffscreenPane();

	void			Init();
	void			MakeCurrent();
	
protected:
	GLXContext		context;
	GLXPixmap		pixmap;
};

// as above, but on show canvas is mirrored into an onscreen window...

class GSBackedPane : public GSPane
{
public:
					GSBackedPane() : GSPane(0) {};
					~GSBackedPane();

	void			Show();
	void			Init();
	void			MakeCurrent();
	void			HandleEvent(XEvent *event);
	
	XPane			backBuffer;

protected:
	GLXContext		context;
	GLXPixmap		pixmap;
};


#endif

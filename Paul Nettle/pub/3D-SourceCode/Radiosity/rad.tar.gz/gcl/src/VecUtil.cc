/*
	File:		VecUtil.cc
	
	Function:	Contains a grab-bag of useful graphics
				vector routines.

	Author:		Andrew Willmott, (c) 1996
	
*/

#include "VecUtil.h"

Bool Refract(
		Real			fromIndex, 
		Real			toIndex,
		const Vector	&v,
		const Vector	&n, 
		Real			cosNV,
		Vector			&refractDir
	)
// Calculates the direction of refraction
// returns true if total internal reflection occurs
{
	Real	kn, cos2, k;
	
	kn = fromIndex / toIndex;
	cos2 = 1.0 - sqr(kn) * (1.0 - sqr(cosNV));

	if (cos2 < 0.0)
		return(1);			// Total internal reflection!
			
	k = kn * cosNV - sqrt(cos2);
	
	refractDir = -kn * v + k * n;

	return(0);
}

void CalcTriNonUnitNormal(Point& a, Point& b, Point& c, Vector& n)
{
	// Sets n to the (unnormalised) normal of the triangle defined by points a, b and c.
	// Effectively returns the sum of the three possible edge cross-products, for stability.
	// <Note> the length of this vector is of course the area of the triangle. 

	n[0] = (a[1] - b[1]) * (a[2] + b[2]) + (b[1] - c[1]) * (b[2] + c[2]) + (c[1] - a[1]) * (c[2] + a[2]);
	n[1] = (a[2] - b[2]) * (a[0] + b[0]) + (b[2] - c[2]) * (b[0] + c[0]) + (c[2] - a[2]) * (c[0] + a[0]);
	n[2] = (a[0] - b[0]) * (a[1] + b[1]) + (b[0] - c[0]) * (b[1] + c[1]) + (c[0] - a[0]) * (c[1] + a[1]);
}

void UpdateBounds(const Point& pt, Point& min, Point& max)
{
	if (min[0] > pt[0])
		min[0] = pt[0];
	else if (max[0] < pt[0])
		max[0] = pt[0];

	if (min[1] > pt[1])
		min[1] = pt[1];
	else if (max[1] < pt[1])
		max[1] = pt[1];

	if (min[2] > pt[2])
		min[2] = pt[2];
	else if (max[2] < pt[2])
		max[2] = pt[2];
}


/*
	File:			TextRenderer.cc

	Function:		Implements TextRenderer.h

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			Defines a vanilla renderer object. Just outputs the calls
					it gets as text.
*/

#include <iostream.h>
#include "TextRenderer.h"


void TextRenderer::MakeCurrent()
{
}

void TextRenderer::Show()
{
	SetWindow();
}

// --- Renderer Drawing Operators -------------------------------------------


Renderer &TextRenderer::SetColour(const Colour &c)
{
	cout << "Colour " << c << endl;
	
	return(SELF);
}

Renderer &TextRenderer::SetPoint(const Point &p)
{
	cout << "Point " << p << endl;
	
	return(SELF);
}

Renderer &TextRenderer::SetCoord(const Coord &c)
{
	cout << "Coord " << c << endl;
	
	return(SELF);
}

Renderer &TextRenderer::SetNormal(const Vector &n)
{
	cout << "Normal " << n << endl;
	
	return(SELF);
}

Renderer &TextRenderer::SetTransform(const Transform &t)
{
	cout << "Transform " << t << endl;
	
	return(SELF);
}

Renderer &TextRenderer::SetCamera(const Camera &c)
{
	cout << "Camera\nproject:" << c.ProjMatrix() << endl;
	cout << "model:" << c.ModelMatrix() << endl;
	
	return(SELF);
}

Renderer &TextRenderer::Pop()
{
	cout << "Pop" << endl;
	
	return(SELF);
}

Renderer &TextRenderer::Push()
{
	cout << "Push" << endl;
	
	return(SELF);
}

Renderer &TextRenderer::Clear()
{
	cout << "Clear" << endl;

	return(SELF);
}

Renderer &TextRenderer::Begin(RenderStyle command)
{
	cout << "Begin: " << (Int) command << endl;
	
	return(SELF);
}

Renderer &TextRenderer::End()
{
	cout << "End" << endl;
	
	return(SELF);
}

void TextRenderer::Print(ostream &s)
{
	s << "Text Renderer." << endl;	
}

Renderer &TextRenderer::Rect(Real left, Real up, Real right, Real down)
{
	cout << "Rect: " << left << up << right << down << endl;
	return(SELF);
}


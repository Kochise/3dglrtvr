/*
	File:		ParseSC.cc
	
	Purpose:	Parses Paul's .sc format
	
	Author:		Mainly uses code from Paul Heckbert & John Murphy.
*/


#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

#include "SceneLang.h"


//////////////////////////////////////////////////////////////////
static int lc;			// current line number in scene file

// read whatever is left on a line (for comments)
void fread_to_eol(FILE *fp) {
    char c;
    do c = getc(fp); while (c!='\n');
    do {c = getc(fp); lc++;} while (c=='\n');
    if (!feof(fp)) ungetc(c, fp);
}

// Chomp away white space, but keep track of the newlines
void eatspace(FILE *fp) {
    char c;
    do {
	c = getc(fp);
	if (c=='#') {c = ' '; fread_to_eol(fp);}
	if (c=='\n') lc++;
	if (feof(fp)) return;
    } while (isspace(c));
    ungetc(c, fp);
}

// read the next string from the file, returns ptr to static
char *fread_word(FILE *fp) {
    static char word[80];	// sets maximum word length
    eatspace(fp);
    int test = fscanf(fp, "%s", word);
    if (test==EOF) strcpy(word, "end");
    else if (test!=1) {
	cerr << "Scene Error, line " << lc
	    << ": scanf returned " << test << endl;
	exit(1);
    }
    return word;
}

// read the next number from the file
double fread_number(FILE *fp) {
    eatspace(fp);
    double number;
    int test = fscanf(fp, "%lf", &number);
    if (test!=1) {
	cerr << "Scene Error, line " << lc
	    << ": scanf returned " << test << endl;
	exit(1);
    }
    return number;
}

Vector fread_Vector(FILE *fp)
{
    double x = fread_number(fp);
    double y = fread_number(fp);
    double z = fread_number(fp);
    return(Vector(x, y, z));
}

Colour fread_Colour(FILE *fp)
{
    double x = fread_number(fp);
    double y = fread_number(fp);
    double z = fread_number(fp);
    return(Colour(x, y, z));
}

// parse a scene file
// add to existing scene

void ParseSCFile(char *filename)
{
    FILE *fp;

    if ((fp = fopen(filename, "r")) == NULL) {
	cerr << "Unable to open scene file " << filename << endl;
	exit(1);
    }
    else cout << "Reading scene file " << filename << "\n";

    Bool bad;
    lc = 1;
    char *word = NULL;

    for (;;) {
	if (feof(fp)) strcpy(word, "end");
	else word = fread_word(fp);
	bad = false;

	switch (word[0]) {
	case '#':			// comment
	    fread_to_eol(fp);
	    break;

	case '/':			// comment
	    fread_to_eol(fp);
	    break;

	case 'a':
	    if (!strcmp(word, "ambient")) {
//		ambient = fread_Vector(fp);
//		ambient *= fread_number(fp);
		fread_Vector(fp);
		fread_number(fp);
	    }
	    else bad = true;
	    break;
	case 'b':
	    if (!strcmp(word, "background")) {
//		background = fread_Vector(fp);
//		background *= fread_number(fp);
		fread_Vector(fp);
		fread_number(fp);
	    }
	    else bad = true;
	    break;
	case 'd':
	    if (!strcmp(word, "diffuse")) {
/*
		cur_material().color = fread_Vector(fp);
		cur_material().kdiffrefl = fread_number(fp);
		cur_material().kspecrefl = 0.;
		cur_material().kspectran = 0.;
		cur_material().exponent = 0.;
		cur_material().indexrefr = 1.;
		cur_material().kemission = 0.;
		new_material = true;
*/
		Colour c = fread_Colour(fp);
		slColour(c * fread_number(fp));
		
	    }
	    else if (!strcmp(word, "diffspec")) {
/*
		cur_material().color = fread_Vector(fp);
		cur_material().kdiffrefl = fread_number(fp);
		cur_material().kspecrefl = fread_number(fp);
		cur_material().kspectran = fread_number(fp);
		cur_material().exponent = fread_number(fp);
		cur_material().indexrefr = fread_number(fp);
		cur_material().kemission = 0.;
		new_material = true;
*/
		Colour c = fread_Colour(fp);
		slColour(c * fread_number(fp));
		
		fread_number(fp);
		fread_number(fp);
		fread_number(fp);
		fread_number(fp);
	    }
	    else bad = true;
	    break;
	case 'e':
	    if (!strcmp(word, "emissive")) {
/*
		cur_material().color = fread_Vector(fp);
		cur_material().kdiffrefl = 0.;
		cur_material().kspecrefl = 0.;
		cur_material().kspectran = 0.;
		cur_material().exponent = 0.;
		cur_material().indexrefr = 1.;
		cur_material().kemission = fread_number(fp);
		new_material = true;
*/
		Colour c = fread_Colour(fp);
		slEmittance(c * fread_number(fp));

	    }
	    else if (!strcmp(word, "end")) {
		cout << "Completed reading the scene\n";
		fclose(fp);
		return;
	    }
	    else bad = true;
	    break;
	case 'g':
	    if (!strcmp(word, "gpop")) {

/*		if (!gstack.first()->next()) {
		    cerr << "Scene Error, line " << lc
			<< ": Can't pop top level gstate" << endl;
		    exit(1);
		}
		gstack.pop();
		cout << "popped stack" << endl;
		cout << gstack.first();
*/
		slEndObject();

	    }
	    else if (!strcmp(word, "gpush")) {

/*		gstack.dup();
		// dup() copies the material structure, light list
		// header, and matrix stack headers.
		// At this point, cur_matrix() points to the same
		// matrix as before the dup().

		// Set up matrix stack in new Gstate so that it contains a
		// copy of current matrix, and nothing else.
		// That way, if someone does too many pops, they'll get
		// an error message.
		// (push and pop must be nested within gpush, gpop)
		Matrix_item *m = new Matrix_item(*cur_matrix());
		gstack.first()->matrix_stack.init();
		gstack.first()->matrix_stack.push(*m);
*/

		slBeginObject("bob");
	
	    }
	    else bad = true;
	    break;
	case 'l':
	    if (!strcmp(word, "lookat")) {
		Vec3d from = fread_Vector(fp);
		Vec3d to = fread_Vector(fp);
		Vec3d up = fread_Vector(fp);
		Vec3d vec = to-from;

		if (up[2] > 0)
			slTransform(Rotation(vl_x, -vl_pi / 2.0));
		else if (up[1] > 0)
			slTransform(Rotation(vl_z, vl_pi / 2.0));
		
/*		double alpha;
		if (vec[1]!=0 || vec[2]!=0) alpha = atan2(-vec[1], -vec[2]);
		else alpha = 0.;
		double beta
		    = atan2(vec[0], sqrt(vec[1]*vec[1] + vec[2]*vec[2]));
		Matrix rm;
		rm.MakeUnit();	// identity
		rm.rotate('x', -alpha);
		rm.rotate('y', -beta);

		double gamma
		    = atan2(up[0]*rm[0][0]+up[1]*rm[1][0]+up[2]*rm[2][0],
			    up[0]*rm[0][1]+up[1]*rm[1][1]+up[2]*rm[2][1]);
		cur_matrix()->rotate('z', gamma);
		cur_matrix()->rotate('y', beta);
		cur_matrix()->rotate('x', alpha);
		cur_matrix()->translate(-from[0], -from[1], -from[2]);
*/


	    }
	    else bad = true;
	    break;
	case 'p':
	    if (!strcmp(word, "persp")) {
			fread_number(fp);
			fread_number(fp);
		}
	    else if (!strcmp(word, "pointlight")) {
//		Light_item *light = new Light_item;
		Vec3d pos = fread_Vector(fp);
/*		light->position = transform33(*cur_matrix(), pos);
		light->color = fread_Vector(fp);
		light->color *= fread_number(fp);
		cur_lights().append(*light);
*/
		fread_Vector(fp);
		fread_number(fp);
	    }
	    else if (!strcmp(word, "poly3") || !strcmp(word, "poly2")) {
		int poly3 = !strcmp(word, "poly3");
		int nvert = (int)fread_number(fp);

		if (nvert<3) {
		    cerr << "Scene Error, line " << lc
			<< ": poly needs >=3 vertices." << endl;
		    exit(1);
		}
//		Polygon *p = new Polygon;
		Vec3d point;
		int i;

		slBeginPoints();
		
		for (i=0; i<nvert; i++) {
		    point[0] = fread_number(fp);
		    point[1] = fread_number(fp);
		    if (poly3) point[2] = fread_number(fp);
		    else point[2] = 0.;
//		    point = transform33(*cur_matrix(), point);
//		    p->append_vertex(point);

			slPoint(point);
		}
		slEndPoints();
		slPoly();
		
//		p->precompute();	// set plane & edge equations
//		append_prim(*p);
	    }
	    else if (!strcmp(word, "pop")) {
/*		if (!cur_matrix()->next()) {
		    cerr << "Scene Error, line " << lc
			<< ": Attempt to pop last matrix on stack" << endl;
		    exit(1);
		}
		gstack.first()->matrix_stack.pop();
*/

			slEndObject();
	    }
	    else if (!strcmp(word, "push")) {
//		gstack.first()->matrix_stack.dup();
			slBeginObject("bob");
	    }
	    else bad = true;
	    break;
	case 'r':
	    if (!strcmp(word, "rotate")) {
		char *axis = fread_word(fp);
		double angle = fread_number(fp);
		if (!axis[1] && (axis[0]=='x' || axis[0]=='y' || axis[0]=='z'))
//		    cur_matrix()->rotate(axis[0], angle*M_PI/180.);
			slTransform(Rotation(vl_axis(axis[0] - 'x'), DegsToRads(angle)));
		else {
		    cerr << "Scene Error, line " << lc
			<< ": Illegal rotate axis (" << axis << ")" << endl;
		    exit(1);
		}
	    }
	    else if (!strcmp(word, "rotgen")) {
			Vec3d v = fread_Vector(fp);
			double angle = fread_number(fp);
			slTransform(Rotation(v, DegsToRads(angle)));
	    }
	    else bad = true;
	    break;
	case 's':
	    if (!strcmp(word, "scale")) {
			double sx, sy, sz;
			sx = fread_number(fp);
			sy = fread_number(fp);
			sz = fread_number(fp);
			slTransform(Scale(Vector(sx, sy, sz)));
	    }
	    else if (!strcmp(word, "screensize")) {
/*
		double dscale = (double)scale / 100.0;
		double sx = dscale * fread_number(fp);
		double sy = dscale * fread_number(fp);
		double sz = dscale * fread_number(fp);
		width = (int)sx;
		height = (int)sy;
		cur_matrix()->scale(sx/2.0, -sy/2.0, sz/2);
		cur_matrix()->translate(1, -1, 0);
*/

		fread_number(fp);
		fread_number(fp);
		fread_number(fp);
		
	    }
	    else if (!strcmp(word, "sphere")) {
		Vec3d center = fread_Vector(fp);
		double radius = fread_number(fp);
/*		center = transform33(*cur_matrix(), center);
		    // transform the sphere
		double scale;
		if (!cur_matrix()->eig_check(scale)) {
		    cerr << "Scene Error, line " << lc
			<< ": Sphere scaled nonuniformly" << endl;
		    exit(1);
		}
		Sphere *s = new Sphere(center, radius*fabs(scale));
		append_prim(*s);
*/
	    }
	    else bad = true;
	    break;
	case 't':
	    if (!strcmp(word, "translate")) {
		double tx, ty, tz;
		tx = fread_number(fp);
		ty = fread_number(fp);
		tz = fread_number(fp);
//		cur_matrix()->translate(tx, ty, tz);
		slTransform(Shift(Vector(tx, ty, tz)));
	    }
	    else bad = true;
	    break;
	case 'w':
	    if (!strcmp(word, "world_space")) {
		// currently, all matrices in matrix stacks transform to screen
		// space

		// save world-to-screen transform
//		world_to_screen = *cur_matrix();

		// Step through matrix stacks of all previous graphics states
		// and premultiply their matrices by screen_to_world space,
		// so that all matrices henceforth transform to world space.

		// We could just flush all previous graphics states and all
		// matrix stacks, but that is less elegant.
		// Doing it this way allows you to place geometry relative to
		// camera, and even in screen space.
//		Gstate_item *gs;
//		Matrix_item *m;
//		Matrix sw = inv(world_to_screen);
//		for (gs=gstack.first(); gs; gs=gs->next())
//		    for (m=gs->matrix_stack.first(); m; m=m->next())
//			*m = sw * *m;		// 4x4 matrix multiply

		// cur_matrix() is identity+roundoff at this point
//		cur_matrix()->MakeUnit();	// to eliminate the roundoff
						// (just being fussy)
	    }
	    else bad = true;
	    break;
	case 'x':
	    if (!strcmp(word, "xyzrange")) {
		double xn, xf, yn, yf, zn, zf;
		xn = fread_number(fp);
		xf = fread_number(fp);
		yn = fread_number(fp);
		yf = fread_number(fp);
		zn = fread_number(fp);
		zf = fread_number(fp);
//		cur_matrix()->scale(2./(xf-xn), 2./(yf-yn), 2./(zf-zn));
//		cur_matrix()->translate((xf+xn)/-2., (yf+yn)/-2., (zf+zn)/-2.);
	    }
	    else bad = true;
	    break;
	case 'z':
	    if (!strcmp(word, "zrange")) {
		double zn, zf;
		zn = fread_number(fp);
		zf = fread_number(fp);
//		cur_matrix()->translate(0., 0., (zf+zn)/(zf-zn));
//		cur_matrix()->scale(1., 1., -2./(1./zn-1./zf));
	    }
	    else bad = true;
	    break;
	default:
	    bad = true;
	    break;
	}

	if (bad) {
	    cerr << "Scene Error, line " << lc
		<< ": bad keyword (" << word << ")." << endl;
	    exit(1);
	}
    }
}


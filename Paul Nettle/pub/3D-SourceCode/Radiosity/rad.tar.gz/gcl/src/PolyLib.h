/*
	File:			PolyLib.h

	Function:		
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */



#ifndef __PolyLib__
#define __PolyLib__

void CreateSolidCube();
void CreateSolidCone();
void CreateSolidCylinder();
void CreateSolidTetrahedron();

void AddPolyObjects();

#endif

/*
	File:			Library.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

	Change History:
		31/01/96	ajw		Started
*/


#include "Library.h"
#include "PolyLib.h"
#include <string.h>

// --- constructor ----------------------

Library::Library() : members(), name(0)
{
}

void Library::Create()
{
	AddMember("group", new scGroup);
	AddMember("poly", new scPoly);
	
	AddPolyObjects();
	
	name = "simple";
}

Int Library::AddMember(scScenePtr objectPtr)
{
	members.Append(LibNode(objectPtr->Label(), objectPtr));
	
	return(members.NumItems() - 1);
}

Int Library::AddMember(char *name, scPrimitive *objectPtr)
{
	members.Append(LibNode(name, objectPtr));
	
	return(members.NumItems() - 1);
}
 
scPrimitive *Library::Member(Char *name)
{
	Int	i;
	
	for (i = 0; i < members.NumItems(); i++)
		if (strcmp(name, members[i].name) == 0)
			return(members[i].object);
	
	cerr << "Object not in library: " << name << endl;
	
	return(0);
}

Bool Library::MemberExists(Char *name)
{
	Int	i;
	
	for (i = 0; i < members.NumItems(); i++)
		if (strcmp(name, members[i].name) == 0)
			return(true);
		
	return(false);
}

scPrimitive *Library::Member(Int index)
{
	return(members[index].object);
}

#pragma mark -
// --- Output operators ------------------------------


ostream &operator << (ostream &s, const LibNode &ln)
{
	s << "item: " << ln.name << ", " << ln.object << endl;
	
	return(s);
}

ostream &operator << (ostream &s, Array<LibNode> &array);

ostream &operator << (ostream &s, const Library &library)
{
	s << "Library " << library.name << ":" << endl;
	s << (Array<LibNode>&) library.members;
	
	return(s);
}

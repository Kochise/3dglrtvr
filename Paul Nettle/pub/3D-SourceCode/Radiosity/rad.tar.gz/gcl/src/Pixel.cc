/*
	File:			Pixel.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			Should be able to replace with a Vec4<Byte> once VL mods
					are done.

	Change History:
		31/01/96	ajw		Started
*/

#include "Pixel.h"

Int Pixel::currentChannel = chRed;

Pixel::Pixel(Byte r, Byte g, Byte b, Byte a)
{
	channel[chRed] = r;
	channel[chGreen] = g;
	channel[chBlue] = b;
	channel[chAlpha] = a;
}

Pixel::Pixel(const Pixel &a)
{
	data = a.data;
}

Pixel::Pixel(Real r)
{
	Byte b = r * 255.0;
	
	channel[chRed] = b;
	channel[chGreen] = b;
	channel[chBlue] = b;
	channel[chAlpha] = 0;
}

Pixel::Pixel(const Colour &c)
{
	channel[chRed] = 255 * c[0];
	channel[chGreen] = 255 * c[1];
	channel[chBlue] = 255 * c[2];
	channel[chAlpha] = 0;
}

Pixel &Pixel::operator = (Pixel a)
{
	data = a.data;
	
	return(SELF);
}	

Pixel &Pixel::operator = (Real r)
{
	channel[currentChannel] = r * 255;
	
	return(SELF);
}


Bool Pixel::operator == (Pixel a) const
{
	return((UInt32 &) *channel == (UInt32 &) *(a.channel));
}

Bool Pixel::operator != (Pixel a) const
{
	return((UInt32 &) *channel != (UInt32 &) *(a.channel));
}

Pixel &Pixel::operator += (Pixel a)
{
	channel[0] += a.channel[0];
	channel[1] += a.channel[1];
	channel[2] += a.channel[2];
	channel[3] += a.channel[3];
	
	return(SELF);
}

Pixel &Pixel::operator -= (Pixel a)
{
	channel[0] -= a.channel[0];
	channel[1] -= a.channel[1];
	channel[2] -= a.channel[2];
	channel[3] -= a.channel[3];
	
	return(SELF);
}

Pixel &Pixel::operator *= (Pixel a)
{
	channel[0] *= a.channel[0];
	channel[1] *= a.channel[1];
	channel[2] *= a.channel[2];
	channel[3] *= a.channel[3];
	
	return(SELF);
}

Pixel &Pixel::operator *= (Real r)
{
	channel[0] *= r;
	channel[1] *= r;
	channel[2] *= r;
	channel[3] *= r;
	
	return(SELF);
}

Pixel &Pixel::operator /= (Pixel a)
{
	channel[0] /= a.channel[0];
	channel[1] /= a.channel[1];
	channel[2] /= a.channel[2];
	channel[3] /= a.channel[3];
	
	return(SELF);
}

Pixel &Pixel::operator - ()
{
	channel[0] = -channel[0];
	channel[1] = -channel[1];
	channel[2] = -channel[2];
	channel[3] = -channel[3];
	
	return(SELF);
}

Pixel Pixel::operator + (Pixel a) const
{
	Pixel b;
	
	b.channel[0] = channel[0] + a.channel[0];
	b.channel[1] = channel[1] + a.channel[1];
	b.channel[2] = channel[2] + a.channel[2];
	b.channel[3] = channel[3] + a.channel[3];
	
	return(b);
}

Pixel Pixel::operator - (Pixel a) const
{
	Pixel b;
	
	b.channel[0] = channel[0] - a.channel[0];
	b.channel[1] = channel[1] - a.channel[1];
	b.channel[2] = channel[2] - a.channel[2];
	b.channel[3] = channel[3] - a.channel[3];
	
	return(b);
}

Pixel Pixel::operator * (Pixel a) const
{
	Pixel b;
	
	b.channel[0] = channel[0] * a.channel[0];
	b.channel[1] = channel[1] * a.channel[1];
	b.channel[2] = channel[2] * a.channel[2];
	b.channel[3] = channel[3] * a.channel[3];
	
	return(b);
}

Pixel Pixel::operator * (Real r) const
{
	Pixel b;
	
	b.channel[0] = channel[0] * r;
	b.channel[1] = channel[1] * r;
	b.channel[2] = channel[2] * r;
	b.channel[3] = channel[3] * r;
	
	return(b);
} 

Pixel Pixel::operator / (Pixel a) const
{
	Pixel b;
	
	b.channel[0] = channel[0] / a.channel[0];
	b.channel[1] = channel[1] / a.channel[1];
	b.channel[2] = channel[2] / a.channel[2];
	b.channel[3] = channel[3] / a.channel[3];
	
	return(b);
}

Pixel Pixel::operator / (Real r) const
{
	Pixel b;
	
	b.channel[0] = channel[0] / r;
	b.channel[1] = channel[1] / r;
	b.channel[2] = channel[2] / r;
	b.channel[3] = channel[3] / r;
	
	return(b);
} 

ostream &operator << (ostream &s, Pixel p)
{
	s << (int) p.channel[0] << ":" << (int) p.channel[1] << ":" << (int) p.channel[2] 
		<< ":" << (int) p.channel[3] << ":" << endl;
		
	return(s);
}
 
istream &operator >> (istream &s, Pixel &p)
{
	p = cRed;
	
	return(s);
}

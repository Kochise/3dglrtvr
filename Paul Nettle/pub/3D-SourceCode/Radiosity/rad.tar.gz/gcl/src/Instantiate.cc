#include "Geometry.h"
#include "Library.h"
#include "XGraphicsSystem.h"


/*
#pragma instantiate Array<Vec3<double> >
#pragma instantiate Array<RGBCol>
#pragma instantiate Array<int>
#pragma instantiate ArrayList<LibNode>
#pragma instantiate Array<AttrRec>
#pragma instantiate Array<AttrStackRec>
*/

#ifdef VL_SGI_INST
#pragma instantiate Array<Avar>
#pragma instantiate Array<char>
#pragma instantiate istream &operator>>(istream&,Array<Vec3d>&)
#pragma instantiate istream &operator>>(istream&,Array<Colour>&)
#pragma instantiate istream &operator>>(istream&,Array<Int>&)
#pragma instantiate ostream &operator<<(ostream&,Array<LibNode>&)
#pragma instantiate ostream &operator<<(ostream&,Array<AttrRec>&)
#pragma instantiate ostream &operator<<(ostream&,Array<AttrStackRec>&)
#pragma instantiate scPrimitive *Clone(scPrimitive*)
#pragma instantiate Array<AttrRec>
#pragma instantiate Array<XEventPane*>
#else
#error not_implemented
#endif


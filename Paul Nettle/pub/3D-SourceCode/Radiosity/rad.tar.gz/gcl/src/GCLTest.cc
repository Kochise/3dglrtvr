/* 
	Test program for AJW's GL windowing guff
	
*/

//#include "MesaApp.h"
#include "XGraphicsSystem.h"
//#include "GLRenderer.h"
//#include "TextRenderer.h"
#include "EPSRenderer.h"
#include "Parse.h"
#include <stdlib.h>
#include "SceneLang.h"

void CubeScene(Renderer &pane);
void CubeScene(Renderer &pane)
{
	pane
		.SetTransform(Rotation(vl_y, vl_pi / 2.0))
		.Begin(renPoly)
		.SetColour(cRed)
		.SetPoint(Point(-1, -1, 1))
		.SetPoint(Point(-1,  1, 1))
		.SetPoint(Point( 1,  1, 1))
		.SetPoint(Point( 1, -1, 1))
		.End();
		
	pane
		.Push()
		.SetTransform(Rotation(vl_y, vl_pi / 2.0))
		.Begin(renPoly)
		.SetColour(cBlue)
		.SetPoint(Point(-1, -1, 1))
		.SetPoint(Point(-1,  1, 1))
		.SetPoint(Point( 1,  1, 1))
		.SetPoint(Point( 1, -1, 1))
		.End();
	
	pane
		.SetTransform(Rotation(vl_y, vl_pi / 2.0))
		.Begin(renPoly)
		.SetColour(cOrange)
		.SetPoint(Point(-1, -1, 1))
		.SetPoint(Point(-1,  1, 1))
		.SetPoint(Point( 1,  1, 1))
		.SetPoint(Point( 1, -1, 1))
		.End();

	pane
		.Pop()
		.SetTransform(Rotation(vl_x, vl_pi / 2.0))
		.Begin(renPoly)
		.SetColour(cGreen)
		.SetPoint(Point(-1, -1, 1))
		.SetPoint(Point(-1,  1, 1))
		.SetPoint(Point( 1,  1, 1))
		.SetPoint(Point( 1, -1, 1))
		.End();
		
	pane	
		.Pop()
		.Show();
}

#if 0
class MesaRenderer : public GLRenderer
{
public:
	MesaRenderer(Int h, Int w) : GLRenderer(w, h) {};
	void MakeCurrent() {};
	void Show() { MacShow(); };
};
#endif

void ImageTest(Renderer &myPane1)
{
#if 0
	myPane1.GetImage(image);
	
	
	cout << "grabbed image of " << image.Rows() << " x " << image.Cols() << endl;
	cout << "starting pane 2" << endl;
	
	myPane2.Clear().SetImage(image);
	myPane2.Show();
		
#if 0
	Pixel::currentChannel = chRed;
	image.MakeBlock(1);
	myPane1.Clear().Image(image);
	myPane1.Show();
	Pixel::currentChannel = chBlue;
	image.MakeBlock(0.5);
	myPane1.Clear();
	myPane1.SetImage(image);
	myPane1.Show();
	Pixel::currentChannel = chGreen;
	image.MakeBlock(0.2);
	myPane1.Clear();
	myPane1.SetImage(image);
	myPane1.Show();
	
	blob.SetSize(50, 50);
	blob.MakeUnit(1);
	sub(image, 30, 40, 50, 50) = blob;
	
	myPane1.Clear();
	myPane1.SetImage(image);
	myPane1.Show();
		
	gs.Run();
#endif
#endif
}

void GouraudTest(Renderer *r)
{
	r->Clear().Show();
	r->Begin(renPoly);
	r->SetColour(cRed).SetPoint(Point(-1, -1, 0))
		.SetColour(cGreen).SetPoint(Point(1, -1, 0))
		.SetColour(cBlue).SetPoint(Point(1, 1, 0))
		.SetColour(cWhite).SetPoint(Point(-1, 1, 0));
	r->End();
	r->Show();
}

main(int argc, char **argv)
{
	//MesaRenderer			mesaRenderer(300, 300);
	
//	TextRenderer			textRenderer;
	EPSRenderer				epsRenderer;
	Renderer				*r;
	Camera					camera(false);
	Int						i;
	RGBAImage 				image;
	FILE					*ppmfile;
	scScenePtr				scene;
	FileName				file;
	GraphicsSystem			gs;
	GSPane					xglRenderer;
	
//	MacInit();
	slSetLibrary(new Library);
	epsRenderer.Attach("out.eps");
//	mesaRenderer.Init();
	gs.CreateWindow(&xglRenderer, "blob", 300, 300);
	r = &xglRenderer;
	
#if 1
	image.SetSize(100,100);
	image.Clear(cPurple);
	r->SetBgColour(cBlack);
	r->Clear();
	r->PutImage(image);
	r->Show();
	gs.Run();
	image.SetSize(200, 200);
	image.Clear(cGreen);
	image.SavePPM("green.ppm");
#endif

#if 1
//	file.SetPath("Black Sun:reactor:scenes:scomplex_09.sl");
	file.SetPath("/usr/people/ajw/pafs/scenes/scomplex_09.sl");
	if (!(scene = ReadSceneFile(file)))
		exit(1);

	r->SetBgColour(cWhite);
	r->Clear();
	r->Draw(*scene);
	r->Show();

	r->GetImage(image);
	image.SavePPM("test.ppm");
	image.SaveTIFF("test.tiff");
	gs.Run();
#endif

#if 0
	r->SetBgColour(cYellow);
	r->Clear();
	camera.SetZoom(0.5);
	r->SetCamera(camera);
	r->SetTransform(Shift(Vector(0.3, 0.2, 0)) * Rotation(vl_z, DegsToRads(30)));
	GouraudTest(r);
	r->Show();
#endif	

#if 0
	r->SetBgColour(cCyan);
	r->Clear();
	camera.SetZoom(2);
	r->SetCamera(camera);
	CubeScene(*r);
	r->Show();
#endif	
	
//	while(1)
	//	MacSpin();
	
	gs.Run();
}

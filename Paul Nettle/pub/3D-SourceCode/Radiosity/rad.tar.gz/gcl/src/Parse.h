#ifndef __Parse__
#define __Parse__

#include "Scene.h"
#include "FileName.h"

scScenePtr ReadSceneFile(FileName &filename);

scObject *scParseObject(istream &s);

#endif

/*
	File:			SceneObjects.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

	Change History:
		31/01/96	ajw		Started
*/

#include "SceneObjects.h"
#include "String.h"


// --- Polygon methods --------------------

    
Char *scPoly::Label() const
{
	return("poly");
}

void scPoly::Draw(Renderer &r, Context *context)
{
	Int 		i, j;
	PointList	*points;
	ColourList	*colours;
	IndexList	*indexes;
			
	if (points = SC_GET(Points))
	{
		r.Begin(renPoly);
		
		if (indexes = SC_GET(Indexes))
		{
			if (colours = SC_GET(Colours))
				for (i = 0; i < indexes->NumItems(); i++)
				{
					j = (*indexes)[i];
					r.SetColour((*colours)[j]).SetPoint((*points)[j]);
				}
			else
			{
				if (SC_GET(Emittance))
					r.SetColour(*(SC_GET(Emittance)));
				else
					r.SetColour(*(SC_GET(Colour)));
				
				for (i = 0; i < indexes->NumItems(); i++)
					r.SetPoint((*points)[(*indexes)[i]]);
			}
		}
		else
		{
			if (colours = SC_GET(Colours))
				for (i = 0; i < points->NumItems(); i++)
					r.SetColour((*colours)[i]).SetPoint((*points)[i]);
			else
			{
				if (SC_GET(Emittance))
					r.SetColour(*(SC_GET(Emittance)));
				else
					r.SetColour(*(SC_GET(Colour)));
				
				for (i = 0; i < points->NumItems(); i++)
					r.SetPoint((*points)[i]);
			}
		}
		
		r.End();
	}
}

void scPoly::Parse(istream &s)
{
}


  
#pragma mark -
// --- Transforming points --------------------

    
void scPoints::Apply(Transform &m)
{
	Int i;
	
	for (i = 0; i < NumItems(); i++)
		SELF[i] = proj(m * Vector4(SELF[i], 1.0));
}

void scColour::Parse(istream &s)
{
	s >> (Colour &) SELF;
}

void scTransform::Parse(istream &s)
{
	s >> (Transform &) SELF;
}

void scEmittance::Parse(istream &s)
{
	s >> (Colour &) SELF;
}

void scPoints::Parse(istream &s)
{
	s >> (PointList &) SELF;
}

void scColours::Parse(istream &s)
{
	s >> (ColourList &) SELF;
}

void scIndexes::Parse(istream &s)
{
	s >> (IndexList &) SELF;
}

void scCamera::Parse(istream &s)
{
	String str;
	Char c;
	
	ChompSpace(s);
	while (s.peek() == '+')					// extension?
	{
		s.get(c);
		str.ReadWord(s);

		if (str == "params")		
		{
			s >> zoom;
			s >> sceneOrient;
			s >> sceneOffset;
#ifndef VL_ROW_ORIENT			
			sceneOrient = trans(sceneOrient);
			sceneOffset = trans(sceneOffset);
#endif
		}
		else
			cerr << "unknown camera option: '" << str << "'" << endl;
		
		ChompSpace(s);
	}
}

void scCamera::Print(ostream &s) const
{
	s << "camera";
	
	if (zoom != 1 || sceneOrient != vl_I || sceneOffset != vl_I)
	{
		s << " +params " <<
		zoom << ' ' <<
		sceneOrient << ' ' <<
		sceneOffset;
	}
}

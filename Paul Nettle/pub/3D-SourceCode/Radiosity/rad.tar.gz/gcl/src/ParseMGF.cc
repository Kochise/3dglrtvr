/*
	File:		ParseMGF.cc
	
	Function:	Provides routine to parse .mgf files into a scene.
	
	Author:		Andrew Willmott, 11/1996
*/


#include <stdio.h>

extern "C" 
{
#include <string.h>
#include "parser.h"
// Must nuke explicit declaration of strcmp in lookup.h,
// otherwise we run into link problems. (Grrr.)
#include "lookup.h"
}


#include "SceneLang.h"

int MyObject(int ac, char **av);
int MyTransform(int ac, char **av);
int MyCylinder(int ac, char **av);
int MyFace(int ac, char **av);
int MySphere(int ac, char **av);
int MyComment(int ac, char **av);

void mgf2rgb(
		C_COLOR		*cin,           /* input MGF chrominance */
		double		intensity,      /* input luminance or reflectance */
		float		cout[3]         /* output RGB color */
	);

scScenePtr ParseMGFFile(const Char *filename)
{
	scScenePtr result = slBeginObject((char*) filename);
	slCamera();
	slColour(cBlue * 0.5);
	
	// initialize dispatch table 

	mg_ehand[MG_E_COMMENT] = MyComment;	
	mg_ehand[MG_E_COLOR] = c_hcolor;	
	mg_ehand[MG_E_CMIX] = c_hcolor;		
	mg_ehand[MG_E_CSPEC] = c_hcolor;	
	mg_ehand[MG_E_CXY] = c_hcolor;		
	mg_ehand[MG_E_CCT] = c_hcolor;		
	//mg_ehand[MG_E_CYL] = MyCylinder;	
	mg_ehand[MG_E_ED] = c_hmaterial;	
	mg_ehand[MG_E_FACE] = MyFace;		
	mg_ehand[MG_E_MATERIAL] = c_hmaterial;
	mg_ehand[MG_E_NORMAL] = c_hvertex;	
	//mg_ehand[MG_E_OBJECT] = MyObject;	
	mg_ehand[MG_E_POINT] = c_hvertex;	
	mg_ehand[MG_E_RD] = c_hmaterial;	
	mg_ehand[MG_E_RS] = c_hmaterial;	
	mg_ehand[MG_E_SIDES] = c_hmaterial;	
	//mg_ehand[MG_E_SPH] = MySphere;	
	mg_ehand[MG_E_TD] = c_hmaterial;	
	mg_ehand[MG_E_TS] = c_hmaterial;	
	mg_ehand[MG_E_VERTEX] = c_hvertex;	
	mg_ehand[MG_E_XF] = xf_handler;		

	mg_init();							/* initialize the parser */
	
	if (mg_load((char*)filename) != MG_OK)
	{
		cerr << "*** Error reading .mgf file" << endl;
	}

	slEndObject();
	return(result);
}


Int MyObject(int ac, char **av)			/* group object name */
{
	static int	objnest;

#ifdef MGF_DUMP
	int i;
	for (i = 0; i < ac; i++)
		printf("%s ", av[i]);
	printf("\n");
#endif

	return(MG_OK);
}

int MyComment(int ac, char **av)
{
#ifdef MGF_DUMP
	int i;
	printf("comment:\n");
	for (i = 0; i < ac; i++)
		printf("%s ", av[i]);
	printf("\n");
#endif
	return(MG_OK);
}

int MyFace(int ac, char **av)			/* translate an N-sided face */
{
	C_VERTEX	*vp;
	int 		i;
	static int	gOldID = -1;
	FVECT		n, p;
	
#ifdef MGF_DUMP
	printf("face:\n");
	for (i = 0; i < ac; i++)
		printf("%s ", av[i]);
	printf("\n");
#endif

	if (ac < 4)
		return(MG_EARGC);
	
	if (xf_context && xf_context->xid != gOldID)
	{
		gOldID = xf_context->xid;
	}
		
	if (c_cmaterial->clock)
	{
		float	rgbval[3];

		mgf2rgb(&c_cmaterial->rd_c, c_cmaterial->rd, rgbval);
		slColour(Colour(rgbval[0], rgbval[1], rgbval[2]));
		mgf2rgb(&c_cmaterial->ed_c, c_cmaterial->ed, rgbval);
		slEmittance(Colour(rgbval[0], rgbval[1], rgbval[2])/700.0);
		c_cmaterial->clock = 0;
	}
	
	slBeginPoints();
	for (i = 1; i < ac; i++) 
	{
		if ((vp = c_getvert(av[i])) == NULL)
			return(MG_EUNDEF);
		
		xf_xfmpoint(p, vp->p);
		xf_rotvect(n, vp->n);
		slPoint(Vector(p[0], p[1], p[2]));
	}
	slEndPoints();
	slPoly();
	
	return(MG_OK);			
}


int MySphere(int ac, char **av)			/* translate sphere description */
{
#ifdef MGF_DUMP
	printf("sphere:\n");
#endif
	return(MG_OK);		/* we'll actually put it out later */
}


int MyCylinder(int ac, char **av)			/* translate a cylinder description */
{
#ifdef MGF_DUMP
	printf("cyl:\n");
	int i;
	for (i = 0; i < ac; i++)
		printf("%s ", av[i]);
	printf("\n");
#endif
	return(MG_OK);		/* we'll actually put it out later */
}


// Beats me why this isn't in libmgf...

                        /* Change the following to suit your standard */
#define  CIE_x_r                0.640           /* nominal CRT primaries */
#define  CIE_y_r                0.330
#define  CIE_x_g                0.290
#define  CIE_y_g                0.600
#define  CIE_x_b                0.150
#define  CIE_y_b                0.060
#define  CIE_x_w                0.3333          /* use true white */
#define  CIE_y_w                0.3333

#define CIE_C_rD        ( (1./CIE_y_w) * \
                                ( CIE_x_w*(CIE_y_g - CIE_y_b) - \
                                  CIE_y_w*(CIE_x_g - CIE_x_b) + \
                                  CIE_x_g*CIE_y_b - CIE_x_b*CIE_y_g     ) )
#define CIE_C_gD        ( (1./CIE_y_w) * \
                                ( CIE_x_w*(CIE_y_b - CIE_y_r) - \
                                  CIE_y_w*(CIE_x_b - CIE_x_r) - \
                                  CIE_x_r*CIE_y_b + CIE_x_b*CIE_y_r     ) )
#define CIE_C_bD        ( (1./CIE_y_w) * \
                                ( CIE_x_w*(CIE_y_r - CIE_y_g) - \
                                  CIE_y_w*(CIE_x_r - CIE_x_g) + \
                                  CIE_x_r*CIE_y_g - CIE_x_g*CIE_y_r     ) )


/* XYZ to RGB conversion matrix */

float   xyz2rgbmat[3][3] =
{
	{(CIE_y_g - CIE_y_b - CIE_x_b*CIE_y_g + CIE_y_b*CIE_x_g)/CIE_C_rD,
	 (CIE_x_b - CIE_x_g - CIE_x_b*CIE_y_g + CIE_x_g*CIE_y_b)/CIE_C_rD,
	 (CIE_x_g*CIE_y_b - CIE_x_b*CIE_y_g)/CIE_C_rD},
	{(CIE_y_b - CIE_y_r - CIE_y_b*CIE_x_r + CIE_y_r*CIE_x_b)/CIE_C_gD,
	 (CIE_x_r - CIE_x_b - CIE_x_r*CIE_y_b + CIE_x_b*CIE_y_r)/CIE_C_gD,
	 (CIE_x_b*CIE_y_r - CIE_x_r*CIE_y_b)/CIE_C_gD},
	{(CIE_y_r - CIE_y_g - CIE_y_r*CIE_x_g + CIE_y_g*CIE_x_r)/CIE_C_bD,
	 (CIE_x_g - CIE_x_r - CIE_x_g*CIE_y_r + CIE_x_r*CIE_y_g)/CIE_C_bD,
	 (CIE_x_r*CIE_y_g - CIE_x_g*CIE_y_r)/CIE_C_bD}
};

/* convert MGF color to RGB */

void mgf2rgb(
		C_COLOR		*cin,          /* input MGF chrominance */
		double		intensity,     /* input luminance or reflectance */
		float		cout[3]        /* output RGB color */
	)
// original had 'register' qualifier for some arguments(?!) -- this
// causes some modern compilers to choke.
{
        static double   cie[3];
                                        /* get CIE XYZ representation */
        c_ccvt(cin, C_CSXY);
        cie[0] = intensity*cin->cx/cin->cy;
        cie[1] = intensity;
        cie[2] = intensity*(1./cin->cy - 1.) - cie[0];
                                        /* convert to RGB */
        cout[0] = xyz2rgbmat[0][0]*cie[0] + xyz2rgbmat[0][1]*cie[1]
                        + xyz2rgbmat[0][2]*cie[2];
        if(cout[0] < 0.) cout[0] = 0.;
        cout[1] = xyz2rgbmat[1][0]*cie[0] + xyz2rgbmat[1][1]*cie[1]
                        + xyz2rgbmat[1][2]*cie[2];
        if(cout[1] < 0.) cout[1] = 0.;
        cout[2] = xyz2rgbmat[2][0]*cie[0] + xyz2rgbmat[2][1]*cie[1]
                        + xyz2rgbmat[2][2]*cie[2];
        if(cout[2] < 0.) cout[2] = 0.;
}

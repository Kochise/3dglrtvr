/*
	File:			ScenePane.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			May have to split some of this stuff out.
					To come: picking, quaternion rotation (mouseball) &
					mouse pole.

*/

#include "ScenePane.h"

#ifdef VL_ROW_ORIENT
#error not_implemented
// Need to reorder rotation matrices.
#endif


#pragma mark -
// --- ScenePane class -------------------------------------------


ScenePane::ScenePane(Bool doubleBuf) : GSPane(doubleBuf), itsScene(0), itsCamera(0),
	rotX(0), rotY(0),
	transX(0), transY(0), transZ(0),
	zoom(1),
	isSavedCam(false)
{
}

void ScenePane::SetScene(scScenePtr scene)
{
	itsCamera = (scCamera *) scene->FindFirst(aCamera);
	Assert(itsCamera != 0, "No camera in scene.");	
	itsScene = scene;
	
	itsCamera->SetSceneOrient(
		Rotation(vl_x, rotX * vl_pi)
		* Rotation(vl_y, rotY * vl_pi));

	itsCamera->SetSceneOffset(Shift(Vector(transX, transY, transZ) * 4));
	itsCamera->SetZoom(zoom);
	
	Redraw();
		
	if (doubleBuffered)
		Redraw();
}

void ScenePane::Redraw()
{
	Clear().Draw(itsScene).Show();
}

const Real kElevLimit = 0.49; 
	// To stop us reaching the singularity on the y axis.


void ScenePane::ViewFrom(Point &position, Vector &normal)
{
	itsCamera->SetPosition(position);
	itsCamera->SetLookat(position + normal);
	
	rotX = rotY = 0;
	transX = transY = transZ = 0;
	zoom = 1;
	itsCamera->SetSceneOrient(
		Rotation(vl_x, rotX * vl_pi)
		* Rotation(vl_y, rotY * vl_pi));

	itsCamera->SetSceneOffset(Shift(Vector(transX, transY, transZ) * 4));
	itsCamera->SetZoom(zoom);

	Redraw();
	if (!isSavedCam)
	{
		savedCam = *itsCamera;
		isSavedCam = true;
	}
}

void ScenePane::Restore()
{
	if (isSavedCam)
	{
		*itsCamera = savedCam;
		isSavedCam = false;
	}
}

void ScenePane::TrackMouse(XButtonEvent *be)
{
	Int 			menu;
	UInt 			keyState, newState;
	int		 		x, y, w, h;
	Real 			tRotX = rotX, tRotY = rotY;
	Real 			tZoom = zoom;
	Real			tTransX = transX, tTransY = transY, tTransZ = transZ;
	Real			offX, offY;
	
	w = width;
	h = height;
	GetMouse(&x, &y, &keyState);
	
	newState = keyState;
	if (keyState & Button3Mask)
		inverseTransform = inv(itsCamera->ProjMatrix() * itsCamera->ModelMatrix());
		
	while (newState & (Button1Mask | Button2Mask | Button3Mask))
	{
		offX = Real(x - be->x) / Real(w);
		offY = Real(y - be->y) / Real(h);
		
		if (keyState & Button1Mask)
		{
			if (itsCamera->IsOrtho())
			{
				tZoom = zoom - offY;
				itsCamera->SetZoom(tZoom);
			}
			else if (keyState & ShiftMask)
			{
				tZoom = zoom - offY;
				itsCamera->SetZoom(tZoom);
			}
			else
			{
				tRotY = rotY + offX;	// rotation
				tRotX = rotX + offY;	// elevation
				if (tRotX < -kElevLimit)
					tRotX = -kElevLimit;
				else if (tRotX > kElevLimit)
					tRotX = kElevLimit;
	
				itsCamera->SetSceneOrient(
					Rotation(vl_x, tRotX * vl_pi)
					* Rotation(vl_y, tRotY * vl_pi));
			}
			
			Clear().Draw(itsScene).Show();
		}
		else if (keyState & Button2Mask)
		{
			if (keyState & ShiftMask && !itsCamera->IsOrtho())
				tTransZ = transZ + offY;
			else
			{
				tTransX = transX + offX;
				tTransY = transY - offY;
			}
			itsCamera->SetSceneOffset(Shift(Vector(tTransX, tTransY, tTransZ) * 4));
			Clear().Draw(itsScene).Show();
		}
		else if (keyState & Button3Mask)
		{
			Int levelsUp = 32 * sqrt(sqr(offX) + sqr(offY));
							
			if (keyState & ShiftMask)
				Pick(Real(be->x) / Real(w), Real(be->y) / Real(h), 1, levelsUp);
			else
				Pick(Real(be->x) / Real(w), Real(be->y) / Real(h), 0, levelsUp);
		}
		
		GetMouse(&x, &y, &newState);
	} 
	
	rotX = tRotX;
	rotY = tRotY;
	transX = tTransX;
	transY = tTransY;
	transZ = tTransZ;
	zoom = tZoom;
}

void ScenePane::HandleEvent(XEvent *event)
{
	if (event->type == Expose)
		Redraw();
	else if (event->type == ButtonPress)
		TrackMouse((XButtonEvent *) event);	
	else
		XEventPane::HandleEvent(event);
}



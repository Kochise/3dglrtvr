/*
	File:			PolyLib.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

	Change History:
		31/01/96	ajw		Started
*/

#include "PolyLib.h"
#include "SceneLang.h"

void AddPolyObjects()
{
	slAddToLibrary(slBeginObject("tetrahedron"));
	CreateSolidTetrahedron();
	slEndObject();

	slAddToLibrary(slBeginObject("cylinder"));
	CreateSolidCylinder();
	slEndObject();

	slAddToLibrary(slBeginObject("cone"));
	CreateSolidCone();
	slEndObject();
	
	slAddToLibrary(slBeginObject("cube"));
	CreateSolidCube();
	slEndObject();
}

const Int NumTesselations = 8;


void CreateSolidCube()
{
	slBeginPoints();
	slPoint(Point(-1, -1, -1));
	slPoint(Point( 1, -1, -1));
	slPoint(Point( 1, -1,  1));
	slPoint(Point(-1, -1,  1));
	slPoint(Point(-1,  1, -1));
	slPoint(Point( 1,  1, -1));
	slPoint(Point( 1,  1,  1));
	slPoint(Point(-1,  1,  1));
	slEndPoints();
	
	slIndexes(Indexes(0, 1, 2, 3, IDX_END));
	slPoly();

	slIndexes(Indexes(7, 6, 5, 4, IDX_END));
	slPoly();
	
	slIndexes(Indexes(1, 5, 6, 2, IDX_END));
	slPoly();
	
	slIndexes(Indexes(6, 7, 3, 2, IDX_END));
	slPoly();
	
	slIndexes(Indexes(4, 0, 3, 7, IDX_END));
	slPoly();
	
	slIndexes(Indexes(1, 0, 4, 5, IDX_END));
	slPoly();
}

// --- Tetrahedron creation -------------------------------------

void TetrahedronPoints()
// Creates a tetrahedron lying on the x-z plane, and centred on the y-axis.
{
	Real RecipRoot3;
	Real hmax;

	RecipRoot3 = 1 / sqrt(3);
	hmax = sqrt(2.0 / 3.0);			// Height of tetrahedron 

	slBeginPoints();
	slPoint(Point(0, 0, RecipRoot3));
	slPoint(Point(0.5, 0, -RecipRoot3 / 2));
	slPoint(Point(-0.5, 0, -RecipRoot3 / 2));
	slPoint(Point(0, hmax, 0));
	slEndPoints();
}

void CreateSolidTetrahedron()
// Creates a tetrahedron lying on the x-z plane, and centred on the y-axis.
{
	TetrahedronPoints();

	slIndexes(Indexes(0, 2, 1, IDX_END));		// base 		
	slPoly();
	slIndexes(Indexes(0, 1, 3, IDX_END));		// right side 
	slPoly();
	slIndexes(Indexes(3, 1, 2, IDX_END));		// back 
	slPoly();
	slIndexes(Indexes(0, 3, 2, IDX_END));		// left side
	slPoly();
}


// --- Cylinder ------------------------


void CylinderPoints()
{
	Int i;
	Real theta, dTheta, cosTheta, sinTheta;

	theta = 0;
	dTheta = 2 * vl_pi / NumTesselations;
	slBeginPoints();
	for (i = 0; i < NumTesselations; i++)
	{
		cosTheta = cos(theta) / 2.0;
		sinTheta = sin(theta) / 2.0;
		slPoint(Point(cosTheta, 1, sinTheta));
		slPoint(Point(cosTheta, 0, sinTheta));
		theta = theta + dTheta;
	}
	slEndPoints();
}

void SolidCylinderEnds()
{
	Int i;
	IndexList topFace, bottomFace;
	
	for (i = 0; i < NumTesselations; i++)
	{
			topFace.Append(2 * i);
			bottomFace.Append(2 * (NumTesselations - i) - 1);
	}

	slIndexes(topFace);
	slPoly();
	slIndexes(bottomFace);
	slPoly();
}

void SolidCylinderSides()
{
	Int			topLHS;
	IndexList	tesselation(4);
	Int			i;

	for (i = 0; i < NumTesselations; i++)
	{
		topLHS = 2 * i;							// Vertex num of top LHS of face 
		tesselation[0] = topLHS;				// Do LHS	
		tesselation[1] = (topLHS + 1);			// of face.	
		if (i == NumTesselations - 1)
			topLHS = -2;						// Last face has to close back to first 2 vertices 
		tesselation[2] = (topLHS + 3);
		tesselation[3] = (topLHS + 2);
		slIndexes(tesselation);
		slPoly();
	}
}

void CreateSolidCylinder()
{
	CylinderPoints();
	SolidCylinderEnds();
	SolidCylinderSides();
}

// --- Cone ------------------------


void ConePoints()
{
	Int i;
	Real theta, dTheta, cosTheta, sinTheta;

	theta = 0;
	dTheta = 2 * vl_pi / NumTesselations;
	slBeginPoints();
	slPoint(Point(0, 1, 0));
	
	for (i = 0; i < NumTesselations; i++)
	{
		cosTheta = cos(theta) / 2;
		sinTheta = sin(theta) / 2;
		slPoint(Point(cosTheta, 0, sinTheta));
		theta = theta + dTheta;
	}
	slEndPoints();
}

void SolidConeEnds()
{
	Int i;
	IndexList topFace, bottomFace;
	
	slBeginIndexes();
	for (i = 0; i < NumTesselations; i++)
		slIndex(i + 1);
	slEndIndexes();

	slPoly();
}

void SolidConeSides()
{
	IndexList	tesselation(4);
	Int			i;

	tesselation[0] = 0;

	for (i = 1; i <= NumTesselations; i++)
	{
		tesselation[1] = i;				// Do LHS	
		if (i == NumTesselations)
			tesselation[2] = 1;						// Last face has to close back to first 2 vertices 
		else
			tesselation[2] = i + 1;

		slIndexes(tesselation);
		slPoly();
	}
}

void CreateSolidCone()
{
	ConePoints();
	SolidConeEnds();
	SolidConeSides();
}

/*{ --- Sphere creation ------------------------------------- }

	procedure MakeSphereFaces (library: CLibrary; sphere: CSceneObject);
		var
			i, j, p, offset: integer;
			triangle1, triangle2, square: CFace;
	begin
		p = NumTesselations + 1;
		with sphere do
			for i = 2 to NumTesselations + 1 do				{ Step around the sphere... }
				begin
					triangle1 = CFace(library.Member('face'));		{ Make a face on the top of the sphere }
					triangle1.AddIndex(1);
					triangle1.AddIndex(p);
					triangle1.AddIndex(i);
					AddChild(triangle1);									{ And add it to the sphere }

					offset = NumTesselations;
					for j = 1 to (NumTesselations div 2) - 2 do		{ Make the faces between rings of vertices... }
						begin
							square = CFace(library.Member('face'));			{ Make such a face }
							square.AddIndex(i + offset - NumTesselations);
							square.AddIndex(p + offset - NumTesselations);
							square.AddIndex(p + offset);
							square.AddIndex(i + offset);
							AddChild(square);										{ And add it to the sphere }
							offset = offset + NumTesselations;
						end;

					triangle2 = CFace(library.Member('face'));			{ Make a face on the bottom of the sphere }
					triangle2.AddIndex(offset + 2);
					triangle2.AddIndex(offset - NumTesselations + i);
					triangle2.AddIndex(offset - NumTesselations + p);
					AddChild(triangle2);									{ And add it to the sphere }
					p = i;
				end;
	end;

	function CreateSolidSphere (library: CLibrary): CSceneObject;
		var
			sphere: CSceneObject;
	begin
		sphere = CreateSphereSet(library);

		MakeSphereFaces(library, sphere);

		CreateSolidSphere := sphere;
	end;

{ --- Procedure to add all the above objects to a library --------------------- }

	procedure AddSolidObjects (library: CLibrary);
	begin
		with library do
			begin
				AddMember(CreateSolidCube(library));
				AddMember(CreateSolidCylinder(library));
				AddMember(CreateSolidTetrahedron(library));
				AddMember(CreateSolidSphere(library));
			end;
	end;

end.



void cylinder(float r1, float r2)
{
	int i;
	float d, dd, top[3], btm[3], nrm[3];
	float scale, x, y;
	
	dd = 2 * kPi / kCylSubdivs;
	scale = 1 / sqrt((r2 - r1) * (r2 - r1) + 1);
	top[2] = 1; btm[2] = 0; nrm[2] = (r2 - r1) * scale;
	
	d = 0;
	bgnqstrip();
	
	for (i = 0; i < kCylSubdivs + 1; i++)
	{
		x = sin(d);
		y = cos(d);
		
		nrm[0] =  scale * x;
		nrm[1] =  scale * y;
	
		top[0] = r1 * x;
		top[1] = r1 * y;
		
		btm[0] = r2 * x;
		btm[1] = r2 * y;
		
		n3f(nrm);
		v3f(top);
		v3f(btm);
		
		d += dd;
	}

	endqstrip();
}

void ccylinder(float r1, float r2)
{
	int i;
	float d, dd, top[3], nrm[3];
	
	dd = 2 * kPi / kCylSubdivs;
	
	// top

	n3f(SetVec(nrm, 0, 0, 1));
	top[2] = 1;
	d = 0;
		
	bgnpolygon();
	
	for (i = 0; i < kCylSubdivs + 1; i++)
	{
		top[0] =  r1 * sin(d);
		top[1] =  r1 * cos(d);
	
		v3f(top);
		
		d += dd;
	}

	endpolygon();
	
	// bottom

	n3f(SetVec(nrm, 0, 0, -1));
	top[2] = 0;
	d = 0;
	
	bgnpolygon();
	
	for (i = 0; i < kCylSubdivs + 1; i++)
	{
		top[0] =  r2 * sin(d);
		top[1] =  r2 * cos(d);
	
		v3f(top);
		
		d += dd;
	}

	endpolygon();
}
*/

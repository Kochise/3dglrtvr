#include "FileName.h"
#include "GCLConfig.h"
#include <stdio.h>

void FileName::ChopExtension()
{
	Char	*dotPos;
	
	if (dotPos = strrchr(name.Ref(),  '.'))
	{
		extension = dotPos + 1;
		name = name.SubString(0, (int) (dotPos - name.Ref()));
	}
	else
		extension = "";
}

String FileName::GetPath()
{
	String result;
	
	result.SetSize(path.Length() + name.Length() + extension.Length() + 3);
#ifdef GCL_MACOS
	sprintf(result.Ref(), "%s.%s", name.Ref(), extension.Ref());
#else
	sprintf(result.Ref(), "%s/%s.%s", path.Ref(), name.Ref(), extension.Ref());
#endif
	return(result);
}

void	FileName::SetPath(const char *filePath)
{
	char *dotPos, *slashPos;
	
	slashPos = strrchr(filePath, '/');
	
	if (slashPos)
	{
		path = StrConst(filePath).Prefix((int) (slashPos - filePath));
		name = slashPos + 1;
	}
	else
	{
		path = ".";
		name = filePath;
	}

	ChopExtension();
}

/*
	File:			Pixel.h

	Function:		Defines an RGBA pixel which can be added / subtracted etc.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Pixel__
#define __Pixel__

#include "Basics.h"
#include "Colour.h"
#include "iostream.h"

class Pixel
{
public:
	
	Pixel() {};
	Pixel(Real r);
	Pixel(Byte r, Byte g, Byte b, Byte a);
	Pixel(const Pixel &a);
	Pixel(const Colour &c);
	
	operator Real() const { return(channel[currentChannel] / 255.0); };
	
	Pixel	&operator = (Pixel a);	
	Pixel	&operator = (Real r);

	Bool	operator == (Pixel a) const;	
	Bool	operator != (Pixel a) const;

	Pixel 	&operator += (Pixel a);
	Pixel 	&operator -= (Pixel a);
	Pixel 	&operator *= (Pixel a);
	Pixel 	&operator *= (Real r);
	Pixel 	&operator /= (Pixel a);

	Pixel 	&operator - ();
	Pixel 	operator + (Pixel a) const;
	Pixel 	operator - (Pixel a) const; 
	Pixel 	operator * (Pixel a) const;
	Pixel 	operator * (Real r) const;
	Pixel	operator / (Pixel a) const;
	Pixel 	operator / (Real r) const;
	
	static Int 		currentChannel;

	union 
	{
		Byte	 		channel[4];
		UInt32			data;
	};
};

ostream &operator << (ostream &s, Pixel p);
istream &operator >> (istream &s, Pixel &p);

enum PixelChannel { chAlpha, chBlue, chGreen, chRed };

#endif

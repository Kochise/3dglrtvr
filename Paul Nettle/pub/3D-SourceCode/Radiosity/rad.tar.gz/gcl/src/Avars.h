/*
	File:			Avars.h
	
	Function:		Provides avar-controlled scene objects, and methods
					for extracting a list of avars from the current scene.

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Avars__
#define __Avars__

#include "SceneObjects.h"
#include "Array.h"
#include <iostream.h>

ostream &operator << (ostream &s, Avar &avar);
typedef Array<Avar> AvarList;


class scAvarColour : public scColour
{
public:	
	scAvarColour(Avar &avar, Colour colour);

	Bool 			HasAvar(Avar &avar, Int slot);
	void			AddToContext(Context *context);
	void			Print(ostream &s) const;
	void			Parse(istream &s);
					
	virtual void	Recalc();
	Object  		*Clone() const { return new scAvarColour(SELF); };
		
	Avar			avar;
	Colour			colour;
	Int				listSlot;
};

class scAvarEmittance : public scEmittance
{
public:	
	scAvarEmittance(Avar &avar, Colour colour);

	Bool 			HasAvar(Avar &avar, Int slot);
	void			AddToContext(Context *context);
	void			Print(ostream &s) const;
	void			Parse(istream &s);

	virtual void	Recalc();
	Object  		*Clone() const { return new scAvarEmittance(SELF); };
		
	Avar			avar;
	Colour			colour;
	Int				listSlot;
};

class scAvarTransform : public scTransform
{
public: 
	scAvarTransform(Avar &avar, Vector vector);

	Bool 			HasAvar(Avar &avar, Int slot);
	void			AddToContext(Context *context);

	virtual void	Recalc() {};
	Object  		*Clone() const { return new scAvarTransform(SELF); };
		
	Avar			avar;
	Vector			vector;
	Int				listSlot;
};

class scAvarShift : public scAvarTransform
{
public:	
	scAvarShift(Avar &avar, Vector vector) : scAvarTransform(avar, vector) { Recalc();};
	void			Recalc();
	void			Print(ostream &s) const;
	void			Parse(istream &s);
	Object  		*Clone() const { return new scAvarShift(SELF); };
};

class scAvarRotation : public scAvarTransform
{
public:	
	scAvarRotation(Avar &avar, Vector vector) : scAvarTransform(avar, vector) { Recalc();};
	void	Recalc();
	void			Print(ostream &s) const;
	void			Parse(istream &s);
	Object  		*Clone() const { return new scAvarRotation(SELF); };
};

class scAvarScale : public scAvarTransform
{
public:	
	scAvarScale(Avar &avar, Vector vector) : scAvarTransform(avar, vector) { Recalc();};
	void	Recalc();
	void			Print(ostream &s) const;
	void			Parse(istream &s);
	Object  		*Clone() const { return new scAvarScale(SELF); };
};


class scAvarList : public scAttribute, public AvarList
{
public:
	scAvarList() : scAttribute(aAvarList), AvarList() {};
	
	void			Print(ostream &s) const;
	Bool			SetAvar(Char *name, Real value);

	Object  	 	*Clone() const { return new scAvarList(SELF); };
};


class CreateAvarList: public scSceneAction
{
public:
	CreateAvarList() : scSceneAction(), avarList(0) {};
	
	void		Start();
	void		Attribute(scAttribute &sa);

	scAvarList	*avarList;
	Avar		newAvar;
};

 
#endif

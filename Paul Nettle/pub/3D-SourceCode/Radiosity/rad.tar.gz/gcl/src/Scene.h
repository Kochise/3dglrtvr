/*
	File:			Scene.h

	Function:		Basic definitions for a scene and its constituent objects:
					attributes (for setting state variables such as colour),
					primitives (drawing) and groups (aggregates of primitives).
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Scene__
#define __Scene__

#include "ObjArray.h"
#include "Renderer.h"
#include "Context.h"


// --- Basic Object types -----------------------------


enum scAttributeID
{
	aColour = 1, 	// a colour/reflectance value
	aEmittance,		// an emittance value
	aPoints,		// a list of points
	aColours,		// a list of colours
	aNormals,		// a list of normals
	aIndexes,		// 
	aNormalIndexes,
	aTransform,		// a transformation
	aCamera,		// scene camera
	aAvarList,		// a list of avar values
// ...
	aNumAttributes 
};

/*
	Possible new types: FaceList, Face, FaceIndexes
    That way the same face could be included in multiple groups,
	a la .obj files. We still need a way of restricting drawing
	multiply-referenced faces, though. Perhaps tag groups?
	Also, highlighting specific groups.
	Also, smoothing groups / texturing...
*/

enum scPrimitiveID
{
	pGroup = 1,
	pPoly,
	pSphere,
	pCylinder,
	pCone,
	pTetrahedron,
// ...
	pNumBasicPrimitives
};

const int scNull = 0;


// --- Avar class -------------------------------------------------------------


class Avar 
{
public:
	Avar() {};
	Avar(Char *name, Real value = 0, Real lowerBound = 0, Real upperBound = 1) :
		name(name), value(value), lowerBound(lowerBound), upperBound(upperBound) {};

	Char	*name;			// Avar's name
	Real	value;			// its value
	Real 	lowerBound;		// its range
	Real 	upperBound;
};

ostream  &operator << (ostream &s, const Avar &avar);


// --- Fundamental scene objects -----------------------------------------------

#define SO_GET(X) ((sc ## X *) Get(a ## X))		// shorthand for fetch & cast attribute...

#ifdef ANSI_CC
class scObject : public Object;
#else
class scObject;
#endif

class scGroup;

typedef Action<scObject> 			scAction;			
typedef scObject			 		*scObjectPtr;


#ifdef ANSI_CC
class scObject
#else
class scObject : public Object
#endif
{
	public:
	
			scObject() :               		Object(), itsType(scNull) {};
			scObject(Int itsType) : 		Object(), itsType(itsType) {};
			scObject(const scObject &so) : 	Object(), itsType(so.itsType) {};
	virtual ~scObject();
	
	virtual void			Apply(Transform &m);				// Transform the object
	void					ApplyAction(scAction &a);			// Apply action to object
	virtual void			ApplyToSelf(scAction &a);			// Internal routine for the above.			
	void 					Print(ostream &s) const;
	virtual void			HierPrint(ostream &s, Int indent) const;
		
	Object 					*Clone() const { return new scObject(SELF); };
	Bool					IsPrim() const { return (itsType > 0); };
	Bool					IsAttr() const { return (itsType < 0); };
	Bool					IsGroup() const { return (itsType == pGroup); };
	scPrimitiveID			PrimID() const { return (scPrimitiveID) itsType; };
	scAttributeID			AttrID() const { return (scAttributeID) -itsType; };
	
protected:
	Int 					itsType;							// -ve == attribute, +ve == primitive.
	static Int 				prIndent;							// indent in printing
};

#define PrimCast(x) ((scPrimitive *) (scObject *)  x)
#define AttrCast(x) ((scAttribute *) (scObject *)  x)
#define GroupCast(x) ((scGroup *) x)

class scAttribute : public scObject
{	
public:
	scAttribute(AttrType attrType) : 		scObject(-attrType) {};
	scAttribute(const scAttribute &sa) :	scObject(sa) {};

	virtual void			AddToContext(Context *context);		// Add this attribute to the context
	virtual	Bool			HasAvar(Avar &avar, Int slot);		// returns true (and sets avar) if the
																// attribute is avar-controlled.
	void		 			Print(ostream &s) const;
		
	Object  				*Clone() const { return new scAttribute(SELF); };
};

class scClearAttr : public scAttribute	// Signals end of influence of a particular attribute.
{	
public:
	scClearAttr(AttrType attrType) :		scAttribute(attrType) {};
	scClearAttr(const scAttribute &sa) :	scAttribute(sa) {};

	void					AddToContext(Context *context);

	void		 			Print(ostream &s) const;

	Object	 				*Clone() const { return new scClearAttr(SELF); };
};


class scGroup;	//	forward declare the group object

class scPrimitive : public scObject, public Renderable
{	
public:

	scPrimitive(scPrimitiveID primType) :	scObject(primType), parent(0) {};
	scPrimitive(const scPrimitive &sp) :	scObject(sp), parent(sp.parent) {};

	virtual void			*UpCast() {return this;};			// Used for casting an object back to its full type.

	void					Draw(Renderer &r);					
	virtual void			Draw(Renderer &r, Context *context);					
	void		 			Print(ostream &s) const;

	void					Apply(Transform &m);				// Transform the object
	virtual void			Set(scAttribute *sa);
	virtual scAttribute		*Get(scAttributeID id);
	virtual scAttribute		*FindFirst(scAttributeID id);

	virtual Char			*Label() const { return "primitive"; }; 
	Object 					*Clone() const { return new scPrimitive(SELF); };
	scGroup					*parent;
private:
	scPrimitive() {};
};


// --- Group object ------------------------


class scGroup : public scPrimitive
{
public:
	scGroup() :						scPrimitive(pGroup), children(), name("unknown") {};
	scGroup(Char *name) :			scPrimitive(pGroup), children(), name(name) {};
	scGroup(const scGroup &sg);
	
	void					Apply(Transform &m);				// Transform the object
	void					ApplyToSelf(scAction &a);			// Apply action to the object

	void					Draw(Renderer &r, Context *context);					
	void 					Print(ostream &s) const;
	void					HierPrint(ostream &s, Int indent) const;
	void					Parse(istream &s);
	void					Set(scAttribute *sa);
	virtual scAttribute		*FindFirst(scAttributeID id);
	
	scObject				*Child(Int i) { return (scObject *) children[i]; };
	Int						NumChildren() { return children.NumItems(); };
	void					SetName(Char *name);
	void					Add(scObject *so);
	scObject				*Last();
	Char					*Label() const; 
	Object					*Clone() const;
	
	Char					*name;
	ObjArray				children;
};

// --- Typedefs ------------------------------------------------------

typedef scGroup						scScene;
typedef scScene						*scScenePtr;
typedef ObjArray					scObjectList;

ostream &operator << (ostream &s, const scScenePtr scene);


// --- Actions --------------------------------------------------------


class scSceneAction : public scAction
{
public:
	scSceneAction() : context(0) {};
	
	void			Start();					// override
	void			Stop();						// override
	void			Process(scObject &so);

	virtual void	Primitive(scPrimitive &sp);
	virtual void	Attribute(scAttribute &sp);
																														
	Context			*context;
};


class scIterator
{
public:
	Int i;
	const scObjectList *list;
	
	scIterator(const scObjectList &l) : i(0), list(&l) {};
	
	void		Start() {i = 0;};
	Bool		AtEnd() { return i >= list->NumItems();};
	void		Next() { i++;};
	void		operator ++ (int) { i++;};
	scObject	*operator ()() {return (scObject *) (*list)[i];};	
};



#endif

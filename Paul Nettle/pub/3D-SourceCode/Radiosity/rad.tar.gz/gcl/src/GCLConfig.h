/*
	File:		GCLConfig.h

	Purpose:	Contains config options for compiling GCL

	Author:		Andrew Willmott, (c) 1997

	Notes:
				GCL_TIFF enables TIFF support. Requires libtiff.
				GCL_MGF enables MGF support. Requires libmgf.
				GCL_MACOS required for compiling on the mac
				GCL_PARSE_SC required to support Paul Heckbert's 'sc'
				scene format.
				GCL_GZIP enables support for automatically gunzipping
				scene files with the extension '.gz'. 'gunzip' must
				be installed for this to work.
*/

// For the SGI
#define GCL_TIFF
#define GCL_MGF
#define GCL_PARSE_SC
#define GCL_GZIP

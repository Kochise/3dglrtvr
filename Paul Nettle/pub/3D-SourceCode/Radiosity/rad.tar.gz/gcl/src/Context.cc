/*
	File:			Context.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			The context maintains a list of the attributes (i.e., 
					state variables), and can conceptually pop or push
					that list from/to a stack. In fact attributes are
					only pushed / popped on a need-to basis, to avoid
					the overhead of copying the entire list each time.

	Change History:
		31/01/96	ajw		Started
*/


#include "Context.h"

const Int16 daemonFlag = 0x4000;
const Int16 unusedFlag = 0x2000;
const Int16 levelMask  = 0x0FFF;


Context::Context(Int numAttrs) :
	attributeList(numAttrs),
	attributeStack(),
	level(0)
{
	Int i;
	
	for (i = 0; i < numAttrs; i++)
	{
		attributeList[i].level = 0; 
		attributeList[i].data = 0;
	}	
}

AttrPtr Context::Get(AttrType attrType)
{
	if (attributeList[attrType].level & daemonFlag)
		return(attributeList[attrType].daemon->Get());
	else
		return(attributeList[attrType].data);		
}

void Context::Set(AttrType attrType, AttrPtr attrPtr)
{
	AttrRec	*pRec = &attributeList[attrType];
	AttrStackRec	sRec;
	Bool			isDaemon = (pRec->level & daemonFlag);
				
	// if the attribute exists and wasn't set this level, push it...
	
	if (pRec->data && (pRec->level & levelMask) < level)
	{
		sRec.attrRec = *pRec;
		sRec.attrType = attrType;
		
		if (isDaemon)
			pRec->daemon->Save();

		attributeStack.Push(sRec);
	}
	
	if (isDaemon)
		pRec->daemon->Set(attrPtr);
	else
		pRec->data = attrPtr;
	pRec->level = level;
}

void Context::SetDaemon(AttrType attrType, AttrDaemon *daemon)
{
	Assert((attributeList[attrType].level & daemonFlag) == 0, "Daemon already set for this slot.");
	
	Set(attrType, daemon);

	if (daemon)
		attributeList[attrType].level |= daemonFlag;
}

void Context::Push()
{
	AttrStackRec sRec;
	
	level++;
	sRec.attrRec.level = -1;	// mark pRec as a sentinel
	attributeStack.Push(sRec);	// Add to the stack
}

void Context::Pop()
{
	Int i;
	
//	pop off all the attributes changed since the last push...

	Assert(level > 0, "(Context::Pop) Too many pops");
	
	while (attributeStack.Top().attrRec.level >= 0)	
	{
		if (attributeStack.Top().attrRec.level & daemonFlag)
			attributeStack.Top().attrRec.daemon->Restore();			
		attributeList[attributeStack.Top().attrType] = attributeStack.Top().attrRec;
		attributeStack.Pop();
	}

//	pop off the sentinel...

	attributeStack.Pop();
	level--;
	
	for (i = 0; i < attributeList.NumItems(); i++)
		if ((attributeList[i].level & levelMask) > level)
		{
			attributeList[i].data = 0;
			attributeList[i].level = 0;
		}
}

Bool Context::IsCurrent(AttrType attrType)
{
	return(attributeList[attrType].level == level);
}

ostream &operator << (ostream &s, const AttrRec &ar)
{
	s << ar.data << "@" << ar.level;
	
	return(s);
}

ostream &operator << (ostream &s, const AttrStackRec &asr)
{
	s << asr.attrRec << ":" << asr.attrType;

	return(s);
}

ostream &operator << (ostream &s, const Context &ctx)
{
	s << "Context at level " << ctx.level << ". Current attributes: " << endl;
	s << (Array<AttrRec> &) ctx.attributeList << endl;
	s << "Attribute stack: " << endl << (Array<AttrStackRec> &) ctx.attributeStack << endl;
	
	return(s);
}



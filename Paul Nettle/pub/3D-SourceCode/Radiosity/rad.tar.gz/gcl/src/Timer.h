/*
	File:			Timer.h

	Function:		Provides routines for timing under several different 
					architectures. You must define one of the following:
				
						ANSI_TIME		Use the ansi clock() routine
						UNIX_USR_TIME	Use the times() call, user time
						UNIX_SYS_TIME	Use the times() call, system time
						UNIX_TOT_TIME	Use the times() call, total process time
						GETRUSAGE_TIME 	Use getrusage() system call
						SGI_TIME		Use the SGI multimedia timing 
										routines (nano-second accuracy.)
		
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Timer__
#define __Timer__


void	StartTimer();	/* Starts timer */
void	StopTimer();	/* Stops timer */
void	ContTimer();	/* Continue timer */
float	GetTimer();		/* Returns time in seconds since timer was started */

float	DeltaTime();	/* returns time delta since DeltaTime or 
						   StartTimer was last called. */
#endif

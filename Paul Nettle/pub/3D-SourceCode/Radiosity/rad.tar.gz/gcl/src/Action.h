/*
	File:			Action.h

	Function:		Defines an 'Action' which can be applied to all members of a container.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Action__
#define __Action__

#include "Basics.h"

#define TAction Action<T>


// --- Abstract Action Class ---------------------------------------------------


template <class T> class Action
{
public: 
		
	virtual void	Start() {};
	virtual void 	Process(T &t) = 0;				// Abstract action method.
	virtual void	Stop() {};
};


// --- A demonstration Action --------------------------------------------


template <class T> class Stats : public Action<T>
{
public:
	
	void	Start();
	void 	Process(T &t);				
	void	Stop();
	
	T 		mean;
	T		variance;
	
protected:
	
	Int		n;
	T		sumX;
	T		sumXSqr;
};


template <class T> void Stats<T>::Start()
{
	sumX = sumXSqr = 0;
	n = 0;
}
	
template <class T> void Stats<T>::Process(T &t)
{
	sumX += t;
	sumXSqr += sqr(t);
	n++;
}
	
template <class T> void Stats<T>::Stop()
{
	mean = sumX / n;
	variance = sumXSqr / n - sqr(mean);
}
	
#endif

/*
	File:			SceneLang.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

	Change History:
		31/01/96	ajw		Started
*/


#include "SceneLang.h"
#include "Context.h"

#define SL_GET(X) (sc ## X *) slContext->Get(a ## X)

/// --- Current library & scene-parsing context ----------------------

static Context *slContext = new Context(aNumAttributes);
static Library *slLibrary = 0;

static scGroup *slCurrentGroupPtr;

// --- Scene command definitions ------------------------------------

scObject *slCurrent()
{
	return(slCurrentGroupPtr->Last());
}

scScenePtr slCurrentGroup()
{
	return(slCurrentGroupPtr);
}
 
scScenePtr slBeginObject(char *name)
{
	if (!slLibrary)
		slSetLibrary(new Library);

	scScenePtr	newGroup = GroupCast(Clone(slLibrary->Member("group")));
	
	newGroup->SetName(name);
			
	if (slCurrentGroupPtr)
		slCurrentGroupPtr->Add(newGroup);
	
	slCurrentGroupPtr = newGroup;
	slContext->Push();

	return(newGroup);
}

void slEndObject()
{
	slCurrentGroupPtr = slCurrentGroupPtr->parent;
	slContext->Pop();	
}

#pragma mark -
// --- Attribute routines ---------------------------------------


void slBeginPoints()
{
	scPoints 	*points = new scPoints;
	
	points->AddToContext(slContext);
	slCurrentGroupPtr->Add(points);
}

void slEndPoints()
{
}

void slBeginColours()
{
	scColours	*colours = new scColours;

	colours->AddToContext(slContext);
	slCurrentGroupPtr->Add(colours);
}

void slEndColours()
{
}

void slBeginNormals()
{
/*	scNormals 	*normals = new scNormals;
	scGroup		*object;
	
	normals->AddToContext(slContext);

	if (object = SL_GET(Group))
		slCurrentGroupPtr->Set(normals);
*/
}

void slEndNormals()
{
}

void slBeginIndexes()
{
	scIndexes	*indexes = new scIndexes;

	indexes->AddToContext(slContext);
	slCurrentGroupPtr->Add(indexes);
}

void slEndIndexes()
{
}

#pragma mark -

void slColour(const Colour &c)
{
	scColours	*colours;
		
	if (colours = SL_GET(Colours))
		colours->Append(c);
	else 
	{
		scColour	*colour = new scColour(c);

		slCurrentGroupPtr->Add(colour);
		colour->AddToContext(slContext);
	}
}

void slEmittance(const Colour &c)
{
	scEmittance	*emit = new scEmittance(c);

	slCurrentGroupPtr->Add(emit);
	emit->AddToContext(slContext);
}

void slIndex(Int i)
{
	scIndexes	*indexes;
	
	if (indexes = SL_GET(Indexes))
		indexes->Append(i);
}

void slPoint(const Point &p)
{
	scPoints	*points;
		
	if (points = SL_GET(Points))
	{
		points->Append(p);
		slIndex(points->NumItems() - 1);
	}
}

void slCamera()
{
	scCamera *camera = new scCamera;
	
	camera->AddToContext(slContext);
	slCurrentGroupPtr->Add(camera);
}

void slTransform(const Transform &t)
{
	scTransform	*transform = new scTransform(t);

	slCurrentGroupPtr->Add(transform);
	transform->AddToContext(slContext);
}

void slPoints(const PointList &pl)
{
	scPoints	*points = new scPoints(pl);

	slCurrentGroupPtr->Add(points);
	points->AddToContext(slContext);
}

void slIndexes(const IndexList &il)
{
	scIndexes	*indexes = new scIndexes(il);

	slCurrentGroupPtr->Add(indexes);
	indexes->AddToContext(slContext);
}

#pragma mark -

void slPoly()
{
	scPrimitive *poly;
	
	poly = Clone(slLibrary->Member("poly"));

	slCurrentGroupPtr->Add(poly);
}

void slApply(Transform &t)
{
	slCurrent()->Apply(t);
}

void slObject(Char *name)
{
	slCurrentGroupPtr->Add(Clone(slLibrary->Member(name)));
}

Bool slObjectExists(Char *name)
{
	if (slLibrary)
		return(slLibrary->MemberExists(name));
	else
		return(false);
}

void slBeginObject(scScenePtr object)
{
	if (!slLibrary)
		slSetLibrary(new Library);
			
	if (slCurrentGroupPtr)
		slCurrentGroupPtr->Add(object);
	
	slCurrentGroupPtr = object;
	slContext->Push();
}

void slObject(scObject *object)
{
	slCurrentGroupPtr->Add(object);
}

void slAttribute(scAttribute *attrPtr)
{
	slCurrentGroupPtr->Add(attrPtr);
}




#pragma mark -
// --- Library routines ---------------------------------------


void slSetLibrary(Library *library)
{
	delete slLibrary;
	
	slLibrary = library;
	slLibrary->Create();
}

Library *slSwapLibrary(Library *newLib)
{
	Library *tl = slLibrary;
	
	slLibrary = newLib;
	return(tl);
}

void slAddToLibrary(scGroup *newGroup)
{
	slLibrary->AddMember(newGroup);
}

Library *slGetLibrary()
{
	return(slLibrary);
}

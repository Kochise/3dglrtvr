
#ifndef __String__
#define __String__

#include "Array.h"
#include <string.h>
#include <iostream.h>
#include <fstream.h>


// --- StrConst Class ----------------------------------

class String;

class StrConst
{
public:
	StrConst() : theString(0) {};
	StrConst(const char *s) : theString(s) {};
	
	operator const char*() { return theString; }; 
	
	Bool		operator == (StrConst s) { return(strcmp(theString, s.theString) == 0); };
	Bool		operator != (StrConst s) { return(strcmp(theString, s.theString) != 0); };

	String		SubString(Int start, Int length);
	String		SubString(Int start);
	String		Prefix(Int length);
	String		Suffix(Int length);

	Int			Length() {return(strlen(theString));};
	const char 	*Ref() { return theString; };
	
protected:	
	const char*	theString;	
};


// --- String class -------------------------------------

// Implements: dynamically-sized string.

class String : public Array<Char>
{
public:
				String() : Array<Char>(16) { item[0] = 0; };
				String(const String &sb) : Array<Char>(sb) {};
				~String() {};
				
				operator StrConst() { return(StrConst(item)); };
				
	String		&Append(StrConst s);
	String		&Insert(StrConst s, Int place);
	String		&Delete(Int start, Int length);
	
	String		&operator = (StrConst s);
	Bool		operator == (StrConst s) { return(strcmp(item, s) == 0); };
	Bool		operator != (StrConst s) { return(strcmp(item, s) != 0); };
		
	istream		&ReadString(istream &s);	// read a quote-enclosed string, e.g. "hello"
	istream		&ReadWord(istream &s);		// read the next string of non-whitespace characters
	istream		&ReadLine(istream &s);		// read a line.
	
	//	My God, C++ sucks.
	
	Int			Length()
					{ return(NumItems() - 1); };
	String		SubString(Int start, Int length)
					{ return(StrConst(item).SubString(start, length)); };
	String		SubString(Int start)
					{ return(StrConst(item).SubString(start)); };
	String		Prefix(Int length)
					{ return(StrConst(item).Prefix(length)); };
	String		Suffix(Int length)
					{ return(StrConst(item).Suffix(length)); };

	void		Free() { Clear(); };
	
	friend		StrConst;
};

inline ostream &operator << (ostream &s, String &sb) { s << (const char *) (StrConst) sb; return(s); };
istream &operator >> (istream &s, String &str);

Bool IsEndOfLine(istream &s);


// --- TempString class --------------------------------------

//	Purpose: For speeding up concatenation sequences. These operators ensure that only
//	one String is used for all the concatenations.

class TempString : public String
{
public:
	TempString() : String() {};
	operator String() { return((String &) SELF); };
};

inline ostream &operator << (ostream &s, TempString &sb)  { s << (String &) sb; return(s); };

inline TempString operator + (StrConst a, StrConst b)     { TempString t; t.Append(a).Append(b);
																return(t); };
inline TempString &operator + (TempString &a, StrConst b) { return((TempString &) a.Append(b)); }
inline TempString &operator + (StrConst a, TempString &b) { return((TempString &) b.Insert(a, 0));}

#endif

#ifndef __FileName__
#define __FileName__

#include "String.h"

class FileName
{
public:
	String	path;
	String	name;
	String	extension;

	void	SetPath(const char *path);
	String	GetPath();
	void	ChopExtension();
};

#endif

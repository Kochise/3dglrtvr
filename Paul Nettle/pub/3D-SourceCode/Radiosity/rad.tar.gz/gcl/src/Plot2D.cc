/*
	File:			Plot2D.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

	Change History:
		31/01/96	ajw		Started
*/

#include "Plot2D.h"
#include "GL/gl.h"

Plot2D::Plot2D() : scPrimitive(pPoly)
{
	samples.SetSize(10, 10);
	samples.MakeZero();
}
 
Char *Plot2D::Label() const
{
	return("2D Plot");
}

void Plot2D::Draw(Renderer &r, Context *context)
{
	Int 		i, j;
	Point		pos0, pos1, pos2, pos3;
	Vector		dx, dz, normal;
	Colour		col = *(SC_GET(Colour));
				
	r.MakeCurrent();

#if 1
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHTING);
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
#endif

	if (!isStep)
	{
		dx = Vector(2.0 / (samples.Cols() - 1), 0, 0);
		dz = Vector(0, 0, 2.0 / (samples.Rows() - 1));

		pos0[2] = -1;
		
		for (i = 0; i < samples.Rows() - 1; i++)
		{
			pos0[0] = -1;
			pos1 = pos0 + dz;
			
			for (j = 0; j < samples.Cols() - 1; j++)
			{
				pos3 = pos0 + dx;
				pos2 = pos1 + dx;
				pos0[1] = samples[i][j] + 0.01;
				pos1[1] = samples[i + 1][j] + 0.01;
				pos2[1] = samples[i + 1][j + 1] + 0.01;
				pos3[1] = samples[i][j + 1] + 0.01;
				
				normal = norm(cross(pos1 - pos0, pos3 - pos0)); 
				
				glNormal3dv(normal.Ref());
				r.SetColour(col).Begin(renPoly).SetPoint(pos0).SetPoint(pos1).SetPoint(pos2).SetPoint(pos3).End();
				
				pos0 += dx;
				pos1 += dx;
			}
			
			pos0 += dz;
		}
	}
	else
	{
		dx = Vector(2.0 / samples.Cols(), 0, 0);
		dz = Vector(0, 0, 2.0 / samples.Rows());

		pos0[2] = -1;
		
		for (i = 0; i < samples.Rows(); i++)
		{
			pos0[0] = -1;
			pos1 = pos0 + dz;
			
			for (j = 0; j < samples.Cols(); j++)
			{
				pos3 = pos0 + dx;
				pos2 = pos1 + dx;
				pos0[1] = pos1[1] = pos2[1] = pos3[1] = samples[i][j];
			
				r.Begin(renPoly).SetPoint(pos0).SetPoint(pos1).SetPoint(pos2).SetPoint(pos3).End();
			
				pos0 += dx;
				pos1 += dx;
			}
			
			pos0 += dz;
		}
	}
	
#if 1
	glDisable(GL_COLOR_MATERIAL);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHTING);
#endif
}
  

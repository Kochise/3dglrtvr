/*
	File:			EPSRenderer.cc

	Function:		Implements EPSRenderer.h

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			Defines a vanilla renderer object. Just outputs the calls
					it gets as text.
*/

#include <iostream.h>
#include "EPSRenderer.h"


#if 0
#include "MesaApp.h"
#define WIN_WIDTH (300 / 2.0)
void EPSRenderer::MoveTo(Real x, Real y)
{
	QDMoveTo(x * WIN_WIDTH + WIN_WIDTH, -y * WIN_WIDTH + WIN_WIDTH);
	cout << "moveto " << x << ", " << y << endl;
}

void EPSRenderer::LineTo(Real x, Real y)
{
	QDLineTo(x * WIN_WIDTH + WIN_WIDTH, -y * WIN_WIDTH + WIN_WIDTH);
	cout << "lineto " << x << ", " << y << endl;
}
#else
void EPSRenderer::MoveTo(Real x, Real y)
{
	itsPlot.MoveTo(x, y);
}

void EPSRenderer::LineTo(Real x, Real y)
{
	itsPlot.LineTo(x, y);
}
#endif

EPSRenderer::EPSRenderer() : 
	Renderer(),
	matrixStack(1, 32),
	start(true),
	style(renNone),
	itsFilename("out.eps")
{
	matrixStack.Top() = vl_I;
}

void EPSRenderer::Attach(Char *epsFilename)
{
	itsFilename = epsFilename;
}

void EPSRenderer::MakeCurrent()
{
}

void EPSRenderer::Show()
{
	itsPlot.Close();
}

// --- Renderer Drawing Operators -------------------------------------------


Renderer &EPSRenderer::SetColour(const Colour &c)
{
	return(SELF);
}

Renderer &EPSRenderer::SetPoint(const Point &p)
{
	Vec4d	hPoint(p, 1.0);
	Point	x;
	Real	saveZ;
	
	hPoint = matrixStack.Top() * hPoint;
	saveZ = hPoint[2];
	if (abs(hPoint[3]) < 1e-6)
		hPoint[3] = 1e-6;
	x = proj(hPoint);
	x[2] = saveZ;
	
	if (start)
	{
		MoveTo(x[0], x[1]);
		firstPoint = x;
		lastPoint = x;
		start = false;
	}
	else
	{
		if (x[2] <= 0)	// behind camera plane.
		{
			if (lastPoint[2] > 0) // we were in front.
			{
				//x = (x * lastPoint[2] - lastPoint * x[2]) / (lastPoint[2] - x[2]);
				//LineTo(x[0], x[1]);
			}
			// otherwise, forget it.
		}		
		else 
		{
			if (lastPoint[2] <= 0)	// moving in front again
			{
				lastPoint = (x * lastPoint[2] - lastPoint * x[2]) / (lastPoint[2] - x[2]);
				//MoveTo(lastPoint[0], lastPoint[1]);
				lastPoint = x;
				return(SELF);
			}

			LineTo(x[0], x[1]);		// normal line.
			lastPoint = x;
		}
	}
		
	return(SELF);
}

Renderer &EPSRenderer::SetCoord(const Coord &c)
{
	return(SELF);
}

Renderer &EPSRenderer::SetNormal(const Vector &n)
{
	return(SELF);
}

Renderer &EPSRenderer::SetTransform(const Transform &t)
{
	matrixStack.Top() *= t;	
	return(SELF);
}

Renderer &EPSRenderer::SetCamera(const Camera &c)
{
	matrixStack.Clear();
	matrixStack.Push(c.ProjMatrix() * c.ModelMatrix());
	return(SELF);
}

Renderer &EPSRenderer::Pop()
{
	matrixStack.Pop();
	return(SELF);
}

Renderer &EPSRenderer::Push()
{
	matrixStack.Push(matrixStack.Top());	
	return(SELF);
}

Renderer &EPSRenderer::Clear()
{
	itsPlot.SetOutputSize(192);	// 192 points: this gets us same size
	itsPlot.Open(itsFilename);	// as 400x400 picture at 150dpi in frame
	itsPlot.SetPort(-1, -1, 1, 1, true);
	itsPlot.SetWidth(0.0005);

	return(SELF);
}

Renderer &EPSRenderer::Begin(RenderStyle newStyle)
{
	Assert(style == renNone, "Unmatched EPSRenderer::Begin().");
	style = newStyle;
	start = true;
	return(SELF);
}

Renderer &EPSRenderer::End()
{
	Assert(style != renNone, "Unmatched EPSRenderer::End().");
	if (lastPoint[2] > 0 && firstPoint[2] > 0)
		LineTo(firstPoint[0], firstPoint[1]);
	style = renNone;
	return(SELF);
}

void EPSRenderer::Print(ostream &s)
{
	s << "EPS Renderer\n  style = " << (int) style << " matrix = " << matrixStack.Top()
		 << " start = " << start << endl;	
}

Renderer &EPSRenderer::Rect(Real left, Real up, Real right, Real down)
{
	return(SELF);
}


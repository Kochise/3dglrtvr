/*
	File:			ScenePane.h

	Function:		'ScenePane' provides a pane which you can attach a scene
					to. The pane then lets the user manipulate the view of the
					scene.

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Pane__
#define __Pane__

#include "XGraphicsSystem.h"
#include "SceneObjects.h"


class ScenePane : public GSPane
{
	public:
	
	ScenePane(Bool doubleBuf = true);
	
	virtual void 	SetScene(scScenePtr scene);
	
	void 			Redraw();											// Force redraw of scene.
	void			TrackMouse(XButtonEvent *be);
	void 			ViewFrom(Point &position, Vector &normal);			// Change viewing point
	void			Restore();
	virtual void	Pick(Real x, Real y, Int which, Int levelsUp) {};	// Pick object at screen coords (x, y)
	
	void			HandleEvent(XEvent *event);	// override	
	Camera*			ItsCamera() { return(itsCamera); };
		
	protected:
	
	Real			rotX, rotY;
	Real			transX, transY, transZ;
	Real 			zoom;
	
	Transform		inverseTransform;
	scScenePtr		itsScene;
	Camera			*itsCamera;
	Camera			savedCam;
	Bool			isSavedCam;
};


#endif

/*
	File:			Geometry.h

	Function:		General geometrical definitions for points, vectors, etc.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Geometry__
#define __Geometry__

#include "VLd.h"
#include "Array.h"
#include "Action.h"
#include "Colour.h"


// --- Fundamental primitives -----------------------------

typedef Double	GCLReal;
typedef Vec3d	Point;				// We try and make provision here for 
typedef Vec3d	Vector;				// points and vectors being separate types in future...
typedef Vec4d	Vector4;		
typedef Vec4d	Quaternion;
typedef Vec2d	Coord;			

typedef Vec4d	HPoint;
typedef Vec4d	HVector;

typedef Mat4d	Transform;
typedef Mat3d	VecTrans;
typedef Int		Index;

inline Transform Rotation(const Vector &axis, Real theta)
{ Transform result; result.MakeHRot(axis, theta); return(result); }
inline Transform Rotation(const Quaternion &q)
{ Transform result; result.MakeHRot(q); return(result); }
inline Transform Scale(const Vector &s)
{ Transform result; result.MakeHScale(s); return(result); }
inline Transform Shift(const Vector &t)
{ Transform result; result.MakeHTrans(t); return(result); }

inline Transform Scale(GCLReal sx, GCLReal sy, GCLReal sz)
{ Transform result; result.MakeHScale(Vector(sx, sy, sz)); return(result); }
inline Transform Scale(GCLReal s)
{ Transform result; result.MakeHScale(Vector(s, s, s)); return(result); }
inline Transform Shift(GCLReal tx, GCLReal ty, GCLReal tz)
{ Transform result; result.MakeHTrans(Vector(tx, ty, tz)); return(result); }

typedef Array<Int>		IndexList;
typedef Array<Point>	PointList;
typedef Array<Vector>	VectorList;
typedef Array<Coord>	CoordList;

inline Real DegsToRads(Real degrees)		// Degrees to radians conversion...
{ return(degrees * (vl_pi / 180.0)); }
inline Real RadsToDegs(Real rads)			// Radians to degrees conversion...
{ return(rads * (180.0 / vl_pi)); }

IndexList Indexes(Int first, ...);	// Constructor for index lists
const Int IDX_END = -1;				// E.g., Indexes(1, 2, 3, 4, 5, IDX_END);


// --- Geometric primitives -----------------------------------------------


class Plane : public Vec4d
{
	public:
	
	Point	Project(const Point &p);
	Real	Distance(const Point &p);
};

class Ray
{
	public:
	
	Ray(Vector const &from, Vector const &to);
	
	Point	origin;	// can do this in 5D, of course...
	Vector  direction;
};

class EltSurface
{
	public:
	
	EltSurface() {};
	EltSurface(Point &pos, Vector &norm) : position(pos), normal(norm) {};
	
	Point position;
	Vector normal;
};


// --- Useful actions -------------------------------


class TransformPoints : public Action<Point>
{
	public:
	
	TransformPoints(Transform &trans) : transform(trans) {};

	void		Process(Vector &v) { v = proj(transform * Vec4d(v, 1.0)); };

	Transform	&transform;
};

class TransformVectors : public Action<Vector>
{
	public:
	
	TransformVectors(VecTrans &trans) : transform(trans) {};
	
	void		Process(Vector &v) { v = transform * v; };
	
	VecTrans 	&transform;
};

#endif

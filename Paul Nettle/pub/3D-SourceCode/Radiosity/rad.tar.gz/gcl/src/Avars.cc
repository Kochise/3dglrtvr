/*
	File:			Avars.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			'Avar' is defined in Scene.cc

	Change History:
		31/01/96	ajw		Started
*/

#include "Avars.h"

void ReadAvar(Avar &a, istream &s);


// --- Transformation avars --------------------------------------

scAvarTransform::scAvarTransform(Avar &avar, Vector vector) : scTransform(),
	avar(avar), vector(vector)
{
	Recalc();
};

Bool scAvarTransform::HasAvar(Avar &setAvar, Int slot)
{
	setAvar = avar;
	listSlot = slot;

	return(true);
}

void scAvarTransform::AddToContext(Context *context)
{
	AvarList	*avarList;
	Real		newValue;
	
	if (avarList = SC_GET(AvarList))
	{
		newValue = (*avarList)[listSlot].value;
	
		if (newValue != avar.value)
		{
			avar.value = newValue;
			Recalc();
		}
	}
	
	scTransform::AddToContext(context);
}

void scAvarShift::Recalc()
{
	(Transform &) SELF = Shift(vector * avar.value);
}

void scAvarShift::Print(ostream &s) const
{
	s << "avar shift " << avar << " " << vector;
}

#include "String.h"

void ReadAvar(Avar &a, istream &s)
{
	String *str = new String;
	Vector v;
	
	str->ReadWord(s);
	a.name = str->Ref();
	s >> v;
	a.lowerBound = v[0];
	a.value = v[1];
	a.upperBound = v[2];
}

void scAvarShift::Parse(istream &s)
{
	ReadAvar(avar, s);
	s >> vector; 
	Recalc();
}

void scAvarRotation::Recalc()
{
	(Transform &) SELF = Rotation(vector, avar.value * vl_pi);
}

void scAvarRotation::Print(ostream &s) const
{
	s << "avar rotate " << avar << " " << vector;
}

void scAvarRotation::Parse(istream &s)
{
	ReadAvar(avar, s);
	s >> vector; 
	Recalc();
}

void scAvarScale::Recalc()
{
	Vector scale(vector);
	Int i;
	
	for (i = 0; i < 3; i++)
		if (scale[i] == 0)
			scale[i] = 1;
		else
			scale[i] *= avar.value;
	
	(Transform &) SELF = Scale(scale);
}

void scAvarScale::Print(ostream &s) const
{
	s << "avar scale " << avar << " " << vector;
}

void scAvarScale::Parse(istream &s)
{
	ReadAvar(avar, s);
	s >> vector; 
	Recalc();
}



#pragma mark -
// --- Colour avar ------------------------------------


scAvarColour::scAvarColour(Avar &avar, Colour colour) : scColour(),
	avar(avar), colour(colour)
{
}

void scAvarColour::Recalc()
{
	(Colour &) SELF = colour * avar.value;
}

Bool scAvarColour::HasAvar(Avar &setAvar, Int slot)
{
	setAvar = avar;

	listSlot = slot;

	return(true);
}

void scAvarColour::AddToContext(Context *context)
{
	AvarList	*avarList;
	
	if (avarList = SC_GET(AvarList))
		avar.value = (*avarList)[listSlot].value;
	
	Recalc();
	
	scColour::AddToContext(context);
}

void scAvarColour::Print(ostream &s) const
{
	s << "avar colour " << avar << " " << colour;
}

void scAvarColour::Parse(istream &s)
{
	ReadAvar(avar, s);
	s >> colour; 
	Recalc();
}


#pragma mark -
// --- Emittance avar ------------------------------------


scAvarEmittance::scAvarEmittance(Avar &avar, Colour colour) : scEmittance(),
	avar(avar), colour(colour)
{
}

void scAvarEmittance::Recalc()
{
	(Colour &) SELF = colour * avar.value;
}

Bool scAvarEmittance::HasAvar(Avar &setAvar, Int slot)
{
	setAvar = avar;

	listSlot = slot;

	return(true);
}

void scAvarEmittance::AddToContext(Context *context)
{
	AvarList	*avarList;
	
	if (avarList = SC_GET(AvarList))
		avar.value = (*avarList)[listSlot].value;
	
	Recalc();
	
	scEmittance::AddToContext(context);
}

void scAvarEmittance::Print(ostream &s) const
{
	s << "avar emittance " << avar << " " << colour;
}

void scAvarEmittance::Parse(istream &s)
{
	ReadAvar(avar, s);
	s >> colour; 
	Recalc();
}

#pragma mark -


void scAvarList::Print(ostream &s) const
{
	//s << "avarList " << (AvarList &) SELF;
}

Bool scAvarList::SetAvar(Char *name, Real value)
{
	Int i;
	
	for (i = 0; i < NumItems(); i++)
		if (strcmp(SELF[i].name, name) == 0)
		{
			SELF[i].value = value;
			return(true);
		}
	return(false);
}


#pragma mark -
// --- Action to build avar list ---------------------------


void CreateAvarList::Start()
{
	delete avarList;
	avarList = new scAvarList;
}

void CreateAvarList::Attribute(scAttribute &sa)
{
	if (sa.HasAvar(newAvar, avarList->NumItems()))
		avarList->Append(newAvar);
}

ostream &operator << (ostream &s, Avar &avar)
{
	s << avar.name << ": " << avar.value << " [" << avar.lowerBound << ", " << avar.upperBound << "]";

	return(s);
}

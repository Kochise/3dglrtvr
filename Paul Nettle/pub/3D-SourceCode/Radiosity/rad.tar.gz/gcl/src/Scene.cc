/*
	File:			Scene.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			

	Change History:
		31/01/96	ajw		Started
*/

#include "Scene.h"
#include <iomanip.h>


//	'gAttributeNameTable' is a Table for the names of the various attributes.
//	Should be more extendable than this...

Char *gAttributeNameTable[] =
{
	"Colour",
	"Emittance",
	"Points",
	"Colours",
	"Normals",
	"Indexes",
	"Normal Indexes",
	"Transformation",
	"Camera",
	"Avar List",
	0
};


//--- scObject methods -------------------------------------------


scObject::~scObject()
{
	itsType = scNull;
};

void scObject::Apply(Transform &m)
{
}

void scObject::ApplyAction(scAction &a)
{	
	a.Start();
	ApplyToSelf(a);
	a.Stop();
}

void scObject::ApplyToSelf(scAction &a)
{	
	a.Process(SELF);
}

void scObject::Print(ostream &s) const
{
	s << "Undefined object";
}

void scObject::HierPrint(ostream &s, Int indent) const
{
	Int i;
	
	for (i = 0; i < indent; i++)
		s << ' ';
		
	Print(s);
	
	s << endl;
}


#pragma mark -
//--- Printing operator --------------------------------------------


Int scObject::prIndent = 4;

ostream &operator << (ostream &s, const scScenePtr scene)
{
	scene->HierPrint(s, 0);	// Start from 0 indentation
	
	return(s);
}

#pragma mark -
//--- scAttribute methods -------------------------------------------


void scAttribute::Print(ostream &s) const
{
	s << "set " << gAttributeNameTable[AttrID()] << " [" << (Int) AttrID() << "]";
}

void scAttribute::AddToContext(Context *context)
{
	context->Set(AttrID(), this);
}

Bool scAttribute::HasAvar(Avar &avar, Int slot)
{
	return(false);
}

void scClearAttr::Print(ostream &s) const
{
	s << "clear " << gAttributeNameTable[AttrID()] << " [" << (Int) AttrID() << "]";
}

void scClearAttr::AddToContext(Context *context)
{
	context->Set(AttrID(), 0);
}


#pragma mark -
//--- scPrimitive methods -------------------------------------------


void scPrimitive::Draw(Renderer &r)
{
	Context *context = new Context(aNumAttributes);
	
	Draw(r, context);
	
	delete context;
}

void scPrimitive::Draw(Renderer &r, Context *context)
{
}

void scPrimitive::Print(ostream &s) const
{
	s << Label();
}

void scPrimitive::Apply(Transform& m)
{
}

void scPrimitive::Set(scAttribute *sa)
{
	Int i = 0;
	
	if (parent)
	{
		while (i < parent->NumChildren())
			if (parent->Child(i) == this)
			{
				parent->children.Insert(i, sa);
				break;
			}
	}
	else
		Assert(false, "can't set attribute of a parentless primitive.");
}

scAttribute *scPrimitive::Get(scAttributeID searchID)
{
	Int i;
	scAttribute *result = 0;
	
	if (parent == 0)
		return(0);
		
	for (i = 0; i < parent->NumChildren(); i++)
		if (parent->Child(i)->AttrID() == searchID)
			result = AttrCast(parent->Child(i));
		else if (parent->Child(i) == this)
			break;
	
	if (result == 0)
		return(parent->Get(searchID));	
	else
		return(result);
}

scAttribute *scPrimitive::FindFirst(scAttributeID id)
{
	return(0);
}


#pragma mark -
//--- scGroup methods -----------


scGroup::scGroup(const scGroup &sg) : scPrimitive(sg), children(sg.children), name(sg.name)
{
	int i;
	
	for (i = 0; i < children.NumItems(); i++)
		if (Child(i)->IsPrim())
			PrimCast(Child(i))->parent = this;
}

void scGroup::ApplyToSelf(scAction &a)
{	
	scIterator i(children);
	
	for (i.Start(); !i.AtEnd(); i++)
		i()->ApplyToSelf(a);
}

void scGroup::Apply(Transform &m)
{
	scIterator i(children);

	for (i.Start(); !i.AtEnd(); i++)
		i()->Apply(m);
}

void scGroup::SetName(Char *newName)
{
	name = newName;
}

void scGroup::Add(scObject *so)
{
	if (so->IsPrim())
		PrimCast(so)->parent = this;
	children.Append(so);
}

scObject *scGroup::Last()
{
	return((scObject *) children.Top());
}

Char *scGroup::Label() const
{
	return(name);
}

void scGroup::Print(ostream &s) const
{
	HierPrint(s, 0);	// Start from 0 indentation
}

void scGroup::HierPrint(ostream &s, Int indent) const
{	
	scIterator i(children);
    Int j;

    for (j = 0; j < indent; j++)
        s << ' ';
	s << "object \"";
	if (name) 
		s << name;
	s << "\"" << endl; // " << (void *) this << ' ' << (void *) parent << endl; 
	
	for (i.Start(); !i.AtEnd(); i++)
		i()->HierPrint(s, indent + prIndent);
		
    for (j = 0; j < indent; j++)
        s << ' ';

	s << "end" << endl;
}

#include "Parse.h"
#include "String.h"

void scGroup::Parse(istream &s)
{
    Char		c;
	scObject	*newObj;
	String		*str = new String;
	
	//	Expected format: [a b c d ...]
	
    while (isspace(s.peek()))				// 	chomp white space
		s.get(c);
		
	s >> *str;
	name = str->Ref();
	
    children.Clear();
    	
	while (1)
	{			
		newObj = scParseObject(s);
		if (newObj == 0)
			break;
		if (!s)
		{
			Expect(false, "Couldn't read object component");
			return;
		}

		Add(newObj);
	}			
}

Object *scGroup::Clone() const
{
	Int i;
	scGroup *result;
		
	result = new scGroup(name);
	
	for (i = 0; i < children.NumItems(); i++)
		result->Add((scObject*) children[i]->Clone());
				
	return(result);
}

#include "SceneObjects.h"

void scGroup::Draw(Renderer &r, Context *context)
{
	scIterator i(children);
	
	if (!SC_GET(Camera))
	{
		// No camera set yet. Better do it now.
		r.Cam((scCamera &) *FindFirst(aCamera));
	}
	
	r.Push();
	context->Push();
	
	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
			PrimCast(i())->Draw(r, context);
		else if (i()->AttrID() == aTransform)
		{
			AttrCast(i())->AddToContext(context);
			r.SetTransform((scTransform &) *AttrCast(i()));
		}
		else
			AttrCast(i())->AddToContext(context);
			
	context->Pop();
	r.Pop();
}

void scGroup::Set(scAttribute *sa)
{
	Int i = 0;
	
	if (parent)
		scPrimitive::Set(sa);	
	else
		children.Prepend(sa);
}

scAttribute *scGroup::FindFirst(scAttributeID id)
{
	scIterator i(children);
	scAttribute *result;
	
	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
		{
			result = PrimCast(i())->FindFirst(id);
			if (result)
				return(result);
		}
		else if (i()->AttrID() == id)
				return(AttrCast(i()));
				
	return(0);
}

#pragma mark -

//--- Actions --------------------------

//	'scSceneAction' will traverse the scene tree, adding all attributes to the context, and
//	calling the 'Primitive' method on any primitives encountered.

void scSceneAction::Start()
{
	delete context;
				
	context = new Context(aNumAttributes);
}

void scSceneAction::Stop()
{
	delete context;
				
	context = new Context(aNumAttributes);
}

void scSceneAction::Process(scObject &so)
{
	if (so.IsAttr())
		Attribute(*AttrCast(&so));
	else if (so.IsPrim())
		Primitive(*PrimCast(&so));
	else
		Assert(0, "Null scObject encountered.");
}

void scSceneAction::Primitive(scPrimitive &sp)
{

}

void scSceneAction::Attribute(scAttribute &sa)
{
	sa.AddToContext(context);
}

// --- Avar methods/operators --------------------------------------------

ostream  &operator << (ostream &s, const Avar &avar)
{
	s << avar.name << " [" << avar.lowerBound << " " << avar.value << " " << avar.upperBound << "]";
	
	return(s);
}

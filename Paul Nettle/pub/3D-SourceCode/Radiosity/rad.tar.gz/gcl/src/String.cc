#include "String.h"
#include <stdio.h>

String	&String::operator = (StrConst s)
{
	SetSize(s.Length() + 1);
	strcpy(item, s);
	
	return(SELF);
}

String	&String::Append(StrConst s)
{
	Int start = items - 1;
	
	Add(s.Length());
	strcpy(item + start, s);

	return(SELF);
}

String	&String::Insert(StrConst s, Int position)
{
	Int len = s.Length();
	
	Array<Char>::Insert(position, len);
	memcpy(item + position, s, len);
	
	return(SELF);
}

String	&String::Delete(Int start, Int length)
{
	Array<Char>::Delete(start, length);		
	return(SELF);
}

String	StrConst::SubString(Int start, Int length)
{
	String	result;
	
	result.SetSize(length + 1);
	memcpy(result.item, theString + start, length);
	result.item[length] = 0;
	
	return(result);
}

String	StrConst::SubString(Int start)
{
	String	result;
	
	result = theString + start;
	
	return(result);
}

String	StrConst::Prefix(Int length)
{
	String	result;
	
	result.SetSize(length + 1);
	memcpy(result.item, theString, length);
	result.item[length] = 0;
	
	return(result);
}

String	StrConst::Suffix(Int length)
{
	String	result;
	Int		strLength = strlen(theString);
		
	result = theString + strLength - length - 1;
	
	return(result);
}

istream &String::ReadString(istream &s)
{
    Char	c;
	
	//	Expected format: "... "
	
    while (isspace(s.peek()))			// 	chomp white space
		s.get(c);
		
    if (s.peek() == '"')						
    {
    	s.get(c);
    	Clear();
    	    	
		while (s.peek() != '"')
		{			
			s.get(c);
			
			if (!s)
			{
				Expect(false, "Couldn't read array component");
				return(s);
			}
			else
				Array<Char>::Append(c);
		}			
		s.get(c);
	}
    else
	{
	    s.clear(ios::failbit);
	    Expect(false, "Error: Expected '\"' while reading string");
	    return(s);
	}
	
	Array<Char>::Append(0);

    return(s);
}

istream &operator >> (istream &s, String &str)
{
	// We default to reading a string. Use the ReadXXX methods to
	// read/parse other types of data.

	str.ReadString(s);
	return(s);
}

istream &String::ReadWord(istream &s)
{
    Char	c;
	
	//	Expected format: "... "
	
    while (isspace(s.peek()))			// 	chomp white space
		s.get(c);
		
   	Clear();
    	    	
	while (!isspace(s.peek()))
	{			
		s.get(c);
		
		if (!s)
		{
			Expect(false, "Couldn't read word");
			return(s);
		}
		else
			Array<Char>::Append(c);
	}			
	
	Array<Char>::Append(0);

    return(s);
}

int iseol(int c)
{
	return(c == 0x0a || c == 0x0d);
}

istream &String::ReadLine(istream &s)
{
    Char	c;
				
   	Clear();
    	    	
	while (1)
	{			
		s.get(c);
		
		if (!s)
		{
			Expect(false, "Couldn't read line");
			return(s);
		}
		else if (iseol(c))
			break;
		else
			Array<Char>::Append(c);
	}			
	
	Array<Char>::Append(0);

    return(s);
}

Bool IsEndOfLine(istream &s)
{
	char c;
	
	while (isspace(s.peek()) && !iseol(s.peek()))
		s.get(c);

	return(iseol(s.peek()));
}

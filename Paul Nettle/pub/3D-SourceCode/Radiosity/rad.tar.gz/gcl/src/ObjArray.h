/*
	File:			ObjArray.h

	Function:		Defines an array type that manages its own storage space, and can be
					used as a stack or a rudimentary list.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __ObjArray__
#define __ObjArray__

#include <iostream.h>
#include "Basics.h"
#include "Action.h"
#include "Object.h"

const kFirstObjAlloc = 16;		// Default number of items to initially allocate to
								// the array

class ObjArray : public Object
{
public:
					ObjArray();
					ObjArray(Int size, Int alloc = kFirstObjAlloc);		
					ObjArray(const ObjArray &array);
				   ~ObjArray();
	
//	ObjArray operators
	
	inline ObjectPtr	operator [] (Int i) const;	// indexing operator
	inline Int			NumItems() const;			// Number of items in the array
	ObjArray			&operator >> (Action<ObjectPtr> &a);	// Apply action to array
	ObjArray			&operator = (const ObjArray &array);	// Assignment operator
// ----------------------------------------------------------------------------!
//	Useful for stack implementations

	inline ObjectPtr	Top();						// Return last item (top-of-stack)
	inline void			Pop();						// Delete last item (pop)
	inline void			Push(ObjectPtr objPtr);		// Add item to end of array (push)
	
// List Operations

	inline void			Set(Int i, ObjectPtr objPtr);	// Change item i to objPtr
	inline void			Append(ObjectPtr objPtr);		// Append item to end of array
	inline void			Prepend(ObjectPtr objPtr);		// Prepend item to start of array
	inline void			Insert(Int i, ObjectPtr objPtr);// Insert item at i
	inline void			Delete(Int i);					// Delete item at i

	void				Clear();					// Delete all items

	void				Print(ostream &s);
	void				Parse(istream &s);
	ObjectPtr			Clone();					// Return copy of list
	void				Free();						// Free all storage

	void				SetSize(Int newSize);		// Set array size directly
	void				Add(Int n);					// Add n items to the array
	void				Shrink(Int n);				// shrink the array by n items
	void 				Insert(Int i, Int n);		// Insert n items at i
	void				Delete(Int i, Int n);		// Delete n items at i
	void				ShrinkWrap();				// Ensure allocated space = space being used.
	
// Low level access

	inline ObjectPtr	*Ref();						// Return pointer to array

//	Private...

protected:
	
	void 		Grow();
	
	ObjectPtr	*item;		// pointer to array
	Int32 		items;		// items in the array
	Int32		allocated;	// number of items we have space allocated for. 
};	


// --- Inlines ----------------------------------------------------------------


inline ObjArray::ObjArray() : items(0), item(0), allocated(0)
{
}

inline Int ObjArray::NumItems() const
{
	return(items);
}

inline ObjectPtr ObjArray::operator [] (Int i) const
{
	CheckRange(i, 0, items, "(ObjArray::[]) index out of range");

	return(item[i]);
}

inline ObjectPtr ObjArray::Top()
{
	return(item[items - 1]);
}

inline void ObjArray::Push(ObjectPtr objPtr)
{
	if (items >= allocated)
		Grow();
	
	item[items++] = objPtr;
}

inline void ObjArray::Pop()
{	
	items--;
	item[items]->Free();
}

inline void ObjArray::Set(Int i, ObjectPtr objPtr)
{
	CheckRange(i, 0, items, "(ObjArray::Set) index out of range");

	item[i]->Free();
	item[i] = objPtr;
}

inline void ObjArray::Append(ObjectPtr objPtr)
{
	if (items >= allocated)
		Grow();
	
	item[items++] = objPtr;
}

inline void ObjArray::Prepend(ObjectPtr objPtr)
{
	Insert(0, 1);	
	item[0] = objPtr;
}

inline void ObjArray::Insert(Int i, ObjectPtr objPtr)
{
	Insert(i, 1);	
	item[i] = objPtr;
}

inline void ObjArray::Delete(Int i)
{
	Delete(i, 1);	
}

inline ObjectPtr *ObjArray::Ref()
{
	return(item);
}

#endif

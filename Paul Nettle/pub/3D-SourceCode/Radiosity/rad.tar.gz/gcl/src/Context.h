/*
	File:			Context.h

	Function:		State machine for rendering a scene. You can add attributes
					to the context, and also push & pop the current context.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Context__
#define __Context__


#include "Array.h"
#include "iostream.h"


#define SC_GET(X) ((sc ## X *) context->Get(a ## X))		// shorthand for fetch & cast...


// --- Attribute types & definition ---------------------------------------

// We don't store the attributes themselves. Instead we store pointers
// to attributes that reside in the scene tree.
// We also define daemons that can be installed to process attributes as they
// are encountered.

typedef Int 			AttrType;
typedef void 			*AttrPtr;

class AttrDaemon 
{
	public:
	
	virtual void			Set(AttrPtr attrPtr) = 0;
	virtual AttrPtr			Get() = 0;
	virtual void			Save() = 0;
	virtual void 			Restore() = 0;
};

class AttrRec
{
public:
	union
	{
		AttrPtr			data;
		AttrDaemon		*daemon;
	};
	Int16			level;	// level at which it was last set 
};

class AttrStackRec
{
public:
	AttrRec		attrRec;
	AttrType	attrType;
};

ostream &operator << (ostream &s, const AttrRec &ar);
ostream &operator << (ostream &s, const AttrStackRec &asr);

typedef Array<AttrRec> AttrList;
typedef Array<AttrStackRec> AttrStackList;


// --- The Context class ----------------


class Context
{
public:
	Context(Int numAttributes);		// maximum number of attributes...

	AttrPtr				Get(AttrType attrType);
	void				Set(AttrType attrType, AttrPtr attrPtr);
	void 				SetDaemon(AttrType attrType, AttrDaemon *daemon);
	
	Bool				IsCurrent(AttrType attrType);
	
	void				Push();
	void				Pop();
	
	protected:
	
	AttrList		attributeList;
	AttrStackList	attributeStack;
	Int				level;			// Current size of the (pseudo) stack

	friend ostream &operator << (ostream &s, const Context &ctx);
};


#endif

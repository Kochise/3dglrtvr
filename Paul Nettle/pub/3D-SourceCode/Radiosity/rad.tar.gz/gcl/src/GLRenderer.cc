#include "GLRenderer.h"
#include "GL/gl.h"

// --- Copying data from & to an image ----------------------------------------


Renderer &GLRenderer::GetImage(Image &image)
{
	image.SetSize(glWidth, glHeight);

	SetWindow();
	glReadBuffer(GL_FRONT);
	glPixelStorei(GL_PACK_ALIGNMENT, 8);

	glReadPixels(0, 0, glWidth, glHeight, GL_RGBA, GL_UNSIGNED_BYTE,
		image.Ref());
	return(SELF);
}

Renderer &GLRenderer::PutImage(Image &image, Int x, Int y)
{
	if (image.Ref())
	{
		cout << "putting " << image.Width() <<" x "<< image.Height() <<", "<< x <<", "<< y << endl;
		SetWindow();
		glDrawBuffer(GL_FRONT);
		glRasterPos2i(x, y);
		glDrawPixels(image.Width(), image.Height(), GL_RGBA, GL_UNSIGNED_BYTE, image.Ref());	
	}
	return(SELF);
}


#pragma mark -
// --- GLRenderer Drawing Operators -------------------------------------------

// translation from render-style to GL style...
static int pcTable[6] = 
	{ 0, GL_POINTS, GL_LINES, GL_LINE_STRIP, GL_LINE_LOOP, GL_POLYGON };

void GLRenderer::Show()
{
	SetWindow();
	glFlush();
}

Renderer &GLRenderer::SetPoint(const Point &p)
{
	glVertex3dv(p.Ref());	
	
	return(SELF);
}

Renderer &GLRenderer::SetNormal(const Vector &n)
{
	glNormal3dv(n.Ref());	
	
	return(SELF);
}

Renderer &GLRenderer::SetCoord(const Coord &c)
{
	glVertex2dv(c.Ref());	
	
	return(SELF);
}

Renderer &GLRenderer::SetColour(const Colour &c)
{
	glColor3fv(c.Ref());	
	
	return(SELF);
}

Renderer &GLRenderer::SetTransform(const Transform &t)
{
#ifdef VL_ROW_ORIENT
	glMultMatrixd(t.Ref());
#else
	glMultMatrixd(trans(t).Ref());
#endif

	return(SELF);
}

Renderer &GLRenderer::SetCamera(const Camera &c)
{
	GLint		mm;
	Int			i;

	SetWindow();
			
	glGetIntegerv(GL_MATRIX_MODE, &mm);		// save the current matrix mode

	glMatrixMode(GL_PROJECTION);			// set the projection matrix
	glLoadMatrixd(trans(c.ProjMatrix()).Ref());		
	glMatrixMode(GL_MODELVIEW);				// clear the model matrix
	glLoadMatrixd(trans(c.ModelMatrix()).Ref());		
	glMatrixMode((GLenum) mm);				// restore matrix mode
	
	return(SELF);
}

Renderer &GLRenderer::Pop()
{
	glPopMatrix();
	
	return(SELF);
}

Renderer &GLRenderer::Push()
{
	glPushMatrix();
	
	return(SELF);
}

Renderer &GLRenderer::Clear()
{
	SetWindow();
	glClearDepth(1);
	glClearColor(bgColour[0], bgColour[1], bgColour[2], 0.5);
	glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
	
	return(SELF);
}

Renderer &GLRenderer::Begin(RenderStyle style)
{
	glBegin((GLenum) pcTable[style]);
	return(SELF);
}

Renderer &GLRenderer::End()
{
	glEnd();
	return(SELF);
}

void GLRenderer::Print(ostream &s)
//	Output state of the Renderer. Largely for debugging.
{
	double  m[16];
	Int i;
	
	SetWindow();
	
	glGetDoublev(GL_PROJECTION_MATRIX, m);
	
	s << "projection transform: " << endl;
	
	for (i = 0; i < 4; i++)
		s << "[ " << m[i] << " " << m[i+ 4] << " " << m[i + 8] << " " 
			<< m[i + 12] << " ]" << endl;
	s << endl;

	glGetDoublev(GL_MODELVIEW_MATRIX, m);
	
	s << "model transform: " << endl;
	
	for (i = 0; i < 4; i++)
		s << "[ " << m[i] << " " << m[i+ 4] << " " << m[i + 8] << " " 
			<< m[i + 12] << " ]" << endl;
	s << endl;
}

Renderer &GLRenderer::Rect(Real left, Real up, Real right, Real down)
{
	glRectd(left, up, right, down);
	return(SELF);
}

void GLRenderer::Init()
{
	// call from attach() routine...
	glMatrixMode(GL_MODELVIEW);
	glEnable(GL_DEPTH_TEST);
}

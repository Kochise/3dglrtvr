#ifndef __Hermite__
#define __Hermite__

#include "Geometry.h"

/*
	Calculate hermite coefficients.
	t0, y0, ydot0 are start time, value, and slope.
	t1, y1, ydot1 same, but at end.
	t1 had better not equal t0.
*/

void CalcHermiteCoeffs(
		Real	t0,
		Real	t1,
		Real	y0,
		Real	y1,
		Real	ydot0,
		Real	ydot1,
		Vector4	&result
	);


/*
	Evaluate y(t), using coeffs computed by CalcHermiteCoeffs().
	t0, t1 have to be same as you supplied to CalcHermiteCoeffs,
	and t should be between t0 and t1, inclusive.
*/

Real EvalCubic(Vector4 &cubicCoeffs, Real t, Real t0, Real t1);

#endif

/*
	File:			SceneLang.h

	Function:		Allows run-time definition of scenes in the standard
					imperative manner.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __SceneLang__
#define __SceneLang__

#include "Geometry.h"
#include "Scene.h"
#include "Library.h"

scObject 	*slCurrent();		// Returns current object
scScenePtr  slCurrentGroup();	// Returns current object

scScenePtr	slBeginObject(char *name);
void		slBeginObject(scScenePtr object);
void 		slEndObject();

void 		slBeginPoints();
void 		slEndPoints();

void 		slBeginColours();
void 		slEndColours();

void 		slBeginIndexes();
void 		slEndIndexes();

void 		slBeginNormals();
void 		slEndNormals();

void 		slColour(const Colour &c);
void 		slEmittance(const Colour &c);

void 		slPoint(const Point &p);
void 		slIndex(Int i);

void		slPoly();
void		slCamera();
void 		slTransform(const Transform &t);

void 		slPoints(const PointList &pl);
void 		slIndexes(const IndexList &il);
void 		slApply(Transform &t);

void 		slObject(Char *name);
Bool		slObjectExists(Char *name);
void 		slObject(scObject *object);
void 		slAttribute(scAttribute *attrPtr);

scAttribute slGetAttribute(Int attr);
scScenePtr 	slGetObject(Char* name);

void		slAddToLibrary(scGroup *newGroup);
Library		*slSwapLibrary(Library *newLib);
void		slSetLibrary(Library *library);
Library 	*slGetLibrary();

#endif

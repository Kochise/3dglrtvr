/*
	File:			SceneObjects.h

	Function:		Contains definitions of the fundamental scene objects and 
					their attributes.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __SceneObjects__
#define __SceneObjects__

#include "Scene.h"
#include "Context.h"
#include "Renderer.h"


// --- Polygons --------------------------------


class scPoly : public scPrimitive
{
public:

	scPoly() : scPrimitive(pPoly) {};
	scPoly(const scPoly &sp) : scPrimitive(sp) {};

	void					Draw(Renderer &r, Context *context);
	Char 					*Label() const;
	void					Parse(istream &s);

	Object  	 			*Clone() const { return new scPoly(SELF); };
};


// --- Attributes ----------------------------


class scColour : public scAttribute, public Colour
{
public: 
	scColour() : scAttribute(aColour), Colour() {};
	scColour(const Colour &c) : scAttribute(aColour), Colour(c) {};
	
	void					Print(ostream &s) const { s << "colour " << (Colour &) SELF; };
	void					Parse(istream &s);

	Object  	 			*Clone() const { return new scColour(SELF); };
};

class scTransform : public scAttribute, public Transform
{
public: 
	scTransform() : scAttribute(aTransform), Transform() {};
	scTransform(const Transform &t) : scAttribute(aTransform), Transform(t) {};
	
	void					Print(ostream &s) const { s << "transform " << (Transform &) SELF; };
	void					Parse(istream &s);

	Object  	 			*Clone() const { return new scTransform(SELF); };
};

class scEmittance : public scAttribute, public Colour
{
public: 
	scEmittance() : scAttribute(aEmittance), Colour() {};
	scEmittance(const Colour &c) : scAttribute(aEmittance), Colour(c) {};
	
	void					Print(ostream &s) const { s << "emittance " << (Colour &) SELF; };
	void					Parse(istream &s);

	Object  	 			*Clone() const { return new scEmittance(SELF); };
};

class scPoints : public scAttribute, public PointList
{
public: 
	scPoints() : scAttribute(aPoints), PointList() {};
	scPoints(const PointList &pl) : scAttribute(aPoints), PointList(pl) {};
	
	void					Apply(Transform &m);
	void					Print(ostream &s) const { s << "points " << (PointList &) SELF; };
	void					Parse(istream &s);
	
	Object  	 			*Clone() const { return new scPoints(SELF); };
};
 
class scColours : public scAttribute, public ColourList
{
public: 
	scColours() : scAttribute(aColours) {};
	
	void					Parse(istream &s);

	Object  	 			*Clone() const { return new scColours(SELF); };
};

class scIndexes : public scAttribute, public IndexList
{
public: 
	scIndexes() : scAttribute(aIndexes), IndexList() {};
	scIndexes(const IndexList &il) : scAttribute(aIndexes), IndexList(il) {};
	
	void					Print(ostream &s) const { s << "indexes " << (IndexList &) SELF; };
	void					Parse(istream &s);

	Object  	 			*Clone() const { return new scIndexes(SELF); };
};

class scCamera : public scAttribute, public Camera
{
public:

	scCamera() : scAttribute(aCamera), Camera() {};
	scCamera(const Camera &c) : scAttribute(aCamera), Camera(c) {};

	void					Print(ostream &s) const;
	void					Parse(istream &s);

	Object  	 			*Clone() const { return new scCamera(SELF); };
};
	
#endif

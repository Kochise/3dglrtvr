/*
	File:			GLRenderer.h

	Function:		Implements an OpenGL renderer. This is still an abstract object:
					the MakeCurrent() method must be overridden to set up the GL context.
	
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __GLRenderer__
#define __GLRenderer__

#include "Renderer.h"


// --- The GLRenderer class -----------------------------------------------------


class GLRenderer : public Renderer
{
public:
	GLRenderer(Int w = 100, Int h = 100) : Renderer(), glWidth(w),
			glHeight(h) {};
	
	void				Init();
	virtual void		Show();
	virtual void		Print(ostream &s);
	virtual Renderer	&Begin(RenderStyle style);
	virtual Renderer	&End();

	virtual Renderer	&SetPoint(const Point &p);
	virtual Renderer	&SetNormal(const Point &p);
	virtual Renderer	&SetCoord(const Coord &c);
	virtual Renderer	&SetColour(const Colour &c);

	virtual Renderer	&SetTransform(const Transform &t);
	virtual Renderer	&SetCamera(const Camera &c);

	virtual Renderer	&Clear();
	virtual Renderer	&Pop();
	virtual Renderer	&Push();

	virtual Renderer	&Rect(Real left, Real up, Real right, Real down); 								

	virtual Renderer	&GetImage(Image &image);
	virtual Renderer	&PutImage(Image &image, Int x, Int y);

protected:
	Int		glHeight;
	Int		glWidth;
};

#endif

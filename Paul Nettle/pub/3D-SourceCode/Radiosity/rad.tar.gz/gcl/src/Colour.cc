/*
	File:			Colour.cc

	Function:		Implements Colour.h

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			Would like colour transforms in here some day

	Change History:
		31/01/96	ajw		Started
*/

#include "Colour.h"
#include "Geometry.h"

void ClipColour(Colour &c)
{
	if (c[0] > 1.0) c[0] = 1.0;
	if (c[0] < 0.0) c[0] = 0.0;
	if (c[1] > 1.0) c[1] = 1.0;
	if (c[1] < 0.0) c[1] = 1.0;
	if (c[2] > 1.0) c[2] = 1.0;
	if (c[2] < 0.0) c[2] = 1.0;
}

Colour HSVCol(Real hue, Real saturation, Real value)
// Convert HSV to RGB...
{
	Int		face = floor(hue / 120);
	Real	d = (hue - 120 * face) / 60;
	Colour	result;
	
	hue += 60;				// Realign h so that Red = 60 degrees.
	
	if (hue >= 360)
		hue -= 360;
	
	result[face] = value;
	
	if (d > 1)
	{
		result[(face + 1) % 3] = value * (1 - saturation * (2 - d));
		result[(face + 2) % 3] = value * (1 - saturation);
	}
	else
	{
		result[(face + 1) % 3] = value * (1 - saturation);
		result[(face + 2) % 3] = value * (1 - saturation * d);
	}

	return(result);
}

ClrTrans	RGBScale(Real rscale, Real gscale, Real bscale);
ClrTrans	RGBSaturate(Real sat);
ClrTrans	RGBOffset(Real roff, Real goff, Real boff);
ClrTrans	RGBHueRotate(Real degrees);

/*
Changing Brightness

   To scale RGB colors a matrix like this is used: 

      CMat4 [4][4] = {
           rscale, 0.0,    0.0,    0.0,
           0.0,    gscale, 0.0,    0.0,
           0.0,    0.0,    bscale, 0.0,
           0.0,    0.0,    0.0,    1.0,
       };

   Where rscale, gscale, and bscale specify how much to scale the r, g, and b components of colors. This can be used to
   alter the color balance of an image. 

   In effect, this calculates: 

           tr = r*rscale;
           tg = g*gscale;
           tb = b*bscale;
*/

ClrTrans RGBScale(Real rscale, Real gscale, Real bscale)
{
	return(HScale4f(Colour(rscale, gscale, bscale)));
}

/*
   Modifying Saturation

   Converting to Luminance

   To convert a color image into a black and white image, this matrix is used: 

       float mat[4][4] = {
           rwgt,   rwgt,   rwgt,   0.0,
           gwgt,   gwgt,   gwgt,   0.0,
           bwgt,   bwgt,   bwgt,   0.0,
           0.0,    0.0,    0.0,    1.0,
       };

   Where rwgt is 0.3086, gwgt is 0.6094, and bwgt is 0.0820. This is the luminance vector. Notice here that we do not
   use the standard NTSC weights of 0.299, 0.587, and 0.114. The NTSC weights are only applicable to RGB colors in
   a gamma 2.2 color space. For linear RGB colors the values above are better. 

   In effect, this calculates: 

           tr = r*rwgt + g*gwgt + b*bwgt;
           tg = r*rwgt + g*gwgt + b*bwgt;
           tb = r*rwgt + g*gwgt + b*bwgt;

   Modifying Saturation

   To saturate RGB colors, this matrix is used: 

        float mat[4][4] = {
           a,      b,      c,      0.0,
           d,      e,      f,      0.0,
           g,      h,      i,      0.0,
           0.0,    0.0,    0.0,    1.0,
       };

   Where the constants are derived from the saturation value s as shown below: 

       a = (1.0-s)*rwgt + s;
       b = (1.0-s)*rwgt;
       c = (1.0-s)*rwgt;
       d = (1.0-s)*gwgt;
       e = (1.0-s)*gwgt + s;
       f = (1.0-s)*gwgt;
       g = (1.0-s)*bwgt;
       h = (1.0-s)*bwgt;
       i = (1.0-s)*bwgt + s;

	i.e. Sat(s) + I(s);
	Useful: extrap(A,  B, s);

   One nice property of this saturation matrix is that the luminance of input RGB colors is maintained. This matrix can also
   be used to complement the colors in an image by specifying a saturation value of -1.0. 

   Notice that when s is set to 0.0, the matrix is exactly the "convert to luminance" matrix described above. When s is set
   to 1.0 the matrix becomes the identity. All saturation matrices can be derived by interpolating between or extrapolating
   beyond these two matrices. 

   This is discussed in more detail in the note on Image Processing By Interpolation and Extrapolation. 

*/

ClrTrans RGBToLum()
{
	ClrTrans result;
	
	result[0] = Vec4f(cRGBToLum, 0.0);
	result[1] = Vec4f(cRGBToLum, 0.0);
	result[2] = Vec4f(cRGBToLum, 0.0);
	result[3] = vl_w;
	
	return(result);
}

ClrTrans RGBSat(Real sat)
{
	return(Mix(RGBToLum(), ClrTrans(vl_I), sat));
}

ClrTrans RGBOffset(const Colour &c)
{
	return(HTrans4f(c));
}

ClrTrans RGBHueRotate(Real degrees)
{
	return(HRot4f(vl_1, DegsToRads(degrees)));	// rotate around (1, 1, 1) = grey line
}

/*
   Hue Rotation While Preserving Luminance

   We make an identity matrix 

      identmat(mmat);

   Rotate the grey vector into positive Z 

       mag = sqrt(2.0);
       xrs = 1.0/mag;
       xrc = 1.0/mag;
       xrotatemat(mmat,xrs,xrc);
       mag = sqrt(3.0);
       yrs = -1.0/mag;
       yrc = sqrt(2.0)/mag;
       yrotatemat(mmat,yrs,yrc);
       matrixmult(mmat,mat,mat);

   Shear the space to make the luminance plane horizontal 

       xformrgb(mmat,rwgt,gwgt,bwgt,&lx,&ly,&lz);
       zsx = lx/lz;
       zsy = ly/lz;
       zshearmat(mat,zsx,zsy);

   Rotate the hue 

       zrs = sin(rot*PI/180.0);
       zrc = cos(rot*PI/180.0);
       zrotatemat(mat,zrs,zrc);

   Unshear the space to put the luminance plane back 

       zshearmat(mat,-zsx,-zsy);

   Rotate the grey vector back into place 

       yrotatemat(mat,-yrs,yrc);
       xrotatemat(mat,-xrs,xrc);

   Conclusion

  */


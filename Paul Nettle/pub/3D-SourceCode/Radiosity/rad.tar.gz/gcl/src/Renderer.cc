/*
	File:			Renderer.cc

	Function:		Implements Renderer.h

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott

	Notes:			Defines a vanilla renderer object. Just outputs the calls
					it gets as text!

	Change History:
		31/01/96	ajw		Started
*/

#include "Renderer.h"

Renderer::Renderer()
{
	bgColour = cBlack;
}

Renderer *Renderer::sCurrentRenderer = 0;

ostream &operator << (ostream &s, Renderer &gsr)
{
	gsr.Print(s);
	return(s);
}

Renderer &Renderer::Draw(Renderable &thing)
{
	thing.Draw(SELF);
	return(SELF);
}

Renderer &Renderer::Draw(Renderable *thing)
{
	if (thing)
		thing->Draw(SELF);
	return(SELF);
}

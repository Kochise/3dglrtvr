/*
	File:			Image.h

	Function:		Defines an image: a 2D array of pixels. Provides common
					operations on images.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */


#ifndef __Image__
#define __Image__

#include "Colour.h"

// --- Useful enums -------------

enum ImgChannel
{
	chMono,
	chRed,
	chBlue,
	chGreen,
	chAlpha,
	chMatte,
	chDepth,
	chMax
};

enum ImgStoreType
{
	imgByte,
	imgUInt16,
	imgUInt32,
	imgFloat,
	imgDouble,
	imgPack,
};

enum 
{
	rgba_R = 0,
	rgba_G = 1,
	rgba_B = 2,
	rgba_A = 3,
};

struct RGBAPixel
{
	Byte	ch[4];
};

typedef UInt32 ImgTag;

// --- Generic image class ---------

class Image 
{
public:
	Image(ImgTag it) : width(0), height(0), tag(it) {};
	virtual Void	SetSize(Int width, Int height) = 0;
	virtual Void	Clear(const Colour &c) = 0;
	virtual Void	SetPixel(Int x, Int y, const Colour &c) = 0;
	virtual Colour	GetPixel(Int x, Int y) = 0;

	virtual Void	SetSpan(Int row, Int start, Int length, const Colour *src) = 0;
	virtual Void	GetSpan(Int row, Int start, Int length, Colour *dst) = 0;

	virtual Void	SetRGBASpan(Int row, Int start, Int length, const RGBAPixel *src);
	virtual Void	GetRGBASpan(Int row, Int start, Int length, RGBAPixel *dst);
#if 0
	virtual Void	SetFloatSpan(ImgChannel channel, Int row, Int start, Int length, const Byte *src) = 0;
	virtual Void	GetFloatSpan(ImgChannel channel, Int row, Int start, Int length, Byte *dst) = 0;
	virtual Void	SetByteSpan(ImgChannel channel, Int row, Int start, Int length, const Byte *src) = 0;
	virtual Void	GetByteSpan(ImgChannel channel, Int row, Int start, Int length, Byte *dst) = 0;
#endif

	Int				SavePPM(const Char *filename);
	Int				LoadPPM(const Char *filename);     
	Int 			SaveTIFF(const Char *filename);
	Int				LoadTIFF(const Char *filename);
	Int 			SaveJPEG(const Char *filename);
	Int				LoadJPEG(const Char *filename);

	Int				Height() const { return(height); };
	Int				Width() const { return(width); };

	virtual Void	CopyFrom(Int x, Int y, Image &i);
	virtual Byte	*Ref() const {return(0);};
	
protected:
	Int				width;
	Int				height;
	ImgTag			tag;
};

class RGBAImage : public Image
{
public:
	RGBAImage() : Image('rgba'), data(0) {};
	
	Void	SetSize(Int width, Int height);

	Void	Clear(const Colour &c);
	Void	SetPixel(Int x, Int y, const Colour &c);
	Colour	GetPixel(Int x, Int y);
	Void	SetSpan(Int row, Int start, Int length, const Colour *src);
	Void	GetSpan(Int row, Int start, Int length, Colour *dst);
	Byte	*Ref() const {return((Byte*) data);};

protected:
	RGBAPixel	*data;
};


// --- Channel-based image --------------


#if 0
class ChannelImage : public Image
{
public:
	ChannelImage();

protected:
	Void			*channel[chMax];
	imgStoreType	chanType[chMax];
}
#endif

Colour RGBAToColour(RGBAPixel rgba);
RGBAPixel ColourToRGBA(const Colour &c);

#endif

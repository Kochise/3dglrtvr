/*
	File:			Camera.h
	
	Function:		Defines a camera. When sent to a Renderer, this defines
					the current view (and perspective) transformations.
					A camera can be embedded in a scene: see SceneObjects.cc

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */
 
#ifndef __Camera__
#define __Camera__

#include "Geometry.h"
#include <iostream.h>

// Maps view into viewport [-1,1] x [-1,1]

class Camera
{
public:	
	Camera(Bool ortho = false);
	
	void	SetClipping(Real nearPlane, Real farPlane);	// Set standard camera parameters.
	void	SetPerspective(Real fieldOfView);
	void	SetPosition(Point pos);
	void	SetLookat(Point at);	
	void	SetViewUp(Vector at);	
	
	void	SetZoom(Real zoomFactor);				// Scale the scene around the lookat point.
	void	SetSceneOrient(Transform &t);			// Rotate the scene around the lookat point.
	void	SetSceneOffset(Transform &t);			// Offset the lookat point from its original location.
		
	Transform 	ProjMatrix() const;
	Transform 	ModelMatrix() const;
	void		CalcProjMatrix();

	Bool		IsOrtho() { return(ortho); };
	
protected:
	
	Point		position;
	Point		up;						// up vector, normalised
	Point		dir;					// vector from camera position to lookat point.
	Real		clipNear, clipFar;		// near and far clipping planes
	Real		fov;					// field of view in degrees
	Int			lhand;					// left handed coordinate system?
	Int 		ortho;					// orthogonal camera (XXX split out into own class)
	
	Real		zoom;
	Transform	sceneOrient;
	Transform	sceneOffset;
};

ostream &operator << (ostream &s, Camera &c);

#endif

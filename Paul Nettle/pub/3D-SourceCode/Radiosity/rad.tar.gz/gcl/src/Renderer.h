/*
	File:			Renderer.h

	Function:		Contains the definition for the renderer class. A particular
					graphics system must implement objects of this type.
					
					'Renderer' is an object model to wrap up the display system.

					example use: r.Clear().Start(renPoly).Colour(cRed).Vertex(a).Vertex(b).Vertex(c).End().Show();
	
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1995-1996, Andrew Willmott
 */

#ifndef __Renderer__
#define __Renderer__

#include "Geometry.h"
#include "Colour.h"
#include "Image.h"
#include "Camera.h"
#include "Action.h"


// --- The Renderer class -----------------------------------------------------


class Renderer;

typedef Action<Renderer>	RenderAction;
typedef Renderer 			*RendererPtr;

enum RenderStyle 			// Commands for point-series drawing
{
	renNone, 
	renPoints,
	renLines,
	renLineStrip,
	renLineLoop,
	renPoly
};

class Renderable
{
public:
	virtual void		Draw(Renderer &r) = 0;
};

class Renderer				// Abstract class for something you can render into
{
public:
	Renderer();
	
	virtual void		Show() = 0;
	virtual void 		MakeCurrent() = 0;
	virtual void		Print(ostream &s) = 0;
	
	Renderer			&Draw(Renderable &thing);
	Renderer			&Draw(Renderable *thing);
	virtual Renderer	&Begin(RenderStyle style) = 0;
	virtual Renderer	&End() = 0;

	virtual Renderer	&SetPoint(const Point &p) = 0;
	virtual Renderer	&SetNormal(const Point &p) = 0;
	virtual Renderer	&SetCoord(const Coord &c) = 0;
	virtual Renderer	&SetColour(const Colour &c) = 0;

	virtual Renderer	&SetTransform(const Transform &t) = 0;
	virtual Renderer	&SetCamera(const Camera &c) = 0;

	void				SetBgColour(const Colour &c) { bgColour = c; };
	const Colour		GetBgColour() { return(bgColour); };

	virtual Renderer	&Clear() = 0;
	virtual Renderer	&Pop() = 0;
	virtual Renderer	&Push() = 0;

	virtual Renderer	&Rect(Real left, Real up, Real right, Real down) = 0;

	virtual Renderer	&GetImage(Image &image) = 0;
	virtual Renderer	&PutImage(Image &image, Int x = 0, Int y = 0) = 0;

	// short-cuts

	Renderer			&P(const Point &p) {return(SetPoint(p));};
	Renderer			&P(const Coord &c) {return(SetCoord(c));};
	Renderer			&N(const Vector &p) {return(SetNormal(p));};
	Renderer			&C(const Colour &c) {return(SetColour(c));};
	Renderer			&Xform(const Transform &t) {return(SetTransform(t));};
	Renderer			&Cam(const Camera &c) {return(SetCamera(c));};

				
protected:
	inline void 		SetWindow();

	Colour				bgColour;
	static Renderer		*sCurrentRenderer;
};

ostream &operator << (ostream &s, Renderer &gsr);

// --- Inlines ----------------------------------------------------------------


inline void Renderer::SetWindow()
//	swap drawing contexts if necessary...
{
	if (this != sCurrentRenderer)
	{
		sCurrentRenderer = this;
		MakeCurrent();
	}
}

#endif

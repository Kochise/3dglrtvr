
#include "Hermite.h"


/* This basis takes [x(0),x(1),x'(0),x'(1)] as knot points   
   Each column holds the coefficients of one of the Hermite 
   polynomials. */

static Transform gHermiteMatrix(
	 1, 0, 0, 0, 
	 0, 0, 1, 0,
	-3, 3,-2,-1,
	 2,-2, 1, 1
);


/*
	Calculate hermite coefficients.
	t0, y0, ydot0 are start time, value, and slope.
	t1, y1, ydot1 are end time, value, and slope.
	t1 had better not equal t0.
		
	For automatic slope control, set 
		ydot1 = (y2 - y0) / (t2 / t0);
*/

void CalcHermiteCoeffs(
		Real	t0,
		Real	t1,
		Real	y0,
		Real	y1,
		Real	ydot0,
		Real	ydot1,
		Vector4	&result
	)
{
	result = gHermiteMatrix * 
		Vector4(y0, y1, ydot0 * (t1 - t0), ydot1 * (t1 - t0));
}

/*
	evaluate y(t), using coeffs computed by hermite_coeffs().
	t0, t1 have to be same as you supplied to hermite_coeffs.
	t should be between t0 and t1, inclusive.
*/

Real EvalCubic(Vector4 &cubicCoeffs, Real t, Real t0, Real t1)
{
	Real	u = (t - t0) / (t1 -t0);
	Vector4	uCubic(u, sqr(u), sqr(u) * u, sqr(u) * sqr(u));

	return(dot(uCubic, cubicCoeffs));
}


/*
	Here's a dumb sample program that interpolates values of y between
	frame 0 and frame 30:
*/

#ifdef HM_DEBUG
#include <stdio.h>

main()
{
	Vector4	coeffs;
	Real	t0 = 0, t1 = 30;
	Real	y0 = 1,  y1 = 3;
	Real	dy0 = .2, dy1 = 0;
	Int		t;

	CalcHermiteCoeffs(t0, t1, y0, y1, dy0, dy1, coeffs);

	for(t = 0; t < 31; t++)
		printf("\ny(%d) = %f", t, EvalCubic(coeffs, t, t0, t1) );
}

#endif

/*
	File:			HProgRad.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

	Change History:
*/

#include "HProgRad.h"



Void HProgRad::SetScene(scScenePtr theScene)
{  
	Int i;
	
	ProgRad::SetScene(theScene);
	elements.Clear();
	eltParents.Clear();

	for (i = 0; i < patches.NumItems(); i++)
		((HierQuad *) patches[i])->CreateElements(elements, eltParents, i);  

} 

static Colour SingleFormFactor(RadQuad *fromPatch, RadQuad *toPatch)
{
	GCLReal 		visibility;
	GCLReal		factor;
	Colour		result;
		
	if (len(toPatch->Reflectance()) < 0.0001)
	{
		result.MakeZero();
		return(result);
	}

	visibility = fromPatch->Visibility(toPatch);
		
	if (visibility > 0.0)
	{
		factor = fromPatch->EstFormFactor(toPatch);
		result = toPatch->Reflectance();
		result *= factor * visibility;
	}
	else
		result.MakeZero();
		
	return(result);
}


Bool HProgRad::Render()
{
	Int			i, j;
	Colour		c;
	GCLReal		deltaRad;
	Colour		radToShoot;
	Bool		subdivided;
	Int			numElts = elements.NumItems();
	Int 		numPatches = patches.NumItems();
	GCLReal		power, envArea;
	Colour		envPower, envRefl;
	Bool		finished = 0; 
	ColourList	oldB, oldS;
	
	RadMethod::Render();
	
	iterations = 0;
	error = 1.0;
	origShoot = 0;
	
	B.SetSize(numElts);			// Radiosity vectors for R, G, B
	oldB.SetSize(numElts);		// Radiosity vectors for R, G, B
	S.SetSize(numPatches);		// Unshot radiosity vectors for R, G, B
	oldS.SetSize(numPatches);	// Unshot radiosity vectors for R, G, B
	
	for (i = 0; i < patches.NumItems(); i++)
		S[i] = patches[i]->Emittance();
	
	for (i = 0; i < numElts; i++)
		B[i] = S[eltParents[i]];

	envRad = vl_1;

	if (Stage(1)) return(0);
	
	//	Setup for the ambient term

	envRefl.MakeZero();
	envArea = 0;
	envPower.MakeZero();
	 
	for (i = 0; i < numPatches; i++)
	{
		envRefl += patches[i]->area * patches[i]->Reflectance();
		envArea += patches[i]->area;	
		envPower += S[i] * patches[i]->area;
	}
	
	envPower /= envArea;

	//	R = 1 / (1 - avgReflectance)
	
	for (i = 0; i < 3; i++)
		envRefl[i] = 1.0 / (1.0 - envRefl[i] / envArea);
				
	//	Now, run the algorithm...
						
	while (!finished)
	{	
		if (Stage(2)) return(0);
		
		iterations++;
				
		//	Find the patch with the max power to shoot...
				
		maxPower = 0;
		maxPowerIndex = 0;
		envPower.MakeZero();
		
		for (i = 0; i < numPatches; i++)						
		{
			c = S[i] * patches[i]->area;			
			power = dot(c, kRadRGBToLum);
			
			if (maxPower < power)
			{
				maxPower = power;					// length of R, G, B vector...
				maxPowerIndex = i;
			}
		}
		
		radToShoot = S[maxPowerIndex];
		radToShoot *= options.alpha;
		
		// Find initial form factors
		
		MakeFormFactorFromVector(*patches[maxPowerIndex], elements, FFROW);

		do 
		{
			if (options.multiGrid)
			{
				// We save S & B in case we need to reshoot after subdivision
				
				oldS = S;
				oldB = B;
			}
						
			if (Stage(3)) return(0);
			
			S[maxPowerIndex] -= radToShoot;
											
			if (Stage(4)) return(0);			
	
			error = 0;
			
			//	Shoot radiosity, updating S and B as necessary
			
			for (i = 0; i < numElts; i++)
			{
				for (j = 0; j < 3; j++)				
				{
					deltaRad = FFROW[i][j] * radToShoot[j];
					B[i][j] += deltaRad;
										
					// Push radiosity delta to the parent...
					
					S[eltParents[i]][j] += deltaRad * (elements[i]->area / patches[eltParents[i]]->area);
					error += deltaRad * deltaRad;
				}
			}
	
			error = sqrt(error);

			// Calculate ambient light in scene...
	
			if (options.ambient)
			{
				envPower.MakeZero();
				for (i = 0; i < numPatches; i++)
					envPower += S[i] * patches[i]->area;

				envPower /= envArea;
				envRad = envRefl * envPower;
			}
			else
				envRad.MakeZero();

			// Subdivide receiving elements as necessary...
				
			subdivided = false;
			
			if (options.multiGrid)
			{
				if (Stage(5)) return(0);
	
				// Distribute radiosity to vertices so we can measure element error...
				
				for (i = 0; i < numElts; i++)
					((HierQuad *) elements[i])->SetColour(B[i] + envRad * elements[i]->Reflectance());

				RadCast(scene)->Smooth();
				
				for (i = 0; i < numElts; i++)
				{
					HierQuad *old = (HierQuad *) elements[i];
				
					if (old->RadError() > options.kFError && old->area >= options.kAError)
					{
						// We need to subdivide
												
						if (!old->HasChildren())
							old->Subdivide();
						
						elements[i] = old->child[0];		// Replace elt with its subdivisions...
						
						elements.Append(old->child[1]);
						elements.Append(old->child[2]);
						elements.Append(old->child[3]);
						
						// 	Very subtle bug here: was originally
						//	eltParents.Append(eltParents[i]); etc (duh.)
						//	Rule: NEVER do X.Append(f(X));
						
						j = eltParents[i];
						eltParents.Append(j);
						eltParents.Append(j);
						eltParents.Append(j);
												
						c = oldB[i];
						oldB.Append(c);
						oldB.Append(c);
						oldB.Append(c);
						
						// Generate new form factors to the children...
						
						FFROW[i] = SingleFormFactor(patches[maxPowerIndex], old->child[0]);
						FFROW.Append(SingleFormFactor(patches[maxPowerIndex], old->child[1]));
						FFROW.Append(SingleFormFactor(patches[maxPowerIndex], old->child[2]));
						FFROW.Append(SingleFormFactor(patches[maxPowerIndex], old->child[3]));
						
						subdivided = true;
					}	
				}
				numElts = elements.NumItems();

				if (subdivided)
 				{
					// We need to reshoot: revert to the previous B and S vectors.
				
					B = oldB;
					S = oldS;
 					if (Stage(6)) return(0);
 				}
			}			
		} 
		while (subdivided);
	
		// Stop us before we shoot again

		if (iterations == 1)
			origShoot = maxPower;
		else if (maxPower < options.error * origShoot)
			finished = 1;
		
		if (Stage(7)) return(0);
	}	
	
	if (Stage(8)) return(0);

	return(1);
}



Void HProgRad::DumpStats()
{
	Int		i, j;
	Colour	c;
	GCLReal	shotErr, mem;
	
	if (origShoot == 0.0)
		shotErr = 1.0;
	else
		shotErr = maxPower / origShoot;
	
	mem = sizeof(Colour) * (B.NumItems() + S.NumItems() + FFRow.NumItems() + elements.NumItems())
		+ sizeof(Int) * eltParents.NumItems();
	mem /= 1024.0;
	
	cout << dumpID
		<< ' ' << options.totTime
		<< ' ' << options.stage
		<< ' ' << patches.NumItems()
		<< ' ' << elements.NumItems()
		<< ' ' << shotErr
		<< ' ' << error
		<< ' ' << options.rays
		<< ' ' << mem
		<< ' ' << iterations
		<< endl;

	for (i = 0; i < elements.NumItems(); i++)		// Colour the elements...
		((HierQuad*) elements[i])->SetColour(B[i] + envRad * elements[i]->Reflectance());

	DumpScene();
}

Int HProgRad::Stage(Int stage)
{
	if (CheckTime()) return(1);

	options.stage = stage;

	switch (stage)
	{
	case 1:		// pre setup
		cout << "renderer " << radRenderVersion << endl;
		cout << "method hprog " << endl;
		cout << "sub " << options.patchSubdivs << endl;
		cout << "esub " << options.eltSubdivs << endl;
		cout << "error " << options.error << endl;
		cout << "scene " << scene->Label() << endl;
		cout << "quads " << options.numPolys << endl;
		cout << "srcPatches " << patches.NumItems() << endl;
		cout << "format ID time stage srcPatches patches shootErr resErr rays mem iterations" << endl; 
		cout << "---------------------------------------------------------------------------" << endl;
	
		options.rays = 0;
		options.totTime = 0;
		options.pfTime = 0;
		options.visTime = 0;
		options.drawTime = 0;
		options.solveTime = 0;
		lastTime = 0;
		DumpStats();
		break;
		
	case 2:		
		break;
		
	case 3:		
		break;
		
	case 4:		
		break;
		
	case 5:	
		break;
		
	case 6:	
		break;
		
	case 8:
		DumpStats();
		break;
	}
	
	if (Idle()) return(1);
	ContTimer();
	return(0);
}


Void HProgRad::DrawMatrix(Renderer &r)
{
	if (!options.drawMatrix)
		return;
		
}

RadQuad *HProgRad::NewMesh()
{
	return(new GridHierQuad());
}


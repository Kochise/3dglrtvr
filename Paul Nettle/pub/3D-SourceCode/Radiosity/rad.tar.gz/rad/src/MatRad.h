/*
	File:			MatRad.h

	Function:		Provides a class for lighting a scene using matrix
					radiosity.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __MatRad__
#define __MatRad__

#include "Rad.h"

class MatRad : public RadMethod
{
	public:
	
	MatRad(RadOptions &options, Renderer *displayP, GraphicsSystem *gsP) : 
			RadMethod(options, displayP, gsP) {};

	Bool		Render();
	RadQuad		*NewMesh();
	Void		DrawMatrix(Renderer &r);
	Int			Stage(Int stage);
	Void		DumpStats();
	Void		DumpMatrix();

	Matd		EmissionVectors(PatchList &patches);
	SparseVecd	FormFactorToVector(Int j, PatchList &patches);
	
	SparseMatd	A[3];			// Array of solution matrices,  one each for R, G, B	
	Matd		E;				// Emission vectors for R, G, B
	Matd		B;				// Radiosity vectors for R, G, B
	Int			solverIterations;	
};

#endif

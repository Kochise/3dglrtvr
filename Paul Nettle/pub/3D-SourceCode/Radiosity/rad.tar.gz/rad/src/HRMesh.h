/*
	File:			HRMesh.h

	Function:		Defines a hierarchical mesh for use with hierarchical/
					wavelet radiosity methods.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */


#ifndef __HRMesh__
#define __HRMesh__

#include "HierMesh.h"
#include "List.h"


// --- Link between HR quads -----------------------


class HRQuad;

enum SubdivChoice { kSubNone, kSubFrom, kSubTo, kSubBoth };

class RadLink : public Node
{
public:
	RadLink();
	
	virtual Void Gather() = 0;
	// Gather radiosity from from->B and accumulate in to->R
	// Implemented differently depending on transport mechanism.
							
	virtual Void			Set(HRQuad *fromPatch, HRQuad *toPatch) = 0;
	virtual RadLink			*CreateSubLink(HRQuad *from, HRQuad *to) = 0;
	// Create a new link between from and to, reusing the visibility calcs of the old
	// link if possible.
	
	inline Bool				NeedVisibility();
	// return true if we need a new visibility estimate.
	// 'visibility' should have been initialised to its parent's value
	// prior to calling this.
	
	virtual Int				RefineOracle(GCLReal &kAError, GCLReal &kFError);
	virtual GCLReal			Error() = 0;
	virtual GCLReal			BFError() = 0;

	virtual Void			Print(ostream &s);
	virtual Void			DrawLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom, GCLReal weight);

	HRQuad					*from, *to;
	GCLReal					visibility;
};

ostream &operator << (ostream &s, RadLink &rl);


typedef RadLink			LinkNode;
typedef List			LinkList;
typedef Iter<RadLink>	LinkIter;

ostream &operator << (ostream &s, RadLink &l);


// --- Hierarchical Radiosity Quad ----------------------------------------


class HRQuad;
typedef Array<HRQuad *> TreeList; // YYY

class HRQuad : public HierQuad
{
public:
	HRQuad();

	HierQuad 		*New() { return(0); };
	Void			Print(ostream &s);
	Void			Draw(Renderer &r);
	Void			GetTrees(TreeList &trees);
	
	Void			CalcStats();
	GCLReal 		SampleKernel(GCLReal x1, GCLReal y1, HRQuad *to,
						GCLReal x2, GCLReal y2, GCLReal *visPtr);
					// Kernel sampled between point (x1,y1) on this patch and
					// (x2,y2) on 'to'.
	GCLReal			SubToSubFormFactor(Int i1, Int j1, HRQuad *to,
						Int i2, Int j2, Int n, GCLReal *visPtr);
					// Form factor between pane (i1,j1) and pane (i2,j2) on 'to'.
	GCLReal			EstSubFormFactor(Int i1, Int j1, HRQuad *to,
						GCLReal x2, GCLReal y2, Int n, GCLReal *visPtr);
					// Form factor between pane (i1,j1) and the point (x2,y2) on 'to'.
	
	Void			Refine(LinkNode *link);
	Bool			RefineFurther();
	
	Void			PushPull();
	Void			Gather();
					// Gather radiosity to self
	Void			GatherAll();
					// Gather radiosity to self and all children
	
	// Stub routines for wavelet radiosity.
	virtual Void	Prepare() = 0;
	// Get ready for a traversal: initialise top-level B to element's emittance.
	virtual GCLReal	Error() = 0;
	// Returns error of a push/pull traversal
	virtual Void	Add() = 0;
	// Add received (gathered) energy R to current radiosity B
	virtual Void	Push() = 0;
	// Push accumulated radiosity to children.
	virtual Void	Pull() = 0;
	// Pull up radiosity from children.
	virtual Void	ClearR() = 0;
	// Get ready for a gather: clear R.
	
	//	Visualisation stuff
	Void			DrawSampledLeaf(Renderer &r, Int n);
	Void 			DrawMatrix(Renderer &r, Int numBasePatches);
	Void			DrawContributors(Renderer &r);
	Void			DrawContributorsRec(Renderer &r);

	// Fields
	LinkList		links;
};

inline Bool RadLink::NeedVisibility()
{
	return((to->area >= abs(1.0 / to->props->options->patchSubdivs)) ||
		(visibility > 0.0 && visibility < 1.0));
}
 
#endif

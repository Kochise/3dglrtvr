 
#ifndef __MultiWavelets__
#define __MultiWavelets__
 

#include "HRMesh.h"
#include "WaveSupport.h"


// --- M2 classes: 2 x 2 multiwavelets. (Bi-linear) --------


class M2Link : public RadLink
{
public:
	Void			Gather();
	Void			Set(HRQuad *from, HRQuad *to);
	RadLink			*CreateSubLink(HRQuad *from, HRQuad *to);
	
	Void			Print(ostream &s);
	Void			DrawLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom, GCLReal weight);

	GCLReal			Error();
	GCLReal			BFError();
	GCLReal			OracleError(Matd &K);
	GCLReal			CCOracleError(Matd &K);
	Void			CalcTransport();
	GCLReal			CalcKernel(Matd &K, GCLReal *visPtr);

	// Fields
	GCLReal			transport[16];
	GCLReal			factor;
	static Bool		useCC;
};


class M2Quad : public HRQuad
{
public:
	Void		SetParent(HierQuad &parent);
	HierQuad 	*New() { return(new M2Quad); };
	Void		Print(ostream &s);
	Void		PrintSelf(ostream &s);
	Void		ParseSelf(istream &s);
	
	Void		DrawLeaf(Renderer &r);
	Colour		SampleLeaf(Coord &c);
	Int			Coeffs() { if (IsQuad()) return(4); else return(3); };
		
	Void		Add();
	Void		Push();
	Void		Pull();
	Void		Prepare();
	GCLReal		Error();
	Void		ClearR();

	// Fields
	Colour		B[4];
	Colour		R[4];
	static Colour lastB[4];
};


// --- M3 classes: 3 x 3 multiwavelets. (Bi-quadratic) --------


class M3Link : public RadLink
{
public:
	Void			Gather();
	Void			Set(HRQuad *from, HRQuad *to);
	RadLink			*CreateSubLink(HRQuad *from, HRQuad *to);
	
	Void			Print(ostream &s);
	Void			DrawLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom, GCLReal weight);

	GCLReal			Error();
	GCLReal			BFError();
	GCLReal			OracleError(Matd &K);
	GCLReal			CCOracleError(Matd &K);
	Void			CalcTransport();
	GCLReal			CalcKernel(Matd &K, GCLReal *visPtr);

	// Fields
	GCLReal			transport[81];		// wavelength independent.
	GCLReal			factor;
	static Bool		useCC;
};


class M3Quad : public HRQuad
{
public:
	Void		SetParent(HierQuad &parent);
	HierQuad 	*New() { return(new M3Quad); };
	Void		Print(ostream &s);
	Void		PrintSelf(ostream &s);
	Void		ParseSelf(istream &s);
	
	Void		DrawLeaf(Renderer &r);
	Colour		SampleLeaf(Coord &c);
	Int			Coeffs() { if (IsQuad()) return(9); else return(6); };
	
	Void		Add();
	Void		Push();
	Void		Pull();
	Void		Prepare();
	GCLReal		Error();
	Void		ClearR();

	// Fields
	Colour		B[9];
	Colour		R[9];
	static Colour lastB[9];
};

#endif

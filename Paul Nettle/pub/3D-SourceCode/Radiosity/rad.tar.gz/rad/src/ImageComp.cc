/*
	File:		ImageComp.cc

	Purpose:	To compare two identically-sized image files.

 */
 
#include "arg.h"
#include "stdlib.h"

#include "Image.h"
#include "XGraphicsSystem.h"

Void ApplyToImageDiff(Action<GCLReal> &action, ImgChannel channel, Image &image1, Image &image2)
{
	Int		i, j;
	GCLReal	temp;
	action.Start();
	
	for (i = 0; i < image1.Height(); i++)
		for (j = 0; j < image1.Width(); j++)
		{
			temp = (GCLReal) image1(i, j) - (GCLReal) image2(i, j);
			action.Process(temp);
		}	
	action.Stop();
}

Void AbsImageDiff(Image &image1, Image &image2, Image &destImage)
{
	Int i, j, k;
	
	for (i = 0; i < image1.Rows(); i++)
		for (j = 0; j < image1.Cols(); j++)
		{
			Pixel &a = image1(i, j);
			Pixel &b = image2(i, j);
			Pixel &c = destImage(i, j);
			
			for (k = 0; k < 4; k++)
				if (a.channel[k] < b.channel[k])
					c.channel[k] = b.channel[k] - a.channel[k];
				else
					c.channel[k] = a.channel[k] - b.channel[k];
		}
}


/*
	Main Program
 */

int main(int argc, char **argv)
{
	GraphicsSystem	*gs;
	Stats<GCLReal>		rstats, bstats, gstats;
	RGBAImage		A, B, C;
	GSPane			*window;
	char			*file1, *file2;
	int				useWin;
	GCLReal			totMean = 0, totVar = 0;
	
	// command-line options
	
	if (arg_parse(argc, argv, 
			"", 										"usage: prog [options]",
			
			"%S",	&file1,								"image file 1",
			"%S",	&file2,								"image file 2",
			
			// Output options
			
			"-window", ARG_FLAG(&useWin), 				"display images in window",
			0) < 0)
		exit(1);
	
	// Read two images
	
	if (!A.LoadFromTIFF(file1))
		exit(1);

	if (useWin)
	{
		gs = new GraphicsSystem;
		window = new GSPane;
		gs->CreateWindow(window, "difference", A.Cols(), A.Rows());
		window->SetImage(A);
	}
	
	if (!B.LoadFromTIFF(file2))
		exit(1);
	
	if (B.Cols() != A.Cols() || B.Rows() != A.Rows())
	{
		cerr << "Error: picture dimensions don't match." << endl;
		exit(1);
	}
	
	if (useWin)
	{
		window->Clear();
		window->SetImage(B);
	}
	
	// Compare...
	
	C.SetSize(A.Rows(), A.Cols());
	AbsImageDiff(A, B, C);	
	
	Pixel::currentChannel = chRed;
	ApplyToImageDiff(rstats, A, B);
	
	Pixel::currentChannel = chGreen;
	ApplyToImageDiff(gstats, A, B);

	Pixel::currentChannel = chBlue;
	ApplyToImageDiff(bstats, A, B);
	
	cout << dot(kRadRGBToLum, Vector(rstats.mean, gstats.mean, bstats.mean)) << endl;
	cout << sqrt(dot(kRadRGBToLum, Vector(rstats.variance, gstats.variance, bstats.variance))) << endl;
	
	if (useWin)
	{
		window->Clear();
		window->SetImage(C);
		gs->Run();
	}
	
	return(0);
}

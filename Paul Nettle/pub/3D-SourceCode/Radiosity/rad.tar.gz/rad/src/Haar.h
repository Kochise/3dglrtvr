
#ifndef __Haar__
#define __Haar__

#include "HRMesh.h"

class HaarLink : public RadLink
{
public:
	Void			Gather();	
	Void			Set(HRQuad *from, HRQuad *to);
	LinkNode		*CreateSubLink(HRQuad *from, HRQuad *to);
	Void			Print(ostream &s);
	Void			DrawLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom, GCLReal weight);
	
	GCLReal			Error();
	GCLReal			BFError();

	GCLReal 		transport;
	GCLReal 		factor;
};

class HaarQuad : public HRQuad
{
public:
	Void		SetParent(HierQuad &parent);
	HierQuad 	*New() { return(new HaarQuad); };
	Colour		SampleLeaf(Coord &c);
	Void		Print(ostream &s);
	Void		PrintSelf(ostream &s);
	Void		ParseSelf(istream &s);
	
	Void		Add();
	Void		Push();
	Void		Pull();
	Void		Prepare();
	GCLReal		Error();
	Void		ClearR();

	// Fields
	Colour		B;
	Colour		R;
	static Colour lastB;
};

#endif

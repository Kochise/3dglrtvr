/*
	File:			Forms.h

	Function:		Integrates the 'Forms' user interface kit for SGIs into
					the X window graphics system. (See XGraphicsSystem.h.)
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __Forms__
#define __Forms__

#include <forms.h>
#include <iostream.h>
#include <strstream.h>
#include "XGraphicsSystem.h"


// --- Forms Graphics System --------------------------------------------------


class FormsGraphicsSystem : public GraphicsSystem
{
	public:

				FormsGraphicsSystem(int argc, char **argv, char *name = 0);
				
	Void		CreateFormsPane(XEventPane *xpane, FL_OBJECT *object);
	Void		CreateWindow(XEventPane *xpane, Char *title = "OpenGL window",
					Int width = 400, Int height = 400);
	
	// overrides
	
	Void		GetMouse(XEventPane *pane, Int *x, Int *y, UInt *keyState);
	Void		Spin();
	Void		Run();	
};

// --- Form class ------------------------------------------------------------


class Form
{
	public:
		
	virtual Void	Event(FL_OBJECT *object);

	Void			Show();
	Void			Hide();	
	
	Void			RegisterForm(FL_FORM *form);
	Void			RegisterObj(FL_OBJECT *object);

	FL_FORM			*form;
};


// --- The Field Class --------------------------------------------------------


/*
	Allows you to use streams to set Forms fields, e.g., 
		Field(myField) << "Blah blah blah" << show;
*/

class Field : public ostrstream
{
	public:
	
	Field(FL_OBJECT *commentObj) : object(commentObj), ostrstream() {};

	virtual Void Show();

	FL_OBJECT *object;
};

class InputField : public Field
{
	public:
	
	InputField(FL_OBJECT *commentObj) : Field(commentObj) {};

	Void Show();	// override
};

ostream &show(ostream &s);


Void my_activate(FL_OBJECT *obj);		// These versions do dimming of 
Void my_deactivate(FL_OBJECT *obj);		// inactive controls. Kind of.

Void fl_deactivate_group(FL_OBJECT *obj);
Void fl_activate_group(FL_OBJECT *obj);

#endif

#ifndef __RadPane__
#define __RadPane__

#include "ScenePane.h"
#include "Forms.h"
#include "RadMesh.h"


FL_OBJECT 	*const msgPick = (FL_OBJECT *) 0x04;

class FormsScenePane : public ScenePane
{
public:
	FormsScenePane(Bool doubleBuf) : ScenePane(doubleBuf) {};

	Void			SetParent(Form *parent);
	
	Form			*parent;
};

class RadScenePane : public FormsScenePane
{
public:
	RadScenePane(Bool doubleBuf = true);

	Void SetScene(scScenePtr scene);
	Void Pick(GCLReal x, GCLReal y, Int which, Int levelsUp);		// Pick object at screen coords (x, y)

	RadQuad	*selPatch[2];
};

class MatrixScenePane : public FormsScenePane
{
public:
	MatrixScenePane(Bool doubleBuf = true);

	Void	SetScene(scScenePtr scene);
	Void 	Pick(GCLReal x, GCLReal y, Int which, Int levelsUp);		// Pick object at screen coords (x, y)
};

#endif

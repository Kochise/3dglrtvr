/*
	File:			ProgRad.h

	Function:		Provides a class for lighting a scene using progressive 
					radiosity.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __ProgRad__
#define __ProgRad__

#include "Rad.h"

class ProgRad : public RadMethod
{
public:
	ProgRad(RadOptions &options, Renderer *displayP, GraphicsSystem *gsP)
		 : RadMethod(options, displayP, gsP) {};

	Bool		Render();				
	Int			Stage(Int stage);		
	RadQuad		*NewMesh();

	Void		DrawMatrix(Renderer &r);
	Void		DumpStats();
	
	Void		MakeFormFactorFromVector(RadQuad &fromPatch, PatchList &patches, 
					ColourList &result);

	ColourList	B;						// Radiosity of scene elements
	ColourList	S;						// Unshot radiosities
	
	Int			maxPowerIndex;			// index of patch with largest unshot power
	GCLReal		error, maxPower, origShoot;
	Colour		envRad;					// Ambient radiosity.
	Int			iterations;
	
	ColourList	FFRow;					// Row of form factors * reflectance for R, G, B
};

#define FFROW FFRow


#endif

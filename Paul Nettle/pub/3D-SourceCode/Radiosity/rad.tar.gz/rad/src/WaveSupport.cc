#include "WaveSupport.h"
#include "RadOptions.h"
#include "Renderer.h"

// ----------------------------------

GCLReal CalcError(Colour *B1, Colour *B2, Int n)
{
	Colour csum(vl_0);
	
	for (int i = 0; i < n; i++)
		csum += *B1++ - *B2++;
	return(dot(csum, kRadRGBToLum) / n);
}

Colour Average(Colour *B, Int n)
{
	Colour csum(vl_0);
	
	for (int i = 0; i < n; i++)
		csum += *B++;
	return(csum / n);
}

Void Scale(Colour *c, Int n, GCLReal s)
{
	for (int i = 0; i < n; i++)
		*c++ *= s;
}

Void Mult(const Matd &m, Colour *src, Colour *dst)
// dst = m * src
{
	for (int i = 0; i < m.Rows(); i++)
	{
		dst[i] = vl_0;
		for (int j = 0; j < m.Cols(); j++)
			dst[i] += m[i][j] * src[j];
	}
}

Void MultAcc(const Matd &m, Colour *src, Colour *dst)
// dst += m * src
{
	for (int i = 0; i < m.Rows(); i++)
		for (int j = 0; j < m.Cols(); j++)
			dst[i] += m[i][j] * src[j];
}

Void TensorMult(const Matd &m, Colour *src, Colour *dst)
// [dst] = m * [src] * trans(m)
// [src] is the matrix S[i][j] = src[i.n + j], where n is the # of
// rows (and columns) in m.
// A tensor-product multiplication is O(n ^ 3/2) where the equivalent full 
// multiplication (using Mult) would be O(n^2), which is why we go to
// this extra trouble to perform it.
{
	Colour	t[16];
	
	LeftTensorMult(m, src, t);
	RightTensorMult(m, t, dst);
}

Void LeftTensorMult(const Matd &m, Colour *src, Colour *dst)
// dst = m * [src]
{
	for (int i = 0; i < m.Rows(); i++)
		for (int j = 0; j < m.Cols(); j++)
		{
			*dst = vl_0;
			for (int k = 0; k < m.Cols(); k++)
				*dst += m[i][k] * src[k * m.Cols() + j];
			dst++;
		}
}

Void RightTensorMult(const Matd &m, Colour *src, Colour *dst)
// [dst] = [src] * trans(m)
{
	for (int i = 0; i < m.Cols(); i++)
		for (int j = 0; j < m.Cols(); j++)
		{
			*dst = vl_0;
			for (int k = 0; k < m.Cols(); k++)
				*dst += m[j][k] * src[i * m.Cols() + k];
			dst++;
		}
}

Void LeftTensorMultAcc(const Matd &m, Colour *src, Colour *dst)
// [dst] += m * [src]
{
	for (int i = 0; i < m.Rows(); i++)
		for (int j = 0; j < m.Cols(); j++)
		{
			for (int k = 0; k < m.Cols(); k++)
				*dst += m[i][k] * src[k * m.Cols() + j];
			dst++;
		}
}

Void RightTensorMultAcc(const Matd &m, Colour *src, Colour *dst)
// [dst] += [src] * trans(m)
{
	for (int i = 0; i < m.Cols(); i++)
		for (int j = 0; j < m.Cols(); j++)
		{
			for (int k = 0; k < m.Cols(); k++)
				*dst += m[j][k] * src[i * m.Cols() + k];
			dst++;
		}
}


// ----------------------------------


Colour M2QuadSample(Coord &c, Colour *B)
{
	Colour result;
	result = (B[0] + B[1] * c[0]) +
			 (B[2] + B[3] * c[0]) * -c[1];
	return(result);
}

Colour M2TriSample(Coord &c, Colour *B)
{
	Colour result;
	result = B[0] * (1 - c[0] - c[1]) + B[1] * c[0] + B[2] * c[1]; 
	return(result);
}

Colour M3QuadSample(Coord &c, Colour *B)
{
	Colour	result;
	GCLReal x1 =  c[0], x2 = sqr(c[0]) - 1.0 / 3.0;
	GCLReal y1 = -c[1], y2 = sqr(c[1]) - 1.0 / 3.0;

	result =       B[0] + B[1] * x1 + B[2] * x2  +
			 y1 * (B[3] + B[4] * x1 + B[5] * x2) +
			 y2 * (B[6] + B[7] * x1 + B[8] * x2);

	return(result);
}

Colour M3TriSample(Coord &c, Colour *B)
{
	Colour	result;
	GCLReal ga = 1 - c[1] - c[0];
	GCLReal gb = c[0];
	GCLReal gc = c[1];
	
	result =	B[0] * sqr(ga) + 
				B[1] * sqr(gb) +
				B[2] * sqr(gc) + 2 * (
				B[3] * ga * gb +
				B[4] * gb * gc + 
				B[5] * gc * ga);

	return(result);
}

Void DrawWaveLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom,
	Colour weight, const Matd &m)
{
	GCLReal	dx = (right - left) / m.Cols();
	GCLReal dy = (bottom - top) / m.Rows();
	GCLReal oldLeft = left;
	GCLReal *tc = m.Ref();
	Int		i, j;
	
	right = left + dx;
	bottom = top + dy;
	
	for (i = 0; i < m.Rows(); i++)
	{
		for (j = 0; j < m.Cols(); j++)
		{
			r.SetColour(weight * *tc);
			r.Rect(left, top, right, bottom);
			left += dx; right += dx;
			tc++;
		}
		left = oldLeft; right = oldLeft + dx;
		top += dy; bottom += dy;
	}
}

// ---------------------------------------------------


Void MakeTensorMatrix(const Matd &c, Matd &a)
// a = C, where C is the tensor-product of matrix c with itself. O(n^4)
{
	Int		n = c.Rows();
	Int		i, j, k, l, s, t;
	
	a.SetSize(sqr(n), sqr(n));
	for (i = 0, s = 0; i < n; i++)
		for (j = 0; j < n; j++, s++)
			for (k = 0, t = 0; k < n; k++)
				for (l = 0; l < n; l++, t++)
					a[s][t] = c[j][l] * c[i][k];
}

Void RightTensorMult(const Matd &a, const Matd &c, Matd &d)
// d = a * C, where C is the tensor-product of matrix c with itself.
// O(mn^3).
{
	Int		n = c.Rows();
	Int		i, j, k, l, s, t, m;
	Matd	p;
	
	d.SetSize(a.Rows(), sqr(n));
	d = vl_0;
	p.SetSize(c);
	
	for (m = 0; m < a.Rows(); m++)
	{
		p = vl_0;
		for (l = 0; l < n; l++)
			for (i = 0, s = 0; i < n; i++)
				for (j = 0; j < n; j++, s++)
					p[i][l] += c[j][l] * a[m][s];
					
		for (k = 0, t = 0; k < n; k++)
			for (l = 0; l < n; l++, t++)
				for (i = 0; i < n; i++)
					d[m][t] += c[i][k] * p[i][l];
	}
}

Void LeftTensorMult(const Matd &c, const Matd &a, Matd &d)
// d = C * a, where C is the tensor-product of matrix c with itself.
// O(mn^3).
{
	Int		n = c.Rows();
	Int		i, j, k, l, s, t, m;
	Matd	p;
	
	d = vl_0;
	p.SetSize(c);
		
	for (m = 0; m < a.Cols(); m++)
	{
		p = vl_0;
		for (j = 0; j < n; j++)
			for (k = 0, t = 0; k < n; k++)
				for (l = 0; l < n; l++, t++)
					p[j][k] += c[j][l] * a[t][m];
					
		for (i = 0, s = 0; i < n; i++)
			for (j = 0; j < n; j++, s++)
				for (k = 0; k < n; k++)
					d[s][m] += c[i][k] * p[j][k];
	}
}

/*
	File:			RadPoly.h

	Function:		Defines polygon in a radiosity scene. Major features are an
					intersection method for raytracing, and the ability to mesh
					the polygon.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
*/

#ifndef __RadPoly__
#define __RadPoly__

#include "Geometry.h"
#include "Library.h"
#include "RadMesh.h"
#include "HRMesh.h"
#include "RT_Grid.h"

#define RadCast(x) ((RadPrim *) x->UpCast())
#define RadPrimCast(x) ((RadPrim *) PrimCast(x)->UpCast())

//	Mix-in class for radiosity primitives

class RadPrim
{
public:

	// Ray-tracing Methods

	virtual Void		AddToGrid(Grid* grid) = 0;
	virtual Bool		FindBounds(Point& min, Point& max) = 0;
	virtual scPrimitive *ClosestIntersection(Point &start, Vector &dir, Point &p) = 0;
	virtual Bool 		IntersectsWithRay(Point &start, Point &end) = 0;

 	// Radiosity methods

	Void				InitRad(RadOptions &options);
	virtual Void		InitRad(Context *context, RadOptions &options) = 0;
	virtual Void		Reanimate(RadOptions &options) = 0;
	
	Void				ApplyTransforms();
	virtual Void		ApplyTransforms(Transform t, Context *context) {};
	Void				MakeQuadTri();
	virtual Void		MakeQuadTri(Context *context) {};
	virtual Void		GetTrees(TreeList &trees) = 0;
	virtual Void		CreatePatches(PatchList &patches, PatchStats *stats = 0) = 0;
	virtual Colour		Sample(GCLReal u, GCLReal v) { return cBlack; };	// sample in uv space.

	virtual Void 		Compare(scPrimitive *to, GCLReal edgeLen, 
							GCLReal &areaSum, Colour &cSum, Colour &cSqrSum, Colour &refSum) = 0;
	virtual Void		Smooth() = 0;								// push colours out to vertices.
};
 
class RadGroup : public scGroup, public RadPrim
{
public:
	RadGroup() : scGroup(), RadPrim(), grid(0) {};
	RadGroup(Char *name) : scGroup(name), RadPrim(), grid(0) {};
	RadGroup(const RadGroup &rg) : scGroup(rg), RadPrim(), grid(0) {};

	//	Ray tracing methods.

	Grid*				grid;

	Void			CreateGrid();
	Void			AddToGrid(Grid* grid);
	Bool			FindBounds(Point& min, Point& max);
	scPrimitive 	*ClosestIntersection(Point &start, Vector &dir, Point &p);
	Bool			IntersectsWithRay(Point &start, Point &end);

	//	Radiosity methods
	
	Void			ApplyTransforms(Transform t, Context *context);
	Void			MakeQuadTri(Context *contex);
	Void			GetTrees(TreeList &trees);
	Void			CreatePatches(PatchList &patches, PatchStats *stats);

	Void			Reanimate(RadOptions &options);
	Void			InitRad(Context *context, RadOptions &options);
	Void			Smooth();										// push colours out to vertices.
	Void 			Compare(scPrimitive *to, GCLReal edgeLen,
						GCLReal &areaSum, Colour &cSum, Colour &cSqrSum, Colour &refSum);

	Void			*UpCast() {return((RadPrim *) this);};		
	Object			*Clone() const;
};

 
class RadPoly : public scPoly, public RadPrim		
{
public:
	 
	RadPoly();
	~RadPoly();
	
	Void			*UpCast() { return((RadPrim *) this); };		
	Object		 	*Clone() const { return new RadPoly(SELF); };
	
	Void 			Draw(Renderer &r, Context *context);

	//	Ray tracing methods.

	Void			AddToGrid(Grid* grid);
	Bool			FindBounds(Point& min, Point& max);
	scPrimitive 	*ClosestIntersection(Point &start, Vector &dir, Point &p);
	Bool 			IntersectsWithRay(Point &start, Point &end);

	//	Radiosity methods
	
	Coord			FindCoord(Point &p);
	Bool			PointInPoly(Vector &p, Int axis);

	Void			Print(ostream &s) const;
	Void			Parse(istream &s);
		
	Point			&Vertex(Int i)	{return((*props.points)[elem->index[i]]);};
	Point			&Centre()		{return(elem->centre);};
	Int 			NumVertices()	{if (elem->index[3] < 0) return(3); else return(4);};

	Void			InitRad(Context *context, RadOptions &options);
	Void			Reanimate(RadOptions &options);
	Void			SetupProps(RadOptions &options);
	
	Void			GetTrees(TreeList &trees);
	Void			CreatePatches(PatchList &patches, PatchStats *stats);
	Colour			Sample(GCLReal u, GCLReal v);					// sample in uv space.
	Void			Smooth();										// push colours out to vertices.
	Void 			Compare(scPrimitive *to, GCLReal edgeLen,
						GCLReal &areaSum, Colour &cSum,
						Colour &cSqrSum, Colour &refSum);

	RadProps		props;
	RadQuad			*elem;
};


// --- Radiosity Library --------------------------------------------------


class RadLib : public Library
{
public:
	Void 	Create();	// override
};
 

#endif

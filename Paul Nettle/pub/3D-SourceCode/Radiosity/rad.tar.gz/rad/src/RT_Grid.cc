/*
	File:			RT_Grid.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			Need to merge in hierarchical grid stuff from shine
*/

#include "RT_Grid.h"

#pragma instantiate Array<TriEntry>
#pragma instantiate Array<Int>

Real gPushSizeLimit = 0.1;
Real gMaxCellRatio = 0.2;
Real gMinDensity = 0.03;
Real gMaxExpand = 3.0;



// --- Useful #defines ------------------------------------


#define SGN(x) (((x) > 0 ) ? 1 : (((x) < 0) ? -1 : 0))


// --- Min & Max routines -------------------------------------


inline Real	MaxElt(Vector &v);
inline Real	MinElt(Vector &v);
Int		MaxEltIndex(Vector &v);
Int		MinEltIndex(Vector &v);

inline Real MaxElt(Vector &v)
{
	return(Max(Max(v[0], v[1]), v[2]));
}

inline Real MinElt(Vector &v)
{
	return(Min(Min(v[0], v[1]), v[2]));
}

Int MinEltIndex(Vector &v)
{
	if (v[0] < v[1])
		if (v[0] < v[2])
			return(0);
		else
			return(2);
	else
		if (v[1] < v[2])
			return(1);
		else
			return(2);
}

Int MaxEltIndex(Vector &v)
{
	if (v[0] > v[1])
		if (v[0] > v[2])
			return(0);
		else
			return(2);
	else
		if (v[1] > v[2])
			return(1);
		else
			return(2);
}

// --- Bounding box utility routines -------------------

inline Void FindMaxElts(Vector &a,  Vector &b, Vector &c)
{
	c[0] = Max(a[0], b[0]);
	c[1] = Max(a[1], b[1]);
	c[2] = Max(a[2], b[2]);
}

inline Void FindMinElts(Vector &a,  Vector &b, Vector &c)
{
	c[0] = Min(a[0], b[0]);
	c[1] = Min(a[1], b[1]);
	c[2] = Min(a[2], b[2]);
}

Real BoxVol(Vector &min, Vector &max)
{
	Vector t = max;

	t -= min;

	return(t[0] * t[1] * t[2]);
}

Void UpdateBox(RTTri* tri, Vector& min, Vector& max)
{
	Int		i;
	Point*	points = tri->ptList->Ref();
	Real*	pt;
		
	for (i = 0; i < 3; i++)
	{
		pt = points[tri->v[i]].Ref();	
			
		if (min[0] > pt[0])
			min[0] = pt[0];
		else if (max[0] < pt[0])
			max[0] = pt[0];
	
		if (min[1] > pt[1])
			min[1] = pt[1];
		else if (max[1] < pt[1])
			max[1] = pt[1];
	
		if (min[2] > pt[2])
			min[2] = pt[2];
		else if (max[2] < pt[2])
			max[2] = pt[2];
	}
}


// --- Grid methods -----------------------------------------------------


static RTTri* gLastTri = 0;


Grid::Grid(Int maxCells1, Int maxCellPolys1, Int maxGridPolys1) : grid(), maxCells(maxCells1), 
	maxCellPolys(maxCellPolys1), totalTris(0), dirty(false), 
	level(0), pushedEntries(0), stamp(0)
{
	max = Vector(-HUGE_VAL, -HUGE_VAL, -HUGE_VAL);
	min = Vector( HUGE_VAL,  HUGE_VAL,  HUGE_VAL);
	gLastTri = 0;
}

Grid::Grid() : grid(), maxCells(40), 
	maxCellPolys(40),  totalTris(0), dirty(false), 
	level(0), pushedEntries(0), stamp(0)
{
	max = Vector(-HUGE_VAL, -HUGE_VAL, -HUGE_VAL);
	min = Vector( HUGE_VAL,  HUGE_VAL,  HUGE_VAL);
	gLastTri = 0;
}

Grid::~Grid()
{
}


Void Grid::Prepare()
// Prepare grid for raytracing.
{
	// do nuthin...
}

Void Grid::UpdateBBox(Point& cellMin, Point& cellMax)
{
	if (min[0] > cellMin[0])
		min[0] = cellMin[0];
	if (max[0] < cellMax[0])
		max[0] = cellMax[0];

	if (min[1] > cellMin[1])
		min[1] = cellMin[1];
	if (max[1] < cellMax[1])
		max[1] = cellMax[1];

	if (min[2] > cellMin[2])
		min[2] = cellMin[2];
	if (max[2] < cellMax[2])
		max[2] = cellMax[2];
}

#pragma mark -

Void Grid::SetupGrid()
{
	Real	halfWidth, maxSpan;
	Vector	centre, span;
	Int		i;
	
	//	Calculate the boundaries for the Fujimoto grid.  We already know
	//	the world-space boundaries for the object.

	span = max - min;
	maxSpan = MaxElt(span);
	cellSize = maxSpan / maxCells;
	
	//	Calculate how many grid cells the object will have in each 
	//	direction.  We've already assigned the widest direction a 
	//	preset number of grid cells and the narrower directions fewer 
	//	cells.

	for (i = 0; i < 3; i++)
	{
		numCells[i] = (Int) ceil(maxCells * span[i] / maxSpan);

		if (numCells[i] == 0)				// Ensure at least 1 cell in all directions
			numCells[i] = 1;
		
		halfWidth = numCells[i] * cellSize / 2.0;

		max[i] = min[i] + numCells[i] * cellSize;
	}

	//	Allocate a one-dimensional array for the grid.

	totalCells = numCells[0] * numCells[1] * numCells[2];
	xSpan = numCells[1] * numCells[2];
	ySpan = numCells[2];

	grid.SetSize(totalCells);

	for (i = 0; i < grid.NumItems(); i++)
		grid[i] = 0;

	//	We also allocate entries to go into the grid.  Start counting from
	//	one -- we'll save zero for the "end-of-linked-list" symbol.

	triEntries.SetSize(1);
	triEntries[0].tri = 0;
	triEntries[0].next = 0;
}


Void Grid::AddTriangle(RTTri *tri)
//	Add a triangle to this grid.
{
	Vector	tMin, tMax;
	Vector	cellMin, vertex;
	Point	*p1, *p2, *p3;
	Int		i, entry;
	Int		x, y, z, sign, *last, cellNum;
	Point*	points = tri->ptList->Ref();
	Int		start[3], end[3];
	Real	temp;
	
	//	We want to enter the polygon into all of the grid cells 
	//	it intersects.  We first limit our test of grid cells to 
	//	those in which the polygon's bounding box resides.

	p1 = points + tri->v[0];
	p2 = points + tri->v[1];
	p3 = points + tri->v[2];

	FindMaxElts(*p1, *p2, tMax);
	FindMaxElts(*p3, tMax, tMax);
	
	FindMinElts(*p1, *p2, tMin);
	FindMinElts(*p3, tMin, tMin);
		
	//	Find the equivalent cell bounds

	for (i = 0; i < 3; i++)
	{
		start[i] = (Int) ((tMin[i] - min[i]) / cellSize);
		end[i]   = (Int) ((tMax[i] - min[i]) / cellSize);

		// Crop to the grid

		if (end[i] >= numCells[i])
			end[i] = numCells[i] - 1;
		else if (end[i] < 0)
			end[i] = 0;
			
		if (start[i] >= numCells[i])
			start[i] = numCells[i] - 1;
		else if (start[i] < 0)
			start[i] = 0;
	}
	
	//	Finally, the triangle is added to every grid cell in the bounding box
	//	which straddles the plane of the triangle. 

	for (x = start[0]; x <= end[0]; x++)
		for (y = start[1]; y <= end[1]; y++)
			for (z = start[2]; z <= end[2]; z++)
			{
				//	We test each vertex of the cell by plugging it into the triangle's
				//	plane equation. If a vertex has a different sign from the preceeding
				//	vertices, we know the plane straddles this cube, and we add the triangle to the
				//	cell. A result of zero means the plane touches the vertex, which is also grounds
				//	for adding the triangle. 
				
				cellMin = min + Vector(x, y, z) * cellSize;
				cellNum = x * xSpan + y * ySpan + z;
				temp = dot(tri->normal, cellMin) + tri->d;
				sign = SGN(temp);
				
				if (sign == 0)	// The first sign is zero: we can stop immediately.
					i = 1;
				else
					for (i = 1; i < 8; i++)	
					{
						vertex = cellMin;
						
						if (i & 1) vertex[0] += cellSize;
						if (i & 2) vertex[1] += cellSize;
						if (i & 4) vertex[2] += cellSize;
						
						temp = dot(tri->normal, vertex) + tri->d;

						if (sign != SGN(temp))
							break;
					}

				//	Add the triangle if we have a straddle

				if (i < 8)
				{
					triEntries.Add(1);
					triEntries.Last().tri = tri;
					
					triEntries.Last().next = grid[cellNum];
					grid[cellNum] = triEntries.NumItems() - 1;
				}
			}
			
}

#pragma mark -

inline Void Grid::ConvertToGridPoint(Point &point, Point &fujiPoint)
{
	fujiPoint = (point - min) / cellSize;
}

Void Grid::RayClampEntryPoint(Int index, Bool backEntry[3], Vector& fujiPoint, Int cell[3])
{
	if (backEntry[index])
	{
		//	If we're entering from the back end, we're entering the 
		//	largest numbered cell in this direction. 

		cell[index] = numCells[index] - 1;
		fujiPoint[index] = (Real) numCells[index];
	}
	else
	{
		//	From the front, it's the smallest, which is conveniently zero.

		cell[index] = 0;
		fujiPoint[index] = 0.0;
	}

}  


Bool Grid::FindGridStart(
	Point&		start,
	Vector&		direction,
	Int			cell[3],
	Int			increment[3],
	Int			limit[3],
	Real&		tRay, 
	Vector&		tDelta,
	Vector&		tMax 
	)
{
	Int		i;
	Vector	fujiPoint;
	Vector	in, out;
	Bool	backEntry[3];
	Point	point;
				
	ConvertToGridPoint(start, fujiPoint);

	if (0.0 <= fujiPoint[0] && fujiPoint[0] <= numCells[0] &&
		0.0 <= fujiPoint[1] && fujiPoint[1] <= numCells[1] &&
		0.0 <= fujiPoint[2] && fujiPoint[2] <= numCells[2])
	{
		//	We are starting inside the Fujimoto grid.  Let's figure out
		//	in which cell we are beginning.
		
		tRay = 0.0;
	    
	    for (i = 0; i < 3; i++)
		{
		    cell[i] = (Int) floor(fujiPoint[i]);

			if (cell[i] == numCells[i])
				cell[i]--;
		}
	}

	//	Otherwise, we have to compute the entry point.
	//	into the Fujimoto grid.

	else
	{
		for (i = 0; i < 3; i++)
		{
		    //	Avoid the divide by zero.  This would occur if the ray
		    //	has no component in one or two directions.
	
		    if (abs(direction[i]) != (Real) 0.0)
		    {
			    in[i]     = (min[i] - start[i]) / direction[i];
			    out[i]    = (max[i] - start[i]) / direction[i];
		    }
		    else
		    {
			    in[i]     = -HUGE_VAL;
			    out[i]    =  HUGE_VAL;
		    }

		    //	We're really concerned only with the entry point of the ray into
		    //	the grid.  Thus, if we've got our entry and exit points backwards,
		    //	then correct the entry point.
	
		    if (backEntry[i] = (in[i] > out[i]))
				in[i] = out[i];
	    }

	    //	The actual entry point into the grid occurs at the maximum of the
	    //	just-computed entry values (i.e., we enter the grid when we've
	    //	crossed the X _and_ the Y _and_ the Z planes of the Fujimoto 
		//	grid.

	    tRay = MaxElt(in);			
				
	    point = start + tRay * direction;
    
	    //	Compute the entry point in terms of grid space.  (I.e., in
	    //	what cell do we enter the grid?)
	    
	    ConvertToGridPoint(point, fujiPoint);
	    
		for (i = 0; i < 3; i++)
		    cell[i] = (Int) floor(fujiPoint[i]);

		// the cell direction corresponding to the maximum component(s)
		// of 'in' will lie along the boundary of the grid. To 
		// prevent spilling over the boundary due to round-off error, we clamp the
		// direction(s) back to the grid boundary.
		
	    if (in[0] > in[1])	
	    {
		    if (in[0] >= in[2])	
		    {
			    RayClampEntryPoint(0, backEntry, fujiPoint, cell);
    
			    if (in[0] == in[2])	
				    RayClampEntryPoint(2, backEntry, fujiPoint, cell);
		    }
		    else
			    RayClampEntryPoint(2, backEntry, fujiPoint, cell);
	    }
	    else if (in[0] == in[1])
	    {
		    if (in[2] >= in[0])
		    {
			    RayClampEntryPoint(2, backEntry, fujiPoint, cell);
    
			    if (in[2] == in[0])
			    {
				    RayClampEntryPoint(0, backEntry, fujiPoint, cell);
				    RayClampEntryPoint(1, backEntry, fujiPoint, cell);
			    }
		    }
		    else
		    {
			    RayClampEntryPoint(0, backEntry, fujiPoint, cell);
			    RayClampEntryPoint(1, backEntry, fujiPoint, cell);
		    }
	    }
	    else
	    {
		    if (in[1] >= in[2])
		    {
			    RayClampEntryPoint(1, backEntry, fujiPoint, cell);
    
			    if (in[1] == in[2])
				    RayClampEntryPoint(2, backEntry, fujiPoint, cell);
		    }
		    else
			    RayClampEntryPoint(2, backEntry, fujiPoint, cell);
	    }

	   	//	If the ray completely misses the Fujimoto grid, then we 
		//	of course didn't hit anything.

		for (i = 0; i < 3; i++)	
			if (cell[i] < 0 || numCells[i] <= cell[i])
				return(false);
	}
	
	// Calculate auxillary info used for traversing the grid
	
	for (i = 0; i < 3; i++)
	{
		Real scale = cellSize;
	
		//	The ray that goes through the Fujimoto grid is parameterized,
		//	i.e., the ray is of the form start + t * direction, where t is
		//	the parameter.  For any given direction (i.e. X, Y, or Z),
		//	the amount that t changes as the ray crosses to the next cell
		//	in the same direction is fixed.  Calculate what that change in
		//	t is and store the information.  We're going to use this 
		//	information to help us traverse the Fujimoto grid.

	    tDelta[i] = (abs(direction[i]) == (Real) 0.0) ? 0.0 : scale / abs(direction[i]);
	
		//	Note the sign of the direction vector of the ray.

		increment[i] = SGN(direction[i]);
		limit[i] = (increment[i] < 0) ? -1 : numCells[i];

		//	Make a note of what the value of the ray parameter t will
		//	be when we cross over the next orthogonal plane in this 
		//	direction.  (Of course, if the direction vector has no 
		//	component in this direction, then we'll _never_ reach the 
		//	next grid cell in this direction.)

		if (increment[i] == 0)
			tMax[i] = HUGE_VAL;
		else if (increment[i] == 1)
			tMax[i] = tRay + tDelta[i] * (cell[i] + 1 - fujiPoint[i]);
		else
		{
			//	The the grid point is integral, i.e. if it lies exactly on
			//	one of the orthogonal planes, then the next movement will
			//	cross the entire cell.
		
			if (fujiPoint[i] == floor(fujiPoint[i]))
				tMax[i] = tRay + tDelta[i]; 
			else
				tMax[i] = tRay + tDelta[i] * 
					(fujiPoint[i] - floor(fujiPoint[i]));
		}
	}
	
	return(true);
}


#pragma mark -
// --- Intersection methods --------------------------------------------------


Bool Grid::IntersectionExists(Point& start, Point& end)
{
	Vector	direction = end - start;
	Vector  reflectPoint;
	Real	t;
	Int		increment[3], limit[3];	
	Real	tRay;
	Vector	tDelta, tMax;
	Int		nextCellDir,  nextEntry;
	Int		cell[3];
	Int		entry;
	Real	normDotDirection;
	RTTri*	thisTri;
	
	RTTri::gStamp++;

	//	Figure out grid parameters, and return if we completely miss it.

	if (!FindGridStart(start, direction, cell, increment, limit, tRay, tDelta, tMax))
		return(false);
		    
	//	Traverse the grid...

	for (;;)
	{
		//	We have to check all the triangles within this cell, since they
		//	are in no particular order with respect to the ray.  (In other
		//	words, we're essentially doing a bucket sort, and we're currently
		//	in one of the buckets.)

		entry = grid[cell[0] * xSpan + cell[1] * ySpan + cell[2]];

		for (; entry; entry = triEntries[entry].next)
		{			
			//	Find ray intersection with tri's plane. Bail if there isn't one.

			thisTri = triEntries[entry].tri;

			if (!thisTri->TriPlaneIntersection(start, direction, t))
				continue;
			
			//	Bail if the intersection occurs before 'start'
			
			if (t <= 0.000001 || t >= 0.99999)
				continue;

			reflectPoint = start + t * direction;

			//	Okay, let's do the actual test. If we've hit the tri itself,
			//	we can return.
		
			if (!thisTri->IsStamped())
				thisTri->FindBaryCoords(reflectPoint);
			
			if (thisTri->IsTrue(TRI_HIT))
			{
				gLastTri = triEntries[entry].tri;
				return(true);
			}
		}	

		//	Otherwise, let's move on to the next cell, if there is one.
		//	We are keeping track of what the t parameter value will be
		//	when we cross over the next orthogonal plane in the grid in
		//	each direction.  We can tell which cell we will be 
		//	traversing into by which direction requires the smallest
		// "additional t" for the changeover to the next cell in that
		//	direction to occur.
		//	Update our records, i.e. what the current cell is and
		//	how much "additional t" it's going to take to move to
		//	the next cell in this direction.

		nextCellDir = MinEltIndex(tMax);
		cell[nextCellDir] += increment[nextCellDir];

		//	If we've exited the grid, then bail -- we didn't find any
		//	intersections.

		if (cell[nextCellDir] == limit[nextCellDir])
			return(false);
		else
			tMax[nextCellDir] += tDelta[nextCellDir];
	}
}

Bool Grid::FirstIntersection(
	Point&		start,
	Vector&		direction,
	Point&		place,
	RTTri*&		tri,
	Void*		orig
	)
//	Finds the first intersection along the given ray. Ignores intersections with orig, if it is not
//	nil.
{
	Vector	reflectPoint;
	Int		increment[3],  limit[3];	
	Real	tRay, t, minT, tRayLast;
	Vector	tDelta, tMax;
	Int		i, nextEntry;
	Int		nextCellDir;
	Int		cell[3], reflectCell[3];
	Int		entry;
	Vector	baryCoords;
	Bool	foundPoly = false;
	Real	normDotDirection;
	RTTri*	thisTri;
		
	RTTri::gStamp++;
		
	//	Figure out grid parameters, and return if we completely miss its bounding box.

	if (!FindGridStart(start, direction, cell, increment, limit, tRay, tDelta, tMax))
		return(false);
	
	//	Traverse the grid, keeping track of the closest intersection found so far.

	for (;;)
	{
		//	We have to check all the triangles within this cell, since they
		//	are in no particular order with respect to the ray.  (In other
		//	words, we're essentially doing a bucket sort, and we're currently
		//	in one of the buckets.)

		foundPoly = false;
		entry = grid[cell[0] * xSpan + cell[1] * ySpan + cell[2]];

		nextCellDir = MinEltIndex(tMax);	// next cell after this...
		tMax[nextCellDir] += tDelta[nextCellDir];
		tRayLast = tRay;
		tRay = tMax[nextCellDir];			// t at which we leave this cell
		minT = tRay;						// don't count anything we hit after that
		
		for (; entry; entry = triEntries[entry].next)
		{
			thisTri = triEntries[entry].tri;
			
			if (thisTri->data == orig)
				continue;
						
			//	Find ray intersection with tri's plane. Bail if there isn't one.

			if (!triEntries[entry].tri->TriPlaneIntersection(start, direction, t))
				continue;
			
			//	Bail if it occurs before start, or after minT
						
			if (t <= 1e-6 || t >= minT - 1e-6)
				continue;

			reflectPoint = start + t * direction;
						
			//	Okay, let's do the actual test. If we've hit the tri itself,
			//	we can return a hit after we've finished this voxel.
		
			if (!thisTri->IsStamped())
				thisTri->FindBaryCoords(reflectPoint);
			
			if (thisTri->IsTrue(TRI_HIT))
			{
				minT = t;		
				place = reflectPoint;
				tri = thisTri;	
				foundPoly = true;	
			}
		}	

		if (foundPoly)
			return(true);

		cell[nextCellDir] += increment[nextCellDir];

		//	If we've exited the grid, then bail--we didn't find any
		//	intersections.

		if (cell[nextCellDir] == limit[nextCellDir])
			return(false);
	}
}


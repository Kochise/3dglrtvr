/*
	File:			MatDisplay.h

	Function:		Routines to display a radiosity matrix in a pane.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __MatDisplay__
#define __MatDisplay__

#include "Renderer.h"
#include "Geometry.h"
#include "RadPoly.h"


class MatrixDisplay : public RadPoly
{
public:
	MatrixDisplay(Void **method) : RadPoly(), method(method) {};
	MatrixDisplay(const MatrixDisplay &md) : RadPoly(md), method(md.method) {};

	Void					*UpCast() { return((RadPrim *) this); };		
	Object		 			*Clone() const { return new MatrixDisplay(SELF); };

	Void					Draw(Renderer &r, Context *context);
	Char 					*Label() const;

	Void					**method;
};

#endif

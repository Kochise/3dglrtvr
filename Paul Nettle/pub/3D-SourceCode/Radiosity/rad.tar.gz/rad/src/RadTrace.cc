/*
	File:		Gather.cc
	
	Function:	Implements a 'final gather' stage for radiosity.
	
*/

#include "RadTrace.h"
#include "RadPoly.h"
#include "CircleSamples.h"
#include "VecUtil.h"
#include "SceneObjects.h"

static Int gCurrentTable;

#ifdef VL_ROW_ORIENT
#error not_implemented
#endif

static Colour FindDiffuseColour(scScenePtr scene, Point &p, Vector &normal)
{
	Vector		uAxis, vAxis;
	Vector		sDir, dir;
	GCLReal		r, s, t, u;
	Int			i, n;
	Colour		result;
	Point		q, start;
	scPrimitive	*hitObject;
	
	n = kNumCircleSamples;	
	r = 0.96;
	result.MakeZero();
	start = p;
	
	// Construct coordinate system
	
	uAxis = norm(FindOrthoVector(normal));	
	vAxis = cross(normal, uAxis);
	
	// Sample over the cone
	
	for (i = 0; i < n; i++)
	{
		s = kCircleSamples[gCurrentTable][i][0] * r;
		t = kCircleSamples[gCurrentTable][i][1] * r;
		u = 1 - sqr(s) - sqr(t);
			
		if (u < 0)
		{
			u = 0;
			cerr << "u error: " << s << " " << t << sqrt(1-u) << endl;
		}
		else
			u = sqrt(u);
			
		dir = s * uAxis + t * vAxis + u * normal;

		if (hitObject = RadCast(scene)->ClosestIntersection(p, dir, q))
		{
			RadPoly *poly = ((RadPoly*) RadCast(hitObject));

			if (poly->elem)
			{
				Coord c = poly->FindCoord(q);	// YYY
				result += poly->Sample(c[0], c[1]) - poly->elem->Emittance();
			}
			else
				result += cRed;
		}
	}
	
	if (++gCurrentTable >= kNumCSArrays)
		gCurrentTable = 0;

	result /= n;

	return(result);
}

static Colour GatherColour(
		scScenePtr	scene,
		Point		&p,
		Vector		&normal,
		Colour		&reflectance,
		PatchList	&polys
	)
{
	Coord	c;
	Int		i, j, n;
	Colour	result, sum;
	GCLReal	factor, sampleFactor = polys[0]->props->options->sampleFactor;
	Vector	dx, dy, dst;
	
	result.MakeZero();
		
	for (j = 0; j < polys.NumItems(); j++)
	{
		// Calculate # of samples to assign to this patch...
		
		factor = polys[j]->ApproxPatchFactor(p, normal);
		n = sampleFactor * factor;
				
		if (n <= 0)
			continue;
			
		// Sample it...
		
		dx = polys[j]->Vertex(0);
		dy = polys[j]->Vertex(1);
		dy -= dx;
		dx = polys[j]->Vertex(3) - dx;
		
		sum.MakeZero();
		
		for (i = 0; i < n; i++)
		{
			c[0] = drand48();
			c[1] = drand48();
			dst = polys[j]->Vertex(0) + dx * c[0] + dy * c[1];	// XXX need a PointFromCoord method; this is quad-spec

			if (!RadCast(scene)->IntersectsWithRay(p, dst))
			{
				c[0] = 2 * c[0] - 1;
				c[1] = -2 * c[1] + 1;
				sum += polys[j]->Sample(c);
			}
		}
		
		result += sum * factor / GCLReal(n) ;
	}
	
	return(result * reflectance);
}

Void FinalGather(scScenePtr scene, Image &image, RadOptions &options)
{
	scPrimitive 	*hitObject;
	Transform		inverseTransform;
	GCLReal			x, y, wx, wy;
	Int				i, j, k;
	GCLReal			save;
	Point			p;
	PatchList		polys;
	PatchList		lights;
	scCamera		*cam;
	
	save = options.patchSubdivs;
	options.patchSubdivs = 0.0;
	polys.Clear();
	RadCast(scene)->CreatePatches(polys);
	options.patchSubdivs = save;

	
	cout << "final gather on scene with weighting of " << options.sampleFactor << endl;
	
	// Find the camera in the scene...
	
	cam = (scCamera*) scene->FindFirst(aCamera);
//	cam = 0; // YYY
	Assert(cam != 0, "No camera in scene.");
		
	// Set up mapping matrix
	
	inverseTransform = inv(cam->ProjMatrix() * cam->ModelMatrix());
	wy = 2.0 / image.Height();
	y = -1 + wy / 2.0;
	
	image.Clear(cBlack);

	for (i = 0; i < image.Height(); i++)
	{
		wx = 2.0 / image.Width();
		x = -1 + wx / 2.0;
		
		cout << "row " << i << "/" << image.Height() << "\r" << flush;
		
		for (j = 0; j < image.Width(); j++)
		{
			Vec4d	eyePoint(x, y, -1, 1);
			Vec4d	target(x, y, 1, 1);	
			Vector	pEye, pTarget;
			
			eyePoint = inverseTransform * eyePoint;
			target = inverseTransform * target;
			pEye = proj(eyePoint);
			pTarget = proj(target);
			
			hitObject = RadCast(scene)->ClosestIntersection(pEye, norm(pTarget - pEye), p);
			
			if (hitObject)
			{
				RadPoly *poly = ((RadPoly*) RadCast(hitObject));
	
				if (poly->elem)
				{
					Colour pixClr;
	
					pixClr = poly->elem->Emittance();

					
					pixClr += GatherColour(scene, p, poly->elem->Normal(),
						poly->elem->Reflectance(),
						polys);						


					ClipColour(pixClr);
					image.SetPixel(j, i, pixClr);
				}
				else
					image.SetPixel(j, i, cRed);
			}
			else
				image.SetPixel(j, i, cBlue);
		
			x += wx;
		}

		y += wy;
	}
	cout << endl;
}

Void RayCastScene(scScenePtr scene, Image &image)
// Ray-trace scene...
{
	scPrimitive 	*hitObject;
	Transform		inverseTransform;
	GCLReal			x, y, wx, wy;
	Int				i, j;
	Point			p;
	scCamera		*cam;

	// Find the camera in the scene...
	
	cam = (scCamera*) scene->FindFirst(aCamera);
//	cam = 0; // YYY
	Assert(cam != 0, "No camera in scene.");
		
	// Set up mapping matrix
	
	inverseTransform = inv(cam->ProjMatrix() * cam->ModelMatrix());
	wy = 2.0 / image.Height();
	y = -1 + wy / 2.0;
	image.Clear(cBlack);

	for (i = 0; i < image.Height(); i++)
	{
		wx = 2.0 / image.Width();
		x = -1 + wx / 2.0;
		
		cout << "row " << i << "/" << image.Height() << "\r" << flush;
		
		for (j = 0; j < image.Width(); j++)
		{
			Vec4d	eyePoint(x, y, -1, 1);
			Vec4d	target(x, y, 1, 1);	
			Vector	pEye, pTarget;
			
			eyePoint = inverseTransform * eyePoint;
			target = inverseTransform * target;
			pEye = proj(eyePoint);
			pTarget = proj(target);
			
			hitObject = RadCast(scene)->ClosestIntersection(pEye, norm(pTarget - pEye), p);
			
			if (hitObject)
			{
				RadPoly *poly = ((RadPoly*) RadCast(hitObject));
	
				if (poly->elem)
				{
					Colour	pixClr;
					Coord	c = poly->FindCoord(p);

					pixClr = poly->Sample(c[0], c[1]);
					ClipColour(pixClr);
					image.SetPixel(j, i, pixClr);
				}
				else
					image.SetPixel(j, i, cRed);
			}
			else
				image.SetPixel(j, i, cBlue);
		
			x += wx;
		}

		y += wy;
	}
}


/*
	File:			AnaRad.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "AnaRad.h"
#include "AnaMesh.h"


Bool AnaRad::Render()
//	Returns true if no interruptions.
{
	Int			i, j;
	Colour		patchCol;
	GCLReal		save;
	Point		p;
	Vector		n;
	PatchList	lights;

	RadMethod::Render();
	 
	if (options.visibility == vis_none)
	{
		save = options.patchSubdivs;
		options.patchSubdivs = 0;
		polys.Clear();
		RadCast(scene)->CreatePatches(polys);
		options.patchSubdivs = save;
	
		for (j = 0; j < polys.NumItems(); j++)
			if (len(polys[j]->Emittance()) > 0)	// A light!
				lights.Append(polys[j]);
	}
	
	options.jitterRot = false;

	Stage(1);

	for (i = 0; i < patches.NumItems(); i++)
	{
		p = patches[i]->Centre();
		n = patches[i]->Normal();
		
		patchCol = cBlack;

		if (options.visibility == vis_none)
		{
			for (j = 0; j < lights.NumItems(); j++)	
				patchCol += (lights[j]->PatchFactor(p, n) * 
					lights[j]->Emittance() *
					lights[j]->Visibility(patches[i]));
		}
		else
		{
			for (j = 0; j < patches.NumItems(); j++)	
				patchCol += (patches[j]->PatchFactor(p, n) * 
					patches[j]->Emittance() *
					patches[j]->Visibility(patches[i]));
		}	

		patches[i]->SetColour(patches[i]->Emittance() + 
			patches[i]->Reflectance() * patchCol);
	}
	
	Stage(2);
	
	return(0);
}

RadQuad *AnaRad::NewMesh()
{
	return(new GridAnaQuad);
}


Void AnaRad::DumpStats()
{
	cout << dumpID
		<< ' ' << options.totTime
		<< ' ' << options.stage
		<< ' ' << options.numPatches
		<< ' ' << patches.NumItems()
		<< ' ' << options.rays
		<< endl;

	DumpScene();
}

Int AnaRad::Stage(Int stage)
{
	if (CheckTime()) return(1);

	options.stage = stage;

	switch (stage)
	{
	case 1:		// pre setup
		cout << "method ana " << endl;
		cout << "sub " << options.patchSubdivs << endl;
		cout << "scene " << scene->Label() << endl;
		cout << "format ID time stage illumPatches patches rays" << endl; 
		cout << "----------------------------------------------" << endl;
	
		options.rays = 0;
		options.totTime = 0;
		options.pfTime = 0;
		options.visTime = 0;
		options.drawTime = 0;
		options.solveTime = 0;
		lastTime = 0;
		DumpStats();
		break;

	case 2:
		DumpStats();
		break;
				
	default:
		break;
	}

	if (Idle()) return(0);
	ContTimer();	
	return(0);
}



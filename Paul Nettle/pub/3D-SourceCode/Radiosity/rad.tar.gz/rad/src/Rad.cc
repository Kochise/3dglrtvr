/*
	File:			Rad.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "Rad.h"
#include "fstream.h"
#include "String.h"
#include <stdio.h>


// --- Base radiosity method class ------------------------------


RadMethod::RadMethod(RadOptions &theOptions, Renderer *displayP, GraphicsSystem *gsP) : 
		options(theOptions), displayP(displayP), gsP(gsP)
{
	options.radObject = this;
	options.display = displayP;
}

RadMethod::~RadMethod()
{
	delete scene;
}


Void RadMethod::SetScene(scScenePtr theScene)
{
	// We apply the transforms in the scene tree to all points 
	// (no twiddling avars after this), and create the radiosity
	// mesh. We also throw in an initial smooth.

	// Make a copy of the scene, and apply transformations to all points
	// in the scene. (No avar twiddling after this.)
	scene = Clone(theScene);
	options.scene = scene;	
	RadCast(scene)->ApplyTransforms();
//	RadCast(scene)->MakeQuadTri(); YYY

	// Initialise meshes & smooth.
	RadCast(scene)->InitRad(options);
	RadCast(scene)->Smooth();

	patches.Clear();
	stats.Init();	
	RadCast(scene)->CreatePatches(patches, &stats);

}

Bool RadMethod::Render()
{
	options.pfTime = 0;
	options.visTime = 0;
	options.totTime = 0;
	dumpID = 0;
	
	//	Set limit below which entries in the form-factor matrix get clamped to
	//	zero.	
	
	StartTimer();	// Initialise, then suspend timer.
	StopTimer();
	
	((RadGroup*) RadCast(scene))->CreateGrid();
	
	return(1);
}

Int RadMethod::Stage(Int stage)
{
	return(0);
}

Bool RadMethod::Idle()
{
		return(false);
}

Bool RadMethod::Pause()
{
		return(false);
}

Void RadMethod::DrawMatrix(Renderer &r)
{
	Expect(false, "Radiosity method has no draw matrix method.");
}

Void RadMethod::RenderMatrix(Renderer &r)
{
	r.Clear();
	DrawMatrix(r);
	r.Show(); 
}

Void RadMethod::DumpScene()
{
	ofstream	outFile;
	char		filename[64];

	if (dumpID != 0)	// don't bother with first one.
	{
		sprintf(filename, "%s.%02d.sl", options.outFile, dumpID);

		outFile.open(filename);
		if (outFile)
			scene->HierPrint(outFile, 0);
		outFile.close();
	}
	
	dumpID++;
}

Void RadMethod::DumpStats()
{
	Assert(false, "Must override!");
}

Bool RadMethod::CheckTime()
{
	StopTimer();
	options.totTime = GetTimer();

	if (options.totTime > options.limitTime)
	{
		DumpStats();
		return(1);
	}

	if (options.totTime - lastTime >= options.sliceTime)
	{
		while (options.totTime - lastTime >= options.sliceTime)
			lastTime += options.sliceTime;

		DumpStats();
	}
	return(0);
}

#define RAD_TLD
Bool RadMethod::Update()
{
	return(true); 
}

Void RadMethod::StartUpdate()
{
	StartTimer();
	nextUpdate = 0.0;
}

#include "AnaRad.h"
#include "MatRad.h"
#include "ProgRad.h"
#include "HProgRad.h"
#include "HierRad.h"

RadMethod *RadMethod::NewRadMethod(RadOptions &theOptions,
			 Renderer *displayP, GraphicsSystem *gsP)
{
	switch (theOptions.method)
	{
	case kOverrelaxation:			
		return(new MatRad(theOptions, displayP, gsP));
	case kConjugateGradient:			
		return(new MatRad(theOptions, displayP, gsP));
	case kProgressive:			
		return(new ProgRad(theOptions, displayP, gsP));
	case kProgPlus:			
		return(new HProgRad(theOptions, displayP, gsP));
	case kHierarchical:			
		return(new HierRad(theOptions, displayP, gsP));
	case kAnalytical:			
		return(new AnaRad(theOptions, displayP, gsP));
	default:
		cerr << "warning: unrecognized radiosity method" << endl;
	}

	return(0);
}

#include "RadPane.h"
#include "RadPoly.h"


Void FormsScenePane::SetParent(Form *newParent)
{
	parent = newParent;
}


#pragma mark -
// --- RadScenePane class ------------------------------------


RadScenePane::RadScenePane(Bool doubleBuf) : FormsScenePane(doubleBuf)
{
	selPatch[0] = 0;
	selPatch[1] = 0;
}

Void RadScenePane::SetScene(scScenePtr scene)
{
	selPatch[0] = 0;
	selPatch[1] = 0;

	ScenePane::SetScene(scene);
}

/*
	'ScenePane::Pick' maps from display coords ([-1, 1], [-1, 1]) to
	a ray through the screen. We assume our world-to-screen matrix
	maps from some form of view pyramid to the box from -1 to 1 in all
	dimensions. 
		
	Note that this works regardless of whether a perspective or orthogonal
	projection is used.
*/

Void RadScenePane::Pick(GCLReal x, GCLReal y, Int which, Int levelsUp)
{
	scPrimitive 	*pickedObject;
	Point 			p, pEye;
	Coord 			coord;
	Int				i;
	
	x = 2 * (x - 0.5);
	y = 2 * (0.5 - y);

	Vec4d eyePoint(x, y, -1, 1);
	Vec4d target(x, y, 1, 1);	

	eyePoint = inverseTransform * eyePoint;
	target = inverseTransform * target;
	
	Redraw();
}


#pragma mark -
// --- MatrixScenePane -----------------------------------------------


MatrixScenePane::MatrixScenePane(Bool doubleBuf) : FormsScenePane(doubleBuf)
{
}


Void MatrixScenePane::SetScene(scScenePtr scene)
{
	ScenePane::SetScene(scene);
}

Void MatrixScenePane::Pick(GCLReal x, GCLReal y, Int which, Int levelsUp)
{
	scPrimitive 	*pickedObject;
	Point 			p;
	Coord 			coord;
	Int				i;
	
	x = 2 * (x - 0.5);
	y = 2 * (0.5 - y);

	Vec4d eyePoint(x, y, -1, 1);
	Vec4d target(x, y, 1, 1);	

	eyePoint = inverseTransform * eyePoint;
	target = inverseTransform * target;

}

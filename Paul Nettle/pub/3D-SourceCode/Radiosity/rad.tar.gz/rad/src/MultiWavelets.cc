/*
	File:			MultiWavelets.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			
			
					Sample Coord system:
							 t
					  0 +----^----+ 3
						|	 |	  |
						|	 |	  |
						+----0----> s
						|	 |	  |
						|	 |	  |
					  1 +---------+ 2
					
					Or
					t
					^
					|\
					| \
					|  \
					|   \
					O----+> s
					
*/

#include "MultiWavelets.h"
#include "WaveCoeffs.h"

#define RAD_USE_SO 

#define M2Child(x) ((M2Quad *) child[x])
#define M2Cast(x) ((M2Quad *) x)


// --- M2Link methods ---------------------------------------------------

Bool M2Link::useCC;

Void M2Link::CalcTransport()
//	Calculate M2 transport coefficients.
{
	Matd	T(M2Cast(to)->Coeffs(), M2Cast(from)->Coeffs(), transport);
	Matd	K;
	GCLReal	*visPtr = 0;
	
	if (to->props->options->visInQuad) 
	{
		visibility = 0.0;
		visPtr = &visibility;
	}
	
	factor = CalcKernel(K, visPtr);
		
	// Calculate the transport coefficients by performing quadrature
	// on the kernel samples using the appropriate R and S matrices.

	Matd	D(K.Rows(), T.Cols());
	
	if (useCC)
		if (from->IsQuad()) 
			RightTensorMult(K, MCC2_S, D);
		else
			D = K * MCC2_Tri_S;
	else if (from->IsQuad()) 
		RightTensorMult(K, M2_S, D);
	else
		D = K * M2_Tri_S;
		
	if (to->IsQuad()) 
		LeftTensorMult(M2_R, D, T);
	else
		T = M2_Tri_R * D;

	if (!visPtr)
		T *= visibility;
}

// Oracle stuff...

GCLReal M2Link::OracleError(Matd &K)
// Implements the smoothness oracle of the original
// wavelet paper [Gort93].
{
	GCLReal *tx, *ty, dummy;
	Real t, err = 0.0;
	Matd	P;
	Int		i, j;
	
	if (to->IsQuad())
	{
		P = M2_E * K;
		tx = M2_Ex.Ref();
		ty = M2_Ey.Ref();
	}
	else
	{
		P = M2T_E * K;
		tx = M2T_Ex.Ref();
		ty = M2T_Ey.Ref();
	}

	if (from->IsQuad())
	{
		for (i = 0; i < 4; i++)
			for (j = 0; j < 4; j++)
			{
				t = from->SampleKernel(M2_Ex[i], M2_Ey[i], to, tx[j], ty[j], 0);
				err += abs(t - dot(M2_E[i], P[j])); 
			}
	}
	else
	{
		for (i = 0; i < 4; i++)
			for (j = 0; j < 4; j++)
			{
				t = from->SampleKernel(M2T_Ex[i], M2T_Ey[i], to, tx[j], ty[j], 0);
				err += abs(t - dot(M2T_E[i], P[j])); 
			}
	}
		
	return(err / 4.0);
}

GCLReal M2Link::CCOracleError(Matd &K)
// Implements a smoothness oracle for the CC rule.
// We simply take the flatlet panes at each corner
// as our sample points. Because R = I for flatlets,
// each of these samples corresponds precisely to a column
// of P, saving us a dot product for each sample pair.
{
	GCLReal *tx, *ty, dummy;
	Real t, err = 0.0;
	Matd	P;
	Int		h, i, j;
	

	if (to->IsQuad())
	{
		P = M2_E * K;
		tx = M2_Ex.Ref();
		ty = M2_Ey.Ref();
	}
	else
	{
		P = M2T_E * K;
		tx = M2T_Ex.Ref();
		ty = M2T_Ey.Ref();
	}

	for (h = 0; h < 2; h++)
		for (i = 0; i < 2; i++)
			for (j = 0; j < 4; j++)
			{
				t = from->EstSubFormFactor(h, i, to,
					tx[j], ty[j], 2, 0);
				err += abs(t - P[j][2 * h + i]);
			}
	
	return(err / 4.0);
}

GCLReal M2Link::CalcKernel(Matd &K, GCLReal *visPtr)
// Sample kernel at all combinations of Quad/Tri quadrature points.
{
	GCLReal	t, error = 0.0;
	GCLReal	*tx, *ty, *fx, *fy;
	Int		i, j, k, fn, tn;

	if (to->IsQuad())
	{ tx = M2_x.Ref(); ty = M2_y.Ref(); tn = M2_x.Elts(); }
	else
	{ tx = MT2_x.Ref(); ty = MT2_y.Ref(); tn = MT2_x.Elts(); }

	if (from->OrientInfo(to) == -1)
	{
		// Too close to use normal quadrature: swap to the CC
		// rule for stability.

		fn = 4;
		K.SetSize(tn, fn);
	
		for (i = 0; i < tn; i++)
			for (j = 0; j < 2; j++)
				for (k = 0; k < 2; k++)
			{
				t = from->EstSubFormFactor(j, k, to,
					tx[i], ty[i], 2, visPtr);
				if (error < t)
					error = t;
				K[i][k + 2 * j] = t;
			}
		useCC = true;
#ifdef RAD_USE_SO
		error = CCOracleError(K);
#else
		error /= M2Cast(from)->Coeffs();
#endif
	}
	else
	{
		if (from->IsQuad())
		{ fx = M2_x.Ref(); fy = M2_y.Ref(); fn = M2_x.Elts(); }
		else
		{ fx = MT2_x.Ref(); fy = MT2_y.Ref(); fn = MT2_x.Elts(); }
	
		K.SetSize(tn, fn);
		
		for (i = 0; i < tn; i++)
			for (j = 0; j < fn; j++)
			{
				// XXX This is horribly inefficient: should be passing the
				// list of samples into the sample kernel routine, so it
				// can reuse axis calculations. Fix!
				t = from->SampleKernel(fx[j], fy[j], to, tx[i], ty[i], visPtr);
				if (error < t)
					error = t;
				K[i][j] = t;
			}
		useCC = false;
#ifdef RAD_USE_SO
		error = OracleError(K);
#else
		error /= M2Cast(from)->Coeffs();
#endif
	}

	if (visPtr)
		*visPtr /= (tn * fn);
	return(error); 
}

LinkNode *M2Link::CreateSubLink(HRQuad *fromPatch, HRQuad *toPatch)
{
	M2Link *result = new M2Link;

	result->visibility = visibility;
	result->Set(fromPatch, toPatch);

	return((LinkNode *) result);
}

Void M2Link::Set(HRQuad *fromPatch, HRQuad *toPatch)
{
	from = fromPatch;
	to = toPatch;
	factor = 0.0;
	
	if (NeedVisibility())
	{
		if (to->props->options->visInQuad)
		{
			// do trivial test; if there is some potential
			// visibility, we'll calculate it during quadrature.
			if (!from->PotentiallyVis(to))
				visibility = 0.0;
			else
				visibility = 0.5;
		}
		else
			visibility = from->Visibility(to);
	}
			
	CalcTransport();
}

Void M2Link::Gather()
{
	M2Quad *fto = M2Cast(to), *ffrom = M2Cast(from);
	MultAcc(Matd(fto->Coeffs(), ffrom->Coeffs(), transport), ffrom->B, fto->R);
}

GCLReal M2Link::Error()
{
	return(factor * visibility);
}

GCLReal M2Link::BFError()
{
	if (from->IsQuad())
		return(to->area * factor * dot(kRadRGBToLum, to->Reflectance() * M2Cast(from)->B[0]));
	else
		return(to->area * factor * dot(kRadRGBToLum, to->Reflectance() * Average(M2Cast(from)->B, 3)));
}

Void M2Link::Print(ostream &s)
{
	RadLink::Print(s);
	s << " transport = " << Matd(M2Cast(to)->Coeffs(), M2Cast(from)->Coeffs(), transport) << " vis = " << visibility;
}

Void M2Link::DrawLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom, GCLReal weight)
{
	DrawWaveLink(r, left, top, right, bottom, weight * to->Reflectance(), 
		Matd(Matd(M2Cast(to)->Coeffs(), M2Cast(from)->Coeffs(), transport)));
}

#pragma mark -
// --- M2Quad methods ----------------------------------------


Colour M2Quad::lastB[4];

Void M2Quad::Add()
{	
	for (int i = 0; i < Coeffs(); i++)
		B[i] += Reflectance() * R[i];
}
									
Void M2Quad::Push()
{
	if (IsTri())
	{
		Mult(M2_Tri_P0, B, M2Child(1)->B);
		Mult(M2_Tri_P1, B, M2Child(2)->B);
		Mult(M2_Tri_P2, B, M2Child(0)->B);
		Mult(M2_Tri_P3, B, M2Child(3)->B);
	}
	else
	{	
	/*
		Conceptually, this is just trans(T) * B * T: T interpolates rows, and trans(T)
		interpolates columns. We break up the multiplication because our destination matrix
		is not stored contigously.
	*/
		Colour t[4];

		RightTensorMult(M2_P0, B, t);
		LeftTensorMult(M2_P0, t, M2Child(0)->B);
		LeftTensorMult(M2_P1, t, M2Child(1)->B);
		RightTensorMult(M2_P1, B, t);
		LeftTensorMult(M2_P0, t, M2Child(3)->B);
		LeftTensorMult(M2_P1, t, M2Child(2)->B);
	}
}

Void M2Quad::Pull()
{
	if (IsTri())
	{
		// B = sum M2_Tri_L[i] * c[i].B
		Mult   (M2_Tri_L0, M2Child(1)->B, B);
		MultAcc(M2_Tri_L1, M2Child(2)->B, B);
		MultAcc(M2_Tri_L2, M2Child(0)->B, B);
		MultAcc(M2_Tri_L3, M2Child(3)->B, B);
	}
	else
	{
		Colour t[4];
		
		RightTensorMult(M2_L0, M2Child(0)->B, t);
		RightTensorMultAcc(M2_L1, M2Child(3)->B, t);
		LeftTensorMult(M2_L0, t, B);
		
		RightTensorMult(M2_L0, M2Child(1)->B, t);
		RightTensorMultAcc(M2_L1, M2Child(2)->B, t);
		LeftTensorMultAcc(M2_L1, t, B);
	}
}

Void M2Quad::Prepare()
{
	if (IsQuad())
	{
		for (int i = 0; i < 4; i++)
		{
			lastB[i] = B[i];
			B[i] = vl_0; 
		}
		B[0] = Emittance();	
	}
	else
		for (int i = 0; i < 3; i++)
		{
			lastB[i] = B[i];
			B[i] = Emittance();
		}
}

GCLReal M2Quad::Error()
{
	return(dot(kRadRGBToLum, B[0] - lastB[0]));
}

Void M2Quad::ClearR()
{
	for (int i = 0; i < Coeffs(); i++)
		R[i] = vl_0;
}


// --- The numerical code for M2s -----------------------------------------


Colour M2Quad::SampleLeaf(Coord &c)
{
	if (IsQuad())
		return(M2QuadSample(c, B));
	else
		return(M2TriSample(c, B));
}

Void M2Quad::DrawLeaf(Renderer &r)
{
	if (props->options->wire)
		RadQuad::Draw(r);
	else
	{
		Colour c0, c1, c2, c3;
		
		if (IsQuad())
		{
			c0 = B[0] - B[1] - B[2] + B[3];	// b + db/dx + db/dy + db2/dxdy
			c1 = B[0] - B[1] + B[2] - B[3];
			c2 = B[0] + B[1] + B[2] + B[3];
			c3 = B[0] + B[1] - B[2] - B[3];
		}
		else
		{
			c0 = B[2];
			c1 = B[0];
			c2 = B[1];
		}
		
		if (highlight)
		{
			DrawHighlight(r);
			if (!props->options->funcView)
				return;
		}
		
		if (props->options->funcView)
		{
			r.Begin(renLineLoop).C(cWhite);
			SendPoints(r);
			r.End();
			
			r.Begin(renPoly);
			Project(r, c0, Vertex(0));
			Project(r, c1, Vertex(1));
			Project(r, c2, Vertex(2));
			if (IsQuad())
				Project(r, c3, Vertex(3));
			r.End();
		}
		else
		{
			r.Begin(renPoly).C(c0).P(Vertex(0)).C(c1).P(Vertex(1)).C(c2).P(Vertex(2));
			if (IsQuad())
				r.C(c3).P(Vertex(3));
			r.End();
		}
	}
}

Void M2Quad::Print(ostream &s)
{
	s << " + m2 ";
	PrintRec(s);
}

Void M2Quad::PrintSelf(ostream &s)
{
	HRQuad::PrintSelf(s);
	for (int i = 0; i < Coeffs(); i++)
		s << B[i] << ' ';
}

Void M2Quad::ParseSelf(istream &s)
{
	HRQuad::ParseSelf(s);
	for (int i = 0; i < Coeffs(); i++)
		s >> B[i];
}

Void M2Quad::SetParent(HierQuad &itsParent)
{
	HierQuad::SetParent(itsParent);

	if (itsParent.child[3] == this)
		((HRQuad &) itsParent).Push();
}


#pragma mark -
// --- M3 Classes ---------------------------------

#define M3Child(x) ((M3Quad *) child[x])
#define M3Cast(x) ((M3Quad *) x)

Bool M3Link::useCC;

// --- M3Link methods -----------------

Void M3Link::CalcTransport()
//	Calculate M3 transport coefficients.
{
	Matd	T(M3Cast(to)->Coeffs(), M3Cast(from)->Coeffs(), transport);
	Matd	K;
	GCLReal	*visPtr = 0;
	
	if (to->props->options->visInQuad) 
	{
		visibility = 0.0;
		visPtr = &visibility;
	}
	
	factor = CalcKernel(K, visPtr);
		
	// Calculate the transport coefficients by performing quadrature
	// on the kernel samples using the appropriate R and S matrices.

	Matd	D(K.Rows(), T.Cols());	

	if (useCC)
		if (from->IsQuad()) 
			RightTensorMult(K, MCC3_S, D);
		else
			D = K * MCC3_Tri_S;
	else if (from->IsQuad()) 
		RightTensorMult(K, M3_S, D);
	else
		D = K * M3_Tri_S;
		
	if (to->IsQuad()) 
		LeftTensorMult(M3_R, D, T);
	else
		T = M3_Tri_R * D;
		
	if (!visPtr)
		T *= visibility;
}

// Oracle stuff...

GCLReal M3Link::OracleError(Matd &K)
// Implements the smoothness oracle of the original
// wavelet paper [Gort93].
{
	GCLReal *tx, *ty, dummy;
	Real t, err = 0.0;
	Matd	P;
	Int		i, j;

	
	if (to->IsQuad())
	{
		P = M3_E * K;
		tx = M3_Ex.Ref();
		ty = M3_Ey.Ref();
	}
	else
	{
		P = M3T_E * K;
		tx = M3T_Ex.Ref();
		ty = M3T_Ey.Ref();
	}

	if (from->IsQuad())
	{
		for (i = 0; i < 4; i++)
			for (j = 0; j < 4; j++)
			{
				t = from->SampleKernel(M3_Ex[i], M3_Ey[i], to, tx[j], ty[j], 0);
				err += abs(t - dot(M3_E[i], P[j])); 
			}
	}
	else
	{
		for (i = 0; i < 4; i++)
			for (j = 0; j < 4; j++)
			{
				t = from->SampleKernel(M3T_Ex[i], M3T_Ey[i], to, tx[j], ty[j], 0);
				err += abs(t - dot(M3T_E[i], P[j])); 
			}
	}
		
	return(err / 4.0);
}

GCLReal M3Link::CCOracleError(Matd &K)
// Implements a smoothness oracle for the CC rule.
{
	GCLReal *tx, *ty, dummy;
	Real t, err = 0.0;
	Matd	P;
	Int		h, i, j;
	
	if (to->IsQuad())
	{
		P = M3_E * K;
		tx = M3_Ex.Ref();
		ty = M3_Ey.Ref();
	}
	else
	{
		P = M3T_E * K;
		tx = M3T_Ex.Ref();
		ty = M3T_Ey.Ref();
	}

	for (h = 0; h < 2; h++)
		for (i = 0; i < 2; i++)
			for (j = 0; j < 4; j++)
			{
				t = from->EstSubFormFactor(h, i, to,
					tx[j], ty[j], 3, 0);
				err += abs(t - P[j][h * 6 + i * 2]);
			}
		
	return(err / 4.0);
}

GCLReal M3Link::CalcKernel(Matd &K, GCLReal *visPtr)
// Sample kernel at all combinations of Quad/Tri quadrature points.
{
	GCLReal	t, error = 0.0;
	GCLReal	*tx, *ty, *fx, *fy;
	Int		i, j, k, fn, tn;

	if (to->IsQuad())
	{ tx = M3_x.Ref(); ty = M3_y.Ref(); tn = M3_x.Elts(); }
	else
	{ tx = MT3_x.Ref(); ty = MT3_y.Ref(); tn = MT3_x.Elts(); }

	if (from->OrientInfo(to) == -1)
	{
		// Too close to use normal quadrature: swap to the CC
		// rule for stability.

		fn = 9;
		K.SetSize(tn, fn);
	
		for (i = 0; i < tn; i++)
			for (j = 0; j < 3; j++)
				for (k = 0; k < 3; k++)
			{
				t = from->EstSubFormFactor(j, k, to,
					tx[i], ty[i], 3, visPtr);
				if (error < t)
					error = t;
				K[i][k + 3 * j] = t;
			}
		useCC = true;
#ifdef RAD_USE_SO
		error = CCOracleError(K);
#else
		error /= M3Cast(from)->Coeffs();
#endif
	}
	else
	{
		if (from->IsQuad())
		{ fx = M3_x.Ref(); fy = M3_y.Ref(); fn = M3_x.Elts(); }
		else
		{ fx = MT3_x.Ref(); fy = MT3_y.Ref(); fn = MT3_x.Elts(); }
	
		K.SetSize(tn, fn);
		
		for (i = 0; i < tn; i++)
			for (j = 0; j < fn; j++)
			{
				t = from->SampleKernel(fx[j], fy[j], to, tx[i], ty[i], visPtr);
				if (error < t)
					error = t;
				K[i][j] = t;
			}
		useCC = false;
#ifdef RAD_USE_SO
		error = OracleError(K);
#else
		error /= M3Cast(from)->Coeffs();
#endif
	}
	
	if (visPtr)
		*visPtr /= (tn * fn);
	return(error);
}

LinkNode *M3Link::CreateSubLink(HRQuad *fromPatch, HRQuad *toPatch)
{
	M3Link *result = new M3Link;
		
	result->visibility = visibility;
	result->Set(fromPatch, toPatch);	
		
	return((LinkNode *) result);
}

Void M3Link::Set(HRQuad *fromPatch, HRQuad *toPatch)
{
	from = fromPatch;
	to = toPatch;
	factor = 0.0;
	
	if (NeedVisibility())
	{
		if (to->props->options->visInQuad)
		{
			// do trivial test; if there is some potential
			// visibility, we'll calculate it during quadrature.
			if (!from->PotentiallyVis(to))
				visibility = 0.0;
			else
				visibility = 0.5;
		}
		else
			visibility = from->Visibility(to);
	}
			
	CalcTransport();
}

Void M3Link::Gather()
{
	M3Quad *fto = M3Cast(to), *ffrom = M3Cast(from);
	MultAcc(Matd(fto->Coeffs(), ffrom->Coeffs(), transport), ffrom->B, fto->R);
}

GCLReal M3Link::Error()
{
	return(factor * visibility);
}

GCLReal M3Link::BFError()
{
	return(to->area * factor * dot(kRadRGBToLum, to->Reflectance() * M3Cast(from)->B[0][0]));
}

Void M3Link::Print(ostream &s)
{
	RadLink::Print(s);
	s << " transport = " << Matd(M3Cast(to)->Coeffs(), M3Cast(from)->Coeffs(), transport) << " vis = " << visibility;
}

Void M3Link::DrawLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom, GCLReal weight)
{
	DrawWaveLink(r, left, top, right, bottom, weight * M3Cast(to)->Reflectance(), 
		Matd(Matd(M3Cast(to)->Coeffs(), M3Cast(from)->Coeffs(), transport)));
}

#pragma mark -
// --- M3Quad methods ----------------------------------------


Colour M3Quad::lastB[9];

Void M3Quad::Add()
{	
	for (int i = 0; i < Coeffs(); i++)
		B[i] += Reflectance() * R[i];
}

Void M3Quad::Push()
{
	if (IsTri())
	{
		Mult(M3_Tri_P0, B, M3Child(1)->B);
		Mult(M3_Tri_P1, B, M3Child(2)->B);
		Mult(M3_Tri_P2, B, M3Child(0)->B);
		Mult(M3_Tri_P3, B, M3Child(3)->B);
	}
	else
	{	
		Colour t[9];

		RightTensorMult(M3_P0, B, t);
		LeftTensorMult(M3_P0, t, M3Child(0)->B);
		LeftTensorMult(M3_P1, t, M3Child(1)->B);
		RightTensorMult(M3_P1, B, t);
		LeftTensorMult(M3_P0, t, M3Child(3)->B);
		LeftTensorMult(M3_P1, t, M3Child(2)->B);
	}
}

Void M3Quad::Pull()
{
	if (IsTri())
	{
		Mult(M3_Tri_L0, M3Child(1)->B, B);
		MultAcc(M3_Tri_L1, M3Child(2)->B, B);
		MultAcc(M3_Tri_L2, M3Child(0)->B, B);
		MultAcc(M3_Tri_L3, M3Child(3)->B, B);
	}
	else
	{
		Colour t[9];
		
		RightTensorMult(M3_L0, M3Child(0)->B, t);
		RightTensorMultAcc(M3_L1, M3Child(3)->B, t);
		LeftTensorMult(M3_L0, t, B);
		
		RightTensorMult(M3_L0, M3Child(1)->B, t);
		RightTensorMultAcc(M3_L1, M3Child(2)->B, t);
		LeftTensorMultAcc(M3_L1, t, B);
	}
}

Void M3Quad::Prepare()
{
	if (IsQuad())
	{
		for (int i = 0; i < 9; i++)
		{
			lastB[i] = B[i];
			B[i] = vl_0; 
		}
		B[0] = Emittance();
	}
	else
		for (int i = 0; i < 6; i++)
		{
			lastB[i] = B[i];
			B[i] = Emittance();
		}
}

GCLReal M3Quad::Error()
{
	return(dot(kRadRGBToLum, B[0] - lastB[0]));
}

Void M3Quad::ClearR()
{
	for (int i = 0; i < Coeffs(); i++)
		R[i] = vl_0;
}


// --- The numerical code for M3s -----------------------------------------


Colour M3Quad::SampleLeaf(Coord &c)
{
	if (IsQuad())
		return(M3QuadSample(c, B));
	else
		return(M3TriSample(c, B));
}

Void M3Quad::DrawLeaf(Renderer &r)
{
	if (props->options->wire)
		RadQuad::Draw(r);
	else
	{
		Bool project = props->options->funcView;
		
		if (project)
		{
			r.Begin(renLineLoop).C(cWhite);
			SendPoints(r);
			r.End();
		}
		if (highlight)
		{
			DrawHighlight(r);
			if (!project)
				return;
		}
	
		DrawSampledLeaf(r, 4);
	}
}

Void M3Quad::Print(ostream &s)
{
	s << " + m3 ";
	PrintRec(s);
}

Void M3Quad::PrintSelf(ostream &s)
{
	HRQuad::PrintSelf(s);
	for (int i = 0; i < Coeffs(); i++)
		s << B[i] << ' ';
}

Void M3Quad::ParseSelf(istream &s)
{
	HRQuad::ParseSelf(s);
	for (int i = 0; i < Coeffs(); i++)
		s >> B[i];
}

Void M3Quad::SetParent(HierQuad &itsParent)
{
	HierQuad::SetParent(itsParent);

	if (itsParent.child[3] == this)
		((HRQuad &) itsParent).Push();
}


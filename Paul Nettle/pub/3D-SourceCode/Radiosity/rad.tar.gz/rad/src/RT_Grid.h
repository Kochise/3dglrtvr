/*
	File:			RT_Grid.h

	Function:		Implements standard voxel grid for raytracing
					optimisation.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
*/

#ifndef __RT_Grid__
#define __RT_Grid__

#include "RT_Defs.h"
#include "Array.h"
#include "RT_Tri.h"

typedef struct
{
	RTTri	*tri;
	Int		next;
} TriEntry;

class Grid;


// --- Grid Class --------------------------------------------------


class Grid
{
public:
	Grid();
	Grid(Int maxCells, Int maxCellPolys, Int maxGridPolys);
	~Grid();

	Void		Prepare();
	
	Bool		IntersectionExists(Point& start, Point& end);
	Bool		FirstIntersection(Point& start, Vector& direction, Point& place, RTTri*& tri, Void* orig);
	
	Void		Draw(Int level);
	
//protected:

	Int					maxCells;
	Int					maxCellPolys;
	Int					maxGridPolys;
	Real				cellSize;
	Int					numCells[3];
	Vector				min, max;		// axis-aligned bounding box.
	Int					xSpan, ySpan;	// byte-spans for grid array.
	Int					totalCells, totalTris;
	Int					pushedEntries;
	Int					triMem;
	Int					pointMem;

	Bool				cacheHit;
	Point				cachePlace;
	RTTri*				cacheTri;
	
	Array<Int>			grid;			// the grid itself -- just a bunch of cell indexes
	Array<TriEntry>		triEntries;
	Int					dirty;
	Int					level;
	Int					stamp;
	
	Void		UpdateBBox(Point& cellMin, Point& cellMax);
	Void		UpdateBBox(RTTri *tri);
	
	Void		SetupGrid();
	Void		AddTriangle(RTTri *tri);
	
	Int			CountPolys(Int start);
		
	Bool		FindGridStart(Point& start, Vector& direction,
					Int cell[3], Int increment[3], Int limit[3], 
					Real& tRay, Vector& tDelta, Vector& tMax);
	
	Void		ConvertToGridPoint(Point &point, Point &fujiPoint);
	Void		RayClampEntryPoint(Int index, Bool backEntry[3], Vector& fujiPoint, Int cell[3]);
	
	Real		MemoryUsage();
};

#endif

#include "Examiner.h"
#include "SceneLang.h"

#include "Plot2D.h"
#include "GL/gl.h"
#include <fstream.h>

static GLfloat light0Position[] = { 1.0, 1.0, -1.0, 0.0 };
static GLfloat light0Ambient[] = { 0.0, 0.0, 0.0, 1.0 };
static GLfloat light0Diffuse[] = { 0.9, 0.9, 0.9, 1.0 };
static GLfloat light0Specular[] = { 0.0, 0.0, 0.0, 1.0 };
static GLfloat light0Shininess[] = { 20.0 };

Void GLLightsOn(Point *lightPos)
{
	glLightfv(GL_LIGHT0, GL_POSITION, light0Position);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light0Ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light0Diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light0Specular);
//	glLightfv(GL_LIGHT0, GL_SHININESS, light0Shininess);
//	glEnable(GL_LIGHT0);
	
//	glEnable(GL_LIGHTING);
//	glEnable(GL_COLOR_MATERIAL);
//	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
}

Void GLLightsOff()
{
	glDisable(GL_LIGHTING);
	glDisable(GL_COLOR_MATERIAL);
}

class scGLLight : public scPrimitive
{
public:

	scGLLight() : scPrimitive((scPrimitiveID) 808) {};
	scGLLight(const scGLLight &sp) : scPrimitive(sp), pos(sp.pos) {};

	Void			Draw(Renderer &r, Context *context);
	Object  	 	*Clone() const { return new scGLLight(SELF); };

	Point	pos;
};

Void scGLLight::Draw(Renderer &r, Context *context)
{
	GLint	mm;

	r.MakeCurrent();
			
	glGetIntegerv(GL_MATRIX_MODE, &mm);		// save the current matrix mode
	glMatrixMode(GL_PROJECTION);			// set the projection matrix
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);				// clear the model matrix
	glLoadIdentity();
	glMatrixMode((GLenum) mm);				// restore matrix mode
	
	glLightfv(GL_LIGHT0, GL_POSITION, light0Position);
}


// ------------------------

Void Arrow(GCLReal height, GCLReal width)
{
	const GCLReal kWidth = 0.2;
	
	slBeginObject("arrow");
	slTransform(Scale(Vector(width, width, width)));
	
	slObject("cone");
	slApply(Shift(Vector(0, (height - width) / width, 0)));
	
	slObject("cylinder");
	slApply(Scale(Vector(0.3, (height - width) / width, 0.3)));
	slEndObject();
}

Void CentredArrow(GCLReal height, GCLReal width)
{
	const GCLReal kWidth = 0.2;
	
	slBeginObject("cArrow");
	slTransform(Scale(Vector(width, width, width)));
	
	slObject("cone");
	slApply(Shift(Vector(0, (height - width) / width, 0)));
	
	slObject("cylinder");
	slApply(Scale(Vector(0.3,  (2 * height - width) / width, 0.3)));
	slApply(Shift(Vector(0, -height / width, 0)));
	slEndObject();
}

Void Examiner::SampleDiff()
// subtract samples from the currently selected patch.
{
	Int			i, j;
	RadQuad		*leaf;
	Coord		place;
	Int			density = plot->samples.Rows();
	
	if (radPane->selPatch[0])
		for (i = 0; i < density; i++)
			for (j = 0; j < density; j++)
			{
				place[0] = 2 * GCLReal(i) / GCLReal(density - 1) - 1;
				place[1] = 2 * GCLReal(j) / GCLReal(density - 1) - 1;
				
				plot->samples[i][j] -=  len((radPane->selPatch[0])->Sample(place));
			}
}

Void Examiner::SampleAdd()
// Add samples from the currently selected patch.
{
	Int			i, j;
	RadQuad		*leaf;
	Coord		place;
	Int			density = plot->samples.Rows();
	
	if (radPane->selPatch[0])
		for (i = 0; i < density; i++)
			for (j = 0; j < density; j++)
			{
				place[0] = 2 * GCLReal(i) / GCLReal(density - 1) - 1;
				place[1] = 2 * GCLReal(j) / GCLReal(density - 1) - 1;
				
				plot->samples[i][j] +=  len((radPane->selPatch[0])->Sample(place));
			}
}

Void Examiner::Dump(ostream &s)
{
	Int		i, j;
	GCLReal	x;
	
	s << 0.0;
	for (j = 0; j < plot->samples.Cols(); j++)
	{
		x = 2 * (j / GCLReal(plot->samples.Cols() - 1)) - 1;
		s << " " << x;
	}
	s << endl;
	
	for (i = 0; i < plot->samples.Rows(); i++)
	{
		x = 2 * (i / GCLReal(plot->samples.Rows() - 1)) - 1;
		s << x << " ";
		for (j = 0; j < plot->samples.Cols(); j++)
			s << plot->samples[i][j] << ' ';
		s << endl;	
	}
}

Void Examiner::BuildPlot()
{
	slBeginObject("plot");
	slColour(HSVCol(260, 1, 0.8));	// plot colour
	plotColour = (scColour *) slCurrent();
	
	// scale transform
	
	slTransform(Scale(Vector(1, 1, 1)));
	scaler = (scTransform *) slCurrent();
	slObject(plot);
	slEndObject();
	
	// axes
	
	slColour(cWhite);
	CentredArrow(1.3, 0.1);
	slApply(Rotation(vl_x, M_PI / 2.0)); 
	CentredArrow(1.3, 0.1);
	slApply(Rotation(vl_z, -M_PI / 2.0)); 
	CentredArrow(1.3, 0.1);
	
	// base
	
	slBeginPoints();
	slPoint(Point(-1, 0,  1));
	slPoint(Point( 1, 0,  1));
	slPoint(Point( 1, 0, -1));
	slPoint(Point(-1, 0, -1));
	slEndPoints();

	slColour(0.5 * cWhite);
	slPoly();
	 
	slApply(Scale(Vector(1.1, 1, 1.1)));
	slApply(Shift(Vector(0, 1, 0)));
}

Library *Examiner::plotLib = 0;	

Void Examiner::Init(FormsGraphicsSystem &gs, RadScenePane *mainPane)
{
	plot = new Plot2D;
	radPane = mainPane;
	
	fl_set_slider_bounds(scaleSlider, -1, 1);	
	fl_set_slider_value(scaleSlider, 0);	
   
	gs.CreateFormsPane(&plotPane, pane);
	
	plotPane.MakeCurrent();
	
	
	Library *saveLib;
	
	if (!plotLib)
	{
		plotLib = new Library;
		saveLib = slSwapLibrary(plotLib);
		plotLib->Create();
	}
	else
		saveLib = slSwapLibrary(plotLib);
	
	plotScene = slBeginObject("plot");
	slCamera();
	BuildPlot();
	slEndObject();
	
	slSwapLibrary(saveLib);
			
	plot->isStep = false;
	
	plotPane.SetScene(plotScene);
	GLLightsOn(0);
}

Void Examiner::Event(FL_OBJECT *object)
{
	if (object == dismiss)
	{
		plot->samples.SetSize(1, 1);
		Hide();
	}
	else if (object == scaleSlider)
	{
		GCLReal amount = fl_get_slider_value(scaleSlider);
	
		amount = pow(10, amount);
	
		*scaler = Scale(Vector(1, amount, 1));
		plotPane.Redraw();
	}
	else if (object == diff)
	{
		SampleDiff();
		*plotColour = HSVCol(hsvRed, 0.5, 1);
		plotPane.Redraw();	
	}
	else if (object == add)
	{
		SampleAdd();
		*plotColour = HSVCol(hsvGreen, 0.5, 1);
		plotPane.Redraw();	
	}
	else if (object == dump)
	{
		const char	*result;
		RGBAImage	A;
		FILE		*file;

		result = fl_show_fselector("Saving plot data file...", 0, "*.tiff", "plot.tiff");

		if (result)
		{
			cout << "*** dumping plot image to " << result << endl;
			plotPane.MakeCurrent();
			plotPane.GetImage(A);
			cout << " got " << A.Width() << " x " << A.Height() << " image." << endl;
			A.SaveTIFF(result);
		}
	}
	else if (object == dataDump)
	{
		const char *result;
		ofstream	fout;
		
		result = fl_show_fselector("Saving plot data file...", 0, "*.data", "plot.data");
		
		if (result)
		{
			cout << "*** dumping plot data to " << result << endl;
			fout.open(result);
			if (fout)
				Dump(fout);
			else
				perror("Couldn't open output file");
		}
	}
}


#ifndef __rtdefs__
#define __rtdefs__

#include "VLd.h"

typedef Vec3d Point;
typedef Vec3d Vector;

//typedef Vec3d Colour;
//typedef Vec3d Reflectance;

inline ostream &operator<<(ostream &s, Int i[3])
{
	cout << '[' << i[0] << ' ' << i[1] << ' ' << i[2] << ']';
	return(s);
}

#endif

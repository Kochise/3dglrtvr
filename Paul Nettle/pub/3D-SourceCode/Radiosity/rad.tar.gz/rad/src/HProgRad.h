/*
	File:			ProgRad.h

	Function:		Provides a class for lighting a scene using progressive
					radiosity with hierarchical refinement.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */


#ifndef __HProgRad__
#define __HProgRad__

#include "ProgRad.h"

class HProgRad : public ProgRad
{
public:
	HProgRad(RadOptions &options, Renderer *displayP, GraphicsSystem *gsP)
		 : ProgRad(options, displayP, gsP) {};

	Void		SetScene(scScenePtr scene);

	Bool 		Render();
	RadQuad		*NewMesh();
	Int			Stage(Int stage);
	Void		DrawMatrix(Renderer &r);
	Void		DumpStats();

	PatchList	elements;				// elements
	IndexList	eltParents;				// indices of parent patches.

};

#endif

/*
	File:			MatDisplay.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "MatDisplay.h"
#include "stdlib.h"
#include "Rad.h"


// --- Matrix display pane ------------------


Char *MatrixDisplay::Label() const
{
	return("Matrix Display");
}

Void MatrixDisplay::Draw(Renderer &r, Context *context)
{
	r
		.C(cWhite)
		.Begin(renLineLoop)
		.P(Point(-1, -1, 0))
		.P(Point(1, -1, 0))
		.P(Point(1, 1, 0))
		.P(Point(-1, 1, 0))
		.End();
		
	if (method && *method)
		((RadMethod *)(*method))->DrawMatrix(r);
	else
		Expect(false, "no rad method set.");
}

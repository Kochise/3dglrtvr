/*
	File:			RadDraw.cc

	Function:		Renders vanilla or intermediate radiosity scene files.

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

	Change History:
		26/03/96	ajw		Started
*/

#include "RadPoly.h"
#include "SceneLang.h"
#include "XGraphicsSystem.h"
#include "ScenePane.h"
#include "RadTrace.h"
#include "EPSRenderer.h"
#include <unistd.h>
#include "arg.h"
#include <fstream.h>
#include <string.h>

// ------------------------------------------------------------


static RadOptions *gROpts;
static Bool gDump = 0;
static Bool gMove = 0;

class RadDrawPane : public ScenePane
{
public:
	Void	HandleEvent(XEvent *event); 
};

Void RadDrawPane::HandleEvent(XEvent *event)
{
	if (event->type == KeyPress)
	{
		char temp[4];

		XLookupString((XKeyEvent *) event, temp, sizeof(temp) - 1, NULL, NULL);

		switch (temp[0])
		{
		case 'g':
			gROpts->gouraud = !gROpts->gouraud;
			Redraw();
			break;
		case 'w':
			gROpts->wire = !gROpts->wire;
			Redraw();
			break;
		case 'm':
			gROpts->anchor = !gROpts->anchor;
			Redraw();
			break;
		case 'f':
			gROpts->funcView = !gROpts->funcView;
			Redraw();
			break;	
		case 'd':
			gDump = 1;
			break;
		case 'e':
			gDump = 2;
			break;
		case 'c':
			gDump = 3;
			break;
		case ' ':
			gMove = 1;
			break;
		case ',':
			gMove = 2;
			break;
		case '.':
			gMove = 1;
			break;
		case 'q':
			parent->finished = true;
			break;
		default:
			ScenePane::HandleEvent(event);
		}
	}
	else
		ScenePane::HandleEvent(event);	
}

// ------------------------------------------------------------

class ProgramOptions
{
public:
	char	**files;
	int		numFiles;
	char	*outFile;
	Int		size;
	Int		window;
	Int		ppm;
	Int		tiff;
	Int		eps;
	Int		trace;
	Int		final;
	Int		noFork;
	double	grey;
};

static char** gArgv;
static int gArgc;

Void GetFiles(int argc, char **argv)
{
	// Save away a pointer to the list of file names
	// I've checked the source of libarg.c -- it
	// doesn't free anything, so this is safe.

	gArgv = argv;
	gArgc = argc;
}

Void SetOptions(int argc, char **argv, RadOptions &radOpts, ProgramOptions &progOpts)
{
	Int gouraud, wire, func, anchor;
	Arg_form *arg_format;
	
	progOpts.size = 400;
	progOpts.outFile = 0;
	progOpts.grey = 0.0;
		
	arg_format = arg_to_form(
			"", 										"usage: raddraw file1 file2 ... [options]",
			
			"", ARG_SUBR(GetFiles), 						"",
			"-o %S", &progOpts.outFile, 				"output file",
			"-tiff", ARG_FLAG(&progOpts.tiff),			"save as .tiff (default)",
			"-ppm", ARG_FLAG(&progOpts.ppm),			"save as .ppm",
			"-eps", ARG_FLAG(&progOpts.eps),			"save as .eps",
			
			"-gouraud", ARG_FLAG(&gouraud),				"use gouraud shading",
			"-anchor", ARG_FLAG(&anchor),				"use anchored mesh",
			"-wire", ARG_FLAG(&wire), 					"display wireframe",
			"-func", ARG_FLAG(&func), 					"function view",
			"-bg %F", &progOpts.grey, 					"Background grey level",

			"-noFork", ARG_FLAG(&progOpts.noFork), 		"don't go into background",
			"-trace", ARG_FLAG(&progOpts.trace), 		"render using ray tracer",
			"-final", ARG_FLAG(&progOpts.final), 		"render using final gather",
			"-samples %F", &radOpts.sampleFactor, 		"FG sample factor",
			
			// Output options
			
			"-window", ARG_FLAG(&progOpts.window), 		"display output in window",
			"-size %d", &progOpts.size, 				"set window size",
			"", 										"\nFormats accepted: .sl, .obj, .mgf, and gzipped versions of the same",
		0);

	// Do arg parsing
	
	if (argc == 1)
	{
		arg_form_print(arg_format);
		exit(1);
	}
	if (arg_parse_argv(argc, argv, arg_format) < 0)
		exit(1);

	radOpts.gouraud = gouraud;
	radOpts.anchor = anchor;
	radOpts.wire = wire;
	radOpts.funcView = func;

	if (!progOpts.eps && !progOpts.ppm)
		progOpts.tiff = 1;
	if (progOpts.final)
		progOpts.trace = 1;

	progOpts.files = gArgv;
	progOpts.numFiles = gArgc;

	if (strcmp("radview", argv[0]) == 0)
		progOpts.window = 1;
}

#include "Parse.h"


Void DrawRadScene(ProgramOptions &progOpts, RadOptions &radOpts)
{
	GraphicsSystem			gs;
	Int						i;
	scScenePtr				scene;
	ifstream				inFile;
	GCLReal					err;
	Renderer				*display;
	RGBAImage				image;
	FileName				filename;
	RadDrawPane				*displayPane;
	Bool					done = false;
	EPSRenderer				*epsRenderer;
	
	slSetLibrary(new RadLib);

	if (progOpts.window)
	{
		if (!progOpts.noFork && fork())
			exit(0);

		cout 
			<< "keys: " << endl
			<< "  w - wireframe" << endl
			<< "  g - gouraud" << endl
			<< "  m - anchored mesh" << endl
			<< "  f - function view" << endl
			<< "  d - dump camera" << endl
			<< "  d - dump picture" << endl
			<< "  e - dump eps file" << endl
			<< "  , - previous file" << endl
			<< "  . - next file" << endl
			<< "  q - quit" << endl
			;

		displayPane = new RadDrawPane;
		display = displayPane;
		gs.CreateWindow(displayPane, progOpts.files[0], progOpts.size, progOpts.size);
	}
	else if (progOpts.eps)
	{
		epsRenderer = new EPSRenderer;
		display = epsRenderer;
	}
	else if (!progOpts.trace)
	{
		GSOffscreenPane *oPane =  new GSOffscreenPane;

		gs.CreateOffscreen(oPane, progOpts.size, progOpts.size);
		display = oPane;
	}
	
	// Window mode
	
	if (progOpts.window)
	{
		i = 0;
				
		while (!gs.finished)
		{
			filename.SetPath(progOpts.files[i]);
			
			cout << "viewing file: " << filename.GetPath() << endl;
			
			scene = ReadSceneFile(filename);
			if (!scene)
			{
				cout << "failed to read scene file " << filename.GetPath() << endl;
				exit(1);
			}
			
			RadCast(scene)->Reanimate(radOpts);
			RadCast(scene)->Smooth();

			displayPane->SetScene(scene);
			displayPane->SetBgColour(cWhite * progOpts.grey);
			
			// display scene
			
			cout << displayPane->GetBgColour() << endl;
			
			while (!gs.finished && !gMove)
			{
				gs.Spin();
				
				if (gDump)
				{
					// Write out image/eps file...
				
					if (gDump == 3)
					{
						ofstream	fout;
						
						cout << "*** saving camera to view.cam" << endl;
                        fout.open("view.cam");
                        if (fout)
                        {
							((scCamera*) displayPane->ItsCamera())->Print(fout);
							fout.close();
						}
						else
							perror("Couldn't open output file");
 					}
					else if (gDump == 2)
					{
						EPSRenderer eps;
						
						filename.extension = "eps";
						eps.Attach(filename.GetPath().Ref());
						eps.Clear().Draw(scene).Show();
					}
					else
					{
						if (progOpts.trace)
						{
							image.SetSize(progOpts.size, progOpts.size);
							if (progOpts.final)
								FinalGather(scene, image, radOpts);
							else
								RayCastScene(scene, image);
						}
						else
							display->GetImage(image);
	
						if (progOpts.outFile)
							image.SaveTIFF(progOpts.outFile);
						else
						{
							filename.extension = "tiff";
							image.SaveTIFF(filename.GetPath().Ref());
						}
					}
					gDump = 0;
				}
			}
			
			if (gMove)
			{
				if (gMove > 1)
				{
					i--;
					if (i < 0)
						i = progOpts.numFiles - 1;
				}
				else
				{
					i++;
					if (i >= progOpts.numFiles)
						i = 0;
				}
				
				gMove = 0;
			}
		}

		return;
	}
	
	// Batch-render mode.
	
	for (i = 0; i < progOpts.numFiles; i++)
	{
		filename.SetPath(progOpts.files[i]);
		
		cout << "file: " << filename.GetPath() << endl;
		
		scene = ReadSceneFile(filename);
		if (!scene)
		{
			cout << "failed to read scene file " << filename.GetPath() << endl;
			exit(1);
		}
		
		RadCast(scene)->Reanimate(radOpts);
		RadCast(scene)->Smooth();
		
		// change output filename if we have override...
		if (progOpts.outFile)
			filename.SetPath(progOpts.outFile);

		// draw scene
			
		if (progOpts.eps)
		{
			filename.extension = "eps";
			epsRenderer->Attach(filename.GetPath().Ref());
		}
					
		if (progOpts.trace)
		{
			image.SetSize(progOpts.size, progOpts.size);
			if (progOpts.final)
				FinalGather(scene, image, radOpts);
			else
				RayCastScene(scene, image);
		}
		else
		{
			display->SetBgColour(cWhite * progOpts.grey);
			display->Clear().Draw(scene).Show();
			if (!progOpts.eps)
				display->GetImage(image);
		}
		
		// Write out image file...

		if (progOpts.eps)
			;	// already done.
		if (progOpts.ppm)
		{
			filename.extension = "ppm";
			image.SavePPM(filename.GetPath().Ref());
		}
		if (progOpts.tiff)
		{
			filename.extension = "tiff";
			image.SaveTIFF(filename.GetPath().Ref());
		}
	}
}

main(int argc, char **argv)
{
	RadOptions			radOpts;
	ProgramOptions		progOpts;
	
	SetOptions(argc, argv, radOpts, progOpts);

	gROpts = &radOpts;

	if (progOpts.numFiles < 1)
	{
		exit(1);
	}
	
	if (progOpts.outFile && progOpts.numFiles > 1)
	{
		cerr << "you can only use -o with one file argument." << endl;
		exit(1);
	}
	
	DrawRadScene(progOpts, radOpts);

	return(0);
}

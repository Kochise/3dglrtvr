#include "Haar.h"


#define HaarChild(x) ((HaarQuad *) child[x])
#define HaarCast(x) ((HaarQuad *) x)


// --- HaarLink methods ------------------------------------------


LinkNode *HaarLink::CreateSubLink(HRQuad *fromPatch, HRQuad *toPatch)
{
	HaarLink *result = new HaarLink;
	
	Assert(fromPatch != 0 && toPatch != 0, "(HaarLink::CreateSubLink) null in to/from");
	
	result->visibility = visibility;
	result->Set(fromPatch, toPatch);
				
	return((LinkNode *) result);
}

Void HaarLink::Set(HRQuad *fromPatch, HRQuad *toPatch)
{
	Assert(fromPatch != 0 && toPatch != 0, "(HaarLink::Set) null in to/from");
		
	from = fromPatch;
	to = toPatch;

	if (NeedVisibility())
		visibility = from->Visibility(to);
	
	if (fromPatch->props->options->quadLevel > 3)
	{
		transport = fromPatch->EstFormFactorXtra(toPatch, factor);
	}
	else
	{
		transport = fromPatch->EstFormFactor(toPatch);
		factor = transport;
	}
	transport *= visibility;
}

Void HaarLink::Gather()
{
	HaarCast(to)->R += transport * HaarCast(from)->B;
}

GCLReal HaarLink::Error()
{
	return(factor);
}

GCLReal HaarLink::BFError()
{
	return(to->area * factor * 
		dot(kRadRGBToLum, to->Reflectance() * HaarCast(from)->B));
}

Void HaarLink::Print(ostream &s)
{
	RadLink::Print(s);
	s << transport << ' ' << visibility << ' ';
}

Void HaarLink::DrawLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom, GCLReal weight)
{
	r.SetColour(to->Reflectance() * transport * visibility * weight);

	r.Rect(left, top, right, bottom);
}

#pragma mark -
// --- HaarQuad methods --------------------------------------------------


Colour HaarQuad::lastB;

Void HaarQuad::Add()
{
	B += R * Reflectance();
	if (!props->options->shotDisplay)
		colour = B;
	else
		colour = R;
}

Void HaarQuad::Push()
{
	Int i;
	
	for (i = 0; i < 4; i++)
		HaarChild(i)->B = B;
}

Void HaarQuad::Pull()
{
	Int 	i;
	
	B = vl_0;
	for (i = 0; i < 4; i++)
		B += HaarChild(i)->B;
	B /= 4.0;

}

Void HaarQuad::Prepare()
{
	//	Save B for comparison to post push/pull B
	lastB = B;
	//	Initialise B to emittance of this patch.
	B = Emittance();
}

GCLReal HaarQuad::Error()
{
 	return(dot(kRadRGBToLum, B - lastB));
}

Void HaarQuad::ClearR()
{
	R = vl_0;
}

Void HaarQuad::Print(ostream &s)
{
	s << " + haar ";
	PrintRec(s);
}

Void HaarQuad::PrintSelf(ostream &s)
{
	HRQuad::PrintSelf(s);
	s << B << ' ';
}

Void HaarQuad::ParseSelf(istream &s)
{
	HRQuad::ParseSelf(s);
	s >> B;
}

Void HaarQuad::SetParent(HierQuad &itsParent)
{
	HierQuad::SetParent(itsParent);

	B = ((HaarQuad &) itsParent).B;	
}

Colour HaarQuad::SampleLeaf(Coord &c)
{

	if (props->options->gouraud)
	{
		Colour	c1, c2;
		GCLReal	s = (1 + c[0]) / 2.0, t = (1 + c[1]) / 2.0;

		c1 = Mix(Clr(0), Clr(3), s); 
		c2 = Mix(Clr(1), Clr(2), s); 
		return(Mix(c2, c1, t));
	}
	else
		return(B);
}

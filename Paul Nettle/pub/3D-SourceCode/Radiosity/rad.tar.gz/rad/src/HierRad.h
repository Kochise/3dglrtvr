/*
	File:			HierRad.h

	Function:		Provides a class for lighting a scene using hierarchical
					radiosity.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __HierRad__
#define __HierRad__

#include "Rad.h"
#include "HRMesh.h"


class HierRad : public RadMethod
{
public:
	HierRad(RadOptions &options, Renderer *displayP, GraphicsSystem *gsP)
		 : RadMethod(options, displayP, gsP) {};

	TreeList	trees;	// initial polygons; each is a quadtree.
	
	virtual LinkNode
				*TopLink(HRQuad *fromPatch, HRQuad *toPatch);

	Void		SetScene(scScenePtr scene);
	Bool		Render();				// override
	RadQuad		*NewMesh();
	Int			Stage(Int stage);
	Void 		DrawMatrix(Renderer &r);
	Void		DumpStats();
	
	Int			iterations;
	Int			poly;
	GCLReal		error;
	Int			linkPatch;
};

#endif

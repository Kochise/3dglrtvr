#include "RT_Defs.h"
#include "Array.h"

typedef Array<Point> PointList;

// Tri flags...

const Int16 TRI_HIT			= 0x0001;
const Int16 TRI_INACTIVE	= 0x0002;

class RTTri
{
public:
	Int			v[3];			// vertex indices
	PointList	*ptList;		// 
			
	Vector		normal;			// face normal
	Real		d;				// for plane equation
	Int			normMajorAxis;	// largest component of normal
	Real		area;			// triangle size.
	
	Int			stamp;			// local time stamp;
	Vector		coords;			// barycentric coords of last intersection.	
	Int16		flags;			// ...
	Void*		data;
	
	static Int	gStamp;			// global time stamp;

	Bool		FindBaryCoords(Point& point);
	inline Bool TriPlaneIntersection(Point& start, Vector &direction, Real &t);

	Void		MakeNormal();

	Void		Draw();
	Void		Stamp()			{ stamp = gStamp; };
	Bool		IsStamped()		{ return(stamp == gStamp); };
	Bool		IsTrue(Int i)	{ return(flags & i); };
	
	Point&		Vertex(Int i)	{ return((*ptList)[v[i]]); };
//	Point&		Normal(Int i)	{ return(object->normals[n[i]]); };	
};	// 76 bytes




// -- Inlines -------------------------------------------------------


inline Bool RTTri::TriPlaneIntersection(Point& start, Vector &direction, Real &t)
//	returns true if given ray intersects plane of given tri.
//	If there is an intersection, t is set.
{
	Real normDotDirection = dot(normal, direction);
	
	if (normDotDirection == 0.0)
		return(false);

	t = (d + dot(normal, start)) / -normDotDirection;

	return(true);
}


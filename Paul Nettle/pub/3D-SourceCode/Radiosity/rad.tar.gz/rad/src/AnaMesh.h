/*
	File:			AnaMesh.h

	Function:		
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __AnaMesh__
#define __AnaMesh__

#include "RadMesh.h"



class GridAnaQuad : public GridRadQuad
{
public:
	Colour			Sample(Coord c);				// Sample radiosity at this coord.

	PatchList		*lights;
};

#endif

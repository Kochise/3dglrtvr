/*
	File:			Rad.h

	Function:		Defines a base class for all radiosity scene-illumination
					implementations.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */


#ifndef __Rad__
#define __Rad__

#include "Scene.h"
#include "RadOptions.h"
#include "RadPoly.h"
#include "Timer.h"

class GraphicsSystem;


class RadMethod		//	Radiosity method base class.
{
public:

	RadMethod(RadOptions &theOptions, Renderer *displayP, GraphicsSystem *gsP);
	virtual ~RadMethod();

	static RadMethod	*NewRadMethod(RadOptions &theOptions, Renderer *displayP, GraphicsSystem *gsP);
	
	virtual Void		SetScene(scScenePtr scene);
	virtual Bool		Render();
			
	virtual Void		DrawMatrix(Renderer &r);
	Void				RenderMatrix(Renderer &r);
			
	virtual RadQuad		*NewMesh() = 0;		// Return mesh element for this method

	virtual Int			Stage(Int stage);	// Gets called at various stages of radiosity execution.
	virtual Bool		Idle();				// For giving up time
	virtual Bool		Pause();			// Indicate a pause point.
	
	Void				DumpScene();
	virtual Void		DumpStats();
	Bool				CheckTime();

	Void				StartUpdate();
	Bool				Update();

	// Fields
	
	RadOptions			&options;	// Radiosity options
	PatchStats			stats;
	scScenePtr			scene;
	PatchList 			patches;	//  initially-meshed polys
	GCLReal				maxPatchSize;
	Int					dumpID;
	GCLReal				lastTime;
	GCLReal				nextUpdate;
	GraphicsSystem		*gsP;
	
	// visual stuff
	
	Renderer			*displayP;
}; 




// For the stand-alone build

#define RM_IDLE ((RadMethod *) props->options->radObject)->Idle()
#define RM_PAUSE ((RadMethod *) props->options->radObject)->Pause()
#ifdef RAD_DEBUG
#define RM_OUT1(X) cout << "1- " << X << endl;
#define RM_OUT2(X) cout << "2- " << X << endl;
#define RM_OUT3(X) cout << "3- " << X << endl;
#else
#define RM_OUT1(X)
#define RM_OUT2(X)
#define RM_OUT3(X)
#endif
#define RM_DISPLAY_SCENE
#define RM_DISPLAY_START
#define RM_DISPLAY_END


#endif

/*
	File:			RadOptions.h

	Function:		Defines a structure for all of the possible options for the various
					radiosity illumination methods.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __RadOptions__
#define __RadOptions__

#include "Renderer.h"
#include "Scene.h"

enum RadType
{
	kNoMethod,
	kOverrelaxation,
	kConjugateGradient,
	kProgressive,
	kProgPlus,
	kHierarchical, 
	kAnalytical
};

enum HRBasisType
{
	kHaar = 1,
	kFlatlet2,
	kFlatlet3,
	kMultiwavelet2,
	kMultiwavelet3
};

enum VisType	// inter-patch visibility methods
{
	vis_none,	// don't check visibility
	vis_1,		// cast a single ray between the centre of each patch
	vis_16x1,   // cast 16 rays from centre of the receiving patch to 
				// the source patch.
	vis_4x4		// cast 16 rays from anywhere on source to 16 anywhere on
				// dest. (uses Cohen's jittered magic-square method.)
};

enum MeshType
{
	mesh_std,		// standard, divide evenly by area 
	mesh_random,	// vary mesh density for different patches
	mesh_nonlin		// mesh more heavily at patch edges.
};

class RadMethod;

class RadOptions			// A 'fat' structure containing all
{							// the options any of the radiosity
	public:					// methods may need...

	RadOptions();

	//	Options for the current render

   	RadType			method;
   	HRBasisType		basis;

	//	Method options

	GCLReal		patchSubdivs;	// How fine to mesh the scene
	GCLReal 		eltSubdivs;		// How fine to mesh sub elements
	GCLReal 		alpha;			// For overrelaxation solution
	GCLReal 		error;			// error level at which to terminate
	
   	GCLReal		kFError;		// Allowable error in form factors
   	GCLReal		kAError;		// Minimum element size
   	Bool		multiGrid;		// Intermix refinement & solution
   	Bool 		useBF;			// Do brightness-weighted refinement
   	Bool 		ambient;		// Add in ambient-light correction.
	Bool		refAllLinks;	// ensure all links have been refined before
								// terminating.

   	VisType		visibility;		// Type of visibility testing to use
	Bool		jitterRot;		// Recalculate jitter for each new visibility
								// test
	GCLReal		dFError;		// How much  error to tolerate in the differential ff
								// estimate before swapping to an analytical one.
	GCLReal		visError;		// How much more to subdivide when visibility is
								// partial in wavelet radiosity: in such situations
								// the FF limit becomes kFEError * visError.
	Int			quadLevel;		// How accurate to make quadrature
	GCLReal		sampleFactor;	// how many samples for final gather...
	Bool		visInQuad;		// use fractional visibility (a la original WR paper)
								// or integrate into quadrature.
	MeshType	mesh;			// type of meshing to employ.
		
	//	Simulation opts.

	Bool 		stop;
	Bool 		step;
	Bool		pause;

	//	Display options
		
	Bool		graded;
	Bool		anchor;
   	Bool		gouraud;		// Gouraud-shade patches
   	Bool 		wire;			// Wireframe.

   	Bool		redWire;		// Wireframe, but colour red.
   	Bool		shotDisplay;	// show unshot radiosity rather than accumulated radiosity
   	Bool		patchView;		// Display relevant to currently selected patch
   	Void		*pvData;		// Hook for the above
   	Bool		funcView;		// Plot rad as function over patches
   	
   	Bool		animate;		// Animate by highlighting relevant patches
   	Bool		showRays;		// Animate casting of rays
   	Bool		showLinks;
   	
   	Int			choke;
   	Int			sweep;
	Bool		drawMatrix;		// Whether or not to display matrix.

	//	Objects relevant to the current render
	   	
	RadMethod	*radObject;
   	Renderer 	*display;
   	scScene		*scene;
	Int			stage;
	
	//	Statistics for the current render
	
	GCLReal		sliceTime, limitTime;
   	Int			numPolys;
	Int			rays;
	GCLReal		mem;
	GCLReal		pfTime, visTime, solveTime, drawTime, totTime, lastTime;
	GCLReal		numPatches, numLinks, numVis, numIter;
	char		*outFile;
};

extern Reflectance kRadRGBToLum;
extern Char *radRenderVersion;

#endif


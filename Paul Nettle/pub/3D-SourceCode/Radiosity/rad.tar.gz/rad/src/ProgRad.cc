/*
	File:			ProgRad.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "ProgRad.h"

    
  
Void ProgRad::MakeFormFactorFromVector(RadQuad &fromPatch, PatchList &patches, ColourList &result)
// Find the vector of patch factors from patch j. 
// The factors are weighted by the reflectance of the patch they are to.
{
	Int			i, k;
	GCLReal 		visibility;
	GCLReal		factor;
	RadQuad		*curPatch;
		
	result.SetSize(patches.NumItems());
		
	if (options.showRays)
		displayP->Clear().Draw(scene);
	
	for (i = 0; i < patches.NumItems(); i++)		
	{			
		curPatch = patches[i];
		
		if (len(curPatch->Reflectance()) < 0.0001)
		{
			result[i].MakeZero();
			continue;
		}

		visibility = fromPatch.Visibility(curPatch);
		
		if (visibility > 0.0)
		{
			factor = fromPatch.EstFormFactor(curPatch);
			result[i] = curPatch->Reflectance();
			result[i] *= factor * visibility;
		}
		else
			result[i].MakeZero();
	}
	
	if (options.showRays)
		displayP->Show();
}


Bool ProgRad::Render()
//	Returns true if no interruptions.
{
	Int			numPatches = patches.NumItems();
	Int 		i, j;
	
	GCLReal		deltaRad;
	Colour		radToShoot;
	GCLReal		power, envArea;
	Colour		envPower, envRefl;
	Bool		finished = 0;	
	
	RadMethod::Render();

	iterations = 0;
	error = 1.0;
	origShoot = 0;
		
	B.SetSize(numPatches);
	S.SetSize(numPatches);

	envRad = vl_1;
			
	if (Stage(1)) return(0);
	
	for (i = 0; i < patches.NumItems(); i++)
		S[i] = patches[i]->Emittance();
	
	B = S;
				
	//	Setup for the ambient term

	envRefl.MakeZero();
	envArea = 0;
	
	for (i = 0; i < numPatches; i++)
	{
		envRefl += patches[i]->area * patches[i]->Reflectance();
		envArea += patches[i]->area;	
	}
	
	envRefl /= Colour(vl_1) / (Colour(vl_1) - envRefl / envArea);		// R = 1 / (1 - avgReflectance)
	
	//	Now, run the algorithm...

	while (!finished)
	{	
		if (Stage(2)) return(0);

		iterations++;

		maxPower = 0;
		maxPowerIndex = 0;
		envPower.MakeZero();
		
		for (i = 0; i < numPatches; i++)						
		{
			power = dot(S[i] * patches[i]->area, kRadRGBToLum);
				
			if (maxPower < power)
			{
				maxPower = power;					// length of R, G, B vector...
				maxPowerIndex = i;
			}
		}
		
		if (Idle())	
			return(0);

		if (Stage(3)) return(0);
			
		radToShoot = S[maxPowerIndex];
		radToShoot *= options.alpha;
		S[maxPowerIndex] -= radToShoot;
				
		if (Stage(4)) return(0);
				
		MakeFormFactorFromVector(*patches[maxPowerIndex], patches, FFROW);	

		if (Stage(5)) return(0);
		
		error = 0;
		envPower.MakeZero();
				
		for (i = 0; i < numPatches; i++)
		{
			for (j = 0; j < 3; j++)
			{
				deltaRad = FFROW[i][j] * radToShoot[j];
				B[i][j] += deltaRad;
				S[i][j] += deltaRad;
				error += sqr(deltaRad);
			}

			envPower += S[i] * patches[i]->area;
		}
		
		if (options.ambient)
			envRad = envRefl * envPower / envArea;
		else
			envRad.MakeZero();

		error = sqrt(error);

		if (iterations == 1)
			origShoot = maxPower;
		else if (maxPower < options.error * origShoot)
			finished = 1;
		
		if (Stage(6)) return(0);
	}	
	
	if (Stage(7)) return(0);
	
	return(1);
}



Void ProgRad::DumpStats()
{
	Int		i;
	GCLReal	shotErr, mem;
	
	if (origShoot == 0.0)
		shotErr = 1.0;
	else
		shotErr = maxPower / origShoot;
	
	mem = sizeof(Colour) * (B.NumItems() + S.NumItems() + FFRow.NumItems());
	mem /= 1024.0;
	
	cout << dumpID 
		<< ' ' << options.totTime 
		<< ' ' << options.stage 
		<< ' ' << patches.NumItems() 
		<< ' ' << shotErr
		<< ' ' << error
		<< ' ' << options.rays
		<< ' ' << mem
		<< ' ' << iterations 
		<< endl;

	for (i = 0; i < patches.NumItems(); i++)		// Colour the patches...
	{
		// Show the shot vector or the radiosity vector?

		if (options.shotDisplay)			
			patches[i]->colour = S[i];
		else
			patches[i]->colour = B[i] + patches[i]->Reflectance() * envRad;
	}

	DumpScene();
}

Int ProgRad::Stage(Int stage)
{
	if (CheckTime()) return(1);

	options.stage = stage;

	switch (stage)
	{
	case 1:		// pre setup
		cout << "renderer " << radRenderVersion << endl;
		cout << "method prog " << endl;
		cout << "sub " << options.patchSubdivs << endl;
		cout << "error " << options.error << endl;
		cout << "scene " << scene->Label() << endl;
		cout << "quads " << options.numPolys << endl;
		cout << "srcPatches " << patches.NumItems() << endl;
		cout << "format ID time stage patches shootErr resErr rays mem iterations" << endl; 
		cout << "-----------------------------------------------------------" << endl;
	
		options.rays = 0;
		options.totTime = 0;
		options.pfTime = 0;
		options.visTime = 0;
		options.drawTime = 0;
		options.solveTime = 0;
		lastTime = 0;
		DumpStats();
		break;
		
	case 2:		// post setup
		break;
		
	case 3:		
		break;
		
	case 4:		// After patch setup
		break;
		
	case 5:	
		break;
		
	case 6:		// Middle of solve loop.
		break;
		
	case 7:
		DumpStats();
		break;
	}

	if (Idle()) return(0);
	ContTimer();
	return(0);
}


Void ProgRad::DrawMatrix(Renderer &r)
{
	if (!options.drawMatrix)
		return;
		
}


RadQuad *ProgRad::NewMesh()
{
	return(new GridRadQuad());
}

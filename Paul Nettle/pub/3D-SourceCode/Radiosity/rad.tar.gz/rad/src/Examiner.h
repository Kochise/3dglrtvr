
#ifndef __Examiner__
#define __Examiner__


#include "RadPane.h"
#include "Plot2D.h"
#include "Library.h"
#include "radvisForms.h"

class Examiner : public PatchViewForm
{
public:
	Void 			Init(FormsGraphicsSystem &gs, RadScenePane *mainPane);
	Void			Event(FL_OBJECT *object);
	Void			BuildPlot();
	Void			SampleDiff();
	Void			SampleAdd();
	Void			Dump(ostream &s);
	
	scScenePtr		plotScene;
	scTransform 	*scaler;
	scColour		*plotColour;
	ScenePane		plotPane;
	Plot2D			*plot;
	RadScenePane 	*radPane;
	
	static Library	*plotLib;
};

#endif

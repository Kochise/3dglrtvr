/*
	File:			MatRad.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "MatRad.h"
#include "Solve.h" 
#include "Timer.h"
#include <fstream.h>
#include <stdio.h>



Matd MatRad::EmissionVectors(PatchList &patches)
{
	Matd	result(3, patches.NumItems());
	Int		i, j;

	for (i = 0; i < patches.NumItems(); i++)
		for (j = 0; j < 3; j++)
			result[j][i] = patches[i]->Emittance()[j];
		
	return(result);
}

SparseVecd MatRad::FormFactorToVector(Int j, PatchList &patches)
// Find the vector of patch factors to patch j
{
	const GCLReal	epsilon = 1e-6;
	SparseVecd		result(patches.NumItems());
	Int				i;
	GCLReal			vis;
	
	if (options.showRays && options.visibility == vis_1)
		displayP->Clear().Draw(scene);	
	
	if (len(patches[j]->Reflectance()) <= 1e-6)
		result.MakeUnit(j);
	else
	{
		result.Clear();
		for (i = 0; i < patches.NumItems(); i++)
		{
			vis = patches[i]->Visibility(patches[j]);
			
			if (vis > 0.0)
				result.AddElt(i, patches[i]->EstFormFactor(patches[j]) * vis);
		}
		result.Done();
	}
	
	if (options.showRays && options.visibility == vis_1)
	{
		displayP->Show();
		Pause();
	}
	
	return(result);
}

Bool MatRad::Render()
//	Returns true if no interruptions.
{
	Int		i, j;
	Vec3d	error;
	Int		numPolys = patches.NumItems();
	Colour	c;

	RadMethod::Render();
	SparseVecd::SetFuzz(1e-10);
	
	SparseVecd FFRow(numPolys);	// Row of form factors
			
	for (i = 0; i < 3; i++)
		A[i].SetSize(numPolys, numPolys);
	
	E.SetSize(3, numPolys);
	B.SetSize(3, numPolys);

	options.numPatches = 0;

	// Colour scene according to current B vector
	for (i = 0; i < patches.NumItems(); i++)	
		patches[i]->SetColour(patches[i]->Reflectance());

	if (Stage(1)) return(0);
	
	E = EmissionVectors(patches);

	if (Stage(2)) return(0);

	// Initialise A's to unit matrices
	for (j = 0; j < 3; j++)
		A[j] = vl_I;

	if (Stage(3)) return(0);
																
	// Calculate solution matrices
	for (i = 0; i < patches.NumItems(); i++)	
	{
		options.numPatches++;
		// find form factors to this patch
		FFRow = FormFactorToVector(i, patches);	
				
		for (j = 0; j < 3; j++)
		{
			A[j][i] -= FFRow * patches[i]->Reflectance()[j];
			
			c[j] = patches[i]->Emittance()[j] + 
				patches[i]->Reflectance()[j] * dot(FFRow, E[j]);
		}
		patches[i]->SetColour(c);
		
		if (Stage(4)) return(0);
	}
		
	if (Stage(5)) return(0);
	
	error = vl_1;
		
	while (len(error) > 0.001)
	{		
		if (options.method == kOverrelaxation)
		{
			for (i = 0; i < 3; i++)			// Solve one more iteration
				error[i] = SolveOverRelax(A[i], B[i], E[i], 1e-6, options.alpha);
		}
		else
			for (i = 0; i < 3; i++)			// Solve one more iteration
				error[i] = SolveConjGrad(A[i], B[i], E[i], 1e-6);
			
		if (Stage(6)) return(0);
	}

	if (Stage(7)) return(0);
	
	return(1);
}


Void MatRad::DumpMatrix()
{
	Int i, j, k;
	char *rgb = "rgb", temp[1024];
	FILE	*file;
	
	// Look, ma, no error handling!

	for (k = 0; k < 3; k++)
	{
		sprintf(temp, "%s.%c.mlab", options.outFile, rgb[k]);
		file = fopen(temp, "w");
//		fprintf(file, "[\n");
		for (i = 0; i < A[k].Rows(); i++)
		{
			for (j = 0; j < A[k].Cols() - 1; j++)
				fprintf(file, "%.18g, ", A[k][i][j]);
			fprintf(file, "%.18g\n", A[k][i][j]);
		}
		
//		fprintf(file, "]\n");
		fclose(file);
	}

	sprintf(temp, "%s.stats", options.outFile);
	file = fopen(temp, "w");
	fprintf(file, "minArea    %.18g\n", stats.minArea);
	fprintf(file, "maxArea    %.18g\n", stats.maxArea);
	fprintf(file, "minRefl    [%.18g %.18g %.18g]\n",
		stats.minRefl[0], stats.minRefl[1], stats.minRefl[2]);
	fprintf(file, "maxRefl    [%.18g %.18g %.18g]\n",
		stats.maxRefl[0], stats.maxRefl[1], stats.maxRefl[2]);
	fclose(file);
}

Void MatRad::DumpStats()
{
	GCLReal density, mem;
	Int i, j;
		
	mem = 4;
	
	density = 0;
	for (i = 0; i < 3; i++)
		for (j = 0; j < A[i].Rows(); j++)
			density += A[i][j].NumItems();

	mem = (density * (sizeof(GCLReal) + sizeof(Int))) + 
			sizeof(GCLReal) * E.Rows() * E.Cols() +
			sizeof(GCLReal) * B.Rows() * B.Cols();
	mem /= 1024.0;
	
	density /= 3 * A[0].Rows() * A[0].Cols();
	
	cout << dumpID
		<< ' ' << options.totTime
		<< ' ' << options.stage
		<< ' ' << options.numPatches
		<< ' ' << patches.NumItems()
		<< ' ' << options.rays
		<< ' ' << mem
		<< ' ' << density
		<< endl;

	DumpScene();
}

Int MatRad::Stage(Int stage)
{
	if (CheckTime()) return(1);

	options.stage = stage;

	switch (stage)
	{
	case 1:		// pre setup
		cout << "renderer " << radRenderVersion << endl;
		if (options.method == kOverrelaxation)
			cout << "method mat " << endl;
		else
			cout << "method matcg " << endl;
		cout << "sub " << options.patchSubdivs << endl;
		cout << "alpha " << options.alpha << endl;
		cout << "scene " << scene->Label() << endl;
		cout << "quads " << options.numPolys << endl;
		cout << "format ID time stage procPatches patches rays mem density" << endl; 
		cout << "----------------------------------------------------------" << endl;
	
		options.rays = 0;
		options.totTime = 0;
		options.pfTime = 0;
		options.visTime = 0;
		options.drawTime = 0;
		options.solveTime = 0;
		lastTime = 0;
		DumpStats();
		break;
		
	case 2:		// post setup
		break;
		
	case 3:		
		break;
		
	case 4:		// After patch setup
		DeltaTime();
		options.drawTime += DeltaTime();
		break;
		
	case 5:		// Finished calculating A[k]
		DeltaTime();
		if (options.drawMatrix)
			DumpMatrix();
		break;
		
	case 6:		// Middle of solve loop.
		options.solveTime += DeltaTime();
		Int i, j;
		Colour c;
		
		for (i = 0; i < patches.NumItems(); i++)		// Colour scene according to current B vector
		{
			for (j = 0; j < 3; j++)
				c[j] = B[j][i];
				
			patches[i]->SetColour(c);
		}
		break;
		
	case 7:
		DumpStats();
		break;
	}

	if (Idle()) return(0);
	ContTimer();	
	return(0);
}


Void MatRad::DrawMatrix(Renderer &r)
{
	if (!options.drawMatrix)
		return;
		
	Int i, j;
	GCLReal x1, x2, y1, y2, w;
		
	w = 2.0 / A[0].Cols();
	
	y1 = 1;
	y2 = 1 - w;
	
	for (i = 0; i < A[0].Rows(); i++)
	{
		x1 = -1;
		x2 = w - 1;
		
		for (j = 0; j < A[0].Cols(); j++)
		{
			if (patches[i]->highlight == 2 && patches[j]->highlight == 3)
				r.C(cPurple);
			else if (patches[i]->highlight == 2)
				r.C(cYellow);
			else if (patches[j]->highlight == 3)
				r.C(cGreen);
			else if (i == j)
				r.C(cBlack);
			else	
//				r.C((A[0].Cols() * RGBCol(-A[0][i][j], -A[1][i][j], -A[2][i][j])));
				r.C(cPurple);
				
			r.Rect(x1, y1, x2, y2); 
	
			x1 += w;
			x2 += w;
		}
		
		y1 -= w;
		y2 -= w;
	}
}

RadQuad *MatRad::NewMesh()
{
	return(new GridRadQuad());
}

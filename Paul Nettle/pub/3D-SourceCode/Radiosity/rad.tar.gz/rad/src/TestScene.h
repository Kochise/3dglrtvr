/*
	File:			TestScene.h

	Function:		Defines creators for various useful trivial test scenes 
					and objects.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __TestScene__
#define __TestScene__

#include "Scene.h"

scScenePtr BoxScene();
scScenePtr ParallelScene();
scScenePtr SidelightScene();
scScenePtr BlockerScene();
scScenePtr AbuttingScene();
scScenePtr TableScene();
scScenePtr SimpleTriScene();
scScenePtr MultiBounce();

#endif

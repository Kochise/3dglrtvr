/*
	File:			RadComp.cc

	Function:		Provides command line-driven program for comparing two radiosity
					output files.

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

	Change History:
		26/03/96	ajw		Started
*/

#include "RadPoly.h"
#include "SceneLang.h"

#include "unistd.h"
#include "arg.h"
#include "fstream.h"


class ProgramOptions
{
public:
	char	*file1;
	char	*file2;
	Int		density;
	Int		verbose;
};

static char** gArgv;
static int gArgc;

Void GetFiles(int argc, char **argv)
{
	// Save away a pointer to the list of file names
	// I've checked the source of libarg.c -- it
	// doesn't free anything, so this is safe.

	gArgv = argv;
	gArgc = argc;
}

Void SetOptions(int argc, char **argv, RadOptions &radOpts1, RadOptions &radOpts2, ProgramOptions &progOpts)
{
	Int hier, prog, mat;
	Int haar, f2, f3, m2, m3, g1, g2;
 	Arg_form	*arg_format;
	
	progOpts.density = 8;

	arg_format = arg_to_form(
			"", 										"usage: radcomp [options]",
			
			"%S", &progOpts.file1, 						"reference file",
			"", ARG_SUBR(GetFiles), 					"comparison files",
			
			"-g1", ARG_FLAG(&g1),						"use gouraud shading for file 1",
			"-g2", ARG_FLAG(&g2),						"use gouraud shading for file 2",
			"-density %d", &progOpts.density, 			"sample density",
			"-v", ARG_FLAG(&progOpts.verbose),			"verbose output",
		0);

	// Do arg parsing
	
	if (argc == 1)
	{
		arg_form_print(arg_format);
		exit(1);
	}
	if (arg_parse_argv(argc, argv, arg_format) < 0)
		exit(1);

	radOpts1.gouraud = g1;
	radOpts2.gouraud = g2;
}

#include "Parse.h"


Void CompScenes(ProgramOptions &progOpts, RadOptions &radOpts1, RadOptions &radOpts2)
{
	Int						i;
	scScenePtr				scene1, scene2;
	GCLReal					areaSum, mean, variance, normConst;
	Colour					cSum, cSqrSum, refSum;
	FileName				filename;

	// Load in the reference file
		
	slSetLibrary(new RadLib);
	
	filename.SetPath(progOpts.file1);
	scene1 = (scScenePtr) ReadSceneFile(filename);
	if (!scene1)
		exit(1);
		
	RadCast(scene1)->Reanimate(radOpts1);
	RadCast(scene1)->Smooth();
		
	for (i = 0; i < gArgc; i++)
	{
		// Compare two radiosity meshes!
			
		// We track the total radiosity sum, the total sum squared,
		// and the total area in the scene.
	
		areaSum = 0;
		cSum.MakeZero();
		cSqrSum.MakeZero();
		refSum.MakeZero();
		
		// Load mesh to compare...
		
		cout << "comparing to " << gArgv[i] << endl;
		filename.SetPath(gArgv[i]);
		scene2 = (scScenePtr) ReadSceneFile(filename);
		if (!scene2)
			exit(1);
	
		RadCast(scene2)->Reanimate(radOpts2);
		RadCast(scene2)->Smooth();
		
		// Compare!
	
		RadCast(scene1)->Compare(scene2, progOpts.density, areaSum, cSum, cSqrSum, refSum);
		
		normConst = dot(refSum, kRadRGBToLum);
		if (fabs(normConst) < 1-10)
		{	
			mean = 10000.0;
			variance = 10000.0;
		}
		else
		{
			mean = dot(kRadRGBToLum, cSum) / normConst;
			variance = dot(kRadRGBToLum, cSqrSum) / sqr(normConst);
		}
		
		if (progOpts.verbose)
		{
			cout << "areaSum: " << areaSum << endl;
			cout << "cSum: " << cSum << endl;
			cout << "cSqrSum: " << cSqrSum << endl;
			cout << "refSum: " << refSum << endl;
			cout << endl;
			cout << "normConst = " << normConst << endl;
			cout << "mean = " << mean << endl;
			cout << "var = " << variance << endl;
			cout << "err = " << sqrt(variance) << endl;
		}
		else
		{
			cout << mean << endl;
			cout << sqrt(variance) << endl;
		}
	}
}


main(int argc, char **argv)
{
	RadOptions				radOpts1, radOpts2;
	ProgramOptions			progOpts;
	
	SetOptions(argc, argv, radOpts1, radOpts2, progOpts);
	CompScenes(progOpts, radOpts1, radOpts2);
	
	return(0);
}

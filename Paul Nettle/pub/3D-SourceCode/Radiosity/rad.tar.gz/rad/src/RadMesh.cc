/*
	File:			RadMesh.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "RadMesh.h"
#include "Rad.h"
#include "String.h"
#include "VecUtil.h"


// --- PatchStats class ----------------------------------------------------------

Void PatchStats::Init()
{
	maxArea = 0.0;
	minArea = 1e20;
	maxRefl = vl_0;
	minRefl.MakeBlock(1e20);
}

// --- RadQuad class ----------------------------------------------------------


Void RadQuad::DrawHighlight(Renderer &r)
{
	if (highlight == 1)
		r.C(cRed);
	else if (highlight == 2)
		r.C(cYellow);
	else if (highlight == 3)
		r.C(cGreen);
	
	r.Begin(renPoly);
	SendPoints(r);
	r.End();
	
}

Void RadQuad::Draw(Renderer &r)
{
	if (highlight)
	{
		DrawHighlight(r);
		if (!props->options->funcView)
			return;
	}	

	if (props->options->wire)
	{
		if (props->options->redWire)
			r.Begin(renLineLoop).SetColour(0.5 * (cRed + colour));
		else
			r.Begin(renLineLoop).SetColour(Mix(cWhite, colour,  0.8));
		
		SendPoints(r);
		r.End();

		return;
	}

	if (props->options->funcView)
	{
		r.Begin(renLineLoop).C(cWhite);
		SendPoints(r);
		r.End();
	}
	
	r.Begin(renPoly);

	if (!props->options->funcView)
	{
		if (props->options->gouraud)
		{
			r.C(Clr(0)).P(Vertex(0)).C(Clr(1)).P(Vertex(1)).C(Clr(2)).P(Vertex(2));
			if (IsQuad())
				r.C(Clr(3)).P(Vertex(3));
		}
		else
		{
			r.C(colour);
			SendPoints(r);
		}
	}
	else
	{
		if (props->options->gouraud)
		{
			Project(r, Clr(0), Vertex(0));
			Project(r, Clr(1), Vertex(1));
			Project(r, Clr(2), Vertex(2));
			if (IsQuad())
				Project(r, Clr(3), Vertex(3));
		}
		else
		{
			Project(r, colour, Vertex(0));
			Project(r, colour, Vertex(1));
			Project(r, colour, Vertex(2));
			if (IsQuad())
				Project(r, colour, Vertex(3));
		}
	}

	r.End();
}

RadQuad *RadQuad::FindContainer(Coord &coord)
{
	return(this);
}

Colour RadQuad::SampleLeaf(Coord &c)
{
	if (props->options->gouraud)
	{
		// XXX should optimise sometime?
	
		if (IsTri())
		{
			Colour	result;
			GCLReal	s = (c[0] + 1.0) / 2.0;
			GCLReal	t = (-c[1] + 1.0) / 2.0;
			GCLReal	u = 1 - s - t;
			
			result = Clr(0) * u + Clr(1) * s + Clr(2) * t;
			
			return(result);
		}
		else
		{
			Colour	c1, c2, result;
			GCLReal	s = (c[0] + 1.0) / 2.0;
			GCLReal	t = (c[1] + 1.0) / 2.0;
			
			c1 = (1 - s) * Clr(0) + s * Clr(3); 
			c2 = (1 - s) * Clr(1) + s * Clr(2); 
			result = (1 - t) * c2 + t * c1;
			return(result);
		}
	}
	else
		return(colour);
}

Colour RadQuad::Sample(Coord c)
{
	RadQuad *leaf = FindContainer(c);
	
	if (leaf)
		return(leaf->SampleLeaf(c));
	else
		return(cBlack);
}

Void RadQuad::SetHighlight(Int h)
{
	highlight = h;
}

Void RadQuad::Print(ostream &s)
{
	s << index[0] << ' ' << index[1] << ' ' << index[2] << ' ' << index[3] << ' ';
	s << clrIdx[0] << ' ' << clrIdx[1] << ' ' << clrIdx[2] << ' ' << clrIdx[3] << ' ';
	s << colour << ' ';			
}

Void RadQuad::Parse(istream &s)
{
	s >> index[0] >> index[1] >> index[2] >> index[3];
	s >> clrIdx[0] >> clrIdx[1] >> clrIdx[2] >> clrIdx[3];
	s >> colour;
}


// --- Form factor routines --------------------------------------


GCLReal RadQuad::EstPatchFactor(const Point &p, const Vector &np)
//	Factor from this patch to p. 
//  essentially cos theta * cos phi * Ap / (pi * r^2)
{
	GCLReal	result, rad4;
	Vector	temp;

	temp = p - Centre();
	
	result = dot(Normal(), temp);
	
	if (result <= 0)
		result = 0;
	else 
	{
		result *= -dot(np, temp);
		
		if (result <= 0)
			result = 0;
		else
		{
			rad4 = sqr(sqrlen(temp));
			result *= area;
			result /= (rad4 * vl_pi);
		}
	}
	
	return(result);
}


GCLReal RadQuad::EdgeArea(const Vector &p, const Vector &q, const Vector &n)
{ 
	// Numerically stable edge-area calculator. (Including degenerate cases.)
	// Andrew J. Willmott, 1992

	// 4 dots, 1 cross, 1 atan per edge.

	const GCLReal epsilon = 1e-6;
	GCLReal sinFactor, qdotp, projArea;

	qdotp =  dot(p, q);
	sinFactor = sqrlen(p) * sqrlen(q) - sqr(qdotp);

	projArea = dot(-cross(p, q), n);

	if (sinFactor > 0)				// If SinFactor > 0 we may apply the formula without problem 
	{
		sinFactor = sqrt(sinFactor);
		return(projArea * (vl_halfPi - atan(qdotp / sinFactor)) / (2 * vl_pi * sinFactor));
	}								// If not, we have three remaining cases... 

	else if (qdotp > epsilon) 		// CASE 1: p and q point in the same direction }
		return(0);
	else if (qdotp < -epsilon) 		// CASE 2: Viewpoint lies on the edge }
		return(0.5);
	else
		return(0.125);				// CASE 3: Viewpoint lies at either end of the edge }
}

GCLReal RadQuad::PatchFactor(const Point &p, const Vector &np)
// Common terminology for this is the polygon-to-point form factor. 
// The 'form-factor' mentioned in radiosity papers is the average
// patch factor across a patch.
{
	Vector	x1, x2, x3;
	GCLReal	sum;
	
	x1 = Vertex(0);
	x1 -= p;
	x3 = x1;
	x2 = Vertex(1);
	x2 -= p;
	
	sum = EdgeArea(x1, x2, np);
	x1 = Vertex(2);
	x1 -= p;
	sum += EdgeArea(x2, x1, np);
	
	if (IsTri())
		sum += EdgeArea(x1, x3, np);
	else
	{
		x2 = Vertex(3);
		x2 -= p;
		sum += EdgeArea(x1, x2, np);
		sum += EdgeArea(x2, x3, np);
	}

	if (sum > 0.0)
		return(sum);
	else
		return(0.0);
}

Int RadQuad::OrientInfo(RadQuad *to)
// Returns basic orientation info: 0 = centres of
// patches are obscured, -1 = patches close enough
// to warrant good PF approx, 1 = can use standard approx.
{
	GCLReal	result, rad4, npt, res2;
	Vector	temp;

	temp = to->Centre() - Centre();
	result = -dot(to->Normal(), temp);
	
	if (result <= 0)
		return(0);
	else 
	{
		npt = dot(Normal(), temp);
		
		if (npt <= 0)
			return(0);
		else
		{
			rad4 = sqr(sqrlen(temp));
			result *= area / vl_pi;
			res2 = result * Max(npt, 0.25 * sqrt(area));

			if (props->options->quadLevel > 0 &&
				rad4 * props->options->dFError < res2)
				return(-1);
			else
				return(1);
		}
	}
}

GCLReal RadQuad::ApproxPatchFactor(const Point &p, const Vector &np)
// Uses point-to-point PF as default, and swaps to poly-to-point PF
// when necessary.
{
	GCLReal	result, rad4, npt, res2;
	Vector	temp;

	temp = p - Centre();
	
	result = -dot(np, temp);
	
	if (result <= 0)
		result = 0;
	else 
	{
		npt = dot(Normal(), temp);
		
		if (npt <= 0)
			result = 0;
		else
		{
			rad4 = sqr(sqrlen(temp));
			result *= area / vl_pi;
			res2 = result * Max(npt, 0.25 * sqrt(area));

			if (props->options->quadLevel > 0 && rad4 * props->options->dFError < res2)
			{
				// result is blowing up!
				// let's bail to the patch factor formula
				return(PatchFactor(p, np));
			}
			else
				result *= npt / rad4;
		}
	}
	
	return(result);
}

GCLReal RadQuad::EstFormFactor(RadQuad *to)
{
	GCLReal	result, rad4, npt, res2;
	Vector	temp;

	temp = to->Centre() - Centre();
	
	result = -dot(to->Normal(), temp);
	
	if (result <= 0)
		result = 0;
	else 
	{
		npt = dot(Normal(), temp);
		
		if (npt <= 0)
			result = 0;
		else
		{
			rad4 = sqr(sqrlen(temp));
			result *= area / vl_pi;
			res2 = result * Max(npt, 0.25 * sqrt(area));

			if (props->options->quadLevel > 0 && rad4 * props->options->dFError < res2)
			{
				// result is blowing up!
				// let's bail to the patch factor formula

				GCLReal sum;

				if (props->options->quadLevel > 1)
				{
					// use more-accurate PF estimate:
					// sample corners
					
					sum = PatchFactor(to->Vertex(0), to->Normal());
					sum += PatchFactor(to->Vertex(1), to->Normal());
					sum += PatchFactor(to->Vertex(2), to->Normal());
					sum += PatchFactor(to->Vertex(3), to->Normal());
					
					if (props->options->quadLevel > 2)
					{
						// estimate ff from tetrahedron constructed from
						// corner samples and centre. this will
						// underestimate the true ff slightly.
						
						sum += 2.0 * PatchFactor(to->Centre(), to->Normal());
						sum /= 6.0;
					}
					else
					// underestimate curve
						sum /= 4.0;
				}
				else
					sum = PatchFactor(to->Centre(), to->Normal());
				
				return(sum);
			}
			else
				result *= npt / rad4;
		}
	}
	
	return(result);
}

GCLReal RadQuad::EstFormFactorXtra(RadQuad *to, GCLReal &error)
{
	GCLReal	sum, sample, min, max, rn;
	Int		n = 10;
	Point	destPt;
	Vector	dx = 	 to->Vertex(2) - to->Vertex(1);
	Vector 	dy = 	 to->Vertex(1) - to->Vertex(0);
	Int		i, j;
	
	// use most-accurate PF estimate:
	// sample in a grid
	
	min = 10;
	max = -10;
	sum = 0;
	rn = n;
	
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++)
		{
			destPt = to->Vertex(0);
			destPt += ((j + 0.5) / rn) * dx;
			destPt += ((i + 0.5) / rn) * dy;
		
			sample = ApproxPatchFactor(destPt, to->Normal());
			sum += sample;
			min = Min(min, sample);
			max = Max(max, sample);
	}
	
	error = max - min;
	return(sum / sqr(n));
}

Void RadQuad::SetProps(RadProps *parentProps)
{
	Int		m;
	
	props = parentProps;
	Centre().MakeZero();
	
	centre += Vertex(0);
	centre += Vertex(1);
	centre += Vertex(2);
	if (IsQuad())
	{
		centre += Vertex(3);
		centre /= 4;
	}
	else
		centre /= 3;
}

Void RadQuad::Reanimate(RadQuad *parent)
{
	if (parent)
		SetProps(parent->props);
}

Void RadQuad::Smooth(Vecd &weights)
{
	Int j;
	Int n = 3;
	
	if (IsQuad())
		n++;
		
	for (j = 0; j < n; j++)
	{
		Clr(j) += colour;
		weights[clrIdx[j]] += 1;
	}	
}

Void RadQuad::CreatePatches(PatchList &patches, PatchStats *stats)
{
	Assert(false, "(RadQuad::CreatePatches) illegal method.");
}

Void RadQuad::Project(Renderer &r, const Colour &c, const Point &p)
{
	r
		.C(c)
		.P(p + dot(kRadRGBToLum, c) * Normal());
}

ostream &operator << (ostream &s, RadQuad &rq)
{
	rq.Print(s);
	return(s);
}

istream &operator >> (istream &s, RadQuad &rq)
{
	rq.Parse(s);
	return(s);
}


#pragma mark -
// --- Inter-patch visibility -------------------------------------


GCLReal RadQuad::Visibility16(const Point &p, const Vector &n)
//	Returns the fractional visibility of this patch from p.
{
	Vector	temp;
	GCLReal	d;

	// Is 'p' completely behind this patch?
	
	d =	dot(Normal(), Centre());
	
	if (dot(p, Normal()) < d)
		return(0.0);
	
	// Is this patch completely behind p's plane?
		
	d =	dot(n, p);

	if ((dot(Vertex(0), n) <= d)
			&& (dot(Vertex(1), n) <= d)
			&& (dot(Vertex(2), n) <= d)
			&& (IsTri() || dot(Vertex(3), n) <= d))
		return(0.0);
		
	//	If neither is the case, we have at least partial
	//	visibility, so ray cast to estimate it

	return(RadVis16x1(p, n));	
}

GCLReal RadQuad::CentreVis(const Point &p, const Vector &n)
// Returns visibility of the centre of this patch from p.
{
	Vector	temp;
	Point	dstPoint, srcPoint;
	GCLReal	d;
	Bool	hit;
	
	// Is 'p' completely behind this patch?
	
	d =	dot(Normal(), Centre());
	
	if ((dot(p, Normal())) <= d)
		return(0.0);
	
	// Is the centre of this patch behind p's plane?
		
	d =	dot(n, p);

	if (dot(Centre(), n) <= d)
		return(0.0);
		
	//	If neither is the case, we have at least partial
	//	visibility, so ray cast to estimate it

	srcPoint = p;
	srcPoint += n * surfEps;
	dstPoint = Centre();
	dstPoint += Normal() * surfEps;

	hit = RadCast(props->options->scene)->IntersectsWithRay(srcPoint, dstPoint);
	props->options->rays += 1;

	if (props->options->showRays)
	{
		if (hit)
			props->options->display->
				Begin(renLines).C(cRed).P(srcPoint).P(dstPoint).End();
		else
			props->options->display->
				Begin(renLines).C(cGreen).P(srcPoint).P(dstPoint).End();
	}

	if (hit)
		return(0.0);
	else
		return(1.0);
}

Bool RadQuad::PotentiallyVis(RadQuad *to)
// Checks to see whether any part of to is potentially visible
// from this patch, and vice versa. 
// returns true if there is potential visibility, false if not.
{
	Vector	temp;
	GCLReal	dFrom, dTo;

	// Is 'to' completely behind this patch?
	
	dFrom =	dot(Normal(), Vertex(0));
	
	if ((dot(to->Vertex(0), Normal()) <= dFrom)
			&& (dot(to->Vertex(1), Normal()) <= dFrom)
			&& (dot(to->Vertex(2), Normal()) <= dFrom)
			&& (to->IsTri() || dot(to->Vertex(3), Normal()) <= dFrom))
		return(false);
	
	// Is this patch completely behind 'to'?
		
	dTo =	dot(to->Normal(), to->Vertex(0));

	if ((dot(Vertex(0), to->Normal()) <= dTo)
			&& (dot(Vertex(1), to->Normal()) <= dTo)
			&& (dot(Vertex(2), to->Normal()) <= dTo)
			&& (IsTri() || dot(Vertex(3), to->Normal()) <= dTo))
		return(false);
		
	//	If neither is the case, we have at least potential
	//	visibility.

	return(true);
}

Bool RadQuad::PotentiallyVisAndTouching(RadQuad *to, Bool &touching)
// Checks to see whether any part of to is potentially visible
// from this patch, and vice versa. 
// returns true if there is potential visibility, false if not.
// Also sets touching to true if the two patches intersect or touch.
{
	Vector	temp;
	GCLReal	dFrom, dTo, a;
	Bool	pvis, touch;
	Int		n, z, p;
	
	touching = false;
	dFrom =	dot(Normal(), Vertex(0));
	n = p = z = 0;

	// we count p=points above plane, z=points on plane, n = points below plane.
	// pvis = at least 1 p1 coeff +ve && at least 1 p2 coeff +ve
	// touch: p1-touch && p2-touch
	// x-touch: x coeffs not all +ve or all -ve.
	// 
	
	// opt: can do early termination of touch as soon as z>0 or p&n
	//      can do early termination of pvis as soon as p>0
	//		can terminate both iff p>0 && (z>0 | n>0)
	//	currently don't do this 'cause extra testing might
	//	kill the optimisations, and I'm lazy...
	//
			
	a = dot(to->Vertex(0), Normal()) - dFrom;
	if (a > 0) p++; else if (a < 0) n++; else z++;
	a = dot(to->Vertex(1), Normal()) - dFrom;
	if (a > 0) p++; else if (a < 0) n++; else z++;
	a = dot(to->Vertex(2), Normal()) - dFrom;
	if (a > 0) p++; else if (a < 0) n++; else z++;
	if (to->IsTri())
	{
		a = dot(to->Vertex(3), Normal()) - dFrom;
		if (a > 0) p++; else if (a < 0) n++; else z++;
	}
		
	pvis = p;
	touch = z || (p && n);
		
	if (!pvis && !touch)
		return(false);

	dTo =	dot(to->Normal(), to->Vertex(0));
	n = p = z = 0;

	a = dot(Vertex(0), to->Normal()) - dTo;
	if (a > 0) p++; else if (a < 0) n++; else z++;
	a = dot(Vertex(1), to->Normal()) - dTo;
	if (a > 0) p++; else if (a < 0) n++; else z++;
	a = dot(Vertex(2), to->Normal()) - dTo;
	if (a > 0) p++; else if (a < 0) n++; else z++;
	if (IsTri())
	{
		a = dot(Vertex(3), to->Normal()) - dTo;
		if (a > 0) p++; else if (a < 0) n++; else z++;
	}
		
	if (touch && (z || (p && n)))
		touching = true;
	return(pvis & p);
}

GCLReal RadQuad::Visibility44(RadQuad *to)
{
	if (PotentiallyVis(to))
		return(RadVis4x4(to));	
	else
		return(0.0);
}

GCLReal RadQuad::Visibility(RadQuad *to)
{
	switch(props->options->visibility)
	{
	case vis_none:
		return(1.0);
	case vis_1:
		return(CentreVis(to->Centre(), to->Normal()));
	case vis_16x1:
		return(Visibility16(to->Centre(), to->Normal()));
	case vis_4x4:
		return(Visibility44(to));
	default:
		Assert(false, "Illegal visibility method specified!");
	}
	
	return(1.0);	// Keep dimwit compiler happy.
}


//	Arrays for jittered sampling; 4 x 4 source, 4 x 4 dest.

#include "MSJitter.cc"	

static Int gRotPick = 0;

/*	
	Routine: RadVis4x4
	Measures visibility between the patch and q.
	Returns visibility factor between 0 and 1. 
	Uses magic-square jittered 4x4 pattern, a la HR paper.
	Assumes quadrilateral is parallelogram.
 */

GCLReal RadQuad::RadVis4x4(RadQuad *to)
{
	Int			i, misses, showMisses;
	Vector		srcHoriz, srcVert, dstHoriz, dstVert;
	Point		srcPoint, dstPoint;
	Coord		*s1, *d1;
	Bool		hit;
			
	srcVert = Vertex(1) - Vertex(0);
	srcHoriz = Vertex(2) - Vertex(1);
	dstVert =  to->Vertex(1) - to->Vertex(0);
	dstHoriz = to->Vertex(2) - to->Vertex(1);
	misses = 0;
	showMisses = 0;

	if (IsQuad())
	 	s1 = (Coord *) tSource4x4[gRotPick]; 
	else
	 	s1 = (Coord *) tTriSource4x4[gRotPick]; 

	if (to->IsQuad())
	 	d1 = (Coord *) tDest4x4[gRotPick]; 
	else
		d1 = (Coord *) tTriDest4x4[gRotPick]; 
		
	if (props->options->showRays)
		RM_DISPLAY_START;

	props->options->rays += 16;
	
	for (i = 0; i < 16; i++)
	{
		srcPoint = Vertex(0) + s1[i][0] * srcHoriz + (1 - s1[i][1]) * srcVert + surfEps * Normal();
		dstPoint = to->Vertex(0) + d1[i][0] * dstHoriz + (1 - d1[i][1]) * dstVert + surfEps * to->Normal();
		
		hit = RadCast(props->options->scene)->IntersectsWithRay(srcPoint, dstPoint);
		
		if (hit)
			misses++;

		if (props->options->showRays)
		{
			if (hit)
				props->options->display->Begin(renLines).C(cRed).P(srcPoint).P(dstPoint).End();
			else
				props->options->display->Begin(renLines).C(cGreen).P(srcPoint).P(dstPoint).End();
		}
	}
		
	if (props->options->showRays)
	{
		RM_DISPLAY_END;
		RM_OUT1("Visibility: " << GCLReal(16 - misses) * 1.0 / 16.0);
		if (RM_PAUSE) return(0);
	}


	if (props->options->jitterRot)
		if (++gRotPick == kNumMSArrays)
			gRotPick = 0;
		
	return((16 - misses) * 1.0 / 16.0);
}

/*	
	Routine: RadVis16x1
	Measures visibility between the patch and point p by
	casting 16 rays between the two.
	Returns visibility factor between 0 and 1. 
	Uses magic-square jittered 4x4 pattern
	Assumes quadrilateral is parallelogram.
 */

GCLReal RadQuad::RadVis16x1(const Point &p, const Vector &n)
{
	Int			i, misses, showMisses;
	Vector		srcHoriz, srcVert;
	Point		srcPoint, dstPoint;
	Coord		*s1;
	Bool		hit;
			
	dstPoint = p;
	dstPoint += surfEps * n;
	srcVert = Vertex(1) - Vertex(0);
	srcHoriz = Vertex(2) - Vertex(1);
	misses = 0;
	showMisses = 0;

	if (IsQuad())
	 	s1 = (Coord *) tSource4x4[gRotPick]; 
	else
	 	s1 = (Coord *) tTriSource4x4[gRotPick]; 
		
	if (props->options->showRays)
		RM_DISPLAY_START;

	props->options->rays += 16;
	
	for (i = 0; i < 16; i++)
	{
		srcPoint = Vertex(0) + s1[i][0] * srcHoriz + (1 - s1[i][1]) * srcVert;
		srcPoint += surfEps * Normal();
		
		hit = RadCast(props->options->scene)->IntersectsWithRay(srcPoint, dstPoint);
		
		if (hit)
			misses++;

		if (props->options->showRays)
		{
			if (hit)
				props->options->display->
					Begin(renLines).C(cRed).P(srcPoint).P(dstPoint).End();
			else
				props->options->display->
					Begin(renLines).C(cGreen).P(srcPoint).P(dstPoint).End();
		}
	}
		
	if (props->options->showRays)
	{
		RM_DISPLAY_END;
		RM_OUT1("Visibility: " << GCLReal(16 - misses) * 1.0 / 16.0);
		if (RM_PAUSE) return(0);
	}
		
	if (props->options->jitterRot)
		if (++gRotPick == kNumMSArrays)
			gRotPick = 0;

	return(GCLReal(16 - misses) / 16.0);
}


#pragma mark -
// --- Grid Subdivision -------------------------------------------------------------

/*
	First a diagram to give some context. We will be adding elements to a mesh in 
	horizontal strips:
	
	Quad strip:
	
	+-+-+-+-+-+
	|0|1|2|3|4|
	+-+-+-+-+-+
	|5|6|7| ...
	+-+-+-O

	Tri strip:
							  0 +
	|\							|\
	|0\			Orientation:	| \
	+--+					  1 +--+ 2
	|\2|\
	|1\|3\					  0 +--+ 2
	+--+--+						 \ |
	|\5|\				and:	  \|
	|4\|6\ ...				  	   + 1
	+--+--O
*/

Void GridRadQuad::AddChild(RadQuad &quad, Int i, Int j, Int in, Int jn)
{
	children.Append(quad);
}

Void GridRadQuadBase::Mesh(GCLReal density)
// Meshes an element into a grid of similar elements of roughly the given density.
{
	Int		i, j, in, jn, idx1, cIdx1, m;
	RadQuad	child, child2;
	Vector	w, h, dw, dh, pt0, pt1;
	Int		im, jm;
		
	//	Setup increments, step sizes, etc.

	if (props->options->mesh == mesh_random)
	{
		density = (0.1 + 0.9 * drand48()) * density;
	}

	w = Vertex(2) - Vertex(1);	// basis vectors
	h = Vertex(1) - Vertex(0);
	
	in = ceil(len(h) * density);
	jn = ceil(len(w) * density);
	
	// For triangles we must subdivide equally in both directions.
	
	if (IsTri())			
	{
		if (jn < in)
			jn = in;
		else
			in = jn;
	}
	
	if (props->options->mesh != mesh_nonlin)
	{
		im = 0;
		jm = 0;
		w /= jn;
		h /= in;
		child.area = len(w) * len(h);
		if (IsTri())
			child.area *= 0.5;
		child2.area = child.area;	// child2 is always a triangle: it is not used for quad meshing.
	}
	else
	{
		if ((jn % 2) == 1)
			w /= sqr(jn + 1) / 4.0;
		else
			w /= (sqr(jn + 1) - 1) / 4.0;
			
		if ((in % 2) == 1)
			h /= sqr(in + 1) / 4.0;
		else
			h /= (sqr(in + 1) - 1) / 4.0;

		jm = jn;
		im = in;
		dw = w;
		dh = h;
	}
		
	// Set up templates for new elements
	
	child2.index[3] = -1;
	child2.clrIdx[3] = -1;

	// Set up some point stuff

	pt0 = Vertex(0);						// Upper-left corner of the element
	child.index[0] = index[0];				// Index of same
	child.clrIdx[0] = clrIdx[0];			
	
	pt1 = pt0;
	
	//	For a quad, we need to pre-allocate new colours/vertices along the top of
	//	the element.

	if (IsQuad())
		for (j = 0; j < jn - 1; j++)		
		{						
			pt1 += w;

			if (jm > 0)
			{
				if (2 * (j + 1) < jm)
					w += dw;
				else if (2 * (j + 1) > jm)
					w -= dw;
			}
			
			if (j == 0)
			{
				child.index[3] = props->AddPoint(pt1);	// remember first indices
				child.clrIdx[3] = props->AddColour(cRed);
			}
			else
			{
				props->AddPoint(pt1);
				props->AddColour(cRed);
			}
		}
	
	// Now add the new quads/tri's to the grid in turn, from left to right, and top to bottom.
	// Each new quad or pair of tri's will require a new bottom-right vertex.			

	for (i = 0; i < in; i++)		
	{						
		pt1 = pt0 + h;
		
		if (i == in - 1)				// Special-case original bottom-left vertex.
		{
			child.index[1] = index[1];
			child.clrIdx[1] = clrIdx[1];
		}
		else
		{
			child.index[1] = props->AddPoint(pt1);
			child.clrIdx[1] = props->AddColour(cRed);
		}
		
		idx1 = child.index[1];
		cIdx1 = child.clrIdx[1];
		
		//	Add one row of quads/tri's		
				
		if (jm > 0)
			w = dw;
				
		for (j = 0; j < jn; j++)
		{
			pt1 += w;							// For each quad, we add the bottom-right corner as a new point.
			
			if (j == jn - 1 && i == in - 1)		// Special-case original bottom-right corner
			{
				child.index[2] = index[2];
				child.clrIdx[2] = clrIdx[2];
			}
			else
			{
				child.index[2] = props->AddPoint(pt1);
				child.clrIdx[2] = props->AddColour(cRed);
			}
			
			if (IsTri())
			{				
				//	For triangles: we add them in pairs. The first triangle...

				child.index[3] = -1;		
				child.clrIdx[3] = -1;
				child.SetProps(props);
				if (jm > 0)
				{
					child.area = 0.5 * len(w) * len(h);
					child2.area = child.area;
				}
				AddChild(child, i, j, in, jn);
				
				if (j == i)							// if we're at the end of a triangle strip
					break;							// break to the outer loop
				
				if (i == 0 && j == jn - 1)			// Special-case original top-right corner
				{
					child.index[3] = index[3];
					child.clrIdx[3] = clrIdx[3];
				}
				else if (i != 0 || j != 0)
				{
					child.index[3] = child.index[0] + 1;
					child.clrIdx[3] = child.clrIdx[0] + 1;
				}
				
				//	then the second triangle.
				
				child2.index[0] = child.index[2];	child2.clrIdx[0] = child.clrIdx[2];
				child2.index[1] = child.index[3];	child2.clrIdx[1] = child.clrIdx[3];
				child2.index[2] = child.index[0];	child2.clrIdx[2] = child.clrIdx[0];
				
				child2.SetProps(props);		// XXX: not obvious here that SetProps needs indices defined.
				AddChild(child2, i, j, in, jn);
			}
			else
			{		
				//	For quadrilaterals: we calculate bottom-right vertex immediately

				if (i == 0 && j == jn - 1)			// Special-case original top-right corner
				{
					child.index[3] = index[3];
					child.clrIdx[3] = clrIdx[3];
				}
				else if (i != 0 || j != 0)
				{
					child.index[3] = child.index[0] + 1;
					child.clrIdx[3] = child.clrIdx[0] + 1;
				}
	
				// And add the new quad...
	
				if (jm > 0)
					child.area = len(w) * len(h);
				child.SetProps(props);
				AddChild(child, i, j, in, jn);				
			}

			if (jm > 0)
			{
				if (2 * (j + 1) < jm)
					w += dw;
				else if (2 * (j + 1) > jm)
					w -= dw;
			}
			
			// Move on to next quad/tri pair: shift the indices left.
					
			child.index[0] = child.index[3];	child.clrIdx[0] = child.clrIdx[3];
			child.index[1] = child.index[2];	child.clrIdx[1] = child.clrIdx[2];
		}

		// Move on to next row, resetting necessary variables
		
		child.index[0] = idx1;	
		child.clrIdx[0] = cIdx1;
		pt0 += h;

		if (im > 0)
		{
			if (2 * (i + 1) < im)
				h += dh;
			else if (2 * (i + 1) > im)
				h -= dh;
		}
	}
	
	rows = in;
	cols = jn;
}


#pragma mark -


Void GridRadQuad::Draw(Renderer &r)
{
	if (children.NumItems() > 0 && !highlight)
	{
		Int i;
		
		for (i = 0; i < children.NumItems(); i++)
			children[i].Draw(r);
	}
	else
		RadQuad::Draw(r);
}

Void GridRadQuad::CreatePatches(PatchList &patches, PatchStats *stats)
{
	Int		i;
	
	if (stats)
	{
		FindMinCmpts(stats->minRefl, props->reflectance, stats->minRefl);
		FindMaxCmpts(stats->maxRefl, props->reflectance, stats->maxRefl);
	}

	if (props->options->patchSubdivs == 0.0)
	{
		patches.Append(this);
		return;
	}
		
	Mesh(props->options->patchSubdivs);	

	for (i = 0; i < children.NumItems(); i++)
	{
		patches.Append(&(children[i]));
			
		if (stats)
		{
			if (children[i].area > stats->maxArea)
				stats->maxArea = children[i].area;
			if (children[i].area < stats->minArea)
				stats->minArea = children[i].area;
		}
	}
}

Int GridRadQuadBase::FindChildIndex(Coord &coord)
{
	Int		x, y, xy;
	GCLReal	rx, ry;
	
	if (IsTri())
	{			
		rx = coord[0];
		ry = 1 - coord[1];

		// Do some checking...

		if ((rx - ry) > 1 || rx < 0 || ry < 0)
			return(0);

		rx *= cols;
		ry *= rows;

		x = rx;
		if (x == cols)
			x--;
		y = ry;
		if (y == rows)
			y--;	

		xy = rows * (coord[0] + coord[1]);
		if (xy == rows)
			xy--;	

		if (xy > x + (rows - y - 1))
		{
			x = 2 * x + 1;
			coord[0] = x + 1 - rx;
			coord[1] = ry - y;
		}
		else
		{
			x = 2 * x;
			coord[0] = rx - x;
			coord[1] = y + 1 - ry;
		}
		
		return(x + sqr(y));
	}
	else
	{
		rx = (coord[0] + 1.0) / 2.0;
		ry = (-coord[1] + 1.0) / 2.0;

		// Do some checking...

		if (rx < 0 || ry < 0 || rx > 1 || ry > 1)
			return(0);

		rx *= cols;
		ry *= rows;

		x = rx;
		if (x == cols)
			x = cols - 1;
		y = ry;
		if (y == rows)
			y = rows - 1;	
		
		coord[0] = (rx - x) * 2 - 1;
		coord[1] = (y - ry) * 2 + 1;
		
		return(x + y * cols);
	}
}

RadQuad *GridRadQuad::FindContainer(Coord &coord)
{
	Int i = FindChildIndex(coord);
	
	return(children[i].FindContainer(coord));
}

Void GridRadQuad::Smooth(Vecd &weights)
{
	Int i;
	
	for (i = 0; i < children.NumItems(); i++)
		children[i].Smooth(weights);
}

Void GridRadQuad::Print(ostream &s)
{
	s << " +grid ";
	RadQuad::Print(s);
	s << rows << ' ' << cols << ' ' << children << ' ';
}

Void GridRadQuad::Parse(istream &s)
{
	Char c;
	Int i;
	
	RadQuad::Parse(s);
	
	s >> rows >> cols;
	
	children.SetSize(rows * cols);

	ChompSpace(s);	// XXX temporary workaround for >> failure on long line...
	s.get(c);
	for (i = 0; i < children.NumItems(); i++)
		children[i].Parse(s);
	ChompSpace(s);
	s.get(c);
}

Void GridRadQuad::Reanimate(RadQuad *parent)
{
	Int i;

	RadQuad::Reanimate(parent);

	for (i = 0; i < children.NumItems(); i++)
		children[i].Reanimate(this);
}


#pragma mark -


Int RadProps::AddPoint(const Point &p)
{
	points->Append(p);
	return(points->NumItems() - 1);
}

Int RadProps::AddColour(const Colour &c)
{
	colours->Append(c);
	return(colours->NumItems() - 1);
}

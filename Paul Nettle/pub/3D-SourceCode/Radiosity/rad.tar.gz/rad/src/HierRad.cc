/*
	File:			HierRad.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			Integrates Wavelet radiosity.

*/

#include "HierRad.h"
#include "Haar.h"
#include "Flatlets.h"
#include "MultiWavelets.h"

   

Void HierRad::SetScene(scScenePtr theScene)
{
	scene = Clone(theScene);
	options.scene = scene;
	RadCast(scene)->ApplyTransforms();
	RadCast(scene)->InitRad(options);
	RadCast(scene)->Smooth();
	
	trees.Clear();
	RadCast(scene)->GetTrees(trees);

	Int i;
	for (i = 0; i < trees.NumItems(); i++)
		trees[i]->Prepare();    
	
}

Void HierRad::DrawMatrix(Renderer &r)
{
}   

LinkNode *HierRad::TopLink(HRQuad *fromPatch, HRQuad *toPatch)
{
	LinkNode *result;
	
	//	Create a top-level link between two patches
	
	if (options.basis == kHaar)
		result = (LinkNode *) new HaarLink;
	else if (options.basis == kFlatlet2)
		result = (LinkNode *) new F2Link;
	else if (options.basis == kFlatlet3)
		result = (LinkNode *) new F3Link;
	else if (options.basis == kMultiwavelet2)
		result = (LinkNode *) new M2Link;
	else if (options.basis == kMultiwavelet3)
		result = (LinkNode *) new M3Link;
	else
		Assert(false, "(HierRad::TopLink) Unsupported basis");
		
	result->visibility = 0.5;
	result->Set(fromPatch, toPatch);
	
	return(result);
}

// XXX factor out...

#define BEGIN_REF
#define END_REF


Bool HierRad::Render()
{
	Int			i, j;
	Bool		converged, done, subdivided;
	LinkNode	*newLink;
	GCLReal		visibility;
	GCLReal		origErr = 1.0;
	
	//	Initialisation
	
	error = 1.0;
	iterations = 0;
	
	// XXX currently there is a (superficial) bug with M3 patches and
	// graded meshes. As none of the higher-level wavelet methods
	// use graded meshes/anchoring, we avoid the problem by setting
	// those options off here.
	
	if (options.basis != kHaar)
	{
		options.anchor = false;
		options.graded = false;
	}
	
	for (i = 0; i < trees.NumItems(); i++)
	{
		trees[i]->Prepare();
		trees[i]->colour = trees[i]->Reflectance() + trees[i]->Emittance();    
	}
	
	RadMethod::Render();
	
	if (Stage(1)) return(0);
	
	//	Set up initial emission of the patches
	
	if (Stage(2)) return(0);
		
	// --- Create top-level links between patches -------------------------

	// We only want to test visibility once
	// between each pair of patches.

	for (i = 0; i < trees.NumItems(); i++)
	{
		linkPatch = i;

		for (j = i + 1; j < trees.NumItems(); j++)
		{
			if (Stage(3)) return(0);

			visibility = trees[i]->Visibility(trees[j]);
			
			if (visibility == 0.0)
				continue;

			if (trees[i]->Reflectance() != cBlack)
			{
				// Add link from j -> i
							
				newLink = TopLink(trees[j], trees[i]);
				newLink->visibility = visibility;

				if (options.multiGrid)
					trees[i]->links.Prepend(newLink);
				else
				{
					BEGIN_REF
					trees[i]->Refine(newLink);
					END_REF
				}
			}		
			
			if (trees[j]->Reflectance() != cBlack)
			{
				// Add link from i -> j

				newLink = TopLink(trees[i], trees[j]);
				newLink->visibility = visibility;

				if (options.multiGrid)
					trees[j]->links.Prepend(newLink);
				else
				{
					BEGIN_REF
					trees[j]->Refine(newLink);
					END_REF
				}
			}		
		}			
	}
			
	if (Stage(4)) return(0);
	
	// --- Main loop ------------------------------------
	
	done = false;
	subdivided = false;
	
	do
	{
		GCLReal	resErr = 0.0;
		
		iterations++;

		//	Do a gather over the whole scene
		
		for (i = 0; i < trees.NumItems(); i++)
		{
			poly = i;
			trees[i]->GatherAll();
		}

		//	Now reconstruct the basis functions with.
		//	Separating the gather and push/pull stages like
		//	this is the equivalent of Jacobi iteration, which is
		//	more memory and time consuming than Gauss Seidel. Our
		//	experiments with Gauss Seidel have shown that it can
		//	lead to some instability problems however, especially
		//	when there are a small number of very bright lights.
			
		for (i = 0; i < trees.NumItems(); i++)
		{
			poly = i;
			if (Stage(7)) return(0);
			
			trees[i]->Prepare();

			if (Stage(8)) return(0);
			
			trees[i]->PushPull();
			resErr += abs(trees[i]->Error());

			if (Stage(9)) return(0);
		}
		
		if (origErr == 1.0)
			origErr = resErr;
		error = resErr / origErr;

		if (!options.multiGrid && iterations > 1 && error < options.error)
		{
			done = true;
			continue;
		}
		
		if (Stage(10)) return(0);		
				
		//	Refine the links in the scene
				
		if (options.multiGrid)
		{
			subdivided = false;

			for (i = 0; i < trees.NumItems(); i++)
			{
				linkPatch = i;
				if (Stage(5)) return(0);
				if (trees[i]->RefineFurther())
					subdivided = true;
			}
			
			if (Stage(6)) return(0);
			
			if ((!options.refAllLinks || !subdivided) && (error < options.error))
				done = true;
		}
	}
	while (!done);
	
	if (Stage(11)) return(0);
	
	return(1);
}



static Char *tBasis[] = {"none", "haar", "f2", "f3", "m2", "m3"};
static Int tBasisOrder[] = {0, 1, 2, 3, 2, 3};

static GCLReal gAlpha = 0.0;
static Int gLinks0 = 0;

Void HierRad::DumpStats()
{
	Int		i, m = tBasisOrder[options.basis];
	GCLReal	mem, linkMem, nodeMem;
	
	options.numLinks = 0;
	options.numPatches = 0;

	for (i = 0; i < trees.NumItems(); i++)
		trees[i]->CalcStats();
	
	// Calculate projected memory use
	linkMem = sizeof(Void*) * 2 + sizeof(GCLReal) + sizeof(Colour) * sqr(sqr(m));
	nodeMem = sizeof(Void*) * 5 + sizeof(Colour) * sqr(m);
	mem = linkMem * options.numLinks + nodeMem * options.numPatches;
	mem /= 1024.0;
	
	if (gAlpha <= 0.0)
		gLinks0 = options.numLinks;

	if (gAlpha < 0.0)
		gAlpha = options.numLinks / sqr(options.numPolys);
		
	cout << dumpID
		<< ' ' << options.totTime
		<< ' ' << options.stage
		<< ' ' << iterations
		<< ' ' << options.numPatches
		<< ' ' << options.numLinks
		<< ' ' << gAlpha
		<< ' ' << options.numLinks - gLinks0

		<< ' ' << error
		<< ' ' << options.rays
		<< ' ' << mem
		<< endl;

	DumpScene();
}

Int HierRad::Stage(Int stage)
{
	if (CheckTime()) return(1);
	
	options.stage = stage;

	switch (stage)
	{
	case 1:
		cout << "renderer " << radRenderVersion << endl;
		cout << "method hier " << tBasis[options.basis] << endl;
		cout << "tErr " << options.error << endl;
		cout << "fErr " << options.kFError << endl;
		cout << "aErr " << options.kAError << endl;
		cout << "dErr " << options.dFError << endl;
		cout << "vErr " << options.visError << endl;
		cout << "scene " << scene->Label() << endl;
		cout << "quads " << options.numPolys << endl;
		cout << "srcPatches " << trees.NumItems() << endl;
		cout << "format ID time stage iterations patches links sparsity newLinks resErr rays mem" << endl;
		cout << "-------------------------------------------------------------" << endl;

		options.rays = 0;
		options.totTime = 0;
		options.pfTime = 0;
		options.visTime = 0;
		options.drawTime = 0;
		options.solveTime = 0;
		lastTime = 0;
		DumpStats();
		break;
		
	case 2:	
		break;
		
	case 3:		
		break;
		
	case 4:	
		// At this point the first-pass linking has been done.
		gAlpha = -1.0;	// signal the DumpStats procedure
		DumpStats();
		break;
		
	case 5:	
		break;
		
	case 6:	
		break;
		
	case 7:
		break;
		
	case 8:
		break;
		
	case 9:
		break;
		
	case 10:
		break;
		
	case 11:
		DumpStats();
		break;
	}
	
	if (Idle()) return(0);
	ContTimer();
	return(0);
}


RadQuad *HierRad::NewMesh()
{
	RadQuad *elem;

	if (options.basis == kHaar)
		elem = new HaarQuad();
	else if (options.basis == kMultiwavelet2)
		elem = new M2Quad();
	else if (options.basis == kMultiwavelet3)
		elem = new M3Quad();
	else if (options.basis == kFlatlet2)
		elem = new F2Quad();
	else if (options.basis == kFlatlet3)
		elem = new F3Quad();
	else
		Assert(false, "(HierRad::NewMesh) Unhandled basis");
	
	return(elem);
}

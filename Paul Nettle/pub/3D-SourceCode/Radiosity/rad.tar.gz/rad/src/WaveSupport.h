#ifndef __WaveSupport__
#define __WaveSupport__

#include "Renderer.h"
#include "Geometry.h"
#include "Colour.h"

// Matrix and Vector operations

GCLReal CalcError(Colour *B1, Colour *B2,  Int n);
Colour Average(Colour *B, Int n);
Void Scale(Colour *c, Int n, GCLReal s);

Void Mult(const Matd &m, Colour *src, Colour *dst);
Void MultAcc(const Matd &m, Colour *src, Colour *dst);

Void TensorMult(const Matd &m, Colour *src, Colour *dst);
Void LeftTensorMult(const Matd &m, Colour *src, Colour *dst);
Void RightTensorMult(const Matd &m, Colour *src, Colour *dst);
Void LeftTensorMultAcc(const Matd &m, Colour *src, Colour *dst);
Void RightTensorMultAcc(const Matd &m, Colour *src, Colour *dst);

Void MakeTensorMatrix(const Matd &t, Matd &m);
// m = T, where T is the tensor-product of matrix t with itself. O(n^4)
Void LeftTensorMult(const Matd &t, const Matd &k, Matd &d);
// d = T * k, where T is the tensor-product of matrix t with itself.
// O(mn^3).
Void RightTensorMult(const Matd &k, const Matd &t, Matd &d);
// d = k * T, where T is the tensor-product of matrix t with itself.
// O(mn^3).

// Utility routines

Colour M2QuadSample(Coord &c, Colour *B);
Colour M2TriSample(Coord &c, Colour *B);
Colour M3QuadSample(Coord &c, Colour *B);
Colour M3TriSample(Coord &c, Colour *B);

Void DrawWaveLink(Renderer &r, GCLReal left, GCLReal top, 
	GCLReal right, GCLReal bottom, Colour weight, const Matd &m);

GCLReal MaxElt(const Matd &m);

#endif

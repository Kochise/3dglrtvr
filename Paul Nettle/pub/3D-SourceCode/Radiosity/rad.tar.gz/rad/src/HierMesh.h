/*
	File:			HierMesh.h

	Function:		Provides a recursively-subdividable mesh of quadrilaterals
					or triangles.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */


#ifndef __HierMesh__
#define __HierMesh__

#include "RadMesh.h"

class HierQuad : public RadQuad		// quadrilateral capable of subdivision...
{
public:
	HierQuad();
	~HierQuad();
	
	virtual Void		SetParent(HierQuad &parent);
	virtual HierQuad 	*New() { return(new HierQuad); };
	
	Bool				HasChildren() { return(child[0] != 0);};
	
	Void 				Draw(Renderer &r);
	virtual Void 		DrawLeaf(Renderer &r);
	Void				DrawQuad(Renderer &r, RenderStyle start, Int code, Point *midPoint, Colour *midColour);
	Void				DrawTri(Renderer &r, RenderStyle start, Int code, Point *midPoint, Colour *midColour);
	Void				ProjTri(Renderer &r, RenderStyle start, Int code, Point *midPoint, Colour *midColour);
	Void				ProjQuad(Renderer &r, RenderStyle start, Int code, Point *midPoint, Colour *midColour);
	
	Void				Reanimate(RadQuad *parent);
	Void				ConnectNeighbours();
	Void 				Subdivide();

	Void				SetColour(const Colour &c);
	Void 				SetIndexes(Int i1, Int i2, Int i3, Int i4);
	Void 				SetClrIdxs(Int i1, Int i2, Int i3, Int i4);

	Void 				Smooth(Vecd &weights);
	RadQuad				*FindContainer(Coord &coord);	// find the quad containing this coord.

	Void				CollectColour(Colour &c);

	Void				CreatePatches(PatchList &patches, PatchStats *stats);
	Void				CreateElements(PatchList &elements, IndexList &eltParents, Int parent);
	GCLReal				RadError();
		
	// Printing and Parsing
	Void				Print(ostream &s);	
	Void				PrintRec(ostream &s);	
	virtual Void		PrintSelf(ostream &s);	
	Void				Parse(istream &s);	
	virtual Void		ParseSelf(istream &s);	
	Void				PrintID(ostream &s);	// Print code ID.

	// Fields	
	HierQuad			*neighbour[4];		// Pointers to neighbours of this patch...
	HierQuad			*child[4];			// Children, if subdivided...
	HierQuad			*parent;
	
	Int					level;		// level of the quadtree.
	Int32				treeCode;	// used to encode position in quadtree.
};

/*
	Field explanations.
	
	treeCode: 	Defines the path from the root of the tree to this node.
				At level i of the tree, (3 & (treeCode >> (2 * (level - i)))) is the child to follow. 
				E.g., treeCode = 011110 for a level 3 patch: the patch is child 2 of child 3 of child 1 of the root. 
				With 32 bit integers, this allows for 16 different levels:
				the lowest will have 1/65535 the side length of the highest,
				so that should be plenty.
				I.e: level should be < 16!
*/


class GridHierQuad : public GridRadQuadBase
{
public:
	Void			CreatePatches(PatchList &patches, PatchStats *stats);
	Void 			Draw(Renderer &r);
	Void			Smooth(Vecd &weights);
	RadQuad 		*FindContainer(Coord &coord);	
	Void			Reanimate(RadQuad *parent);
	
	Void			Print(ostream &s);	
	Void			Parse(istream &s);	

	Void			AddChild(RadQuad &quad, Int i, Int j, Int in, Int jn);	// override.
	Void			ConnectChildren();

	// Fields
	Array<HierQuad>	children;
};


#endif

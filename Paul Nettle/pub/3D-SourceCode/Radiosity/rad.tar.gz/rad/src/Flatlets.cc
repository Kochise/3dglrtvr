/*
	File:			Flatlets.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

*/

#include "Flatlets.h"
#include "WaveCoeffs.h"
#include "WaveSupport.h"

#define F2Child(x) ((F2Quad *) child[x])
#define F2Cast(x) ((F2Quad *) x)


// --- F2Link methods -----------------


Void F2Link::CalcTransport()
//	Calculate F2 transport coefficients.
{
	Int			i, j, k, l;
	GCLReal		t;
	GCLReal		*visPtr = 0, *tp = transport;
	
	if (to->props->options->visInQuad && visibility < 1.0)
	{
		visPtr = &visibility;
		visibility = 0.0;
	}
	
	factor = 0.0;
	
	for (i = 0; i < 2; i++)
		for (j = 0; j < 2; j++)
			for (k = 0; k < 2; k++)
				for (l = 0; l < 2; l++)
				{
					t = F2Cast(from)->SubToSubFormFactor(
						k, l, to, i, j, 2, visPtr);
					if (factor < t)
						factor = t;
					*tp++ = t;
				}

	if (visPtr)
		*visPtr /= 16.0;
	else
		Matd(4, 4, transport) *= visibility;
}

LinkNode *F2Link::CreateSubLink(HRQuad *fromPatch, HRQuad *toPatch)
{
	F2Link *result = new F2Link;
	
	result->visibility = visibility;
	result->Set(fromPatch, toPatch);
		
	return((LinkNode *) result);
}

Void F2Link::Set(HRQuad *fromPatch, HRQuad *toPatch)
{
	from = fromPatch;
	to = toPatch;
	factor = 0.0;

	if (NeedVisibility())
	{
		if (to->props->options->visInQuad)
		{
			// do trivial test; if there is some potential
			// visibility, we'll calculate it during quadrature.
			if (!from->PotentiallyVis(to))
				visibility = 0.0;
		}
		else
			visibility = from->Visibility(to);
	}
					
	CalcTransport();
}

Void F2Link::Gather()
{
	F2Quad *fto = F2Cast(to), *ffrom = F2Cast(from);
	MultAcc(Matd(fto->Coeffs(), ffrom->Coeffs(), transport), ffrom->B, fto->R);
}

GCLReal F2Link::Error()
{
	return(factor * visibility);
}

GCLReal F2Link::BFError()
{
	return(to->area * factor * dot(kRadRGBToLum, to->Reflectance() * 
		Average(F2Cast(from)->B, F2Cast(from)->Coeffs())));
}

Void F2Link::Print(ostream &s)
{
	RadLink::Print(s);
	s << " transport = " << Matd(F2Cast(to)->Coeffs(), F2Cast(from)->Coeffs(), transport)
		<< " vis = " << visibility; 
}

Void F2Link::DrawLink(Renderer &r, GCLReal left, GCLReal top, 
		GCLReal right, GCLReal bottom, GCLReal weight)
{
	DrawWaveLink(r, left, top, right, bottom, to->Reflectance() * weight,
		Matd(Matd(F2Cast(to)->Coeffs(), F2Cast(from)->Coeffs(), transport)));
}


#pragma mark -
// --- F2Quad methods ----------------------------------------

Colour F2Quad::lastB[4];

Void F2Quad::Add()
{	
	for (int i = 0; i < Coeffs(); i++)
		B[i] += Reflectance() * R[i];
}
										
Void F2Quad::Push()
{
	if (IsTri())
	{
		//	c[i].B = F2_Tri_P[i] * B;
		Mult(F2_Tri_P0, B, F2Child(1)->B);
		Mult(F2_Tri_P1, B, F2Child(2)->B);
		Mult(F2_Tri_P2, B, F2Child(0)->B);
		Mult(F2_Tri_P3, B, F2Child(3)->B);
		// total: 3(64*, 48+)
	}
	else
	{	
	/*
		Conceptually, this is just trans(T) * B * T: T interpolates rows, and trans(T)
		interpolates columns. We break up the multiplication because our destination matrix
		is not stored contigously.
	*/
		Colour t[4];

		RightTensorMult(F2_P0, B, t);	// 2 x 3(8*, 4+)
		LeftTensorMult(F2_P0, t, F2Child(0)->B);	// 4 x 3(8*, 4+)
		LeftTensorMult(F2_P1, t, F2Child(1)->B);
		RightTensorMult(F2_P1, B, t);
		LeftTensorMult(F2_P0, t, F2Child(3)->B);
		LeftTensorMult(F2_P1, t, F2Child(2)->B);
		// total: 3(48*, 24+)
	}
}

Void F2Quad::Pull()
{
	if (IsTri())
	{
		// B = sum F2_Tri_L[i] * c[i].B
		Mult   (F2_Tri_L0, F2Child(1)->B, B);
		MultAcc(F2_Tri_L1, F2Child(2)->B, B);
		MultAcc(F2_Tri_L2, F2Child(0)->B, B);
		MultAcc(F2_Tri_L3, F2Child(3)->B, B);
	}
	else
	{// budget: 48/36
		Colour t[4];
		
		RightTensorMult(F2_L0, F2Child(0)->B, t);// 2x8/4
		RightTensorMultAcc(F2_L1, F2Child(3)->B, t); // 8/8
		LeftTensorMult(F2_L0, t, B);
		
		RightTensorMult(F2_L0, F2Child(1)->B, t);//8/4
		RightTensorMultAcc(F2_L1, F2Child(2)->B, t);//2x8/8
		LeftTensorMultAcc(F2_L1, t, B);
	}
}

Void F2Quad::Prepare()
{
	for (int i = 0; i < Coeffs(); i++)
	{
		lastB[i] = B[i];
		B[i] = Emittance();
	}
}

GCLReal F2Quad::Error()
{
	return(CalcError(B, lastB, Coeffs()));
}

Void F2Quad::ClearR()
{
	for (int i = 0; i < Coeffs(); i++)
		R[i] = vl_0;
}

Void F2Quad::DrawLeaf(Renderer &r)
{
	if (props->options->wire)
		RadQuad::Draw(r);
	else
	{
		Int		i, j;
		Colour	*c = B;
		
		Vector dx = (Vertex(2) - Vertex(1)) / 2;
		Vector dy = (Vertex(1) - Vertex(0)) / 2;
		Point pt;
		
		if (props->options->funcView)
		{
			r.Begin(renLineLoop).C(cWhite);
			SendPoints(r);
			r.End();
		}
		
		if (highlight)
		{
			DrawHighlight(r);
			if (!props->options->funcView)
				return;
		}
			
		if (props->options->gouraud)
			DrawSampledLeaf(r, 1);
		else if (props->options->funcView)
			for (i = 0; i < 2; i++)
				for (j = 0; j < 2; j++)
				{
					r.Begin(renPoly);
					if (IsQuad())
					{
						pt = Vertex(0) + dx * j + dy * i;
						Project(r, *c, pt);
						Project(r, *c, pt + dy);
						Project(r, *c, pt + dx + dy);
						Project(r, *c, pt + dx);
					}
					else if (i + j >= 2)
					{
						pt = Vertex(0) + dx * (2 - i) + dy * j;
						Project(r, *c, pt);
						Project(r, *c, pt - dx);
						Project(r, *c, pt + dy);
					}
					else
					{
						pt = Vertex(0) + dx * j + dy * (2 - i);
						Project(r, *c, pt);
						Project(r, *c, pt + dx);
						Project(r, *c, pt - dy);
					}
					c++;
					r.End();
				}
		else						
			for (i = 0; i < 2; i++)
				for (j = 0; j < 2; j++)
				{
					r.SetColour(*c).Begin(renPoly);
					
					if (IsQuad())
					{
						pt = Vertex(0) + dx * j + dy * i;
						r.P(pt).P(pt + dy).P(pt + dx + dy).P(pt + dx);
					}
					else if (i + j >= 2)
					{
						pt = Vertex(0) + dx * (2 - i) + dy * j;
						r.P(pt).P(pt - dx).P(pt + dy);
					}
					else
					{
						pt = Vertex(0) + dx * j + dy * (2 - i);
						r.P(pt).P(pt + dx).P(pt - dy);
					}
					c++;
					r.End();
				}
	}
}

Void F2Quad::Print(ostream &s)
{
	s << " + f2 ";
	PrintRec(s);
}

Void F2Quad::PrintSelf(ostream &s)
{
	HRQuad::PrintSelf(s);
	for (int i = 0; i < Coeffs(); i++)
		s << B[i] << ' ';
}

Void F2Quad::ParseSelf(istream &s)
{
	HRQuad::ParseSelf(s);
	for (int i = 0; i < Coeffs(); i++)
		s >> B[i];
}

Void F2Quad::SetParent(HierQuad &itsParent)
{
	HierQuad::SetParent(itsParent);

	if (itsParent.child[3] == this)
		((F2Quad &) itsParent).Push();
}

Colour F2Quad::SampleLeaf(Coord &c)
{
	if (props->options->gouraud)
	{
		Colour mB[4];

		// Transform into equiv. multiwavelet basis...
		if (IsQuad())
		{
			TensorMult(MCC2_R, B, mB);
			return(M2QuadSample(c, mB));
		}
		else
		{
			Mult(MCC2_Tri_R, B, mB);
			return(M2TriSample(c, mB));
		}
	}
	else
	{
		Int i = 0;	// YYY quad-spec
		if (c[0] >= 0)
			i++;
		if (c[1] < 0)
			i += 2;
		return(B[i]);
	}
}

#pragma mark -
// --- F3 Flatlet methods -------------------------------------------------------


#define F3Child(x) ((F3Quad *) child[x])
#define F3Cast(x) ((F3Quad *) x)


// --- F3Link methods -----------------


Void F3Link::CalcTransport()
//	Calculate F3 transport coefficients.
{
	Int i, j, k, l;
	GCLReal t;
	GCLReal *tc = transport;
	GCLReal *visPtr = 0;
	
	if (to->props->options->visInQuad && visibility < 1.0)
	{
		visPtr = &visibility;
		visibility = 0.0;
	}
					
	factor = 0.0;
					
	for (i = 0; i < 3; i++)
		for (j = 0; j < 3; j++)
			for (k = 0; k < 3; k++)
				for (l = 0; l < 3; l++)
				{
					t = F3Cast(from)->SubToSubFormFactor(
						k, l, to, i, j, 3, visPtr);
					if (factor < t)
						factor = t;
					*tc++ = t;
				}

	if (visPtr)
		*visPtr /= 81.0;
	else
		Matd(9, 9, transport) *= visibility;
}

LinkNode *F3Link::CreateSubLink(HRQuad *fromPatch, HRQuad *toPatch)
{
	F3Link *result = new F3Link;
		
	result->visibility = visibility;
	result->Set(fromPatch, toPatch);		
		
	return(result);
}

Void F3Link::Set(HRQuad *fromPatch, HRQuad *toPatch)
{

	from = fromPatch;
	to = toPatch;
	factor = 0.0;
	
	if (NeedVisibility())
	{
		if (to->props->options->visInQuad)
		{
			// do trivial test; if there is some potential
			// visibility, we'll calculate it during quadrature.
			if (!from->PotentiallyVis(to))
				visibility = 0.0;
		}
		else
			visibility = from->Visibility(to);
	}
				
	CalcTransport();
}

Void F3Link::Gather()
{
	F3Quad *fto = F3Cast(to), *ffrom = F3Cast(from);
	MultAcc(Matd(fto->Coeffs(), ffrom->Coeffs(), transport), ffrom->B, fto->R);
}

GCLReal F3Link::Error()
{
	return(factor * visibility);
}

GCLReal F3Link::BFError()
{
	return(to->area * factor * dot(kRadRGBToLum, to->Reflectance() * 
		Average(F3Cast(from)->B, F3Cast(from)->Coeffs())));
}

Void F3Link::Print(ostream &s)
{
	RadLink::Print(s);
	s << " transport = " << Matd(F3Cast(to)->Coeffs(), F3Cast(from)->Coeffs(), transport) 
		<< " vis = " << visibility;
}

Void F3Link::DrawLink(Renderer &r, GCLReal left, GCLReal top,
		GCLReal right, GCLReal bottom, GCLReal weight)
{
	DrawWaveLink(r, left, top, right, bottom, to->Reflectance() * weight, 
		Matd(Matd(F3Cast(to)->Coeffs(), F3Cast(from)->Coeffs(), transport)));
}


#pragma mark -
// --- F3Quad methods ----------------------------------------

Colour F3Quad::lastB[9];

Void F3Quad::Add()
{	
	for (int i = 0; i < Coeffs(); i++)
		B[i] += Reflectance() * R[i];
}

Void F3Quad::Push()
{
	if (IsTri())
	{
		Mult(F3_Tri_P0, B, F3Child(1)->B);
		Mult(F3_Tri_P1, B, F3Child(2)->B);
		Mult(F3_Tri_P2, B, F3Child(0)->B);
		Mult(F3_Tri_P3, B, F3Child(3)->B);
	}
	else
	{	
		Colour t[9];

		RightTensorMult(F3_P0, B, t);	
		LeftTensorMult(F3_P0, t, F3Child(0)->B);	
		LeftTensorMult(F3_P1, t, F3Child(1)->B);
		RightTensorMult(F3_P1, B, t);
		LeftTensorMult(F3_P0, t, F3Child(3)->B);
		LeftTensorMult(F3_P1, t, F3Child(2)->B);
	}
}

Void F3Quad::Pull()
{
	if (IsTri())
	{
		// B = sum F3_Tri_L[i] * c[i].B
		Mult   (F3_Tri_L0, F3Child(1)->B, B);
		MultAcc(F3_Tri_L1, F3Child(2)->B, B);
		MultAcc(F3_Tri_L2, F3Child(0)->B, B);
		MultAcc(F3_Tri_L3, F3Child(3)->B, B);
	}
	else
	{
		Colour t[9];
		
		RightTensorMult(F3_L0, F3Child(0)->B, t);
		RightTensorMultAcc(F3_L1, F3Child(3)->B, t);
		LeftTensorMult(F3_L0, t, B);
		
		RightTensorMult(F3_L0, F3Child(1)->B, t);
		RightTensorMultAcc(F3_L1, F3Child(2)->B, t);
		LeftTensorMultAcc(F3_L1, t, B);
	}
}

Void F3Quad::Prepare()
{
	for (int i = 0; i < Coeffs(); i++)
	{
		lastB[i] = B[i];
		B[i] = Emittance();
	}
}

GCLReal F3Quad::Error()
{
	return(CalcError(B, lastB, Coeffs()));
}

Void F3Quad::ClearR()
{
	for (int i = 0; i < Coeffs(); i++)
		R[i] = vl_0;
}

Void F3Quad::DrawLeaf(Renderer &r)
{
	if (props->options->wire)
		RadQuad::Draw(r);
	else
	{
		Int		i, j;
		Colour	*c = B;
		
		Vector dx = (Vertex(2) - Vertex(1)) / 3;
		Vector dy = (Vertex(1) - Vertex(0)) / 3;
		Point pt;
		
		if (props->options->funcView)
		{
			r.Begin(renLineLoop).C(cWhite);
			SendPoints(r);
			r.End();
		}
		
		if (highlight)
		{
			DrawHighlight(r);
			if (!props->options->funcView)
				return;
		}
		
		if (props->options->gouraud)
			DrawSampledLeaf(r, 4);
		else if (props->options->funcView)
			for (i = 0; i < 3; i++)
				for (j = 0; j < 3; j++)
				{
					r.Begin(renPoly);
					if (IsQuad())
					{
						pt = Vertex(0) + dx * j + dy * i;
						Project(r, *c, pt);
						Project(r, *c, pt + dy);
						Project(r, *c, pt + dx + dy);
						Project(r, *c, pt + dx);
					}
					else if (i + j >= 3)
					{
						pt = Vertex(0) + dx * (3 - i) + dy * j;
						Project(r, *c, pt);
						Project(r, *c, pt - dx);
						Project(r, *c, pt + dy);
					}
					else
					{
						pt = Vertex(0) + dx * j + dy * (3 - i);
						Project(r, *c, pt);
						Project(r, *c, pt + dx);
						Project(r, *c, pt - dy);
					}
					c++;
					r.End();
				}
		else
			for (i = 0; i < 3; i++)
				for (j = 0; j < 3; j++)
				{
					r.SetColour(*c++).Begin(renPoly);
					if (IsQuad())
					{
						pt = Vertex(0) + dx * j + dy * i;
						r.P(pt).P(pt + dy).P(pt + dx + dy).P(pt + dx);
					}
					else if (i + j >= 3)
					{
						pt = Vertex(0) + dx * (3 - i) + dy * j;
						r.P(pt).P(pt - dx).P(pt + dy);
					}
					else
					{
						pt = Vertex(0) + dx * j + dy * (3 - i);
						r.P(pt).P(pt + dx).P(pt - dy);
					}
					r.End();
				}	
	}
}

Void F3Quad::Print(ostream &s)
{
	s << " + f3 ";
	PrintRec(s);
}

Void F3Quad::PrintSelf(ostream &s)
{
	HRQuad::PrintSelf(s);
	for (int i = 0; i < Coeffs(); i++)
		s << B[i] << ' ';
}

Void F3Quad::ParseSelf(istream &s)
{
	HRQuad::ParseSelf(s);
	for (int i = 0; i < Coeffs(); i++)
		s >> B[i];
}

Void F3Quad::SetParent(HierQuad &itsParent)
{
	HierQuad::SetParent(itsParent);
	if (itsParent.child[3] == this)
		((F3Quad &) itsParent).Push();
}

Colour F3Quad::SampleLeaf(Coord &c)
{
	if (props->options->gouraud)
	{
		Colour	mB[9];

		// Transform to multiwavelet
		if (IsQuad())
		{
			TensorMult(MCC3_R, B, mB);
			return(M3QuadSample(c, mB));
		}
		else
		{
			Mult(MCC3_Tri_R, B, mB);		
			return(M3TriSample(c, mB));
		}
	}
	else
	{
		Int i = 0;
		
		c *= 3;
		if (c[0] >= -1)
			i++;
		if (c[0] >= 1)
			i++;
			
		if (c[1] < 1)
			i += 3;
		if (c[1] < -1)
			i += 3;
			
		return(B[i]);
	}
}

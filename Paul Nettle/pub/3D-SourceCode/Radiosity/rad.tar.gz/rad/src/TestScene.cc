/*
	File:			TestScene.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "TestScene.h"
#include "SceneLang.h"
#include "Avars.h"
#include "math.h"

int gQuadType = 0;

//#define DO_TETRA
static Void SideWall()
{
	slBeginPoints();
	slPoint(Point(-1, -1, -1));
	slPoint(Point( 1, -1, -1));
	slPoint(Point( 1, -1,  1));
	slPoint(Point(-1, -1,  1));
	slEndPoints();
}

static Void MyCube()
{
	if (slObjectExists("myCube")) return;
	slAddToLibrary(slBeginObject("myCube"));
			
	SideWall();
	slPoly();
	
	SideWall();
	slApply(Rotation(vl_z, -vl_halfPi));	
	slPoly();
		
	SideWall();
	slApply(Rotation(vl_z, vl_halfPi));	
	slPoly();
	
	SideWall();
	slApply(Rotation(vl_z, vl_pi));	
	slPoly();
	
	SideWall();
	slApply(Rotation(vl_x, -vl_halfPi));	
	slPoly();
		
	SideWall();
	slApply(Rotation(vl_x, vl_halfPi));	
	slPoly();
	
	slEndObject();
}

static Void Table()
{
	scObject *leg;
	
	if (slObjectExists("table")) return;

	MyCube();
	slAddToLibrary(slBeginObject("table"));

	slObject("myCube");
	slApply(Scale(Vector(1, 0.05, 1)));
	slApply(Shift(Vector(0, 0.95, 0)));

	slObject("myCube");
	slApply(Scale(Vector(0.15, 0.9, 0.15)));
	slApply(Shift(Vector(0.85, 0, 0.85)));
	leg = slCurrent();

	slObject(Clone(leg));
	slApply(Rotation(vl_y, vl_halfPi));
		
	slObject(Clone(leg));
	slApply(Rotation(vl_y, 2 * vl_halfPi));
		
	slObject(Clone(leg));
	slApply(Rotation(vl_y, 3 * vl_halfPi));
		
	slEndObject();
}

static Void Wall()
{
	// A 2x2 square centered in the x-z plane, at y=-1.
	if (slObjectExists("wall")) return;
	
	slAddToLibrary(slBeginObject("wall"));
	slBeginPoints();
	slPoint(Point(-1, -1,  1));
	slPoint(Point( 1, -1,  1));
	slPoint(Point( 1, -1, -1));
	slPoint(Point(-1, -1, -1));
	if (gQuadType == 2)
		slPoint(Point(0, -1, 0));
	slEndPoints();
	switch (gQuadType)
	{
	case 0:
		slPoly();
		break;
	case 1:
		slIndexes(Indexes(0, 1, 2, IDX_END));
		slPoly();
		slIndexes(Indexes(2, 3, 0, IDX_END));
		slPoly();
		break;
	case 2:
		slIndexes(Indexes(0, 1, 4, IDX_END));
	 	slPoly();
		slIndexes(Indexes(1, 2, 4, IDX_END));
		slPoly();
		slIndexes(Indexes(2, 3, 4, IDX_END));
		slPoly();
		slIndexes(Indexes(3, 0, 4, IDX_END));
		slPoly();
	}
	
	slEndObject();
}

scScenePtr BoxScene()
{
	scScenePtr result;
	
	Wall();	
	result = slBeginObject("box");
	slCamera();
	slBeginObject("light");
	slColour(cBlack);

	slAttribute(new scAvarEmittance(Avar("light", 20, 5, 50), cWhite));
	slAttribute(new scAvarShift(Avar("height", -0.1, 0.5, -1.9), vl_y));
	slAttribute(new scAvarShift(Avar("shift", 0, -1, 1), vl_z));
	slAttribute(new scAvarRotation(Avar("rotate", 0.0, -1, 1), vl_x));
	slAttribute(new scAvarRotation(Avar("roll", 0.0, -1, 1), vl_z));
	slAttribute(new scAvarScale(Avar("size", 1, 0.1, 2), Vector(0.3, 0, 0.3)));
	slTransform(Rotation(vl_x, vl_pi));
	slObject("wall");
	slEndObject();
		
	slAttribute(new scAvarColour(Avar("floor", 0.5, 0.0, 1), cWhite));
	slObject("wall");
	
	slAttribute(new scAvarColour(Avar("rwall", 0.6, 0.0, 1), RGBCol(1.0, 0.2, 0.2)));
	slObject("wall");
	slApply(Rotation(vl_z, -vl_halfPi));	
		
	slAttribute(new scAvarColour(Avar("gwall", 0.6, 0.0, 1), RGBCol(0.2, 1.0, 0.2)));
	slObject("wall");
	slApply(Rotation(vl_z, vl_halfPi));	
	
	slAttribute(new scAvarColour(Avar("bwall", 0.6, 0.0, 1), RGBCol(1.0, 1.0, 0.5)));
	slObject("wall");
	slApply(Rotation(vl_x, vl_halfPi));	

#ifdef DO_TRI
	slBeginObject("tri");
	slColour(HSVCol(300, 0.5, 0.6));
	slAttribute(new scAvarShift(Avar("tri_height", 1, 0, 2), vl_y));
	slBeginPoints();
	slPoint(Point(-1, -1,  1));
	slPoint(Point( 1, -1,  1));
	slPoint(Point( 1, -1, -1));
	slEndPoints();
	slPoly();
	slEndObject();
	slApply(Rotation(vl_y, (35.0 / 180.0) * vl_pi));
	slApply(Scale(Vector(0.3, 1, 0.3)));
#endif

#ifdef DO_TETRA
	slAttribute(new scAvarRotation(Avar("tetra_rotate_y", 0.0, -1, 1), vl_y));
	slAttribute(new scAvarRotation(Avar("tetra_rotate_z", 0.0, -1, 1), vl_z));
	slColour(HSVCol(200, 0.5, 1));
	slObject("tetrahedron");
	//slApply(Scale(BlockVec3d(0.2)));
	slApply(Rotation(vl_y, (35.0 / 180.0) * vl_pi));
	slApply(Shift(Vector(0, -0.5, 0)));
#endif
	
	slEndObject();

	return(result);
}

scScenePtr ParallelScene()
// Parallel
{
	scScenePtr result;
	
	Wall();
	result = slBeginObject("parallel");
	slCamera();
	slBeginObject("light");
	slColour(cBlack);

	slAttribute(new scAvarEmittance(Avar("light", 20, 5, 50), cWhite));
	slAttribute(new scAvarShift(Avar("height", 0.0, 0.0, -2.0), vl_y));
	slAttribute(new scAvarShift(Avar("shift", 0, -1, 1), vl_z));
	slAttribute(new scAvarRotation(Avar("rotate", 0.0, -1, 1), vl_x));
	slAttribute(new scAvarRotation(Avar("roll", 0.0, -1, 1), vl_z));
	slAttribute(new scAvarScale(Avar("size", 1, 0.1, 2), Vector(0.3, 0, 0.3)));
	
	slTransform(Rotation(vl_x, vl_pi));
	slObject("wall");
	slEndObject();
		
	slColour(0.5 * HSVCol(0, 0, 0.8));
	slObject("wall");
	slEndObject();

	return(result);
}

scScenePtr SidelightScene()
{
	scScenePtr result;
	
	Wall();
	result = slBeginObject("sidelight");
	slCamera();
	slBeginObject("light");
	slColour(cBlack);
	
	slAttribute(new scAvarEmittance(Avar("light", 20, 5, 50), cWhite));
	slAttribute(new scAvarShift(Avar("height", -0.5, 1.5, -0.5), vl_y));
	slAttribute(new scAvarShift(Avar("shift", 0, -1, 1), vl_z));
	slAttribute(new scAvarRotation(Avar("rotate", 0.0, -1, 1), vl_x));
	slAttribute(new scAvarRotation(Avar("roll", 0.0, -1, 1), vl_z));
	slAttribute(new scAvarScale(Avar("size", 1, 0.1, 2), Vector(1.0, 1.0, 0.0)));
	
	slObject("wall");
	slApply(Rotation(vl_x, vl_pi / 2));
	slApply(Scale(0.5, 0.5, 1.0));
	slEndObject();
		
	slColour(0.5 * HSVCol(0, 0, 0.8));
	slObject("wall");
	slEndObject();

	return(result);
}

scScenePtr BlockerScene()
{
	scScenePtr result;

	Wall();
	result = slBeginObject("blocker");
	slCamera();
	slBeginObject("light");
	slColour(cBlack);

	slAttribute(new scAvarEmittance(Avar("light", 20, 5, 50), cWhite));
	slAttribute(new scAvarShift(Avar("height", 0.9, 1.5, -0.9), vl_y));
	slAttribute(new scAvarShift(Avar("shift", 0, -1, 1), vl_z));
	slAttribute(new scAvarRotation(Avar("rotate", 0.0, -1, 1), vl_x));
	slAttribute(new scAvarRotation(Avar("roll", 0.0, -1, 1), vl_z));
	slAttribute(new scAvarScale(Avar("size", 1, 0.1, 2), Vector(0.3, 0, 0.3)));
	
	slTransform(Rotation(vl_x, vl_pi));
	slObject("wall");	
	slEndObject();
		
	slColour(HSVCol(0, 0, 0.5));
	slObject("wall");
	
	slAttribute(new scAvarShift(Avar("blocker_height", 1, 0, 2), vl_y));
	slAttribute(new scAvarScale(Avar("blocker_size", 1, 0.1, 2), Vector(0.2, 0, 0.2)));

	slColour(HSVCol(0, 0.5, 0.5));
	slObject("wall");
	slEndObject();

	return(result);
}

scScenePtr AbuttingScene()
{
	scScenePtr result;

	result = slBeginObject("abutting");
	
	slCamera();

	slBeginObject("light");
	slColour(cBlack);

	slAttribute(new scAvarEmittance(Avar("light", 20, 5, 50), cWhite));

	slAttribute(new scAvarShift(Avar("height", 0.9, 1.5, -0.9), vl_y));
	slAttribute(new scAvarShift(Avar("shift", 0, -1, 1), vl_z));
	slAttribute(new scAvarRotation(Avar("rotate", 0.0, -1, 1), vl_x));
	slAttribute(new scAvarRotation(Avar("roll", 0.0, -1, 1), vl_z));
	slAttribute(new scAvarScale(Avar("size", 1, 0.1, 2), Vector(0.3, 0, 0.3)));
	
	slTransform(Rotation(vl_x, vl_pi));
	slBeginPoints();
	slPoint(Point(-1, 0,  1));
	slPoint(Point( 1, 0,  1));
	slPoint(Point( 1, 0, -1));
	slPoint(Point(-1, 0, -1));
	slEndPoints();
	
	slPoly();
	slEndObject();
		
	slAttribute(new scAvarColour(Avar("wall_refl", 0.9, 0.0, 1), cWhite));
	slObject("wall");
	slObject("wall");
	slApply(Rotation(vl_x, vl_halfPi));	

	slEndObject();

	return(result);
}

scScenePtr TableScene()
{
	scScenePtr result;
	
	Table();
	result = slBeginObject("table");
	slCamera();
	slBeginObject("light");
	slColour(cBlack);

	slAttribute(new scAvarEmittance(Avar("light", 20, 5, 50), cWhite));
	slAttribute(new scAvarShift(Avar("height", 0.9, 1.5, -0.9), vl_y));
	slAttribute(new scAvarShift(Avar("shift", 0, -1, 1), vl_z));
	slAttribute(new scAvarRotation(Avar("rotate", 0.0, -1, 1), vl_x));
	slAttribute(new scAvarRotation(Avar("roll", 0.0, -1, 1), vl_z));
	slAttribute(new scAvarScale(Avar("size", 1, 0.1, 2), Vector(0.3, 0, 0.3)));
	slTransform(Rotation(vl_x, vl_pi));
	slObject("wall");
	slEndObject();
		
	slColour(0.5 * RGBCol(0.8, 0.8, 0.8));
	slObject("wall");
	
	slColour(0.5 * RGBCol(1.0, 0.2, 0.2));
	slObject("wall");
	slApply(Rotation(vl_z, -vl_halfPi));	
		
	slColour(0.5 * RGBCol(0.2, 1.0, 0.2));
	slObject("wall");
	slApply(Rotation(vl_z, vl_halfPi));	
	
	slColour(HSVCol(240, 0.5, 0.5));
	slObject("wall");
	slApply(Rotation(vl_x, vl_halfPi));	
	
#ifdef DO_CUBE
	slColour(HSVCol(200, 0.5, 1));
	slObject("cube");
	slApply(Scale(0.2));
	slApply(Rotation(vl_y, (35.0 / 180.0) * vl_pi));
	slApply(Shift(Vector(0, +0.1, 0)));
#endif
	
	slBeginObject("scene table");
	slAttribute(new scAvarRotation(Avar("rotate table", 0), vl_y));
	slAttribute(new scAvarShift(Avar("shift table", 0, -1, 1), Vector(-0.5, 0, 0)));
	slAttribute(new scAvarScale(Avar("scale table", 0.5), Vector(2, 0, 2)));
	slColour(HSVCol(100, 0.5, 0.5));
	slObject("table");
	slApply(Scale(0.5));
	slApply(Shift(Vector(0, -0.5, 0)));
	slEndObject();
	
	slEndObject();

	return(result);
}

scScenePtr SimpleTriScene()
{
	scScenePtr result;

	slAddToLibrary(slBeginObject("tri"));
	slBeginPoints();
	slPoint(Point(-1, -1,  1));
	slPoint(Point( 1, -1,  1));
	slPoint(Point( 1, -1, -1));
	slEndPoints();
	slPoly();
	slEndObject();

	result = slBeginObject("simple_tri");
	
	slCamera();

	slBeginObject("light");
	slColour(cBlack);

	slAttribute(new scAvarEmittance(Avar("light", 20, 5, 50), cWhite));

	slAttribute(new scAvarShift(Avar("height", 0.9, 1.5, -0.9), vl_y));
	slAttribute(new scAvarShift(Avar("shift", 0, -1, 1), vl_z));
	slAttribute(new scAvarRotation(Avar("rotate", 0.0, -1, 1), vl_x));
	slAttribute(new scAvarRotation(Avar("roll", 0.0, -1, 1), vl_z));
	slAttribute(new scAvarScale(Avar("size", 1, 0.1, 2), Vector(0.3, 0, 0.3)));
	
	slTransform(Rotation(vl_x, vl_pi));
	slBeginPoints();
	slPoint(Point(-1, 0,  1));
	slPoint(Point( 1, 0,  1));
	slPoint(Point( 1, 0, -1));
	slPoint(Point(-1, 0, -1));
	slEndPoints();
	
	slPoly();
	slEndObject();
		
	slColour(0.5 * HSVCol(0, 0, 0.8));
	slObject("tri");
	
	slEndObject();

	return(result);
}

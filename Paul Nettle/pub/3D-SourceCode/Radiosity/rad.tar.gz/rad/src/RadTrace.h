/*
	File:	Gather.h
*/

#include "Scene.h"
#include "Image.h"
#include "RadOptions.h"

Void FinalGather(scScenePtr scene, Image &image, RadOptions &options);
Void RayCastScene(scScenePtr scene, Image &image);

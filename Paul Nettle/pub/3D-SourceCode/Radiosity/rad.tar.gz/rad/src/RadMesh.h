/*
	File:			RadMesh.h

	Function:		Defines a basic mesh of radiosity elements. These can be either
					quads, or triangles. Used as the basis for all radiosity meshes.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __RadMesh__
#define __RadMesh__

#include "Geometry.h"
#include "Renderer.h"
#include "RadOptions.h"


// Statistics for patches in the scene

class PatchStats
{
public:
	Void			Init();

	GCLReal			minArea;
	GCLReal			maxArea;	
	Reflectance		minRefl;
	Reflectance		maxRefl;	
};

// Properties common to all sub-elements of an original scene polygon

class RadProps
{
	public:
	
	Colour				reflectance;	//	Common properties
	Colour				emittance;
	Vector				normal;
	PointList			*points;		//	List of vertex positions
	ColourList			*colours;		//	List of vertex colours
	RadOptions			*options;		//	Radiosity options
	Int					id;

	Int 				AddPoint(const Point &p);		// Adds shared point to the lists.
	Int 				AddColour(const Colour &c);		// Adds shared colour to the lists.
};


class	RadQuad;
typedef RadQuad				*RadQuadPtr;
typedef Array<RadQuadPtr>	PatchList;

/*
	Important note about the index array in the upcoming RadQuad class:

	A quad is defined by    0 3		, e.g., index 0 is index of top-left vertex.
							1 2

	A triangle is 	0	, with index 4 = -1.
				   1 2
				   
	A quad is parameterised by [s, t]: v[0] + s(v[3] - v[0]) + t(v[1] - v[0]): s, t E [-1, 1]
	A tri  is parameterised by (1 - s - t) v[0] + sv[1] + tv[2]: s, t, s + t E [0, 1]
	
	There are also colour indices for each corner of the quad/tri, which lets us share colours
	for internal mesh vertices and along polys that share normals.
*/

class RadQuad
{
public:
					RadQuad() : props(0), highlight(0), colour(cPurple) {};
					~RadQuad() {};	
	
	Int  			index[4];			// Indices of corner vertices
	Int  			clrIdx[4];			// Indices of corner colours
	RadProps		*props;				// Pointer to properties shared by elements of this mesh.
	Point 			centre;				// centre of this quad
	Colour 			colour;				
	GCLReal			area;
	Byte			highlight;			// Whether patch has been highlighted.

	// Total data size: 4 + 16 + 16 + 4 + 24 + 24 + 8 + 1 = 97/100 bytes(!)
	// 1Mb = ~10500 elts.
	
	virtual Void	Draw(Renderer &r);				// Draw this quad
	virtual RadQuad *FindContainer(Coord &coord);	// Find the quad containing this coord.
	virtual Colour	Sample(Coord c);				// Sample radiosity at this coord.
	virtual Colour	SampleLeaf(Coord &c);			// Sample radiosity of this quad, rather than descendants.

	//	Form factor-related methods

	GCLReal			EstPatchFactor(const Point &p, const Vector &n);
					// dA->dA form factor.
	GCLReal 		PatchFactor(const Point &p, const Vector &n);
					// A->dA form factor from quad to elemental surface dS
	GCLReal			ApproxPatchFactor(const Point &p, const Vector &np);
					// Combines EstPatchFactor and PatchFactor according to
					// an approximation oracle
	GCLReal			EstFormFactor(RadQuad *to);
					// returns an estimate of the form factor from this patch
					// to 'to' by calling one of the above methods.
	GCLReal			EdgeArea(const Vector &p, const Vector &q, const Vector &n);
	GCLReal			EstFormFactorXtra(RadQuad *to, GCLReal &error);
	Int				OrientInfo(RadQuad *to);


	//	Visibility methods

	GCLReal			Visibility(RadQuad *to);

	GCLReal			CentreVis(const Point &p, const Vector &n);
	GCLReal			Visibility16(const Point &p, const Vector &n);
	Bool			PotentiallyVis(RadQuad *to);
	Bool			PotentiallyVisAndTouching(RadQuad *to, Bool &touching);
	GCLReal			Visibility44(RadQuad *to);
		
	virtual Void	Smooth(Vecd &weights);			// Push element radiosities to vertices.

	virtual Void 	CreatePatches(PatchList &patches, PatchStats *stats = 0);
													// Grid quad to elements s.t. area < maxPatchSize:
													// return a list of these elements.

	Void			Project(Renderer &r, const Colour &c, const Point &p);
													// Used in function-view rendering.
	virtual Void 	Print(ostream &s);
	virtual Void 	Parse(istream &s);
	virtual Void	Reanimate(RadQuad *parent);

	Void			SetProps(RadProps *props);
	Void			SetHighlight(Int h);
	Void			DrawHighlight(Renderer &r);
	Void			SetColour(const Colour &c) {colour = c;};
	
	virtual Void	CollectColour(Colour &c) {};	// Add up colour * area for all areas.

	// Property accessor methods

	Vector 			&Vertex(Int i) 	{return((*props->points)[index[i]]);};
	Colour 			&Clr(Int i) 	{return((*props->colours)[clrIdx[i]]);};
	Vector 			&Normal() 		{return(props->normal);};
	Vector 			&Centre() 		{return(centre);};
	Colour 			&Emittance() 	{return(props->emittance);};
	Colour			&Reflectance() 	{return(props->reflectance);};

	Bool			IsTri() 		{return(index[3] < 0);};
	Bool			IsQuad() 		{return(index[3] >= 0);};
	Void			SendPoints(Renderer &r)
	{ r.P(Vertex(0)).P(Vertex(1)).P(Vertex(2)); if (IsQuad()) r.P(Vertex(3)); };
	
protected:
	GCLReal 		RadVis4x4(RadQuad *to);
	GCLReal 		RadVis16x1(const Point &p, const Vector &n);

};

ostream &operator << (ostream &s, RadQuad &rq);
istream &operator >> (istream &s, RadQuad &rq);


// --- A quad that can be gridded ----------------------------------------------


class GridRadQuadBase : public RadQuad
{
public:
	Void			Mesh(GCLReal density);

	// Append a copy of the given quad to the quad list.

	virtual Void	AddChild(RadQuad &quad, Int i, Int j, Int in, Int jn) = 0;	
	Int				FindChildIndex(Coord &coord);
													
	Int				rows, cols;
};

class GridRadQuad : public GridRadQuadBase
{
public:
	Void			CreatePatches(PatchList &patches, PatchStats *stats = 0);
	Void 			Draw(Renderer &r);
	Void			Smooth(Vecd &weights);
	RadQuad 		*FindContainer(Coord &coord);	
	Void			Reanimate(RadQuad *parent);

	Void 			Print(ostream &s);
	Void 			Parse(istream &s);

	Void			AddChild(RadQuad &quad, Int i, Int j, Int in, Int jn);	// override.

	Array<RadQuad>	children;
};

const GCLReal surfEps = 1e-6;

#endif

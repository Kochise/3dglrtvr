/*
	File:			RadMain.cc

	Function:		Provides command line-driven program for running the various
					radiosity methods. Output: internal format scene file.

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "unistd.h"
#include "arg.h"
#include "fstream.h"

#include "Rad.h"
#include "String.h"
#include "Avars.h"
#include "SceneLang.h"
#include "Parse.h"

class ProgramOptions
{
public:
	Int		Method;
	Int		noDBuf;
	
	Int		scene;
	GCLReal	scaleRefl;
	Int		size;
	Int		vsize;
	Char	*file;
};

char *defMethodName[] = 
{
	"none",
	"mat",
	"matcg",
	"prog",
	"hprog",
	"hier",
	"ana"
};

char *defBasisName[] = 
{	
	"none",
	"haar",
	"f2",
	"f3",
	"m2",
	"m3"
};


class ScaleReflectances : public scSceneAction
{
public:
	ScaleReflectances(GCLReal sr) : reflScale(sr) {};
		
	Void Attribute(scAttribute &sa);

	GCLReal	reflScale;	
};

Void ScaleReflectances::Attribute(scAttribute &sa)
{
	if (sa.AttrID() == aColour)
		((scColour &) sa) *= reflScale;
}

static Array<char *> gAvarNames;
static Array<GCLReal> gAvarVals;

int AvarArg(int argc, char **argv)
{
	Int i;
	GCLReal val;
	
	if (argc % 2 == 1)
	{
		cerr << "wrong number of avar arguments." << endl;
		exit(1);
	}
	
	for (i = 0; i < argc; i += 2)
	{
		gAvarNames.Append(argv[i]);
		val = atof(argv[i + 1]);
		gAvarVals.Append(val);
	}
	
	return(0);
}

Void SetOptions(int argc, char **argv, RadOptions &radOpts, ProgramOptions &progOpts)
{
	Int 		hier, prog, mat, matcg, hprog, ana;
	Int 		haar, f2, f3, m2, m3;
	Int 		gouraud, wire, ambient, viq;
	Int 		noMGrid, noBF, noGraded, noAnchor, refAllLinks;
	Int			visnone, vis1, vis16, vis44;
	Int			dumpMatrix;
	Int			meshRnd, meshNL;
	GCLReal		refl = 1.0;
	Char		line1[256], line3[256];
	Arg_form	*arg_format;
	
	// Set default arguments
	
	progOpts.size = 400;
	progOpts.file = 0;
	radOpts.outFile = 0;
	progOpts.scaleRefl = 1.0;

	sprintf(line1, "%s, version %s, by Andrew Willmott", argv[0], radRenderVersion);
	sprintf(line3, "Usage: %s [options], where options are as follows:", argv[0]);

	// Create arg form

	arg_format = arg_to_form(
		"", 										line1,
		"", 										"Purpose: radiosity engine",
		"", 										line3,
		
		"-v", ARG_FLAG(&mat), 						"show current version",

		"[%S]",	&progOpts.file,						"scene file",

		"-mat", ARG_FLAG(&mat), 					"use matrix radiosity, overrelaxtion solver",
		"-matcg", ARG_FLAG(&matcg), 				"use matrix radiosity, conjugate gradient solver",
		"-prog", ARG_FLAG(&prog), 					"use progressive radiosity",
		"-hprog", ARG_FLAG(&hprog), 				"use adaptive progressive radiosity",
		"-hier", ARG_FLAG(&hier), 					"use hierarchical radiosity",
		"-ana", ARG_FLAG(&ana), 					"use 1st-order analytical solver",
		
		"-haar", ARG_FLAG(&haar), 					"use Haar basis",
		"-f2", ARG_FLAG(&f2), 						"use F2 basis",
		"-f3", ARG_FLAG(&f3), 						"use F3 basis",
		"-m2", ARG_FLAG(&m2), 						"use M2 basis",
		"-m3", ARG_FLAG(&m3), 						"use M3 basis",
		
		"-sub %F", &radOpts.patchSubdivs, 			"set patch subdivision density",
		"-esub %F", &radOpts.eltSubdivs, 			"set element subdivision density",
		"-alpha %F", &radOpts.alpha, 				"set alpha",
		"-error %F", &radOpts.error, 				"set termination error",
		"-ferr %F", &radOpts.kFError, 				"set ff error",
		"-aerr %F", &radOpts.kAError, 				"set min patch size",
		"-derr %F", &radOpts.dFError, 				"set singularity threshold",
		"-verr %F", &radOpts.visError, 				"wavelet visibility error",
		"-quadLevel %d", &radOpts.quadLevel, 		"quadrature level",
		"-visInQuad", ARG_FLAG(&viq), 				"do visibility testing in quadrature",
					
		"-vis_none", ARG_FLAG(&visnone), 			"no visibility testing",
		"-vis_1", ARG_FLAG(&vis1), 					"single ray visibility", 
		"-vis_16", ARG_FLAG(&vis16), 				"use 16 rays from source -> centre of dest",
		"-vis_44", ARG_FLAG(&vis44), 				"use 16 rays distributed over both patches",

		"-mesh_random", ARG_FLAG(&meshRnd), 		"vary 'sub' parameter randomly",
		"-mesh_nonLin", ARG_FLAG(&meshNL), 			"mesh more heavily at edges",
		"-refl %F", &progOpts.scaleRefl,			"scale all scene reflectances by this amount",

		"-dumpMatrix", ARG_FLAG(&dumpMatrix), 		"dump form-factor matrix",
		"-ambient", ARG_FLAG(&ambient), 			"add ambient term",
		"-no_multigrid", ARG_FLAG(&noMGrid), 		"don't use multigrid methods",
		"-no_BF", ARG_FLAG(&noBF), 					"don't use brightness-weighted refinement",
		"-no_grading", ARG_FLAG(&noGraded), 		"don't enforce a graded mesh",
		"-no_anchor", ARG_FLAG(&noAnchor), 			"don't enforce elimination of t-vertices",
		"-no_refWait", ARG_FLAG(&refAllLinks), 		"don't wait for all links to be refined before stopping",

		"-set", ARG_SUBR(AvarArg), 					"set avar, e.g. -set light 0.5 height 0.2",
		
		// Output options
		
		"-o %S", &radOpts.outFile, 					"output file name",
		"-scene", ARG_FLAG(&progOpts.scene), 		"output scene solution description",
		"-slice %F", &radOpts.sliceTime, 			"time slice",
		"-limit %F", &radOpts.limitTime, 			"time limit",
		
		"-no_dbuf", ARG_FLAG(&progOpts.noDBuf), 	"don't double buffer",
		0
	);

	// Do arg parsing
	
	if (argc == 1)
	{
		arg_form_print(arg_format);
		exit(1);
	}
	if (arg_parse_argv(argc, argv, arg_format) < 0)
		exit(1);

	// Process arguments
	
	progOpts.vsize = progOpts.size;
	radOpts.drawMatrix = dumpMatrix;
	
	if (f2 || f3 || m2 || m3 || haar)
		hier = true;

	if (ana) 
		radOpts.method = kAnalytical;
	else if (hier) 
		radOpts.method = kHierarchical;
	else if (hprog)
		radOpts.method = kProgPlus;
	else if (prog)
		radOpts.method = kProgressive;
	else if (matcg)
		radOpts.method = kConjugateGradient;
	else if (mat)
		radOpts.method = kOverrelaxation;
	else
		radOpts.method = kNoMethod;

	if (f2)
		radOpts.basis = kFlatlet2;
	else if (f3)
		radOpts.basis = kFlatlet3;
	else if (m2)
		radOpts.basis = kMultiwavelet2;
	else if (m3)
		radOpts.basis = kMultiwavelet3;
	else
		radOpts.basis = kHaar;
		
	if (vis44)
		radOpts.visibility = vis_4x4;
	else if (vis16)
		radOpts.visibility = vis_16x1;
	else if (vis1)
		radOpts.visibility = vis_1;
	else if (visnone)
		radOpts.visibility = vis_none;
	else
		radOpts.visibility = vis_4x4;

	if (meshRnd)
		radOpts.mesh = mesh_random;
	if (meshNL)
		radOpts.mesh = mesh_nonlin;

	if (refl != 1.0)
		cout << "scaling reflectances..." << endl;
	
	if (!radOpts.outFile)
		if (hier)
			radOpts.outFile = defBasisName[radOpts.basis];
		else
			radOpts.outFile = defMethodName[radOpts.method];
		
	radOpts.ambient = ambient;
	radOpts.multiGrid = !noMGrid;
	radOpts.useBF = !noBF;
	radOpts.graded = !noGraded;
	radOpts.anchor = !noAnchor;
	radOpts.refAllLinks = !refAllLinks;
	radOpts.visInQuad = viq;
}


Void DoRadiosity(ProgramOptions &progOpts, RadOptions &radOpts)
{
	Camera					camera;
	Int						i;
	scScenePtr				scene;
	RadMethod				*radMethod = 0;
	ofstream				outFile;
	String					filename;
	CreateAvarList			makeAvarList;
	FileName				path;
	
	slSetLibrary(new RadLib);
	
	if (progOpts.file)
	{
		path.SetPath(progOpts.file);
		scene = ReadSceneFile(path);

		if (!scene)
		{
			cerr << "Couldn't read file: " << progOpts.file << endl;
			exit(1);
		}
	}
	else
	{
		cout << "No scene file specified!" << endl;
		exit(1);
	}
	
	// Set avars...
	
	for (i = 0; i < gAvarNames.NumItems(); i++)
		cout << "avar " << gAvarNames[i] << " = " << gAvarVals[i] << endl;
	
	if (progOpts.scaleRefl != 1.0)
	{
		ScaleReflectances sr(progOpts.scaleRefl);
		scene->ApplyAction(sr);
	}
	
	scene->ApplyAction(makeAvarList);
	scene->Set(makeAvarList.avarList);
	
	for (i = 0; i < gAvarNames.NumItems(); i++)
		if (!makeAvarList.avarList->SetAvar(gAvarNames[i], gAvarVals[i]))
			cerr << "No such avar in scene: " << gAvarNames[i] << " (ignoring) " << endl;
										
	// Create radiosity method
	
	radMethod = RadMethod::NewRadMethod(radOpts, 0, 0);

	// Run radiosity method...

	if (radMethod)
	{
		radMethod->SetScene(scene);

		radMethod->Render();
				
		// Output scene file
		
		filename = StrConst(radOpts.outFile) + ".sl";
		outFile.open(filename.Ref());
		if (outFile)
			radMethod->scene->HierPrint(outFile, 0);
		outFile.close();
	}
}


main(int argc, char **argv)
{
	RadOptions				radOpts;
	ProgramOptions			progOpts;
	
	SetOptions(argc, argv, radOpts, progOpts);
	DoRadiosity(progOpts, radOpts);
	
	return(0);
}

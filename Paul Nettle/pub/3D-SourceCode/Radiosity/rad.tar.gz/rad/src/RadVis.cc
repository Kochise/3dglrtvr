/*  
	File:			RadVis.cc

	Function:		GUI front end for the various radiosity methods. Allows visualisation
					of the methods.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

 */

#include "XGraphicsSystem.h"
#include "Forms.h"

#include "TestScene.h"
#include "SceneLang.h"

#include "MatRad.h"
#include "ProgRad.h"
#include "HProgRad.h"
#include "HierRad.h"

#include "Avars.h"
#include "Plot2D.h"
#include "MatDisplay.h"
#include "RadPane.h"
#include "Parse.h"
#include "EPSRenderer.h"

#include <stdlib.h>
#include "unistd.h"
#include "arg.h"

#include "radvisForms.h"	// classes derived from fdesign.
#include "Examiner.h"
#include "RadTrace.h"


static Double		gGreyLevel;
static Double		gScaleRefl;

class ScaleReflectances : public scSceneAction
{
public:
	ScaleReflectances(GCLReal sr) : reflScale(sr) {};
		
	Void Attribute(scAttribute &sa);

	GCLReal	reflScale;	
};

Void ScaleReflectances::Attribute(scAttribute &sa)
{
	if (sa.AttrID() == aColour)
		((scColour &) sa) *= reflScale;
}

// --- FormFactorPanel --------------------


class RadForm;

class FormFactorPanel : public FormFactorForm
{
public:
	FormFactorPanel(RadForm *radform) : FormFactorForm(), parent(radform) {};
	
	Void 	Event(FL_OBJECT *object);
		
	RadForm	*parent;
};


// --- AvarPanel ---------------------


class AvarPanel : public AvarForm
{
public:
	Void 	Init();
	Void	Event(FL_OBJECT *object);
	Void	SetScene(scScenePtr scene);
	Void	Dump(ostream &s);
	
	scAvarList	*avarList;
	ScenePane	*scenePane;
};

Void AvarPanel::Init()
{
	fl_set_slider_bounds(avarSlider, 0, 1);	
	fl_set_slider_value(avarSlider, 1);	
}

Void AvarPanel::SetScene(scScenePtr scene)
{
	Int i;
	CreateAvarList avarGrabber;
	
	scene->ApplyAction(avarGrabber);
	avarList = avarGrabber.avarList;
	
	fl_clear_browser(avarBrowser);
	
	for (i = 0; i < avarList->NumItems(); i++)
		fl_add_browser_line(avarBrowser, (*avarList)[i].name);
}

Void AvarPanel::Dump(ostream &s)
{
	Int i;
	
	for (i = 0; i < avarList->NumItems(); i++)
		cout << (*avarList)[i].name << " = " << (*avarList)[i].value << endl;
}

Void AvarPanel::Event(FL_OBJECT *object)
{
	if (object == avarBrowser)
	{
		if (fl_get_browser(object) > 0)
		{
			Avar &avar = (*avarList)[fl_get_browser(avarBrowser) - 1];
			
			fl_set_slider_bounds(avarSlider, avar.lowerBound, avar.upperBound);	
			fl_set_slider_value(avarSlider, avar.value);	
		}
	}
	else if (object == avarSlider)
	{
		if (fl_get_browser(avarBrowser) > 0)
		{
			(*avarList)[fl_get_browser(avarBrowser) - 1].value = fl_get_slider_value(avarSlider);
			if (scenePane)
				scenePane->Redraw();	
		}
	}
	else if (object == dismiss)
		Hide();
	else if (object == dump)
		Dump(cout);
}

#pragma mark -
// --- The main pane! -------------------------


class RadForm : public ClockworkForm
{
public:

	RadForm(FormsGraphicsSystem &gs, RadOptions &opts);
		
	Void					Event(FL_OBJECT *object);
	Void					Init();
	Void					SetupControls();
	Void					SetOptionControls();
	Void					SetupMenus();
	Void 					UpdateOptions();

	Void 					SamplePatch(Matd &samples);
	Void 					SampleFF(Matd &samples);
	Void 					ShowHide(Int a, Int b);
	Void					RenderMode(Int on);

	Void					UpdateMesh();
	scScenePtr				LoadScene();

	// Fields
	
	Int						oldMethodChoice;
		
	scScenePtr				scene;
	scScenePtr 				matrixScene;
	RadMethod				*radMethod;
	RadOptions				&options;
	
	RadScenePane			mainPane;
	MatrixScenePane			matrixPane;
	GSBackedPane			subPane;

	AvarPanel				avarPanel;
	FormFactorPanel			ffPanel;
	
	FormsGraphicsSystem &gs;
};


// --- Scene loader. --------------------


Void FormFactorPanel::Event(FL_OBJECT *object)
{
	// nice & simple -- just hide the form if 'OK' is
	// clicked.

	if (object == dismiss)
		Hide();
	else 
		parent->UpdateOptions();
};

#pragma mark -

// --- Rad form methods -----------------------------


RadForm::RadForm(FormsGraphicsSystem &gs, RadOptions &opts) : 
	ClockworkForm(), gs(gs), options(opts), scene(0), ffPanel(this)
{ 
}

Void RadForm::Init()
{	
	gs.CreateFormsPane(&mainPane, box1);
	gs.CreateFormsPane(&matrixPane, box2);
	options.visibility = vis_1;
	
	SetupControls();
	SetupMenus();
	SetOptionControls();
			
	//	Enable/Disable the right controls.

	ShowHide(kOverrelaxation, kNoMethod);
	ShowHide(kConjugateGradient, kNoMethod);
	ShowHide(kProgressive, kNoMethod);
	ShowHide(kProgPlus, kNoMethod);
	ShowHide(kHierarchical, kNoMethod);
	ShowHide(0, kOverrelaxation);
	
	// Ensure we're using the radiosity library

	slSetLibrary(new RadLib);
	
	if (scene == 0)
		scene = BoxScene();

	// Set up the radiosity method and the view pane.
	
	mainPane.SetBgColour(cWhite * gGreyLevel);
	mainPane.SetParent(this);

	oldMethodChoice = 0;
	radMethod = RadMethod::NewRadMethod(options, &mainPane, &gs);

	matrixScene = slBeginObject("matrix");
	slCamera();
	slObject(new MatrixDisplay((Void **) &radMethod));
	slEndObject();

	matrixPane.SetScene(matrixScene);
	matrixPane.Redraw();

	radMethod->matDisplayP = &matrixPane;
	radMethod->out1 = comment;
	radMethod->out2 = debug1;
	radMethod->out3 = debug2;

	UpdateMesh();
}

Void RadForm::SetupMenus()
{
	// Set up the menus

	fl_set_choice_fontsize(methodChoice, FL_SMALL_SIZE);
	fl_set_choice_fontstyle(methodChoice, FL_BOLD_STYLE | FL_SHADOW_STYLE);
	fl_set_choice_fontsize(basis, FL_SMALL_SIZE);
	fl_set_choice_fontstyle(basis, FL_BOLD_STYLE | FL_SHADOW_STYLE);
	fl_set_choice_fontsize(ffPanel.visMethod, FL_TINY_SIZE);
	fl_set_choice_fontsize(ffPanel.quadLevel, FL_TINY_SIZE);
}

Void RadForm::SetupControls()
{
	// Set values for the various UI components
			
	fl_set_slider_bounds(patchSubdivs, 0.2, 20);	
	fl_set_slider_value(patchSubdivs, 0.5);	
	fl_set_slider_return(patchSubdivs, 0);	// return immmediately when slider adjusted.
	
	fl_set_slider_bounds(eltSubdivs, 0.2, 20);	
	fl_set_slider_value(eltSubdivs, 0.5);
	fl_set_slider_return(eltSubdivs, 0);	// return immmediately when slider adjusted.
	
	fl_set_slider_bounds(alphaLevel, 1, 2);	
	fl_set_slider_value(alphaLevel, 1);	
	fl_set_slider_return(alphaLevel, 0);
	
	fl_set_slider_bounds(error, 0.0, 0.5);
	fl_set_slider_value(error, 0.05);	

	fl_set_slider_bounds(kFError, 0.01, 0.15);
	fl_set_slider_step(kFError, 0.01);
	fl_set_slider_bounds(kAError, 0.01, 0.10);
	fl_set_slider_step(kAError, 0.001);

	fl_set_counter_bounds(plotRes, 1, 32);
	fl_set_counter_step(plotRes, 1, 1);
	fl_set_counter_value(plotRes, 6);
	
	my_deactivate(examRad);		// Deactivate plot buttons.
	my_deactivate(examFF);
}

Void RadForm::SetOptionControls()
{
   	fl_set_button(displayShot, options.shotDisplay);
   	fl_set_button(animate, options.animate);
   	fl_set_button(ambient, options.ambient);
   	fl_set_button(gouraudBtn, options.gouraud);
   	fl_set_button(showRays, options.showRays);
   	fl_set_button(wireFrame, options.wire);
   	
   	fl_set_button(showLinks, options.showLinks);
   	fl_set_button(multiGrid, options.multiGrid);
   	fl_set_button(useBF, options.useBF);
   	fl_set_button(patchView, options.patchView);
   	fl_set_button(funcView, options.funcView);
   	fl_set_button(pause, options.pause);
   	fl_set_button(drawMatrix, options.drawMatrix);
   	
	fl_set_slider_value(patchSubdivs, options.patchSubdivs);
	fl_set_slider_value(eltSubdivs, options.eltSubdivs);
	fl_set_slider_value(alphaLevel, options.alpha);
	fl_set_slider_value(error, options.error);
   	fl_set_slider_value(kFError, options.kFError);
   	fl_set_slider_value(kAError, options.kAError);
   	
   	fl_set_button(graded, options.graded);
   	fl_set_button(anchor, options.anchor);
   	fl_set_choice(basis, options.basis);
	fl_set_choice(methodChoice, options.method);

   	fl_set_slider_value(ffPanel.dFError, options.dFError);
   	fl_set_button(ffPanel.visInQuad, options.visInQuad);
	fl_set_choice(ffPanel.visMethod, options.visibility + 1);
	fl_set_choice(ffPanel.quadLevel, options.quadLevel + 1);
   	fl_set_button(ffPanel.jitterRot, options.jitterRot);
}

Void RadForm::UpdateOptions()
{
   	options.shotDisplay = fl_get_button(displayShot);
   	options.animate = fl_get_button(animate);
   	options.ambient = fl_get_button(ambient);
   	options.gouraud = fl_get_button(gouraudBtn);
   	options.showRays = fl_get_button(showRays);
   	options.wire = fl_get_button(wireFrame);
   	
   	options.showLinks = fl_get_button(showLinks);
   	options.multiGrid = fl_get_button(multiGrid);
   	options.useBF = fl_get_button(useBF);
   	options.patchView = fl_get_button(patchView);
   	options.funcView = fl_get_button(funcView);
   	options.pause = fl_get_button(pause);
   	options.drawMatrix = fl_get_button(drawMatrix);
   	
	options.patchSubdivs = fl_get_slider_value(patchSubdivs);
	options.eltSubdivs = fl_get_slider_value(eltSubdivs);
	options.alpha = fl_get_slider_value(alphaLevel);
	options.error = fl_get_slider_value(error);
   	options.kFError = fl_get_slider_value(kFError);
   	options.kAError = fl_get_slider_value(kAError);

	options.anchor = fl_get_button(anchor);
	options.graded = fl_get_button(graded);
   	options.basis = (HRBasisType) fl_get_choice(basis);
   	options.method = (RadType) fl_get_choice(methodChoice);

   	options.dFError = fl_get_slider_value(ffPanel.dFError);
   	options.visInQuad = fl_get_button(ffPanel.visInQuad);
   	options.jitterRot = fl_get_button(ffPanel.jitterRot);
	options.visibility = (VisType) (fl_get_choice(ffPanel.visMethod) - 1);
	options.quadLevel = fl_get_choice(ffPanel.quadLevel) - 1;
}

Void RadForm::SampleFF(Matd &samples)
// Sample the form factor values from the currently selected source patch over the
// currently selected destination patch.
{
	Int			i, j;
	RadQuad		*to = mainPane.selPatch[0];
	RadQuad		*from = mainPane.selPatch[1];
	Coord		place;
	Vector		x, y;
	Point		point;
	Int			density;
	
	if (options.method == kHierarchical && (options.basis == kFlatlet3 || options.basis == kMultiwavelet3))
		density = fl_get_counter_value(plotRes) * 3;
	else
		density = fl_get_counter_value(plotRes) * 4;
	
	samples.SetSize(density + 1, density + 1);
	x = to->Vertex(2) - to->Vertex(1);
	y = to->Vertex(0) - to->Vertex(1);
		
	for (i = 0; i <= density; i++)
		for (j = 0; j <= density; j++)
		{
			if (i == 0)
				place[0] = 1e-6;
			else
				place[0] = i / GCLReal(density) - 1e-6;

			if (j == 0)
				place[1] = 1e-6;
			else
				place[1] = j / GCLReal(density) - 1e-6;
			
			point = x * place[0] + y * place[1] + to->Vertex(1);
			samples[i][j] = 
				from->ApproxPatchFactor(point, to->Normal());
		}
}

Void RadForm::SamplePatch(Matd &samples)
// Sample the currently selected patch.
{
	Int			i, j;
	RadQuad		*leaf;
	Coord		place;
	Int			density;
	
	if (options.method == kHierarchical && (options.basis == kFlatlet3 || options.basis == kMultiwavelet3))
		density = fl_get_counter_value(plotRes) * 9;
	else
		density = fl_get_counter_value(plotRes) * 8;

	samples.SetSize(density, density);
		
	for (i = 0; i < density; i++)
		for (j = 0; j < density; j++)
		{
			if (mainPane.selPatch[0]->IsQuad())
			{
				place[0] = 2 * GCLReal(i) / GCLReal(density - 1) - 1;
				place[1] = 2 * GCLReal(j) / GCLReal(density - 1) - 1;
			}
			else
			{
				place[0] = GCLReal(i) / GCLReal(density - 1);
				place[1] = GCLReal(j) / GCLReal(density - 1);
			}
						
			samples[i][j] =  len((mainPane.selPatch[0])->Sample(place));
		}
}


Void RadForm::ShowHide(Int oldMethod, Int newMethod)
{
	switch (oldMethod)
	{
	case kOverrelaxation:
		my_deactivate(alphaLevel);
		my_deactivate(patchSubdivs);
		break;
	case kConjugateGradient:
		my_deactivate(alphaLevel);
		my_deactivate(patchSubdivs);
		break;
	case kProgressive:
		my_deactivate(alphaLevel);
		my_deactivate(patchSubdivs);
		my_deactivate(error);
		break;
	case kProgPlus:
		my_deactivate(error);
		my_deactivate(eltSubdivs);
		my_deactivate(patchSubdivs);
		my_deactivate(kFError);
		my_deactivate(kAError);
		break;
	case kHierarchical:
		my_deactivate(basis);
		my_deactivate(error);
		my_deactivate(kFError);
		my_deactivate(kAError);
		my_deactivate(patchSubdivs);
		break;
	}
		
	switch (newMethod)
	{
	case kOverrelaxation:
		my_activate(alphaLevel);
		my_activate(patchSubdivs);
		break;
	case kConjugateGradient:
		my_activate(alphaLevel);
		my_activate(patchSubdivs);
		break;
	case kProgressive:
		my_activate(alphaLevel);
		my_activate(patchSubdivs);
		my_activate(error);
		break;
	case kProgPlus:
		my_activate(error);
		my_activate(eltSubdivs);
		my_activate(patchSubdivs);
		my_activate(kFError);
		my_activate(kAError);
		break;
	case kHierarchical:
		my_activate(basis);
		my_activate(error);
		my_activate(kFError);
		my_activate(kAError);
		my_activate(patchSubdivs);
		break;
	}
}

Void RadForm::RenderMode(Int on)
{
	if (!on)
	{
		my_activate(goBtn);
		my_activate(avar);
		my_activate(patchSubdivs);
		my_activate(eltSubdivs);
		my_activate(alphaLevel);
		my_activate(exitBtn);
		my_activate(methodChoice);
	}
	else
	{
		my_deactivate(goBtn);
		my_deactivate(avar);
		my_deactivate(exitBtn);
		my_deactivate(patchSubdivs);
		my_deactivate(eltSubdivs);
		my_deactivate(alphaLevel);
		my_deactivate(methodChoice);
	}
}

scScenePtr RadForm::LoadScene()
{
	const char *result;
	scScenePtr	scene = 0;
	FileName	filename;
	
	result = fl_show_fselector("Please pick a scene file", 0, "*.*", 0);
	filename.SetPath(result);
	
	if (result)
		scene = ReadSceneFile(filename);
		
	if (!scene)
		scene = BoxScene();

	if (gScaleRefl != 1.0)
	{
		ScaleReflectances	sr(gScaleRefl);
		scene->ApplyAction(sr);
	}
		
	return(scene);
}

// --- Event Handling ----------------------------------------

static const char *gHelpURL = "http://www.cs.cmu.edu/~radiosity/radvis-help.html";

Void StartHelp()
{
	Char		line[1024];
	int			err;
	StatusForm	status;
	Char		*netscape = "netscape";
	
	// Fire up nutscape, if necessary, and target the help URL.
	// Should change this to use exec*() and wait()...
	
	status.Show();
	Field(status.heading) << "Help" << show;
	Field(status.body) << "Opening " << gHelpURL << show;
	sprintf(line, "%s -remote 'openURL(%s, new-window)'", netscape, gHelpURL);
	err = system(line);

	if (err)
	{
		Field(status.body) << "remote failed (" << err << ")" << show;
		sprintf(line, "%s %s&", netscape, gHelpURL);
		Field(status.body) << "Starting Netscape..." << show;
		err = system(line);
		if (err)
			cout << "Could not invoke Netscape: help is available at "
				 << gHelpURL << show;
		else
			Field(status.body) << "All systems go..." << show;
	}
	else
		Field(status.body) << "All systems go." << show;
	
	sleep(2);
	status.Hide();
}

Void RadForm::UpdateMesh()
{
	Int saveWire = options.wire;

	UpdateOptions();

	options.wire = true;
	radMethod->SetScene(scene);
	mainPane.SetScene(radMethod->scene);
	options.wire = saveWire;

	SetOptionControls();
}

Void RadForm::Event(FL_OBJECT *object)
{
	// Handle UI events. This should be split out into (many) different routines!

	if (object == exitBtn)
	{
		// Our work here is done.
		
		gs.finished = 1;
	}
	else if (object == goBtn)
	{
		// Render the current scene.
				
		RenderMode(1);
		options.stop = false;

		// Attach main pane to the radiosity method's copy of the scene

		Int saveWire = options.wire;
		UpdateOptions();
		radMethod->SetScene(scene);
		mainPane.SetScene(radMethod->scene);
		options.wire = saveWire;
		SetOptionControls();

//		avarPanel.Hide(); XXX need to fix xforms error msg before we can do this.

		// Doooo it...

		radMethod->Render();
		RenderMode(0);
	}
	else if (object == methodChoice)
	{
		// Change the selected radiosity method
	
		if (oldMethodChoice != fl_get_choice(methodChoice))
		{
			delete radMethod;
			UpdateOptions();
			ShowHide(oldMethodChoice, fl_get_choice(methodChoice));

			radMethod = RadMethod::NewRadMethod(options, &mainPane, &gs);
			radMethod->matDisplayP = &matrixPane;
			radMethod->out1 = comment;
			radMethod->out2 = debug1;
			radMethod->out3 = debug2;
			UpdateMesh();

			if (options.method >= kHierarchical)
				options.visibility = vis_4x4;
			else
				options.visibility = vis_1;

			SetOptionControls();
			oldMethodChoice = fl_get_choice(methodChoice);
		}
	}		
	else if (object == resetBtn)
	{
		// reset the current radiosity run
		
		options.stop = true;
		options.step = false;
		options.pause = false;
		options.pvData = 0;
		my_deactivate(examRad);		// Deactivate plot buttons.
		my_deactivate(examFF);
   		fl_set_button(pause, options.pause);

		// go back to the original scene.

		UpdateMesh();
	}
	else if (object == step)
	{
		options.step = true;
		options.pause = true;
   		fl_set_button(pause, options.pause);
	}
	else if (object == gouraudBtn || object == wireFrame || 
		object == displayShot || object == patchView ||
		object == funcView || object == anchor)
	{
		// These are option-changing controls: we update the options and redraw
		// the scene in case it or the way of drawing it has changed.
	
		UpdateOptions();
		mainPane.Redraw();	
	}
	else if (object == patchSubdivs || object == eltSubdivs)
		UpdateMesh();
	else if (object == avar)
	{
		//	Perform a reset
		
		options.stop = true;
		options.step = false;
		options.pause = false;
   		fl_set_button(pause, options.pause);
		mainPane.SetScene(scene);
		
		//	Show the avar panel
		
		avarPanel.Show();
		if (avarPanel.scenePane == 0)
		{
			avarPanel.SetScene(scene);
			avarPanel.scenePane = &mainPane;
			scene->Set(avarPanel.avarList);
			avarPanel.Init();
		}
	}
	else if (object == examRad && mainPane.selPatch[0])
	{
		Examiner *newPlot = new Examiner;
		
		newPlot->Show();
		newPlot->Init(gs, &mainPane);
		SamplePatch(newPlot->plot->samples);
		newPlot->plotPane.SetBgColour(cWhite * gGreyLevel);
		newPlot->plotPane.Redraw();
	}
	else if (object == examFF && mainPane.selPatch[0] && mainPane.selPatch[1])
	{
		Examiner *newPlot = new Examiner;
		
		newPlot->Show();
		newPlot->Init(gs, &mainPane);
		newPlot->plotPane.SetBgColour(cWhite * gGreyLevel);
		SampleFF(newPlot->plot->samples);
		newPlot->plotPane.Redraw();
	}
	else if (object == sceneSelect)
	{
		options.stop = true;
		options.step = false;
		options.pause = false;
   		fl_set_button(pause, options.pause);

		switch(fl_get_choice(sceneSelect))
		{
		case 1:
			scene = BoxScene(); break;
		case 2:
			scene = ParallelScene(); break;
		case 3:
			scene = SidelightScene(); break;
		case 4:
			scene = BlockerScene(); break;
		case 5:
			scene = AbuttingScene(); break;
		case 6:
			scene = TableScene(); break;
		default:
			scene = LoadScene(); break;
		}
		
		UpdateMesh();
		avarPanel.scenePane = 0;
	}
	else if (object == jump)
	{
		if (mainPane.selPatch[0])
			mainPane.ViewFrom(mainPane.selPatch[0]->Centre(), mainPane.selPatch[0]->Normal());
		else
			mainPane.Restore();
	}
	else if (object == dump)
	{
		const char	*result;
		RGBAImage	A;

		result = fl_show_fselector("Saving main image...", 0, "*.tiff", "main.tiff");

		if (result)
		{
			cout << "*** dumping main image to " << result << endl;
			mainPane.GetImage(A);
			A.SaveTIFF(result);
		}
	
	}
	else if (object == dumpEps)
	{
		const char	*result;
		ofstream	fout;

		result = fl_show_fselector("Saving main image...", 0, "*.eps", "main.eps");

		if (result)
		{
			EPSRenderer eps;
			cout << "*** dumping eps file to " << result << endl;
			
			eps.Attach((Char *) result);
			eps.Clear().Draw(radMethod->scene).Show();
		}			
	}
	else if (object == dumpCam)
	{
		const char *result;
		ofstream	fout;
		
		result = fl_show_fselector("Saving camera file...", 0, "*.cam", "main.cam");
		
		if (result)
		{
			cout << "*** saving camera to " << result << endl;
			fout.open(result);
			if (fout)
				((scCamera*) mainPane.ItsCamera())->Print(fout);
			else
				perror("Couldn't open output file");
		}


	}
	else if (object == ffShow)
		ffPanel.Show();
	else if (object == msgPick)
	{
		if (mainPane.selPatch[0])
			my_activate(examRad);
		else
			my_deactivate(examRad);
			
		if (mainPane.selPatch[0] && mainPane.selPatch[1])
			my_activate(examFF);
		else
			my_deactivate(examFF);

		matrixPane.Redraw();
	}
	else if (object == help)
		StartHelp();
	else if (object == drawMatrix)
	{
		UpdateOptions();
		radMethod->RenderMatrix(matrixPane);
	}
	else
		UpdateOptions();
}


// --- Main --------------------------------------

extern int gQuadType; // TestScene.cc

Void InitOptions(int argc, char **argv, RadOptions &options, char **scenePathP)
{
	int ndm, meshRnd, meshNonLin, tri1, tri2;
	gScaleRefl = 1.0;
	gGreyLevel = 0.0;
	
	if (arg_parse(argc, argv,
			"",										"usage: radvis [options]",
			"[%S]",			scenePathP,				"scene file",
			"-noMatrix",	ARG_FLAG(&ndm),			"turn off matrix display",
			"-bg %F",		&gGreyLevel, 			"background grey level",
			"-meshRandom",	ARG_FLAG(&meshRnd), 	"Vary the mesh density",
			"-meshNonLin",	ARG_FLAG(&meshNonLin),	"Mesh more heavily at edges",
			"-refl %F",		&gScaleRefl,			"Scale reflectance",
			"-tri1",		ARG_FLAG(&tri1),		"Triangulate built in scenes (1)",
			"-tri2",		ARG_FLAG(&tri2),		"Triangulate built in scenes (2)",
			0) < 0)
		exit(1);
	
	if (tri1)
		gQuadType = 1;
	else if (tri2)
		gQuadType = 2;
		
	options.drawMatrix = !ndm;
	if (meshRnd)
		options.mesh = mesh_random;
	if (meshNonLin)
		options.mesh = mesh_nonlin;
}

main(int argc, char **argv)
{
	RadOptions 				options;
	char					*scenePath = 0;

	InitOptions(argc, argv, options, &scenePath);

	FormsGraphicsSystem		gs(argc, argv);
	RadForm					radForm(gs, options);	
	
	radForm.Show();	
	radForm.Init();
	
	if (scenePath)
	{
		FileName filename;
		
		filename.SetPath(scenePath);
		radForm.scene = ReadSceneFile(filename);
		if (!radForm.scene)
			exit(1);
		if (gScaleRefl != 1.0)
		{
			ScaleReflectances sr(gScaleRefl);
			radForm.scene->ApplyAction(sr);
		}
		
		radForm.mainPane.SetScene(radForm.scene);
		radForm.avarPanel.scenePane = 0;
	}
	
	gs.Run();

	return(0);
}



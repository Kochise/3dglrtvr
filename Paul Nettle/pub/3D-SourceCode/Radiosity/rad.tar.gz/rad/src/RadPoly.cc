/*
	File:			RadPoly.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "RadPoly.h"
#include "PolyLib.h"
#include "Haar.h"
#include "Flatlets.h"
#include "MultiWavelets.h"
#include "String.h"
#include "Rad.h"
#include "ObjArray.h"
#include "VecUtil.h"

#define RAD_GRID

Void RadPrim::InitRad(RadOptions &options)
{
	Context *context = new Context(aNumAttributes);
	
	options.numPolys = 0;
	InitRad(context, options);
	
	delete context;
}

Void RadPrim::ApplyTransforms() 
{
	Context context(aNumAttributes);
	
	ApplyTransforms(vl_I, &context);
}


#pragma mark -
// --- RadGroup Class ------------------------------------


Void RadGroup::InitRad(Context *context, RadOptions &opts)
{
	scIterator i(children);

	context->Push();

	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
			RadPrimCast(i())->InitRad(context, opts);
		else
			AttrCast(i())->AddToContext(context);

	context->Pop();
}

Void RadGroup::Reanimate(RadOptions &opts)
// Called after a radiosity scene has been read in from file; reconstructs
// any needed info.
{
	scIterator i(children);
	
	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
			RadCast(PrimCast(i()))->Reanimate(opts);
}

Void RadGroup::ApplyTransforms(Transform t, Context *context)
{
	scIterator i(children);
	
	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
			RadCast(PrimCast(i()))->ApplyTransforms(t, context);
		else
		{
			AttrCast(i())->AddToContext(context);
			
			if (i()->AttrID() == aTransform)	// if it's a transform, concatenate it
			{
				t = t * *SC_GET(Transform);
				children.Delete(i.i, 1);		// XXX need an i.Delete()
				i.i--;
			}
			else
				i()->Apply(t);					// otherwise apply t to the attribute.
		}
}


Void RadPrim::MakeQuadTri()
{
	Context context(aNumAttributes);
	
	MakeQuadTri(&context);
}

Void RadGroup::MakeQuadTri(Context *context)
{
	scIterator i(children);
	Int	j;
	
	cout << "Top of groups" << endl;
	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
		{
			if (i()->PrimID() == pPoly)
			{
				PointList	*points;
				ColourList	*colours;
				IndexList	*indexes;

				if (points = SC_GET(Points))
				{
					if (indexes = SC_GET(Indexes))
					{
						if (indexes->NumItems() > 4)
						{
							scIndexes	*triIndexes;
							scPoly		*newPoly;
							cout << "cutting " << indexes->NumItems() << " indexes to tris" << endl;
							/*for (j = 1; j < indexes->NumItems() - 2; j++)
							{
								triIndexes = new scIndexes;
								triIndexes->Append((*indexes)[0]);
								triIndexes->Append((*indexes)[j]);
								triIndexes->Append((*indexes)[j + 1]);
								((ObjArray*) i.list)->Insert(i.i + 1, newPoly = new scPoly);
								newPoly->Set(triIndexes);	
							}*/
							
							indexes->Shrink(indexes->NumItems() - 3);
						}
					}
					else
					{
						if (points->NumItems() > 4)
						{
							scPoints	*triPoints;
							scPoly		*newPoly;
							
							cout << "cutting " << points->NumItems() << " points to tris" << endl;

							/*for (j = 1; j < indexes->NumItems() - 2; j++)
							{
								triPoints = new scPoints;
								triPoints->Append((*points)[0]);
								triPoints->Append((*points)[j]);
								triPoints->Append((*points)[j + 1]);
								((ObjArray*) i.list)->Insert(i.i + 1, newPoly = new scPoly);
								newPoly->Set(triPoints);	
							}
							*/
							points->SetSize(3);
						}
					
					}					
				}
			}	
			else
				RadCast(PrimCast(i()))->MakeQuadTri(context);
		}
		else
			AttrCast(i())->AddToContext(context);
}

Void RadGroup::GetTrees(TreeList &trees)
{
	scIterator i(children);

	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
			RadCast(PrimCast(i()))->GetTrees(trees);
}

Void RadGroup::CreatePatches(PatchList &patches, PatchStats *stats)
{
	scIterator i(children);

	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
			RadCast(PrimCast(i()))->CreatePatches(patches, stats);
}

Void RadGroup::Smooth()
{
	scIterator i(children);

	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
			RadCast(PrimCast(i()))->Smooth();
}


// --- Raytracing methods -----------------------------------


Void RadGroup::CreateGrid()
{
	Vector min, max;
	
	max = Vector(-HUGE_VAL, -HUGE_VAL, -HUGE_VAL);
	min = Vector( HUGE_VAL,  HUGE_VAL,  HUGE_VAL);

	if (FindBounds(min, max))
	{
		grid = new Grid();
		grid->min = min;
		grid->max = max;
		grid->SetupGrid();	
		AddToGrid(grid);
	}
}

Void RadGroup::AddToGrid(Grid* grid)
{
	scIterator i(children);

	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
			RadPrimCast(i())->AddToGrid(grid);
}

Bool RadGroup::FindBounds(Vector& min, Vector &max)
{
	scIterator i(children);

	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
			if (!RadPrimCast(i())->FindBounds(min, max))
				return(false);
	
	return(true);
}

scPrimitive *gOrig = 0;

scPrimitive *RadGroup::ClosestIntersection(Point &start, Vector &dir, Point &p)
{
	scIterator 		i(children);
	scPrimitive 	*object, *closest = 0;
	GCLReal 			distance, closestDistance = 1e10;
	Point	 		q;
	
#ifdef RAD_GRID
	if (!grid)
		CreateGrid();
#endif
	
	if (grid)
	{
		RTTri*	tri;
		
		if (grid->FirstIntersection(start, dir, p, tri, gOrig))
			return((scPrimitive*) tri->data);
		else
			return(0);
	}
		
	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
		{
			if (object = RadCast(PrimCast(i()))->ClosestIntersection(start, dir, q))
			{
				distance = len(q - start);

				if (distance < closestDistance)
				{
					closest = object;
					p = q;
					closestDistance = distance;
				}				
			}
		}
			
	return(closest);
}

Bool RadGroup::IntersectsWithRay(Point &start, Point &end)
// Returns true if there is an intersection, and it occurs within the open
// interval from start to end.
{
	scIterator i(children);
	
#ifdef RAD_GRID
	if (!grid)
		CreateGrid();
#endif

	if (grid)
		return(grid->IntersectionExists(start, end));

	for (i.Start(); !i.AtEnd(); i++)
		if (i()->IsPrim())
			if (RadCast(PrimCast(i()))->IntersectsWithRay(start, end))
				return(true);
	return(false);
}

Object *RadGroup::Clone() const
{
	Int i;
	RadGroup *result;

	result = new RadGroup(name);
	
	for (i = 0; i < children.NumItems(); i++)
		result->Add((scObject*) children[i]->Clone());

	return(result);
}

Void RadGroup::Compare(scPrimitive *to, GCLReal edgeLen,
					GCLReal &areaSum, Colour &cSum, Colour &cSqrSum, Colour &refSum)
{
	Assert(to->IsGroup(), "trying to compare group to a non-group.");
	
	scGroup *group = GroupCast(to);
	
	Assert(group->NumChildren() == NumChildren(), "group structures don't match");
	
	Int i;
	
	for (i = 0; i < NumChildren(); i++)
		if (Child(i)->IsPrim())
			RadCast(PrimCast(Child(i)))->Compare(PrimCast(group->Child(i)), edgeLen,
					areaSum, cSum, cSqrSum, refSum);
}

#pragma mark -
// --- RadPoly class -----------------------------


RadPoly::RadPoly() : scPoly(), RadPrim()
{
	props.colours = 0;
	elem = 0;
}

RadPoly::~RadPoly()
{
	delete elem;
	delete props.colours;	// XXX not valid once we handle global/embedded color lists...
}

Void RadPoly::Draw(Renderer &r, Context *context)
{
	Int i;
	// Draw polygon if there is no mesh yet...
	if (!elem)
		scPoly::Draw(r, context);
	else
		elem->Draw(r);
}

Void RadPoly::Print(ostream &s) const
{
	s << "poly +clrs " << props.colours->NumItems();	// XXX this needs to change when full cls are handled
	if (elem)
		elem->Print(s);
}

Void RadPoly::Parse(istream &s)
{
	Char c;
	Int numCols = 0;
	
	ChompSpace(s);
	
	while (s.peek() == '+')					// extension?
	{
		String str;
		
		s.get(c);
		str.ReadWord(s);
		
		if (str == "clrs")
			s >> numCols;
		else if (str == "grid")
			elem = new GridRadQuad;
		else if (str == "hgrid")
			elem = new GridHierQuad;
		else if (str == "haar")
			elem = new HaarQuad;
		else if (str == "f2")
			elem = new F2Quad;
		else if (str == "f3")
			elem = new F3Quad;
		else if (str == "m2")
			elem = new M2Quad;
		else if (str == "m3")
			elem = new M3Quad;
		else
		{
			cerr << "*** unknown option: '" << str << "'" << endl;
		}
		
		if (elem)
			elem->Parse(s);
		
		ChompSpace(s);
	}
		
	if (numCols > 0)
		props.colours = new ColourList(numCols);	// XXX
}

Bool RadPoly::PointInPoly(Vector &p, Int axis)
//	Test whether given point is in the (convex) polygon, when 
// 	projected onto the X-Z, Y-Z or Z-X plane.
//	'axis' specifies which axis to collapse to zero.
{
	static Int c1[] = { 1, 2, 0 };
	static Int c2[] = { 2, 0, 1 };
	
	Int X = c1[axis];
	Int Y = c2[axis];
	
	Int	i = 0, j, yflag0, yflag1, inside_flag, xflag0;
	
	GCLReal	ty, tx;
	Point	*vtx0, *vtx1;
	Int		items = NumVertices();
	Int		line_flag;

    tx = p[X];
    ty = p[Y];

    vtx0 = &(Vertex(items - 1));
    
    // get test bit for above/below X axis 
    
    yflag0 = ( (*vtx0)[Y] >= ty ) ;
    vtx1 = &(Vertex(0));

    inside_flag = 0 ;
    line_flag = 0 ;
	i = 0;

    for (j = items + 1; --j ; )
    {    
		yflag1 = ( (*vtx1)[Y] >= ty ) ;

	// check if endpoints straddle (are on opposite sides) of X axis
	// (i.e. the Y's differ); if so, +X ray could intersect this edge.
		if ( yflag0 != yflag1 )
		{
		    xflag0 = ((*vtx0)[X] >= tx );

		    // check if endpoints are on same side of the Y axis (i.e. X's
		    // are the same); if so, it's easy to test if edge hits or misses.
		    if ( xflag0 == ((*vtx1)[X] >= tx ))
		    {
			// if edge's X values both right of the point, must hit 
				if ( xflag0 )
				{
					inside_flag = !inside_flag;
				}
		    }
		    else
		    {
			// compute intersection of polygon segment with +X ray, note
			// if >= point's X; if so, the ray hits it.
				if (((*vtx1)[X] - ((*vtx1)[Y]-ty) *
				     ( (*vtx0)[X] - (*vtx1)[X]) / ((*vtx0)[Y] - (*vtx1)[Y])) >= tx )
				{
				    inside_flag = !inside_flag;
				}
			}
	    // if this is second edge hit, then done testing
	    if ( line_flag )
	    	goto Exit;

	    // note that one edge has been hit by the ray's line
	    line_flag = 1 ;
		}

	// move to next pair of vertices, retaining info as possible
		if (j > 1)
		{
			yflag0 = yflag1 ;
			vtx0 = vtx1 ;
		    vtx1 = &(Vertex(++i));
		}
    }
    Exit: ;

    return(inside_flag);
}

Coord RadPoly::FindCoord(Point &p)
{
	Vector	x, y, offset;
	Coord	result;
	
	Assert(elem != 0, "(Radpoly::FindCoord) elem is not defined.");
	
	if (elem->IsTri())
	{
		//	Find p in triangular coordinate system

		VecTrans	s, t;
		Vector		r;
		
		offset = Vertex(1);
		t[2] = elem->Normal();
		t[1] = Vertex(0) - offset;
		t[0] = Vertex(2) - offset;
		s = inv(t);
		offset = p - offset;

		r = offset * s;
		
		result[0] = r[0];
		result[1] = r[1];
	}
	else
	{
		//	Find p in quadrilateral coordinate system
		
		offset = Vertex(1);
		y = Vertex(0) - offset;
		x = Vertex(2) - offset;
		offset = p - offset;
		
		result[0] = 2 * dot(offset, x) / sqrlen(x) - 1;
		result[1] = 2 * dot(offset, y) / sqrlen(y) - 1;
	}
	
	return(result);
}

// --- Raytracing methods -----------------------------------

Void RadPoly::AddToGrid(Grid* grid)
{
	Int 	i;
	RTTri	*tri;

	Assert(elem != 0, "elem not set");
	
	tri = new RTTri;
	tri->v[0] = elem->index[0];
	tri->v[1] = elem->index[1];
	tri->v[2] = elem->index[2];
	tri->ptList = props.points;
	tri->data = (scPrimitive*) this;
	tri->MakeNormal();
	grid->AddTriangle(tri);
	
	// Add second triangle if quadrilateral
	if (elem->index[3] >= 0)
	{
		tri = new RTTri;
		tri->v[0] = elem->index[2];
		tri->v[1] = elem->index[3];
		tri->v[2] = elem->index[0];
		tri->ptList = props.points;
		tri->data = (scPrimitive*) this;
		tri->MakeNormal();
		grid->AddTriangle(tri);
	}
}

Bool RadPoly::FindBounds(Vector &min, Vector &max)
{
	if (!elem)
		return(false);
	
	UpdateBounds(elem->Vertex(0), min, max);
	UpdateBounds(elem->Vertex(1), min, max);
	UpdateBounds(elem->Vertex(2), min, max);

	if (elem->index[3] >= 0)
		UpdateBounds(elem->Vertex(3), min, max);
	
	return(true);
}

scPrimitive *RadPoly::ClosestIntersection(Point &start, Vector &dir, Point &p)
// Finds the closest intersection of the ray with one of the scene objects.
// Returns the object if an intersection has been found, and sets the 3d point and the texture coord.
// otherwise returns nil.
{
#define NORMAL props.normal
#define NORMCMP(x) props.normal[x]
	Int 		i;
	const GCLReal	epsilon = 1e-16;	
	GCLReal 		temp;

	temp = dot(dir, NORMAL);
		
	if (abs(temp) > epsilon)	// planar intersection not off at infinity?
	{
		temp = dot(Centre() - start, NORMAL) / temp;	// find point of planar intersection as distance along
														// dir
		if (temp >= epsilon)	// possible intersection?
		{
			p = start + dir * temp;			
			
	// Now we call PointInPoly with the ray's intersection with the polygon's plane, and an index
	// determining what axis-aligned plane the polygon and point are to be projected onto.

			if (abs(NORMCMP(0)) >= abs(NORMCMP(1)))			// Find ray.normal's largest component...
			{
				if (abs(NORMCMP(1)) >= abs(NORMCMP(2)))
					i = 0;
				else if (abs(NORMCMP(0)) >= abs(NORMCMP(2)))
					i = 0;
				else
					i = 2;
			}
			else if (abs(NORMCMP(2)) >= abs(NORMCMP(1)))
				i = 2;
			else
				i = 1;

			if (PointInPoly(p, i))
				return(this);
		}
	}

	return(0);
#undef NORMAL
#undef NORMCMP
}


Bool RadPoly::IntersectsWithRay(Point &start, Point &end)
// Returns true if there is an intersection, and it occurs within the open
// interval from start to end.
{
#define NORMAL props.normal
#define NORMCMP(x) props.normal[x]
	Int 		i;
	const GCLReal	epsilon = 0;	
	GCLReal 		temp;
	Point		p;
	
	temp = dot((end - start), NORMAL);
		
	if (abs(temp) > epsilon)	// planar intersection not off at infinity?
	{
		temp = dot((Centre() - start), NORMAL) / temp;	// find point of planar intersection as distance along
														// dir
		if (temp >= epsilon && temp <= 1 - epsilon)     // possible intersection is between start and end?
		{
			p = start + (end - start) * temp;			
			
	// Now we call PointInPoly with the ray's intersection with the polygon's plane, and an index
	// determining what axis-aligned plane the polygon and point are to be projected onto.
						
			if (abs(NORMCMP(0)) >= abs(NORMCMP(1)))			// Find ray.normal's largest component...
			{
				if (abs(NORMCMP(1)) >= abs(NORMCMP(2)))
					i = 0;
				else if (abs(NORMCMP(0)) >= abs(NORMCMP(2)))
					i = 0;
				else
					i = 2;
			}
			else if (abs(NORMCMP(2)) >= abs(NORMCMP(1)))
				i = 2;
			else
				i = 1;

			if (PointInPoly(p, i))
				return(true);
		}
	}

	return(false);
#undef NORMAL
#undef NORMCMP
}


#pragma mark -
// --- Radiosity-specific methods -------------------------------


Void RadPoly::Reanimate(RadOptions &options)
{	
	if (!elem)
		return;

	SetupProps(options);
	elem->SetProps(&props);
	elem->Reanimate(0);	
}

Void RadPoly::SetupProps(RadOptions &options)
{
	Colour*		emittancePtr;
	
	//	Fill in the properties structure...
	
	props.id = options.numPolys++;	
	if ((SO_GET(Colour) == 0))
	{
		cerr << "*** Warning: colour missing for radpoly" << endl;
		props.reflectance = cGrey50;
	}
	else
		props.reflectance = *SO_GET(Colour);	// XXX ignore context?
	
	if (emittancePtr = SO_GET(Emittance))
		props.emittance = *emittancePtr;
	else
		props.emittance = cBlack;
	
	//	We are assuming that at this stage the entire scene shares one points list,
	//	and that a colours list has been created. Be warned!
	
	Assert(SO_GET(Points) != 0 /* XXX && SO_GET(Colours)*/, "(RadPoly::InitRad) Scene is missing points or colours list.");
	
	props.points = SO_GET(Points);
	
	// Eventually we will allocate just one colour list, and attempt to handle colour index properties
	// in the scene. 
	
	props.options = &options;

	elem->area = len(cross(Vertex(1) - Vertex(0), Vertex(2) - Vertex(0)));
	if (elem->IsTri())
		elem->area *= 0.5;
		
	// This should be replaced with something more numerically stable. It could fail for
	// degenerate tris.
	
	props.normal = norm(cross((Vertex(1) - Vertex(0)), (Vertex(2) - Vertex(1))));
	elem->SetProps(&props);
}

Void RadPoly::InitRad(Context *context, RadOptions &options)
{
	IndexList	*indexes;
	Int			i;
	
	//	Get rid of any previously-built quad-tri tree.
		
	delete elem;
		
	//	Allocate a new one
		
	elem = options.radObject->NewMesh();
	
	//	Set up indices according to index list if there is one. If not, just number 0..2|3.

	if (!(indexes = SC_GET(Indexes)))
	{
		PointList *points = SC_GET(Points);
		Assert(points->NumItems() == 4 || points->NumItems() == 3, "(RadPoly::InitRad) Poly is not a Quad or a Tri!");
		
		elem->index[3] = -1;
		
		for (i = 0; i < points->NumItems(); i++)
			elem->index[i] = i;
	}
	else 
	{
		Assert(indexes->NumItems() == 4 || indexes->NumItems() == 3, "(RadPoly::InitRad) Poly is not a Quad or a Tri!");

		elem->index[3] = -1;
					
		for (i = 0; i < indexes->NumItems(); i++)
			elem->index[i] = (*indexes)[i];
	}
			
	for (i = 0; i < NumVertices(); i++)	//	for now, assume all polys are disjoint.
		elem->clrIdx[i] = i;

	props.colours = new ColourList(NumVertices());

	//	Now, setup props, and fill in necessary elem fields.
		
	SetupProps(options);
}

Colour RadPoly::Sample(GCLReal u, GCLReal v)
{
	if (elem)
		return(elem->Sample(Coord(u, v)));
	else
		return(props.reflectance);
}

Void RadPoly::Compare(scPrimitive *to, GCLReal edgeLen,
			GCLReal &areaSum, Colour &cSum, Colour &cSqrSum, Colour &refSum)
{
	// Sample density is controlled by edgelen: sample every edgeLen
	// units in either dimension. Same deal as with patchSubdivs.
	
	// XXX currently quad-specific
	
	Colour	err, c1, c2;
	Coord	b,c;
	Colour	pcSum, pcSqrSum, pRefSum;
	Int		nx, ny, i, j;
	GCLReal	xlen, ylen, weight;
	
	xlen = len(Vertex(3) - Vertex(0));
	ylen = len(Vertex(1) - Vertex(0));
	
	nx = edgeLen * xlen;
	ny = edgeLen * ylen;
	if (nx < 1) nx = 1;
	if (ny < 1) ny = 1;

	pcSum.MakeZero();
	pRefSum.MakeZero();
	pcSqrSum.MakeZero();
	
	// Sample away!!!!
	
	for (i = 0; i < nx; i++)
		for (j = 0; j < ny; j++)
		{
			c[0] = 2 * (0.5 + i) / GCLReal(nx) - 1;
			c[1] = 2 * (0.5 + j) / GCLReal(ny) - 1;
		
			c1 = elem->Sample(c);
			c2 = ((RadPoly *) RadCast(to))->elem->Sample(c);
	
			err = c1 - c2;
			pcSum += err;
			pRefSum += (c1 - elem->Emittance());
			pcSqrSum += err * err;
		}
	
	areaSum += elem->area;
	weight = elem->area / GCLReal(nx * ny);
	pcSum *= weight;
	pRefSum *= weight;
	pcSqrSum *= weight;

	cSum += pcSum;
	cSqrSum += pcSqrSum;
	refSum += pRefSum;
}

Void RadPoly::Smooth()
// Smears colours of the mesh polygons out over nearest neighbours. 
{
	if (props.colours)
	{
		Int		i, j, k;
		Vecd	weights(props.colours->NumItems());
		
		weights.MakeZero();
		
		for (i = 0; i < weights.Elts(); i++)
			(*props.colours)[i].MakeZero();
			
		elem->Smooth(weights);
			
		for (i = 0; i < weights.Elts(); i++)
		{
			if (weights[i] > 0)
				(*props.colours)[i] /= weights[i];
		}	
	}
}


#pragma mark -
// --- 


Void RadPoly::GetTrees(TreeList &trees)
{	
	((HRQuad*) elem)->GetTrees(trees);
}

Void RadPoly::CreatePatches(PatchList &patches, PatchStats *stats)
{
	Int i;
	
	// Subdivide base poly to initial mesh, accumulate into polys and
	// patches lists.	
				
	elem->CreatePatches(patches, stats);
}

#pragma mark -
// --- Radiosity library ------------------------------------------------


Void RadLib::Create()
{
	AddMember("group", new RadGroup);
	AddMember("poly", new RadPoly);
	
	AddPolyObjects();
	
	name = "radiosity library";
}

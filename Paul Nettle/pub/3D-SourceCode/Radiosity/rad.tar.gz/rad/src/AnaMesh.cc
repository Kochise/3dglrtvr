/*
	File:			AnaMesh.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

*/

#include "AnaMesh.h"
#include "AnaRad.h"

Colour GridAnaQuad::Sample(Coord c)
{
	Int		i, j;
	Colour	patchCol;
	GCLReal	s = (c[0] + 1.0) / 2.0;
	GCLReal	t = (c[1] + 1.0) / 2.0;		
	// XXX quad-specific
	Point	p = Vertex(0) + s * (Vertex(3) - Vertex(0)) + t * (Vertex(1) - Vertex(0));
	AnaRad	*rad = (AnaRad*) props->options->radObject;

	patchCol = cBlack;
		
	for (j = 0; j < rad->polys.NumItems(); j++)	
		patchCol += rad->polys[j]->Emittance() * rad->polys[j]->PatchFactor(p, Normal());
		
	patchCol *= Reflectance();
	patchCol += Emittance();
	
	return(patchCol);
}

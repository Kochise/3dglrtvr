/*
	File:			AnaRad.h

	Function:		Provides a class for lighting a scene using matrix
					radiosity.
					
	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott
 */

#ifndef __AnaRad__
#define __AnaRad__

#include "Rad.h"

class AnaRad : public RadMethod
{
	public:
	
	AnaRad(RadOptions &options, Renderer *displayP, GraphicsSystem *gsP) : 
			RadMethod(options, displayP, gsP) {};

	Bool		Render();			// override
	Int			Stage(Int stage);	// override
	Void		DumpStats();

	RadQuad		*NewMesh();

	PatchList	polys;
};

#endif

/*
	File:			HierMesh.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			Need to finish triangular mesh.

*/

#include "HierMesh.h"
#include "String.h"
#include "VecUtil.h"

// --- Internal routines ------------------------------------

static Void PrintCode(ostream &s, Int level, Int treeCode);


/*
	Directional set up for a quad element is as follows:

				  0
	
			+-----+-----+
			|     |     |
			|  0  |  3  |
		1	|_____|_____|	3
			|     |     |
			|  1  |  2  |
			|     |     |
			+-----+-----+
				  
				  2
		
	Vertex numbers match with quadrant numbers. So the midpoint of side 1 (west)
	will be vertex 2 of quadrant 0, or vertex 0 of quadrant 2.
*/

/*
	The setup for triangular quaternary subdivisions is as follows:
	
                  /\
                 /  \
                /  0 \
           0   /______\    2
              /\      /\
             /  \  3 /  \
            /  1 \  /  2 \ 
           /______\/______\

                   1
                   
	The subtlety here is that the centre triangle is a rotated
	version of the original. Moreover, all the neighbouring 
	triangles of any given triangle are of a different rotational
	persuasion, which leads to the surprising result that the opposite
	of any particular direction is itself. (Think about it!)
	Also, child 3's neighbours are all internal to the local subdivision.
*/


// --- Constructors ---------------------------------------------


HierQuad::HierQuad() : parent(0), level(0)
{
	Int i;
	
	treeCode = 0;
	
	for (i = 0; i < 4; i++)
	{
		child[i] = 0;
		neighbour[i] = 0;
	}
}

HierQuad::~HierQuad()
{
	Int i;
	
	for (i = 0; i < 4; i++)
		delete child[i];	
}


static Int tOppDir[] =   { 2, 3, 0, 1 };	// Opposite direction lookup table
static Int tDirToCh1[] = { 0, 1, 2, 3 };	// Tables to find children in a certain direction
static Int tDirToCh2[] = { 3, 0, 1, 2 };	// e.g., the two children in dir 1 (west) are 0 and 2	 

static Int tTDirToCh1[] = { 0, 1, 2 };		// Tables to find children in a certain direction
static Int tTDirToCh2[] = { 1, 2, 0 };		// e.g., the two children in dir 0 (north west) are 0 and 1	
 
  
Void HierQuad::ConnectNeighbours()
{
	Int			i, oppDir, ch1, ch2, ch1o, ch2o;
	HierQuad	**tmp;
	
	//	Note: might convert this from tables to calculations sometime, to take
	//	advantage of register vs memory accesses. Hopefully the tables stay
	//	in the data cache, though.

	if (IsQuad())
	{
		child[0]->neighbour[2] = child[1];		// Make neighbour connections between children.
		child[0]->neighbour[3] = child[3];
		child[1]->neighbour[0] = child[0];
		child[1]->neighbour[3] = child[2];
		child[2]->neighbour[0] = child[3];
		child[2]->neighbour[1] = child[1];
		child[3]->neighbour[1] = child[0];
		child[3]->neighbour[2] = child[2];

		for (i = 0; i < 4; i++)									// iterate over the directions...
			if (neighbour[i] && neighbour[i]->HasChildren())	// do we have a neighbour with children?
			{
				tmp = neighbour[i]->child;
				oppDir = tOppDir[i];
				ch1 = tDirToCh1[i];
				ch2 = tDirToCh2[i];
				ch1o = tDirToCh1[oppDir];
				ch2o = tDirToCh2[oppDir];
				
				//	notify neighbour's children that they have new neighbours...
			
				tmp[ch1o]->neighbour[oppDir] = child[ch2];
				tmp[ch2o]->neighbour[oppDir] = child[ch1];
				
				//	& vice-versa
			
				child[ch1]->neighbour[i] = tmp[ch2o];
				child[ch2]->neighbour[i] = tmp[ch1o];
			}
			else
			{
				child[tDirToCh1[i]]->neighbour[i] = 0;
				child[tDirToCh2[i]]->neighbour[i] = 0;
			}
	}
	else	// IsTri()
	{
		// Make neighbour connections between children
	
		child[0]->neighbour[1] = child[3];
		child[1]->neighbour[2] = child[3];
		child[2]->neighbour[0] = child[3];
		child[3]->neighbour[0] = child[2];
		child[3]->neighbour[1] = child[0];
		child[3]->neighbour[2] = child[1];

		for (i = 0; i < 3; i++)									// iterate over the directions...
			if (neighbour[i] && neighbour[i]->HasChildren())	// do we have a neighbour with children?
			{
				tmp = neighbour[i]->child;
				ch1 = tTDirToCh1[i];
				ch2 = tTDirToCh2[i];
				
				//	notify neighbour's children that they have new neighbours...
			
				tmp[ch1]->neighbour[i] = child[ch2];
				tmp[ch2]->neighbour[i] = child[ch1];
				
				//	& vice-versa
			
				child[ch1]->neighbour[i] = tmp[ch2];
				child[ch2]->neighbour[i] = tmp[ch1];
			}
			else
			{
				child[tTDirToCh1[i]]->neighbour[i] = 0;
				child[tTDirToCh2[i]]->neighbour[i] = 0;
			}
	}
}

Void HierQuad::Subdivide()
{
	Int i;
	
	// Hand off to our children if we have them...
	if (HasChildren())
	{
		for (i = 0; i < 4; i++)
			child[i]->Subdivide();
		
		return;
	}

	Int 		centreIndex, midPoint[4];
	Int 		centreClrIdx, midColour[4];
	Int 		oppDir, ch1, ch2, n;
	HierQuad	**tmp;
	
	if (IsQuad())
	// Add centrepoint of quad.
	{
		centreIndex = props->AddPoint(Centre());
		centreClrIdx = props->AddColour(0.25 * (Clr(0) + Clr(1) + Clr(2) + Clr(3)));
	}
	
	for (i = 0; i < 4; i++)
		child[i] = New();				// Allocate the children
	
	// Fill in children's indices, creating new midpoints as necessary.
	
	if (IsTri())
	{
		for (i = 0; i < 3; i++)									// Iterate over the directions...
			if (neighbour[i] && neighbour[i]->HasChildren())	// Do we have a neighbour with children?
			{
				tmp = neighbour[i]->child;
				ch1 = tTDirToCh1[i];
				ch2 = tTDirToCh2[i];
				
				//	If so, fetch neighbour's midpoint on this edge
			
				midPoint[i] = tmp[ch1]->index[ch2];	
				midColour[i] = tmp[ch1]->clrIdx[ch2];	
			}
			else
				//	Otherwise, create a new one.
			{	
				midPoint[i] = props->AddPoint((Vertex(tTDirToCh1[i]) + Vertex(tTDirToCh2[i])) * 0.5);
				midColour[i] = props->AddColour((Clr(tTDirToCh1[i]) + Clr(tTDirToCh2[i])) * 0.5);
			}
			
		child[0]->SetIndexes(index[0], midPoint[0], midPoint[2], -1);
		child[1]->SetIndexes(midPoint[0], index[1], midPoint[1], -1);
		child[2]->SetIndexes(midPoint[2], midPoint[1], index[2], -1);
		child[3]->SetIndexes(midPoint[1], midPoint[2], midPoint[0], -1);

		child[0]->SetClrIdxs(clrIdx[0], midColour[0], midColour[2], -1);
		child[1]->SetClrIdxs(midColour[0], clrIdx[1], midColour[1], -1);
		child[2]->SetClrIdxs(midColour[2], midColour[1], clrIdx[2], -1);
		child[3]->SetClrIdxs(midColour[1], midColour[2], midColour[0], -1);
	}
	else	// IsQuad()
	{
		for (i = 0; i < 4; i++)									// Iterate over the directions...
			if (neighbour[i] && neighbour[i]->HasChildren())	// Do we have a neighbour with children?
			{
				tmp = neighbour[i]->child;						
				oppDir = tOppDir[i];
				ch1 = tDirToCh1[oppDir];
				ch2 = tDirToCh2[oppDir];
				
				//	If so, fetch neighbour's midpoint on this edge
			
				midPoint[i] = tmp[ch1]->index[ch2];	
				midColour[i] = tmp[ch1]->clrIdx[ch2];	
			}
			else
			//	Otherwise, create a new one.
			{
				midPoint[i] = props->AddPoint((Vertex(tDirToCh1[i]) + Vertex(tDirToCh2[i])) / 2);
				midColour[i] = props->AddColour((Clr(tDirToCh1[i]) + Clr(tDirToCh2[i])) / 2);
			}
			
		//	Fill in indices.
		
		child[0]->SetIndexes(index[0], midPoint[1], centreIndex, midPoint[0]);
		child[1]->SetIndexes(midPoint[1], index[1], midPoint[2], centreIndex);
		child[2]->SetIndexes(centreIndex, midPoint[2], index[2], midPoint[3]);
		child[3]->SetIndexes(midPoint[0], centreIndex, midPoint[3], index[3]);

		child[0]->SetClrIdxs(clrIdx[0], midColour[1], centreClrIdx, midColour[0]);
		child[1]->SetClrIdxs(midColour[1], clrIdx[1], midColour[2], centreClrIdx);
		child[2]->SetClrIdxs(centreClrIdx, midColour[2], clrIdx[2], midColour[3]);
		child[3]->SetClrIdxs(midColour[0], centreClrIdx, midColour[3], clrIdx[3]);
	}
	
	//	Now, fill in the neighbour fields
	
	ConnectNeighbours();
	
	//	And fill in other useful fields...
	
	for (i = 0; i < 4; i++)
	{
		child[i]->area = area / 4;
		child[i]->treeCode = (treeCode << 2) | i;
		child[i]->SetProps(props);
		child[i]->SetParent(SELF);
	}
		
	// Subdivide neighbours to maintain an evenly-graded mesh: each quad is 
	// subdivided to within one level of its neighbours.

	if (props->options->graded && parent)
	{
		Int n = 3;
		
		if (IsQuad())
			n++;
			
		// If we don't have a neighbour at our level, but our parent has one,
		// subdivide it so it's within one level of our (new) children.
	
		for (i = 0; i < n; i++)
			if (!neighbour[i] && parent->neighbour[i])
				parent->neighbour[i]->Subdivide();
	}
}

Void HierQuad::Reanimate(RadQuad *par)
{
	RadQuad::Reanimate(parent);
	
	parent = (HierQuad *) par;
	if (parent)
		SetProps(parent->props);
	
	if (HasChildren())
	{
		ConnectNeighbours();
		
		child[0]->Reanimate(this);
		child[1]->Reanimate(this);
		child[2]->Reanimate(this);
		child[3]->Reanimate(this);
	}
}

Void HierQuad::SetParent(HierQuad &itsParent)
{
	colour = itsParent.colour;
	parent = &itsParent;
	level = itsParent.level + 1;
}

Void HierQuad::SetIndexes(Int i1, Int i2, Int i3, Int i4)
{
	index[0] = i1;
	index[1] = i2;
	index[2] = i3;
	index[3] = i4;
}

Void HierQuad::SetClrIdxs(Int i1, Int i2, Int i3, Int i4)
{
	clrIdx[0] = i1;
	clrIdx[1] = i2;
	clrIdx[2] = i3;
	clrIdx[3] = i4;
}

Void HierQuad::Smooth(Vecd &weights)
{
	if (HasChildren())
	{
		Int i;
		
		for (i = 0; i < 4; i++)
			child[i]->Smooth(weights);
	}
	else
	{
		Int i, idx, oppDir, n = 3;
		
		if (IsQuad())
			n++;
			
		for (i = 0; i < n; i++)
		{
			Clr(i) += colour;
			weights[clrIdx[i]] += 1;
		}
		
		if (IsQuad())
		{
			// iterate over directions
			
			for (i = 0; i < 4 ; i++)
				if (neighbour[i] && neighbour[i]->HasChildren())	// if we have neighbours
				{
					oppDir = tOppDir[i];

					// find index of neighbouring midcolour.

					idx = neighbour[i]->child[tDirToCh1[oppDir]]->clrIdx[tDirToCh2[oppDir]];
					
					// add in 2 x our colour, because if we were subdivided, two of our children would
					// contribute to this midpoint.
					
					(*props->colours)[idx] += 2 * colour;
					weights[idx] += 2;
				}
		}
		else
		{
			for (i = 0; i < 3 ; i++)
				if (neighbour[i] && neighbour[i]->HasChildren())
				{					
					idx = neighbour[i]->child[tTDirToCh1[i]]->clrIdx[tTDirToCh2[i]];
	
					// add in 3 x our colour, because if we were subdivided, three of our children would
					// contribute to this midpoint.

					(*props->colours)[idx] += 3 * colour;
					weights[idx] += 3;
				}
		}
	}
}

// --- Anchored drawing routines ------------------------------

// Not for the faint of heart!


#define DRAW_QUAD(C0, V0, C1, V1, C2, V2, C3, V3) \
	r.Begin(style).C(C0).P(V0).C(C1).P(V1).C(C2).P(V2).C(C3).P(V3).End()
#define DRAW_TRI(C0, V0, C1, V1, C2, V2) \
	r.Begin(style).C(C0).P(V0).C(C1).P(V1).C(C2).P(V2).End()
#define PROJ_QUAD(C0, V0, C1, V1, C2, V2, C3, V3) \
			r.Begin(style); \
			Project(r, C0, V0); \
			Project(r, C1, V1); \
			Project(r, C2, V2); \
			Project(r, C3, V3); \
			r.End()
#define PROJ_TRI(C0, V0, C1, V1, C2, V2) \
			r.Begin(style); \
			Project(r, C0, V0); \
			Project(r, C1, V1); \
			Project(r, C2, V2); \
			r.End()

Void HierQuad::DrawQuad(Renderer &r, RenderStyle style, Int code, Point *midPoint, Colour *midColour)
// Draw a quad with anchoring.
{
	switch (code)	// 16 cases for a quad...
	{
	case 0:
		DRAW_QUAD(Clr(0), Vertex(0), Clr(1), Vertex(1), Clr(2), Vertex(2), Clr(3), Vertex(3));
		break;
	case 1:
		DRAW_TRI(Clr(0), Vertex(0), midColour[3], midPoint[3], Clr(3), Vertex(3));
		DRAW_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[3], midPoint[3]);
		DRAW_TRI(Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[3], midPoint[3]);
		break;
	case 2:
		DRAW_TRI(Clr(3), Vertex(3), midColour[2], midPoint[2], Clr(2), Vertex(2));
		DRAW_TRI(Clr(3), Vertex(3), Clr(0), Vertex(0), midColour[2], midPoint[2]);
		DRAW_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[2], midPoint[2]);
		break;
	case 3:
		DRAW_TRI(Clr(0), Vertex(0), midColour[2], midPoint[2], midColour[3], midPoint[3]);
		DRAW_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[2], midPoint[2]);
		DRAW_TRI(Clr(0), Vertex(0), midColour[3], midPoint[3], Clr(3), Vertex(3));
		DRAW_TRI(midColour[2], midPoint[2], Clr(2), Vertex(2), midColour[3], midPoint[3]);
		break;
	case 4:
		DRAW_TRI(Clr(2), Vertex(2), midColour[1], midPoint[1], Clr(1), Vertex(1));
		DRAW_TRI(Clr(2), Vertex(2), Clr(3), Vertex(3), midColour[1], midPoint[1]);
		DRAW_TRI(Clr(3), Vertex(3), Clr(0), Vertex(0), midColour[1], midPoint[1]);
		break;
	case 5:
		DRAW_QUAD(Clr(0), Vertex(0), midColour[1], midPoint[1], midColour[3], midPoint[3], Clr(3), Vertex(3));
		DRAW_QUAD(midColour[1], midPoint[1], Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[3], midPoint[3]);
		break;				
	case 6:
		DRAW_TRI(Clr(3), Vertex(3), midColour[1], midPoint[1], midColour[2], midPoint[2]);
		DRAW_TRI(Clr(3), Vertex(3), Clr(0), Vertex(0), midColour[1], midPoint[1]);
		DRAW_TRI(Clr(3), Vertex(3), midColour[2], midPoint[2], Clr(2), Vertex(2));
		DRAW_TRI(midColour[1], midPoint[1], Clr(1), Vertex(1), midColour[2], midPoint[2]);
		break;				
	case 7:
		DRAW_QUAD(Clr(0), Vertex(0), midColour[1], midPoint[1], midColour[3], midPoint[3], Clr(3), Vertex(3));
		DRAW_TRI(midColour[1], midPoint[1] , midColour[2], midPoint[2] , midColour[3], midPoint[3]);
		DRAW_TRI(midColour[1], midPoint[1], Clr(1), Vertex(1), midColour[2], midPoint[2]);
		DRAW_TRI(midColour[2], midPoint[2], Clr(2), Vertex(2), midColour[3], midPoint[3]);
		break;				
	case 8:
		DRAW_TRI(Clr(1), Vertex(1), midColour[0], midPoint[0], Clr(0), Vertex(0));
		DRAW_TRI(Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[0], midPoint[0]);
		DRAW_TRI(Clr(2), Vertex(2), Clr(3), Vertex(3), midColour[0], midPoint[0]);
		break;				
	case 9:
		DRAW_TRI(Clr(1), Vertex(1), midColour[3], midPoint[3], midColour[0], midPoint[0]);
		DRAW_TRI(Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[3], midPoint[3]);
		DRAW_TRI(Clr(1), Vertex(1), midColour[0], midPoint[0], Clr(0), Vertex(0));
		DRAW_TRI(midColour[3], midPoint[3], Clr(3), Vertex(3), midColour[0], midPoint[0]);
		break;				
	case 10:
		DRAW_QUAD(Clr(1), Vertex(1), midColour[2], midPoint[2], midColour[0], midPoint[0], Clr(0), Vertex(0));
		DRAW_QUAD(midColour[2], midPoint[2], Clr(2), Vertex(2), Clr(3), Vertex(3), midColour[0], midPoint[0]);
		break;				
	case 11:
		DRAW_QUAD(Clr(1), Vertex(1), midColour[2], midPoint[2], midColour[0], midPoint[0], Clr(0), Vertex(0));
		DRAW_TRI(midColour[2], midPoint[2] , midColour[3], midPoint[3] , midColour[0], midPoint[0]);
		DRAW_TRI(midColour[2], midPoint[2], Clr(2), Vertex(2), midColour[3], midPoint[3]);
		DRAW_TRI(midColour[3], midPoint[3], Clr(3), Vertex(3), midColour[0], midPoint[0]);
		break;				
	case 12:
		DRAW_TRI(Clr(2), Vertex(2), midColour[0], midPoint[0], midColour[1], midPoint[1]);
		DRAW_TRI(Clr(2), Vertex(2), Clr(3), Vertex(3), midColour[0], midPoint[0]);
		DRAW_TRI(Clr(2), Vertex(2), midColour[1], midPoint[1], Clr(1), Vertex(1));
		DRAW_TRI(midColour[0], midPoint[0], Clr(0), Vertex(0), midColour[1], midPoint[1]);
		break;				
	case 13:
		DRAW_QUAD(Clr(2), Vertex(2), midColour[3], midPoint[3], midColour[1], midPoint[1], Clr(1), Vertex(1));
		DRAW_TRI(midColour[3], midPoint[3] , midColour[0], midPoint[0] , midColour[1], midPoint[1]);
		DRAW_TRI(midColour[3], midPoint[3], Clr(3), Vertex(3), midColour[0], midPoint[0]);
		DRAW_TRI(midColour[0], midPoint[0], Clr(0), Vertex(0), midColour[1], midPoint[1]);
		break;				
	case 14:
		DRAW_QUAD(Clr(3), Vertex(3), midColour[0], midPoint[0], midColour[2], midPoint[2], Clr(2), Vertex(2));
		DRAW_TRI(midColour[0], midPoint[0] , midColour[1], midPoint[1] , midColour[2], midPoint[2]);
		DRAW_TRI(midColour[0], midPoint[0], Clr(0), Vertex(0), midColour[1], midPoint[1]);
		DRAW_TRI(midColour[1], midPoint[1], Clr(1), Vertex(1), midColour[2], midPoint[2]);
		break;				
	case 15:
		DRAW_TRI(Clr(0), Vertex(0), midColour[1], midPoint[1], midColour[0], midPoint[0]);
		DRAW_TRI(midColour[0], midPoint[0], midColour[3], midPoint[3], Clr(3), Vertex(3));
		DRAW_TRI(midColour[1], midPoint[1], Clr(1), Vertex(1), midColour[2], midPoint[2]);
		DRAW_TRI(midColour[2], midPoint[2], Clr(2), Vertex(2), midColour[3], midPoint[3]);
		DRAW_QUAD(midColour[0], midPoint[0], midColour[1], midPoint[1], midColour[2], midPoint[2], midColour[3], midPoint[3]);
		break;				
	}
}

Void HierQuad::DrawTri(Renderer &r, RenderStyle style, Int code, Point *midPoint, Colour *midColour)
{
//	Draw a triangle with anchoring
	switch (code)	// 8 cases for a tri...
	{
	case 0:
		DRAW_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1) , Clr(2), Vertex(2));
		break;
	case 1:
		DRAW_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[2], midPoint[2]);
		DRAW_TRI(Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[2], midPoint[2]);
		break;
	case 2:
		DRAW_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[1], midPoint[1]);
		DRAW_TRI(midColour[1], midPoint[1], Clr(2), Vertex(2), Clr(0), Vertex(0));
		break;
	case 3:
		DRAW_QUAD(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[1], midPoint[1], midColour[2], midPoint[2]);
		DRAW_TRI(midColour[1], midPoint[1], Clr(2), Vertex(2), midColour[2], midPoint[2]);
		break;
	case 4:
		DRAW_TRI(Clr(0), Vertex(0), midColour[0], midPoint[0], Clr(2), Vertex(2));
		DRAW_TRI(midColour[0], midPoint[0], Clr(1), Vertex(1), Clr(2), Vertex(2));
		break;
	case 5:
		DRAW_TRI(Clr(0), Vertex(0), midColour[0], midPoint[0], midColour[2], midPoint[2]);
		DRAW_QUAD(midColour[0], midPoint[0], Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[2], midPoint[2]);
		break;				
	case 6:
		DRAW_QUAD(Clr(0), Vertex(0), midColour[0], midPoint[0], midColour[1], midPoint[1], Clr(2), Vertex(2));
		DRAW_TRI(midColour[0], midPoint[0], Clr(1), Vertex(1), midColour[1], midPoint[1]);
		break;				
	case 7:
		DRAW_TRI(Clr(0), Vertex(0), midColour[0], midPoint[0], midColour[2], midPoint[2]);
		DRAW_TRI(midColour[0], midPoint[0], Clr(1), Vertex(1), midColour[1], midPoint[1]);
		DRAW_TRI(midColour[2], midPoint[2], midColour[1], midPoint[1], Clr(2), Vertex(2));
		DRAW_TRI(midColour[0], midPoint[0], midColour[1], midPoint[1], midColour[2], midPoint[2]);
		break;				
	}
}

Void HierQuad::ProjQuad(Renderer &r, RenderStyle style, Int code, Point *midPoint, Colour *midColour)
// Projected version of DrawQuad
{
	switch (code)	// 16 cases for a quad...
	{
	case 0:
		PROJ_QUAD(Clr(0), Vertex(0), Clr(1), Vertex(1), Clr(2), Vertex(2), Clr(3), Vertex(3));
		break;
	case 1:
		PROJ_TRI(Clr(0), Vertex(0), midColour[3], midPoint[3], Clr(3), Vertex(3));
		PROJ_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[3], midPoint[3]);
		PROJ_TRI(Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[3], midPoint[3]);
		break;
	case 2:
		PROJ_TRI(Clr(3), Vertex(3), midColour[2], midPoint[2], Clr(2), Vertex(2));
		PROJ_TRI(Clr(3), Vertex(3), Clr(0), Vertex(0), midColour[2], midPoint[2]);
		PROJ_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[2], midPoint[2]);
		break;
	case 3:
		PROJ_TRI(Clr(0), Vertex(0), midColour[2], midPoint[2], midColour[3], midPoint[3]);
		PROJ_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[2], midPoint[2]);
		PROJ_TRI(Clr(0), Vertex(0), midColour[3], midPoint[3], Clr(3), Vertex(3));
		PROJ_TRI(midColour[2], midPoint[2], Clr(2), Vertex(2), midColour[3], midPoint[3]);
		break;
	case 4:
		PROJ_TRI(Clr(2), Vertex(2), midColour[1], midPoint[1], Clr(1), Vertex(1));
		PROJ_TRI(Clr(2), Vertex(2), Clr(3), Vertex(3), midColour[1], midPoint[1]);
		PROJ_TRI(Clr(3), Vertex(3), Clr(0), Vertex(0), midColour[1], midPoint[1]);
		break;
	case 5:
		PROJ_QUAD(Clr(0), Vertex(0), midColour[1], midPoint[1], midColour[3], midPoint[3], Clr(3), Vertex(3));
		PROJ_QUAD(midColour[1], midPoint[1], Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[3], midPoint[3]);
		break;				
	case 6:
		PROJ_TRI(Clr(3), Vertex(3), midColour[1], midPoint[1], midColour[2], midPoint[2]);
		PROJ_TRI(Clr(3), Vertex(3), Clr(0), Vertex(0), midColour[1], midPoint[1]);
		PROJ_TRI(Clr(3), Vertex(3), midColour[2], midPoint[2], Clr(2), Vertex(2));
		PROJ_TRI(midColour[1], midPoint[1], Clr(1), Vertex(1), midColour[2], midPoint[2]);
		break;				
	case 7:
		PROJ_QUAD(Clr(0), Vertex(0), midColour[1], midPoint[1], midColour[3], midPoint[3], Clr(3), Vertex(3));
		PROJ_TRI(midColour[1], midPoint[1] , midColour[2], midPoint[2] , midColour[3], midPoint[3]);
		PROJ_TRI(midColour[1], midPoint[1], Clr(1), Vertex(1), midColour[2], midPoint[2]);
		PROJ_TRI(midColour[2], midPoint[2], Clr(2), Vertex(2), midColour[3], midPoint[3]);
		break;				
	case 8:
		PROJ_TRI(Clr(1), Vertex(1), midColour[0], midPoint[0], Clr(0), Vertex(0));
		PROJ_TRI(Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[0], midPoint[0]);
		PROJ_TRI(Clr(2), Vertex(2), Clr(3), Vertex(3), midColour[0], midPoint[0]);
		break;				
	case 9:
		PROJ_TRI(Clr(1), Vertex(1), midColour[3], midPoint[3], midColour[0], midPoint[0]);
		PROJ_TRI(Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[3], midPoint[3]);
		PROJ_TRI(Clr(1), Vertex(1), midColour[0], midPoint[0], Clr(0), Vertex(0));
		PROJ_TRI(midColour[3], midPoint[3], Clr(3), Vertex(3), midColour[0], midPoint[0]);
		break;				
	case 10:
		PROJ_QUAD(Clr(1), Vertex(1), midColour[2], midPoint[2], midColour[0], midPoint[0], Clr(0), Vertex(0));
		PROJ_QUAD(midColour[2], midPoint[2], Clr(2), Vertex(2), Clr(3), Vertex(3), midColour[0], midPoint[0]);
		break;				
	case 11:
		PROJ_QUAD(Clr(1), Vertex(1), midColour[2], midPoint[2], midColour[0], midPoint[0], Clr(0), Vertex(0));
		PROJ_TRI(midColour[2], midPoint[2] , midColour[3], midPoint[3] , midColour[0], midPoint[0]);
		PROJ_TRI(midColour[2], midPoint[2], Clr(2), Vertex(2), midColour[3], midPoint[3]);
		PROJ_TRI(midColour[3], midPoint[3], Clr(3), Vertex(3), midColour[0], midPoint[0]);
		break;				
	case 12:
		PROJ_TRI(Clr(2), Vertex(2), midColour[0], midPoint[0], midColour[1], midPoint[1]);
		PROJ_TRI(Clr(2), Vertex(2), Clr(3), Vertex(3), midColour[0], midPoint[0]);
		PROJ_TRI(Clr(2), Vertex(2), midColour[1], midPoint[1], Clr(1), Vertex(1));
		PROJ_TRI(midColour[0], midPoint[0], Clr(0), Vertex(0), midColour[1], midPoint[1]);
		break;				
	case 13:
		PROJ_QUAD(Clr(2), Vertex(2), midColour[3], midPoint[3], midColour[1], midPoint[1], Clr(1), Vertex(1));
		PROJ_TRI(midColour[3], midPoint[3] , midColour[0], midPoint[0] , midColour[1], midPoint[1]);
		PROJ_TRI(midColour[3], midPoint[3], Clr(3), Vertex(3), midColour[0], midPoint[0]);
		PROJ_TRI(midColour[0], midPoint[0], Clr(0), Vertex(0), midColour[1], midPoint[1]);
		break;				
	case 14:
		PROJ_QUAD(Clr(3), Vertex(3), midColour[0], midPoint[0], midColour[2], midPoint[2], Clr(2), Vertex(2));
		PROJ_TRI(midColour[0], midPoint[0] , midColour[1], midPoint[1] , midColour[2], midPoint[2]);
		PROJ_TRI(midColour[0], midPoint[0], Clr(0), Vertex(0), midColour[1], midPoint[1]);
		PROJ_TRI(midColour[1], midPoint[1], Clr(1), Vertex(1), midColour[2], midPoint[2]);
		break;				
	case 15:
		PROJ_TRI(Clr(0), Vertex(0), midColour[1], midPoint[1], midColour[0], midPoint[0]);
		PROJ_TRI(midColour[0], midPoint[0], midColour[3], midPoint[3], Clr(3), Vertex(3));
		PROJ_TRI(midColour[1], midPoint[1], Clr(1), Vertex(1), midColour[2], midPoint[2]);
		PROJ_TRI(midColour[2], midPoint[2], Clr(2), Vertex(2), midColour[3], midPoint[3]);
		PROJ_QUAD(midColour[0], midPoint[0], midColour[1], midPoint[1], midColour[2], midPoint[2], midColour[3], midPoint[3]);
		break;				
	}
}

Void HierQuad::ProjTri(Renderer &r, RenderStyle style, Int code, Point *midPoint, Colour *midColour)
// Projected version of DrawTri
{
	switch (code)	// 8 cases for a tri...
	{
	case 0:
		PROJ_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1) , Clr(2), Vertex(2));
		break;
	case 1:
		PROJ_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[2], midPoint[2]);
		PROJ_TRI(Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[2], midPoint[2]);
		break;
	case 2:
		PROJ_TRI(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[1], midPoint[1]);
		PROJ_TRI(midColour[1], midPoint[1], Clr(2), Vertex(2), Clr(0), Vertex(0));
		break;
	case 3:
		PROJ_QUAD(Clr(0), Vertex(0), Clr(1), Vertex(1), midColour[1], midPoint[1], midColour[2], midPoint[2]);
		PROJ_TRI(midColour[1], midPoint[1], Clr(2), Vertex(2), midColour[2], midPoint[2]);
		break;
	case 4:
		PROJ_TRI(Clr(0), Vertex(0), midColour[0], midPoint[0], Clr(2), Vertex(2));
		PROJ_TRI(midColour[0], midPoint[0], Clr(1), Vertex(1), Clr(2), Vertex(2));
		break;
	case 5:
		PROJ_TRI(Clr(0), Vertex(0), midColour[0], midPoint[0], midColour[2], midPoint[2]);
		PROJ_QUAD(midColour[0], midPoint[0], Clr(1), Vertex(1), Clr(2), Vertex(2), midColour[2], midPoint[2]);
		break;				
	case 6:
		PROJ_QUAD(Clr(0), Vertex(0), midColour[0], midPoint[0], midColour[1], midPoint[1], Clr(2), Vertex(2));
		PROJ_TRI(midColour[0], midPoint[0], Clr(1), Vertex(1), midColour[1], midPoint[1]);
		break;				
	case 7:
		PROJ_TRI(Clr(0), Vertex(0), midColour[0], midPoint[0], midColour[2], midPoint[2]);
		PROJ_TRI(midColour[0], midPoint[0], Clr(1), Vertex(1), midColour[1], midPoint[1]);
		PROJ_TRI(midColour[2], midPoint[2], midColour[1], midPoint[1], Clr(2), Vertex(2));
		PROJ_TRI(midColour[0], midPoint[0], midColour[1], midPoint[1], midColour[2], midPoint[2]);
		break;				
	}
}


// --- Control method for anchored draw ------------------------------------------


Void HierQuad::DrawLeaf(Renderer &r)
{
	if (props->options->gouraud && props->options->anchor)		// Draw a T-meshed tri/quad
	{
		if (props->options->funcView)
		{
			r.Begin(renLineLoop).C(cWhite);
			SendPoints(r);
			r.End();
		}
		
		if (highlight)
		{
			if (highlight == 1)
				r.C(cRed);
			else if (highlight == 2)
				r.C(cYellow);
			else if (highlight == 3)
				r.C(cGreen);
			
			r.Begin(renPoly);
			SendPoints(r);
			r.End();
			
			if (!props->options->funcView)
				return;
		}	

		Point		midPoint[4];
		Colour		midColour[4];
		Int			i, oppDir, code = 0;
		HierQuad	**tmp;
		RenderStyle style;
				
		if (props->options->wire)
			style = renLineLoop;
		else
			style = renPoly;
		
		if (IsQuad())		// T-mesh a quad...
		{
			for (i = 0; i < 4 ; i++)		// Build midpoint code
			{
				code = code << 1;
				if (neighbour[i] && neighbour[i]->HasChildren())
				{
					tmp = neighbour[i]->child;
					oppDir = tOppDir[i];
					
					midPoint[i] = tmp[tDirToCh1[oppDir]]->Vertex(tDirToCh2[oppDir]);	
					midColour[i] = tmp[tDirToCh1[oppDir]]->Clr(tDirToCh2[oppDir]);
					code |= 1;
				}
			}
			
			if (props->options->funcView)
				ProjQuad(r, style, code, midPoint, midColour);	
			else
				DrawQuad(r, style, code, midPoint, midColour);
		}
		else	// T-meshing a tri
		{
			for (i = 0; i < 3 ; i++)		// Build midpoint code
			{
				code = code << 1;
				if (neighbour[i] && neighbour[i]->HasChildren())
				{
					tmp = neighbour[i]->child;

					midPoint[i] = tmp[tTDirToCh1[i]]->Vertex(tTDirToCh2[i]);	
					midColour[i] = tmp[tTDirToCh1[i]]->Clr(tTDirToCh2[i]);
					code |= 1;
				}
			}
			
			if (props->options->funcView)
				ProjTri(r, style, code, midPoint, midColour);
			else
				DrawTri(r, style, code, midPoint, midColour);
		}		
	}
	else
		RadQuad::Draw(r);
}

Void HierQuad::Draw(Renderer &r)
{
	Int i;

	if (HasChildren() && !highlight && (!props->options->choke || props->options->choke > level))
		for (i = 0; i < 4; i++)
			child[i]->Draw(r);
	else
		DrawLeaf(r);
}

// --- Tree code utils ----------------------------------------------------


static Void PrintCode(ostream &s, Int level, Int treeCode)
{
	Int i;
	
	for (i = level - 1; i >= 0; i--)
		s << ((treeCode >> (2 * i)) & 3);
}

Void HierQuad::PrintID(ostream &s)
{
	s << props->id;
	if (level > 0)
		 s << ":";
	PrintCode(s, level, treeCode);
}

Void HierQuad::PrintSelf(ostream &s)
{
	RadQuad::Print(s);
}

Void HierQuad::PrintRec(ostream &s)
{
	PrintSelf(s);
	
	if (HasChildren())
	{
		s << " { ";
		child[0]->PrintRec(s);
		child[1]->PrintRec(s);
		child[2]->PrintRec(s);
		child[3]->PrintRec(s);
		s << "} ";
	}
}

Void HierQuad::Print(ostream &s)
{
	PrintRec(s);
}

Void HierQuad::ParseSelf(istream &s)
{
	RadQuad::Parse(s);
}

Void HierQuad::Parse(istream &s)
{
	Char c;
	Int i;

	ParseSelf(s);

	ChompSpace(s);
	
	if (s.peek() == '{')					// children?
	{
		s.get(c);
		
		for (i = 0; i < 4; i++)
		{
			child[i] = New();
			child[i]->Parse(s);
		}	  
		
		ChompSpace(s);
		if (s.peek() != '}')	
			_Warning("(HierQuad::Parse) didn't find '}'");
		else	
			s.get(c);
	}
	else
		for (i = 0; i < 4; i++)
			child[i] = 0;
}

RadQuad *HierQuad::FindContainer(Coord &coord)
{
	// Find the child the coord belongs to, and recursively descend.
	
	if (!HasChildren())
		return(this);
	else if (IsTri())
	{
		if (coord[0] + coord[1] < 0.5)	// bottom-left
		{
			coord[0] *= 2;
			coord[1] *= 2;
			return(child[1]->FindContainer(coord));
		}
		else if (coord[1] > 0.5)		// top 
		{
			coord[0] *= 2;
			coord[1] = 2 * coord[1] - 1;
			return(child[0]->FindContainer(coord));
		}
		else if (coord[0] > 0.5)		// bottom-right
		{
			coord[1] *= 2;
			coord[0] = 2 * coord[0] - 1;
			return(child[2]->FindContainer(coord));
		}
		else							// middle
		{
			coord[0] = 1 - 2 * coord[0];
			coord[1] = 1 - 2 * coord[1];
			return(child[3]->FindContainer(coord));
		}
	}
	else
	{
		coord *= 2.0;
		if (coord[0] < 0)
			if (coord[1] < 0)
			{
				coord += Vec2d(1, 1);
				return(child[1]->FindContainer(coord));
			}
			else
			{
				coord += Vec2d(1, -1);
				return(child[0]->FindContainer(coord));
			}
		else
			if (coord[1] < 0)
			{
				coord += Vec2d(-1, 1);
				return(child[2]->FindContainer(coord));
			}
			else
			{
				coord += Vec2d(-1, -1);
				return(child[3]->FindContainer(coord));
			}
	}
}

GCLReal HierQuad::RadError()
{
	Int		i, n = 3;
	Colour	sum, sumsqr, temp; 
	
	sum.MakeZero(); sumsqr.MakeZero();
	
	if (IsQuad())
		n++;
	
	for (i = 0; i < n; i++)
	{
		temp = Clr(i);
		sum += temp;
		sumsqr += sqr(temp);
	}
	
	return(sqrt(dot(kRadRGBToLum, sumsqr * n - sqr(sum))));
}


#pragma mark -
// --- Bilevel radiosity methods -------------------------------------


Void HierQuad::CreatePatches(PatchList &patches, PatchStats *stats)
{
	Int i;

	level = 0;

	if (area < 1 / sqr(props->options->patchSubdivs))
	{
		patches.Append(this);
	}
	else
	{
		if (!HasChildren())
			Subdivide();
		for (i = 0; i < 4; i++)
			child[i]->CreatePatches(patches, stats);
	}
}

Void HierQuad::CreateElements(PatchList &elements, IndexList &eltParents, Int parent)
{
	Int i, j;
			
	if (area < 1 / sqr(props->options->eltSubdivs))
	{
		elements.Append(this);
		eltParents.Append(parent);
	}
	else	
	{
		if (!HasChildren())
			Subdivide();
		for (i = 0; i < 4; i++)
			child[i]->CreateElements(elements, eltParents, parent);
	}
}

Void HierQuad::CollectColour(Colour &c)
{
	if (HasChildren())
	{
		Int i;
		
		for (i = 0; i < 4; i++)
			child[i]->CollectColour(c);
	}
	else
		c += colour * area;
}

Void HierQuad::SetColour(const Colour &c)
{
	colour = c;

	if (HasChildren())
	{
		child[0]->SetColour(c);
		child[1]->SetColour(c);
		child[2]->SetColour(c);
		child[3]->SetColour(c);
	}
}


#pragma mark -


Void GridHierQuad::AddChild(RadQuad &quad, Int i, Int j, Int in, Int jn)
{
	// Called by ::Mesh to add a new quad to the grid.
	
	if (i == 0 && j == 0)
		children.PreAllocate(in * jn);
	
	children.Add(1);
	(RadQuad &) children.Last() = quad;
}

Void GridHierQuad::ConnectChildren()
//	Fill in the neighbour fields of all our children.
{
	Int i, j;
	Int pos;
	
	//	Join up mesh neighbours
	
	if (IsQuad())
	{
		// traverse the rectangular grid

		for (i = 0; i < rows; i++)
			for (j = 0; j < cols; j++)
			{
				pos = i * cols + j;
			
				if (i > 0) 	// connect with top neighbour
				{
					children[pos].neighbour[0] = &(children[pos - cols]);
					children[pos - cols].neighbour[2] = &(children[pos]);
				}
				if (j > 0)	// connect with left neighbour
				{
					children[pos].neighbour[1] = &(children[pos - 1]);
					children[pos - 1].neighbour[3] = &(children[pos]);
				}
			}
	}
	else
	{
		Int	orient, left, upper;

		pos = 0;
		
		// traverse the triangular grid
		
		/*
			2	1
		  0 +--+		the diagonal is dir 2 for both tris
			|\ |		the upper/lower side is dir 1 for both tris
			| \|		the left/right side is dir 0 for both tris. 
			+--+ 0		lower tri is orient = 0, upper is orient = 1.
		   1   2
		
		*/

		for (i = 0; i < rows; i++)
			for (j = 0; j < 2 * i + 1; j++)
			{
				orient = (i + pos) & 1;		// which way is this tri oriented?
						
				if (i > 0 && orient)		// connect with top neighbour
				{
					upper = pos - 2 * i;	// index of upper neighbour
					children[pos].neighbour[1] = &(children[upper]);
					children[upper].neighbour[1] = &(children[pos]);
				}
				if (j > 0 || orient)		// connect with left/diagonal neighbour
				{
					left = pos - 1;			// index of left neighbour
					orient = orient << 1;	// direction 1 or 2?
					children[pos].neighbour[orient] = &(children[left]);
					children[left].neighbour[orient] = &(children[pos]);
				}
				pos++;
			}
	}
}


Void GridHierQuad::Draw(Renderer &r)
{
	if (children.NumItems() > 0 && !highlight)
	{
		Int i;
		
		for (i = 0; i < children.NumItems(); i++)
			children[i].Draw(r);
	}
	else
		RadQuad::Draw(r);
}


Void GridHierQuad::CreatePatches(PatchList &patches, PatchStats *stats)
{
	Int i;
	
	if (stats)
	{
		FindMinCmpts(stats->minRefl, props->reflectance, stats->minRefl);
		FindMaxCmpts(stats->maxRefl, props->reflectance, stats->maxRefl);
	}

	if (props->options->patchSubdivs == 0.0)
	{
		patches.Append(this);
		return;
	}
		
	Mesh(props->options->patchSubdivs);	
	ConnectChildren();
	
	for (i = 0; i < children.NumItems(); i++)
	{
		patches.Append(&(children[i]));
			
		if (stats)
		{
			if (children[i].area > stats->maxArea)
				stats->maxArea = children[i].area;
			if (children[i].area < stats->minArea)
				stats->minArea = children[i].area;
		}
	}
}

RadQuad *GridHierQuad::FindContainer(Coord &coord)
{
	cout << "coord was: " << coord << endl;
	Int i = FindChildIndex(coord);
	cout << "coord is now: " << coord << "[" << i << "]" << endl;
	
	return(children[i].FindContainer(coord));
}

Void GridHierQuad::Smooth(Vecd &weights)
{
	Int i;
	
	for (i = 0; i < children.NumItems(); i++)
		children[i].Smooth(weights);
}

Void GridHierQuad::Print(ostream &s)
{
	s << " +hgrid ";
	RadQuad::Print(s);
	s << rows << ' ' << cols << ' ' << children << ' ';
}

Void GridHierQuad::Parse(istream &s)
{
	Int i;
	Char c;

	RadQuad::Parse(s);	

	s >> rows >> cols;
	children.SetSize(rows * cols);

	ChompSpace(s);	// XXX temporary workaround for >> failure on long line...
	s.get(c);
	for (i = 0; i < children.NumItems(); i++)
		children[i].Parse(s);
	ChompSpace(s);
	s.get(c);

	// XXX temporary fix -- we should be read/writing the top-level elem as well.
	index[3] = children[0].index[3];	

	ConnectChildren();

	for (i = 0; i < children.NumItems(); i++)
		children[i].props = props;
}

Void GridHierQuad::Reanimate(RadQuad *parent)
{
	Int i;

	if (parent)
		SetProps(parent->props);

	for (i = 0; i < children.NumItems(); i++)
		children[i].Reanimate(this);
}

/*
	File:			HRMesh.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

*/

#include "HRMesh.h"
#include "Rad.h"


// --- RadLink methods -------------------------------------


RadLink::RadLink() : from(0), to(0)
{
}

Int RadLink::RefineOracle(GCLReal &kAError, GCLReal &kFError)
{
	GCLReal	w, err;
    Vector	temp;
	GCLReal	fromProj, toProj;

	if (visibility > 0.0 && visibility < 1.0)
		w = from->props->options->visError;
	else
		w = 1.0;
		
	if (from->props->options->useBF)
		err = BFError();
	else
		err = Error();
	
	if (err < 0.0) err = 0.0;
	if (err < kFError * w)
		return(kSubNone);

	//	Projected area of the two patches
	
    temp = norm(to->Centre() - from->Centre());
    toProj = -dot(to->Normal(), temp) * to->area;
    fromProj = dot(from->Normal(), temp) * from->area;

	if (toProj < 0) toProj = 0;
	if (fromProj < 0) fromProj = 0;

	//	Decide which patch to subdivide...

	if (toProj > fromProj)
		if (to->area < kAError)
			return(kSubNone);
		else
			return(kSubTo);
	else 
		if (from->area < kAError)
			return(kSubNone);
		else
			return(kSubFrom);
}

Void RadLink::Print(ostream &s)
{
	s << "["; from->PrintID(s); s << "->"; to->PrintID(s); s << "] ";
}

Void RadLink::DrawLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom, GCLReal weight)
{
	r.C(cCyan).Rect(left, top, right, bottom);
}

ostream &operator << (ostream &s, RadLink &rl)
{
	rl.Print(s);
	
	return(s);
}


#pragma mark -
// --- Useful #defines ----------------------------------


#define HRQChild(x) ((HRQuad *) child[x])
#define HRQCast(x) ((HRQuad *) x)


// --- HRQuad methods -------------------------------------------


HRQuad::HRQuad() : HierQuad()
{
}	
	
Void HRQuad::DrawContributors(Renderer &r)
{
	LinkIter i;

	for (i.Begin(links); !i.AtEnd(); i.Inc())
		i.Data().from->DrawLeaf(r);	
}

Void HRQuad::DrawContributorsRec(Renderer &r)
{
	Int i;
	
	DrawContributors(r);
	if (HasChildren())
		for (i = 0; i < 4; i++)
			HRQChild(i)->DrawContributorsRec(r);
}

Void HRQuad::Draw(Renderer &r)
{
	Int		i, saveWire;
	HRQuad	*upper;
	
	if (props->options->patchView && props->options->pvData)
	{
		// in patch view mode...
		
		if (props->options->pvData == this)	
		{
			// this is the patch being viewed...
			
			DrawLeaf(r);						// draw it.
			props->options->patchView = false;
			DrawContributors(r);				// draw its contributors
			
			saveWire = props->options->wire;
			props->options->wire = true;
			upper = (HRQuad *) parent;
			while (upper != 0)					// draw everything contributing to higher levels of
			{									// the tree
				upper->Draw(r);
				upper->DrawContributors(r);
				upper = (HRQuad *) upper->parent;
			}
			
			props->options->redWire = true;		// draw everything contributing to lower levels of the tree
			if (HasChildren())
				for (i = 0; i < 4; i++)
					HRQChild(i)->DrawContributorsRec(r);
			props->options->redWire = false;
			
			props->options->wire = saveWire;
			props->options->patchView = true;
		}
		else if (HasChildren())			 // Otherwise, check children...
			for (i = 0; i < 4; i++)
				child[i]->Draw(r);
	}
	else
		HierQuad::Draw(r);
}


GCLReal HRQuad::EstSubFormFactor(Int i1, Int j1, HRQuad *to, 
			GCLReal x2, GCLReal y2, Int n, GCLReal *visPtr)
//	x, y E [0, 1], origin at patch's top left corner (vertex 0).
{
	GCLReal	result, rad4, npt, res2;
	Vector	temp;
	Point	srcPt, dstPt;
	Vector	dx2 = to->Vertex(2) - to->Vertex(1);	//	0	|	1 ----> 2
	Vector	dy2 = to->Vertex(1) - to->Vertex(0);	//	dy	|		dx
	Vector	dx1 = 	  Vertex(2) -     Vertex(1);	//		|
	Vector 	dy1 = 	  Vertex(1) -     Vertex(0);	//	1	v
	GCLReal x1, y1, rn = n;

	if (to->IsQuad())
	{
		x2 = (x2 + 1) / 2;
		y2 = (y2 + 1) / 2;
	}
	else
		y2 = 1 - y2;
	
	if (IsQuad())
	{
		x1 = (j1 + 0.5) / rn;
		y1 = (i1 + 0.5) / rn;
	}
	else if (i1 + j1 >= n)
	{
		x1 = 1 - (i1 + 1.0/3.0) / rn;
		y1 = (j1 + 1.0/3.0) / rn;
	}
	else
	{
		x1 = (j1 + 1.0/3.0) / rn;
		y1 = 1 - (i1 + 1.0/3.0) / rn;
	}
	
	dstPt = to->Vertex(0) + x2 * dx2 + y2 * dy2;
	srcPt = (Vertex(0) + x1 * dx1 + y1 * dy1);
	temp = dstPt;
	temp -= srcPt;
	
	if (props->options->showLinks)
		props->options->display->P(dstPt).P(srcPt);
		
	result = -dot(to->Normal(), temp);
	
	if (result <= 0)
		return(0.0);
	else 
	{
		npt = dot(Normal(), temp);
		
		if (npt <= 0)
			return(0.0);
		else
		{
			GCLReal sArea = area / sqr(rn);
			
			rad4 = sqr(sqrlen(temp));
			result *= sArea / vl_pi;
			res2 = result * Max(npt, 0.25 * sqrt(sArea));

			if (props->options->quadLevel > 0 &&
				rad4 * props->options->dFError < res2)
			{
				Vector v0, v1, v2, v3;

				// result is blowing up!
				// let's bail to the patch factor formula
				
				dx1 /= rn;
				dy1 /= rn;
				v0 = Vertex(0) - dstPt;
				if (IsQuad())
				{
					v0 += j1 * dx1 + i1 * dy1;
					v1 = v0 + dy1;
					v2 = v1 + dx1;
					v3 = v0 + dx1;
				}
				else if (i1 + j1 >= n)
				{
					v0 += (n - i1) * dx1 + j1 * dy1;
					v1 = v0 - dx1;
					v2 = v0 + dy1;
				}
				else
				{
					v0 += j1 * dx1 + (n - i1) * dy1;
					v1 = v0 + dx1;
					v2 = v0 - dy1;
				}				
								
				result = EdgeArea(v0, v1, to->Normal());
				result += EdgeArea(v1, v2, to->Normal());
				if (IsQuad())
				{
					result += EdgeArea(v2, v3, to->Normal());
					result += EdgeArea(v3, v0, to->Normal());
				}
				else
					result += EdgeArea(v2, v0, to->Normal());
				
				if (result < 0.0)
					return(0.0);
			}
			else
				result *= npt / rad4;
		}
	}

	if (visPtr)
	{
		srcPt += surfEps * Normal();
		dstPt += surfEps * to->Normal();
		
		if (!RadCast(props->options->scene)->IntersectsWithRay(srcPt, dstPt))
			*visPtr	+= 1.0;
		else
			return(0.0);
	}
	
	return(result);
}

GCLReal HRQuad::SubToSubFormFactor(Int i1, Int j1, HRQuad *to,
			Int i2, Int j2, Int n, GCLReal *visPtr)
{
	GCLReal x2, y2;

	if (to->IsQuad())
	{
		x2 = (2 * j2 + 1 - n) / n;
		y2 = (2 * i2 + 1 - n) / n;
	}
	else if (i2 + j2 >= n)
	{
		x2 = 1 - (i2 + 1.0/3.0) / n;
		y2 = 1 - (j2 + 1.0/3.0) / n;
	}
	else
	{
		x2 = (j2 + 1.0/3.0) / n;
		y2 = (i2 + 1.0/3.0) / n;
	}
		
	return(EstSubFormFactor(i1, j1, to, x2, y2, n, visPtr));
}

GCLReal HRQuad::SampleKernel(GCLReal x1, GCLReal y1, HRQuad *to, GCLReal x2, GCLReal y2, GCLReal *visPtr)
//	x, y E [-1, 1], origin at patch's top left corner (vertex 0).
{
	GCLReal	result;
	Vector	temp, delta;
	Point	srcPt, dstPt;
	Vector	dx2 = to->Vertex(2) - to->Vertex(1);	//	0	|	1 ----> 2
	Vector	dy2 = to->Vertex(1) - to->Vertex(0);	//	dy	|		dx
	Vector	dx1 = 	  Vertex(2) -     Vertex(1);	//		|
	Vector 	dy1 = 	  Vertex(1) -     Vertex(0);	//	1	v
	
	if (IsQuad())
	{
		x1 = (x1 + 1.0) / 2.0;
		y1 = (y1 + 1.0) / 2.0;
	}
	else
		y1 = 1 - y1;

	if (to->IsQuad())
	{
		x2 = (x2 + 1.0) / 2.0;
		y2 = (y2 + 1.0) / 2.0;
	}
	else
		y2 = 1 - y2;

	srcPt = Vertex(0) + x1 * dx1 + y1 * dy1;
	dstPt = to->Vertex(0) + x2 * dx2 + y2 * dy2;

	
	delta = dstPt;
	delta -= srcPt;

	temp = norm(delta);
	result = dot(Normal(), temp);
	
	if (result <= 0.0)
		return(0.0);
	else 
	{
		result *= -dot(to->Normal(), temp);
		
		if (result <= 0.0)
			return(0.0);
		else
			result *= area / (sqrlen(delta) * vl_pi);
	}
		
	if (visPtr)
	{
		// Sample visibility...
		srcPt += surfEps * Normal();
		dstPt += surfEps * to->Normal();
		
		if (!RadCast(props->options->scene)->IntersectsWithRay(srcPt, dstPt))
			*visPtr	+= 1.0;
		else
			return(0.0);
	}

	return(result);
}


// --- RadLink Refinement ------------------------


Void HRQuad::Refine(LinkNode *link)
{
	Int			i, j, which;
	GCLReal		factor, visibility;
	
	which = link->RefineOracle(props->options->kAError, props->options->kFError);
	
	if (props->options->showLinks)
	{
		RM_DISPLAY_START;
		props->options->display->Begin(renLines);
	}
		
	if (which == kSubNone)			// Form link here.
	{
		links.Prepend(link);
		
		if (props->options->showLinks)
		{
			props->options->display->
				C(cRed).P(Centre()).P(link->from->Centre()).End();
			RM_DISPLAY_END;
			RM_OUT1("Forming link here.");
			if (RM_PAUSE) return;
		}
	}
	else if (which == kSubTo)		// Subdivide 'to' patch (this one!)
	{
		if (props->options->showLinks)
		{
			props->options->display->C(cGreen)
				.P(Centre()).P(link->from->Centre());
			RM_DISPLAY_END;
			RM_OUT1("Pushing link down to children of receiver");
			if (RM_PAUSE) return;
		}
		
		if (!HasChildren())
		{
			Subdivide();
			Push();
		}
		for (i = 0; i < 4; i++)
			HRQChild(i)->Refine(link->CreateSubLink(link->from, HRQChild(i)));
	}
	else if (which == kSubFrom)		// Subdivide 'from' patch
	{
		if (props->options->showLinks)
		{
			props->options->display->C(cBlue).P(Centre())
				.P(link->from->Centre()).End();
			RM_DISPLAY_END;
			RM_OUT1("Pushing link down to children of source");
			if (RM_PAUSE) return;
		}
		
		if (!link->from->HasChildren())
		{
			link->from->Subdivide();
			link->from->Push();
		}
			
		for (i = 0; i < 4; i++)
			Refine(link->CreateSubLink(HRQCast(link->from->child[i]), this));		
	}		
	else 							// Subdivide both patches
	{
		if (props->options->showLinks)
		{
			props->options->display->C(cYellow).P(Centre())
				.P(link->from->Centre()).End();
			RM_DISPLAY_END;
			RM_OUT1("Pushing link down to children of source & dest");
			if (RM_PAUSE) return;
		}
		
		if (!HasChildren())
		{
			Subdivide();
			Push();
		}

		if (!link->from->HasChildren())
		{
			link->from->Subdivide();
			link->from->Push();
		}
			
		for (i = 0; i < 4; i++)
			for (j = 0; j < 4; j++)
				HRQChild(j)->Refine(link->CreateSubLink(HRQCast(link->from->child[i]), HRQChild(j)));		
	}		
}

Bool HRQuad::RefineFurther()
//	Refines any links whose error is too high, both in this element and
//	its children.
//	Returns true if any links were refined.
{
	LinkIter	i;
	Int 		j, which;
	Bool		split = false;
		
	// bottom-up traversal to avoid refining a link more than once.
	if (HasChildren())
		for (j = 0; j < 4; j++)
			if (HRQChild(j)->RefineFurther())
				split = true;

	// Step through links, see whether any should be pushed down the hierarchy.
	for (i.Begin(links); !i.AtEnd(); i.Inc())
	{
		which = i.Data().RefineOracle(props->options->kAError, props->options->kFError);
		
		if (which == kSubTo)				// push link down to p's children
		{
			if (props->options->showLinks)
			{
				props->options->display->Begin(renLines).C(cGreen).P(Centre()).P(i.Data().from->Centre()).End();
				RM_OUT1("Pushing link down to children of receiver.");
				if (RM_PAUSE) return(false);
			}
			
			if (!HasChildren())
			{
				Subdivide();
				Push();
			}
			
			for (j = 0; j < 4; j++)
				HRQChild(j)->links.Prepend(i.Data().CreateSubLink(i.Data().from, HRQChild(j)));
				
			i.Delete();
		}
		else if (which == kSubFrom)			// replace link with links to q's children
		{
			if (props->options->showLinks)
			{
				props->options->display->Begin(renLines).C(cBlue).P(Centre()).P(i.Data().from->Centre()).End();
				RM_OUT1("Pushing link down to children of source.");
				if (RM_PAUSE) return(false);
			}				

			if (!i.Data().from->HasChildren())
			{
				i.Data().from->Subdivide();
				i.Data().from->Push();
			}
			
			for (j = 0; j < 4; j++)
				i.InsertBefore(i.Data().CreateSubLink(HRQCast(i.Data().from->child[j]), this));		
			
			i.Delete();
		}
		
		if (which != kSubNone)
			split = true;
			
		if (i.AtEnd())	// XXX
			break;
	}
	
	return(split);	
}


// --- Matrix display --------------------------------------------------


Void HRQuad::DrawMatrix(Renderer &r, Int numBasePatches)
{
	LinkIter	i;
	Int			j;
	GCLReal		x, y, wx, wy, n, m, temp;	
		
	// Step through links, and draw each one in the appropriate position.
		
	wy = 2.0 / GCLReal(numBasePatches);
	y = 1 - 2 * GCLReal(props->id) / GCLReal(numBasePatches);

	if (level > 0)
	{
		m = 1.0 / GCLReal(1 << (2 * level));
		wy *= m;

		y -= GCLReal(treeCode) * wy;	
	}
	else
		m = 1;
	
	// Draw row of the matrix
	
	for (i.Begin(links); !i.AtEnd(); i.Inc())
	{			
		wx = 2.0 / GCLReal(numBasePatches);
		x = 2 * GCLReal(i.Data().from->props->id) / GCLReal(numBasePatches) - 1;
		
		if (i.Data().from->level > 0)
		{
			n = 1.0 / GCLReal(1 << (2 * i.Data().from->level));
			wx *= n;

			x += GCLReal(i.Data().from->treeCode) * wx;
		}
		else
			n = 1;
		
		if (highlight == 2 || i.Data().from->highlight == 3) 
		{
			if (highlight == 2 && i.Data().from->highlight == 3)
				r.C(cPurple);
			else if (highlight == 2) 
				r.C(cYellow);
			else
				r.C(cGreen); 
			r.Rect(x, y, x + wx, y - wy);
		}
		else
			i.Data().DrawLink(r, x, y, x + wx, y - wy, GCLReal(numBasePatches) * (1 << (2 * i.Data().to->level)));
	}

	if (HasChildren())
		for (j = 0; j < 4; j++)
			HRQChild(j)->DrawMatrix(r, numBasePatches);
}

Void HRQuad::CalcStats()
{
	LinkIter i;
	
	for (i.Begin(links); !i.AtEnd(); i.Inc())
		props->options->numLinks++;
	props->options->numPatches++;
	
	if (HasChildren())
	{
		((HRQuad *) child[0])->CalcStats();
		((HRQuad *) child[1])->CalcStats();
		((HRQuad *) child[2])->CalcStats();
		((HRQuad *) child[3])->CalcStats();
	}
}

Void HRQuad::Gather()
{
	LinkIter i;
	
	ClearR();

	for (i.Begin(links); !i.AtEnd(); i.Inc())
	{
		i.Data().Gather();
		
		if (props->options->showLinks)
			props->options->display->Begin(renLines).C(cRed).P(Centre()).P(i.Data().from->Centre()).End();
	}
}

#pragma mark -


Void HRQuad::PushPull()
{
	Int		i;
			
	Add();       // Add R in to B: accumulated radiosity from this and higher levels

	if (HasChildren())
	{				
	    Push();  // Push B down to children's B's
		
		for (i = 0; i < 4; i++)
		    HRQChild(i)->PushPull();   // recurse
		
		Pull();       
	}
}

Void HRQuad::GatherAll()
{
	Int		i;
		
	Gather();    // Gather radiosity across all links to this patch into R
		
	if (HasChildren())
	{				
		for (i = 0; i < 4; i++)
		    HRQChild(i)->GatherAll();   // recurse
	}
}

Void HRQuad::Print(ostream &s)
{
	LinkIter i;
	
	PrintID(s);
	s << " = ";
	HierQuad::PrintSelf(s);
	s << ' ';
	for (i.Begin(links); !i.AtEnd(); i.Inc())
		s << i.Data();
		
	s << endl;
}

Void HRQuad::GetTrees(TreeList &trees)
{
	trees.Append(this);
}

Void HRQuad::DrawSampledLeaf(Renderer &r, Int n)
{
	Int			i, j;
	Vector		dx = (Vertex(2) - Vertex(1)) / GCLReal(n);
	Vector		dy = (Vertex(1) - Vertex(0)) / GCLReal(n);
	Point		pt;
	GCLReal		ds = 2.0 / GCLReal(n);
	GCLReal		tds = 1.0 / GCLReal(n);
	GCLReal		sx, sy;
	Bool		project = props->options->funcView;
			
	// Render patch by drawing a mesh of (linearly interpolated)
	// sample points. 'n' controls the number of elements in the mesh.
	 
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++)
		{
			if (project)
			{
				r.Begin(renPoly);

				if (IsQuad())
				{
					pt = Vertex(0) + dx * j + dy * i;
					sx = ds * j - 1; sy = 1 - ds * i;
					Project(r, SampleLeaf(Coord(sx, sy)), pt);
					Project(r, SampleLeaf(Coord(sx, sy - ds)), pt + dy);
					Project(r, SampleLeaf(Coord(sx + ds, sy - ds)), pt + dx + dy);
					Project(r, SampleLeaf(Coord(sx + ds, sy)), pt + dx);
				}
				else if (j - i > 0)
				{
					pt = Vertex(0) + dx * i + dy * j;
					sx = tds * i; sy = 1 - tds * j;
					Project(r, SampleLeaf(Coord(sx, sy)), pt);
					Project(r, SampleLeaf(Coord(sx + tds, sy)), pt + dx);
					Project(r, SampleLeaf(Coord(sx + tds, sy - tds)), pt + dx + dy);
				}
				else
				{
					pt = Vertex(0) + dx * j + dy * i;
					sx = tds * j; sy = 1 - tds * i;
					Project(r, SampleLeaf(Coord(sx, sy)), pt);
					Project(r, SampleLeaf(Coord(sx, sy - tds)), pt + dy);
					Project(r, SampleLeaf(Coord(sx + tds, sy - tds)), pt + dx + dy);
				}

				r.End();
			}
			else
			{
				r.Begin(renPoly);

				if (IsQuad())
				{
					sx = ds * j - 1; sy = 1 - ds * i;
					pt = Vertex(0) + dx * j + dy * i;
					r.C(SampleLeaf(Coord(sx, sy))).P(pt);
					r.C(SampleLeaf(Coord(sx, sy - ds))).P(pt + dy);
					r.C(SampleLeaf(Coord(sx + ds, sy - ds))).P(pt + dx + dy);
					r.C(SampleLeaf(Coord(sx + ds, sy))).P(pt + dx);
				}
				else if (j - i > 0)
				{
					pt = Vertex(0) + dx * i + dy * j;
					sx = tds * i; sy = 1 - tds * j;
					r.C(SampleLeaf(Coord(sx, sy))).P(pt);
					r.C(SampleLeaf(Coord(sx + tds, sy))).P(pt + dx);
					r.C(SampleLeaf(Coord(sx + tds, sy - tds))).P(pt + dx + dy);
				}
				else
				{
					pt = Vertex(0) + dx * j + dy * i;
					sx = tds * j; sy = 1 - tds * i;
					r.C(SampleLeaf(Coord(sx, sy))).P(pt);
					r.C(SampleLeaf(Coord(sx, sy - tds))).P(pt + dy);
					r.C(SampleLeaf(Coord(sx + tds, sy - tds))).P(pt + dx + dy);
				}

				r.End();
			}
		}	
}

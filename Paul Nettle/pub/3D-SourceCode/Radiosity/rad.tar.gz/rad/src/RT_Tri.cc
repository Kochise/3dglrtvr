#include "RT_Tri.h"

Int RTTri::gStamp = 0;

// --- Triangle routines ------------------------------------


#define CROSS_X_3(a, b, c)	((a[1] - b[1]) * (c[2] - b[2]) - (a[2] - b[2]) * (c[1] - b[1]))
//	returns (a - b) x (c - a) . (1, 0, 0)
#define CROSS_Y_3(a, b, c)	((a[2] - b[2]) * (c[0] - b[0]) - (a[0] - b[0]) * (c[2] - b[2]))
//	returns (a - b) x (c - a) . (0, 1, 0)
#define CROSS_Z_3(a, b, c)	((a[0] - b[0]) * (c[1] - b[1]) - (a[1] - b[1]) * (c[0] - b[0]))
//	returns (a - b) x (c - a) . (0, 0, 1)


Bool RTTri::FindBaryCoords(Point& point)
{
	Int		i0 = v[0],  i1 = v[1], i2 = v[2];
	Real	temp;
	Point*	points = ptList->Ref();
	
	// Time stamp object so we can reuse this intersection test if necessary... 

	Stamp();

	flags &= (0xFFFFFFFF ^ TRI_HIT);
	
	//	Given a point lying in the plane of the triangle, we return false
	//	if it lies outside the triangle, and its barycentric coordinates if it
	//	lies inside.

	temp = normal[normMajorAxis];

    switch(normMajorAxis)
	{
    case 0:
	    coords[0] = CROSS_X_3(points[i2], points[i1], point) / temp;
		if (coords[0] < (Real) 0.0)  return(false);

	    coords[1] = CROSS_X_3(points[i0], points[i2], point) / temp;
		if (coords[1] < (Real) 0.0)  return(false);

		coords[2] = 1.0 - coords[0] - coords[1];
		if (coords[2] < (Real) 0.0)  return(false);
		
		flags |= TRI_HIT;
        return(true);

    case 1:
	    coords[0] = CROSS_Y_3(points[i2], points[i1], point) / temp;    
        if (coords[0] < (Real) 0.0) return(false);

	    coords[1] = CROSS_Y_3(points[i0], points[i2], point) / temp;	    
        if (coords[1] < (Real) 0.0) return(false);

		coords[2] = 1.0 - coords[0] - coords[1];
        if (coords[2] < (Real) 0.0) return(false);

 		flags |= TRI_HIT;
		return(true);

    case 2:
	    coords[0] = CROSS_Z_3(points[i2], points[i1], point) / temp;	    
		if (coords[0] < (Real) 0.0) return(false);

	    coords[1] = CROSS_Z_3(points[i0], points[i2], point) / temp;	    
		if (coords[1] < (Real) 0.0) return(false);

		coords[2] = 1.0 - coords[0] - coords[1];
		if (coords[2] < (Real) 0.0) return(false);
		
 		flags |= TRI_HIT;
		return(true);
	}
	
	return(true);	// to keep the compiler happy.
}

// ----------------------------------------


static Void CalcTriNonUnitNormal(Point& a, Point& b, Point& c, Vector& n)
{
	// Sets n to the (unnormalised) normal of the triangle defined by points a, b and c.
	// Effectively returns the sum of the three possible edge cross-products, for stability.
	// <Note> the length of this vector is of course the area of the triangle. 

	n[0] = (a[1] - b[1]) * (a[2] + b[2]) + (b[1] - c[1]) * (b[2] + c[2]) + (c[1] - a[1]) * (c[2] + a[2]);
	n[1] = (a[2] - b[2]) * (a[0] + b[0]) + (b[2] - c[2]) * (b[0] + c[0]) + (c[2] - a[2]) * (c[0] + a[0]);
	n[2] = (a[0] - b[0]) * (a[1] + b[1]) + (b[0] - c[0]) * (b[1] + c[1]) + (c[0] - a[0]) * (c[1] + a[1]);
}

Void RTTri::MakeNormal()
{
	Real	xf,  yf,  zf;
	Int		i, j, k;
	Point*	points = ptList->Ref();
	
	// Calculate face normal & other info
	
	CalcTriNonUnitNormal(points[v[0]], points[v[1]], points[v[2]], normal);
	
	d = -(dot(normal, points[v[2]]));
 
	xf = fabs(normal[0]);
	yf = fabs(normal[1]);
	zf = fabs(normal[2]);

	if (xf > yf)
	{
		if (xf > zf)
			normMajorAxis = 0;
		else
			normMajorAxis = 2;
	}
	else 
	{
		if (yf > zf)
			normMajorAxis = 1;
		else
			normMajorAxis = 2;
	}
	
	area = len(normal);
}

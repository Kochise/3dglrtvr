#ifndef __Flatlets__
#define __Flatlets__
 
#include "HRMesh.h"

// Note: This code is nowhere near as general as it could be, because
// of speed concerns.

// --- F2 Flatlets ------------------------------------


class F2Link : public RadLink
{
public:
	Void			Gather();
	Void			Set(HRQuad *from, HRQuad *to);
	RadLink			*CreateSubLink(HRQuad *from, HRQuad *to);
	Void			Print(ostream &s);
	Void			DrawLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom, GCLReal weight);

	GCLReal			Error();
	GCLReal			BFError();
	Void			CalcTransport();

	// Fields
	
	GCLReal			transport[16];		// wavelength independent.
	GCLReal			factor;
};

class F2Quad : public HRQuad
{
public:
	Void		SetParent(HierQuad &parent);
	HierQuad 	*New() { return(new F2Quad); };
	Void		Print(ostream &s);
	Void		PrintSelf(ostream &s);
	Void		ParseSelf(istream &s);
	
	Void		DrawLeaf(Renderer &r);
	Colour		SampleLeaf(Coord &c);
	
	Void		Add();
	Void		Push();
	Void		Pull();
	Void		Prepare();
	GCLReal		Error();
	Void		ClearR();

	Int			Coeffs() { return(4); };

	// Fields
	Colour		B[4];
	Colour		R[4];
	static Colour lastB[4];
};


// --- F3 Flatlets ----------------------------------------------


class F3Link : public RadLink
{
public:
	Void			Gather();
	Void			Set(HRQuad *from, HRQuad *to);
	RadLink			*CreateSubLink(HRQuad *from, HRQuad *to);
	Void			Print(ostream &s);
	Void			DrawLink(Renderer &r, GCLReal left, GCLReal top, GCLReal right, GCLReal bottom, GCLReal weight);

	GCLReal			Error();
	GCLReal			BFError();
	Void			CalcTransport();

	GCLReal			transport[81];
	GCLReal			factor;
};

class F3Quad : public HRQuad
{
public:
	Void		SetParent(HierQuad &parent);
	HierQuad 	*New() { return(new F3Quad); };
	Void		Print(ostream &s);
	Void		PrintSelf(ostream &s);
	Void		ParseSelf(istream &s);

	Void		DrawLeaf(Renderer &r);
	Colour		SampleLeaf(Coord &c);
	
	Void		Add();
	Void		Push();
	Void		Pull();
	Void		Prepare();
	GCLReal		Error();
	Void		ClearR();

	Int			Coeffs() { return(9); };

	// Fields
	Colour		B[9];
	Colour		R[9];
	static Colour lastB[9];
};

#endif

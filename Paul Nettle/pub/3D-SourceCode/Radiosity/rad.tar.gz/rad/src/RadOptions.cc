/*
	File:			RadOptions.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "RadOptions.h"


// --- Default radiosity options --------------------------------


RadOptions::RadOptions() : 

	method(kOverrelaxation),
	basis(kHaar),

	sampleFactor(20),
	patchSubdivs(2.0),
	eltSubdivs(2.0),
	alpha(1.0), 
	error(0.01), 
	kAError(0.01),
	kFError(0.05),
	dFError(0.05),
	visError(0.15),
	visibility(vis_4x4),
	jitterRot(true),
	multiGrid(1),
	useBF(true),
	ambient(false),
	visInQuad(false),
	refAllLinks(true),
	mesh(mesh_std),
	
	gouraud(false),
	wire(false),
	redWire(false),
	graded(true),
	anchor(true),
	patchView(0),
	funcView(0),
	showRays(0),
	showLinks(0),
	quadLevel(1),
   	shotDisplay(0),
	animate(0),

	pvData(0),
	display(0),
	scene(0),
	pause(0),

	stop(0),
	step(0),
	choke(0),
	sweep(0),
	drawMatrix(true),
	
	// Stats
	
	sliceTime(1e10),	// dump stats only after termination.
	limitTime(1e10),	// don't place any time limit on termination
	outFile("out")
{
}

Reflectance kRadRGBToLum(1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0);

Char *radRenderVersion = "2.1";

/*
	File:			Forms.cc

	Function:		See header file

	Author(s):		Andrew Willmott

	Copyright:		Copyright (c) 1997, Andrew Willmott

	Notes:			

*/

#include "Forms.h"

 
// --- Forms Graphics System --------------------------------------------------


FormsGraphicsSystem::FormsGraphicsSystem(int argc, char **argv, char *name) :
	GraphicsSystem()
{
	itsEventsMask = StructureNotifyMask;	

	if (name == 0)
		name = argv[0];

	fl_initialize(&argc, argv, name, 0, 0);
}

int FormsXCallback(XEvent *event, Void *data)
{
	((XEventPane *) data)->HandleEvent(event);
	
	return(1);
}

Void FormsGraphicsSystem::CreateFormsPane(XEventPane *xpane, FL_OBJECT *object)
{
	const Int inset = 4;
	
	CreateSubwindow(xpane, FL_OBJECT_WID(object), object->x + inset, 
		object->y + inset, object->w - 2 * inset, object->h - 2 * inset);
		
	fl_add_event_callback(xpane->paneXID, Expose, FormsXCallback, xpane);
	fl_add_event_callback(xpane->paneXID, ButtonPress, FormsXCallback, xpane);
	fl_add_event_callback(xpane->paneXID, KeyPress, FormsXCallback, xpane);

	fl_activate_event_callbacks(xpane->paneXID);
}

Void FormsGraphicsSystem::CreateWindow(XEventPane *xpane, Char *title, 
		Int width, Int height)
{
	GraphicsSystem::CreateWindow(xpane, title, width, height);
		
	fl_add_event_callback(xpane->paneXID, Expose, FormsXCallback, xpane);
	fl_add_event_callback(xpane->paneXID, ButtonPress, FormsXCallback, xpane);
	fl_add_event_callback(xpane->paneXID, KeyPress, FormsXCallback, xpane);

	fl_activate_event_callbacks(xpane->paneXID);
}

Void FormsGraphicsSystem::GetMouse(XEventPane *pane, Int *x, Int *y, UInt *keyState)
{
	fl_get_win_mouse(pane->paneXID, x, y, keyState);
}

Void FormsGraphicsSystem::Spin()
{
	FL_OBJECT *choice;
	
	choice = fl_check_forms(); 
	
	if (choice != 0)
		cerr << "Uncaptured forms event: " << choice << endl;
}

Void FormsGraphicsSystem::Run()
{
	GraphicsSystem::Run();
}


// --- The Field Class --------------------------------------------------------


ostream &show(ostream &s)
{
	Field *cs = (Field *) &s;	// C++: hate, hate, hate...
								// There is no way to do this safely, i.e.,
	cs->Show();					//  guarantee it will only be run on a Field.

	return(s);
}
  
Void Field::Show()
{
	fl_set_object_label(object, str());	
	fl_check_only_forms();
}

Void InputField::Show()
{
	fl_set_input(object, str());
}


// --- Extra forms routines ---------------------------------------------------


Void fl_update_colors(FL_FORM *form)
{
	FL_OBJECT *obj;

	for (obj = form->first; obj != 0; obj = obj->next)
	{
		if (obj->active == 1 && obj->lcol == FL_INACTIVE)
		{
			fl_set_object_lcol(obj, FL_BLACK);
			fl_set_object_color(obj, obj->col1, FL_BLACK);
		}
		else if (obj->active == -1 && obj->lcol == FL_BLACK)
		{
			fl_set_object_lcol(obj, FL_INACTIVE);
			fl_set_object_color(obj, obj->col1, FL_INACTIVE);
		}
	}
}

Void fl_deactivate_group(FL_OBJECT *obj)
{
	fl_deactivate_object(obj);
	fl_update_colors(obj->form);
}

Void fl_activate_group(FL_OBJECT *obj)
{
	fl_activate_object(obj);
	fl_update_colors(obj->form);
}

Void my_activate(FL_OBJECT *obj)
{
	fl_activate_object(obj);
	fl_set_object_lcol(obj, FL_BLACK);
	fl_set_object_color(obj, obj->col1, FL_BLACK);
}

Void my_deactivate(FL_OBJECT *obj)
{
	fl_deactivate_object(obj);
	fl_set_object_lcol(obj, FL_INACTIVE);
	fl_set_object_color(obj, obj->col1, FL_INACTIVE);
}

Void dumpobj(FL_OBJECT *obj)
{
	cout << "@: " << obj << endl;
    cout <<  "form: " << obj->form << endl;		// the parent form of object 
    cout <<  "prev: " << obj->prev << endl;		// prev. obj in form                  
    cout <<  "next: " <<  obj->next << endl;	// next. obj in form                  
    cout <<  "vdata: " << obj->u_vdata << endl;	// anything user likes                
    cout <<  "ldata: " << obj->u_ldata << endl;	// anything user lines                
    cout <<  "class: " << obj->objclass << endl;// class of object 
    cout <<  "type: " << obj->type << endl;		// type within the class              
    cout <<  "boxtype: " << obj->boxtype << endl;// what kind of box type         

	cout <<  "handle: " << obj->handle << endl;
}


#pragma mark -
// --- Form class -------------


Void ObjFormCallback(FL_OBJECT *object, Void *data)
{
	((Form *) object->u_vdata)->Event(object);
}

Void Form::RegisterForm(FL_FORM *form)
{
	fl_set_form_callback(form, ObjFormCallback, 0);
}

Void Form::RegisterObj(FL_OBJECT *object)
{
	object->u_vdata = this;
}

Void Form::Event(FL_OBJECT *object)
{
	cerr << "Received event for object :" << object << " in form " << this << "." << endl;
}

Void Form::Show()
{
	fl_show_form(form, FL_PLACE_SIZE, FL_FULLBORDER, "Radiosity Visualisation");
}

Void Form::Hide()
{
	fl_hide_form(form);
}

# 
# Setup file for master source directory.
#

setenv REACTOR `pwd` 
setenv PATH `$REACTOR/bin/newpath $REACTOR/bin`



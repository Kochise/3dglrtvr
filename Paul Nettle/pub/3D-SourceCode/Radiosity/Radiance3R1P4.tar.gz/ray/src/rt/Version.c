char VersionID[]="RADIANCE 3.1.4 official version September 2, 1997";

#include "standard.h"
#include "color.h"
#include "warp3d.h"

#define exp10(x)	exp(2.30258509*(x))

char	*mbcalfile = NULL;		/* macbethcal mapping file */
char	*cwarpfile = NULL;		/* color space warping file */

struct mbc {
	COLORMAT	cmat;
	float	xa[3][6], ya[3][6];
	COLOR	cmin, cmax;
}	mbcond;				/* macbethcal conditioning struct */

WARP3D	*cwarp;				/* color warping structure */

#define VECRES	5		/* MGF vector resolution */

#define NLSTEP	100		/* number of steps in ramp */

#define NCURVES	4		/* number of color curves */

struct {
	char	cnam[16];
	short	cclr, clty;
	W3VEC	clr;
} curve[NCURVES] = {
	"Grey", 1, 1, {1,1,1},
	"Red", 2, 1, {1,.1,.1},
	"Green", 3, 1, {.1,1,.1},
	"Blue", 4, 1, {.1,.1,1},
};

char *progname;


main(ac, av)
int	ac;
char	**av;
{
	extern int	warp3d(), mbcal();
	int	badmbc;

	if (ac != 9) {
		fprintf(stderr,
"Usage: %s mbc_in cwp_in cwe_plot cwi_plot cwa_plot mb_plot cwe_mgf mb_mgf\n",
				av[0]);
		exit(1);
	}
	progname = av[0];
	mbcalfile = av[1];
	cwarpfile = av[2];
	badmbc = getmbcalfile(mbcalfile, &mbcond) < 0;
	cwarp = load3dw(cwarpfile, new3dw(W3EXACT));
	mgffile(av[7], warp3d, cwarp);
	if (!badmbc)
		mgffile(av[8], mbcal, &mbcond);
	plotfile(av[3], "Exact Color Warp", warp3d, cwarp);
	set3dwfl(cwarp, 0);
	plotfile(av[4], "Interpolated Color Warp", warp3d, cwarp);
	set3dwfl(cwarp, W3FAST);
	plotfile(av[5], "Discrete Warp Approximation", warp3d, cwarp);
	if (!badmbc)
		plotfile(av[6], "Macbethcal Transformation", mbcal, &mbcond);
	exit(0);
}


mgffile(fn, mfun, mfdp)
char	*fn;
int	(*mfun)();
char	*mfdp;
{
	register int	i, j, k;
	COLOR	clr;
	FILE	*fp;

	fp = fopen(fn, "w");
	fprintf(fp, "c R =\n\tcxy %f %f\n", CIE_x_r, CIE_y_r);
	fprintf(fp, "c G =\n\tcxy %f %f\n", CIE_x_g, CIE_y_g);
	fprintf(fp, "c B =\n\tcxy %f %f\n", CIE_x_b, CIE_y_b);
	fprintf(fp, "m norm =\n\tc\n\trd .5\n\tsides 1\n");
	for (i = 0; i < VECRES; i++)
	    for (j = 0; j < VECRES; j++)
		for (k = 0; k < VECRES; k++) {
			setcolor(clr, (i+.5)/VECRES, (j+.5)/VECRES,
					(k+.5)/VECRES);
			fprintf(fp,
			"m\n\tc\n\t\tcmix %f R %f G %f B\n\trd %f\n\tsides 1\n",
				CIE_rf*clr[0], CIE_gf*clr[1], CIE_bf*clr[2],
				bright(clr));
			fprintf(fp, "v v1 =\n\tp %f %f %f\n", clr[0],clr[1],clr[2]);
			(*mfun)(clr, clr, mfdp);
			fprintf(fp, "v v2 =\n\tp %f %f %f\n", clr[0],clr[1],clr[2]);
			fprintf(fp, "sph v1 .005\nm norm\ncyl v1 .0025 v2\n");
			fprintf(fp,
			"m\n\tc\n\t\tcmix %f R %f G %f B\n\trd %f\n\tsides 1\n",
				CIE_rf*clr[0], CIE_gf*clr[1], CIE_bf*clr[2],
				bright(clr));
			fprintf(fp, "sph v2 .0035\n");
		}
	fprintf(fp, "m norm =\n\tcxy .4 .25\n\trd .3\n");
	for (i = 0; i < cwarp->npts; i++) {
		fprintf(fp,
		"m\n\tc\n\t\tcmix %f R %f G %f B\n\trd %f\nsides 1\n",
				CIE_rf*cwarp->ip[i][0],
				CIE_gf*cwarp->ip[i][1],
				CIE_bf*cwarp->ip[i][2],
				CIE_rf*cwarp->ip[i][0] +
				CIE_gf*cwarp->ip[i][1] +
				CIE_bf*cwarp->ip[i][2]);
		fprintf(fp, "v v1 =\n\tp %f %f %f\n", cwarp->ip[i][0],
				cwarp->ip[i][1], cwarp->ip[i][2]);
		fprintf(fp, "v v2 =\n\tp %f %f %f\n",
				cwarp->ip[i][0]+cwarp->ov[i][0],
				cwarp->ip[i][1]+cwarp->ov[i][1],
				cwarp->ip[i][2]+cwarp->ov[i][2]);
		fprintf(fp, "sph v1 .005\nm norm\ncyl v1 .0025 v2\n");
		fprintf(fp,
		"m\n\tc\n\t\tcmix %f R %f G %f B\n\trd %f\nsides 1\n",
				CIE_rf*(cwarp->ip[i][0]+cwarp->ov[i][0]),
				CIE_gf*(cwarp->ip[i][1]+cwarp->ov[i][1]),
				CIE_bf*(cwarp->ip[i][2]+cwarp->ov[i][2]),
				CIE_rf*(cwarp->ip[i][0]+cwarp->ov[i][0]) +
				CIE_gf*(cwarp->ip[i][1]+cwarp->ov[i][1]) +
				CIE_bf*(cwarp->ip[i][2]+cwarp->ov[i][2]));
		fprintf(fp, "sph v2 .0035\n");
	}
	fclose(fp);
}


plotfile(fn, ttl, mfun, mfdp)
char	*fn, *ttl;
int	(*mfun)();
char	*mfdp;
{
	register int	i, j;
	double	d;
	COLOR	clr;
	FILE	*fp;

	fp = fopen(fn, "w");
	fprintf(fp, "include=line.plt\ntitle=\"%s\"\n", ttl);
	fprintf(fp, "xlabel=\"Input Value\"\n");
	fprintf(fp, "ylabel=\"Output Value\"\n");
	for (j = 0; j < NCURVES; j++) {
		fprintf(fp, "%clabel=\"%s\"\n", j+'A', curve[j].cnam);
		fprintf(fp, "%ccolor=%d\n", j+'A', curve[j].cclr);
		fprintf(fp, "%clintype=%d\n", j+'A', curve[j].clty);
		fprintf(fp, "%cdata=\n", j+'A');
		for (i = 0; i < NLSTEP; i++) {
			copycolor(clr, curve[j].clr);
			d = (i+.5)/NLSTEP;
			scalecolor(clr, d);
			fprintf(fp, "\t%f", bright(clr));
			(*mfun)(clr, clr, mfdp);
			fprintf(fp, "\t%f\n", bright(clr));
		}
		fprintf(fp, ";\n");
	}
	fclose(fp);
}


mbcal(co, ci, mb)			/* apply macbethcal adj. to scaline */
COLOR	co, ci;
register struct mbc	*mb;
{
	double	d;
	register int	i, j;

	colortrans(co, mb->cmat, ci);
	clipgamut(co, bright(co), CGAMUT, mb->cmin, mb->cmax);
	for (i = 0; i < 3; i++) {
		d = colval(co,i);
		for (j = 0; j < 4 && mb->xa[i][j+1] <= d; j++)
			;
		colval(co,i) = ( (mb->xa[i][j+1] - d)*mb->ya[i][j] +
				(d - mb->xa[i][j])*mb->ya[i][j+1] ) /
				(mb->xa[i][j+1] - mb->xa[i][j]);
	}
}


getmbcalfile(fn, mb)			/* load macbethcal file */
char	*fn;
register struct mbc	*mb;
{
	extern char	*fgets();
	char	buf[128];
	FILE	*fp;
	int	inpflags = 0;
	register int	i;

	if ((fp = fopen(fn, "r")) == NULL) {
		perror(fn);
		exit(1);
	}
	while (fgets(buf, sizeof(buf), fp) != NULL) {
		if (!(inpflags & 01) &&
				sscanf(buf,
				"rxa(i) : select(i,%f,%f,%f,%f,%f,%f)",
				&mb->xa[0][0], &mb->xa[0][1],
				&mb->xa[0][2], &mb->xa[0][3],
				&mb->xa[0][4], &mb->xa[0][5]
				) == 6)
			inpflags |= 01;
		else if (!(inpflags & 02) &&
				sscanf(buf,
				"rya(i) : select(i,%f,%f,%f,%f,%f,%f)",
				&mb->ya[0][0], &mb->ya[0][1],
				&mb->ya[0][2], &mb->ya[0][3],
				&mb->ya[0][4], &mb->ya[0][5]
				) == 6)
			inpflags |= 02;
		else if (!(inpflags & 04) &&
				sscanf(buf,
				"gxa(i) : select(i,%f,%f,%f,%f,%f,%f)",
				&mb->xa[1][0], &mb->xa[1][1],
				&mb->xa[1][2], &mb->xa[1][3],
				&mb->xa[1][4], &mb->xa[1][5]
				) == 6)
			inpflags |= 04;
		else if (!(inpflags & 010) &&
				sscanf(buf,
				"gya(i) : select(i,%f,%f,%f,%f,%f,%f)",
				&mb->ya[1][0], &mb->ya[1][1],
				&mb->ya[1][2], &mb->ya[1][3],
				&mb->ya[1][4], &mb->ya[1][5]
				) == 6)
			inpflags |= 010;
		else if (!(inpflags & 020) &&
				sscanf(buf,
				"bxa(i) : select(i,%f,%f,%f,%f,%f,%f)",
				&mb->xa[2][0], &mb->xa[2][1],
				&mb->xa[2][2], &mb->xa[2][3],
				&mb->xa[2][4], &mb->xa[2][5]
				) == 6)
			inpflags |= 020;
		else if (!(inpflags & 040) &&
				sscanf(buf,
				"bya(i) : select(i,%f,%f,%f,%f,%f,%f)",
				&mb->ya[2][0], &mb->ya[2][1],
				&mb->ya[2][2], &mb->ya[2][3],
				&mb->ya[2][4], &mb->ya[2][5]
				) == 6)
			inpflags |= 040;
		else if (!(inpflags & 0100) &&
				sscanf(buf,
				"r = %f*r1 + %f*g1 + %f*b1",
				&mb->cmat[0][0], &mb->cmat[0][1],
				&mb->cmat[0][2]) == 3)
			inpflags |= 0100;
		else if (!(inpflags & 0200) &&
				sscanf(buf,
				"g = %f*r1 + %f*g1 + %f*b1",
				&mb->cmat[1][0], &mb->cmat[1][1],
				&mb->cmat[1][2]) == 3)
			inpflags |= 0200;
		else if (!(inpflags & 0400) &&
				sscanf(buf,
				"b = %f*r1 + %f*g1 + %f*b1",
				&mb->cmat[2][0], &mb->cmat[2][1],
				&mb->cmat[2][2]) == 3)
			inpflags |= 0400;
	}
	fclose(fp);
	if (inpflags != 0777) {
		fprintf(stderr,
		"%s: cannot grok macbethcal file \"%s\" (inpflags==0%o)\n",
			progname, fn, inpflags);
		return(-1);
	}
					/* compute gamut */
	for (i = 0; i < 3; i++) {
		colval(mb->cmin,i) = mb->xa[i][0] -
				mb->ya[i][0] *
				(mb->xa[i][1]-mb->xa[i][0]) /
				(mb->ya[i][1]-mb->ya[i][0]);
		colval(mb->cmax,i) = mb->xa[i][4] +
				(1.-mb->ya[i][4]) *
				(mb->xa[i][5] - mb->xa[i][4]) /
				(mb->ya[i][5] - mb->ya[i][4]);
	}
	return(0);
}

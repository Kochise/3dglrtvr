/*
 *  ev.c - program to evaluate expression arguments
 *
 *     1/29/87
 */

#include  <stdio.h>


main(argc, argv)
int  argc;
char  *argv[];
{
	extern int  errno;
	extern double  eval();
	int  i;

#ifdef  CPM
	fixargs("ev", &argc, &argv);
#endif
#ifdef  BIGGERLIB
	biggerlib();
#endif

	errno = 0;
	for (i = 1; i < argc; i++)
		printf("%.9g\n", eval(argv[i]));

	quit(errno ? 2 : 0);
}


eputs(msg)
char  *msg;
{
	fputs(msg, stderr);
}


wputs(msg)
char  *msg;
{
	eputs(msg);
}


quit(code)
int  code;
{
	exit(code);
}

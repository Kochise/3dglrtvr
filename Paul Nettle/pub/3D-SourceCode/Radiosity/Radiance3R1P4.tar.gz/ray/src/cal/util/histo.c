/*
 * Compute a histogram from input data
 *
 *	9/5/96	Greg Ward
 */

#include <stdio.h>
#include <math.h>
#include <ctype.h>

#ifdef DECL_ATOF
extern double	atof();
#endif

#define MAXCOL		64		/* maximum number of input columns */
#define MAXDIV		256

#define isint(x)	(floor((x)+1e-6) != floor((x)-1e-6))

long	histo[MAXCOL][MAXDIV];
double	minv, maxv;
int	ndiv;

int	ncols;


main(argc, argv)
int	argc;
char	*argv[];
{
	if (argc < 3)
		goto userr;
	minv = atof(argv[1]);
	maxv = atof(argv[2]);
	if (argc == 4)
		ndiv = atoi(argv[3]);
	else {
		if (argc > 4 || !isint(minv) || !isint(maxv))
			goto userr;
		maxv += 0.5;
		minv -= 0.5;
		ndiv = maxv - minv + 0.5;
	}
	if (minv >= maxv | ndiv <= 0)
		goto userr;
	if (ndiv > MAXDIV) {
		fprintf(stderr, "%s: maximum number of divisions: %d\n",
				argv[0], MAXDIV);
		goto userr;
	}
	readinp();
	printres();
	exit(0);
userr:
	fprintf(stderr, "Usage: %s min max n\n", argv[0]);
	fprintf(stderr, "   Or: %s imin imax\n", argv[0]);
	exit(1);
}


readinp()			/* gather statistics on input */
{
	char	buf[12*MAXCOL];
	double	d;
	register int	c;
	register char	*cp;

	while ((cp = fgets(buf, sizeof(buf), stdin)) != NULL) {
		for (c = 0; c < MAXCOL; c++) {
			while (isspace(*cp))
				cp++;
			if (!*cp)
				break;
			d = atof(cp);
			while (*cp && !isspace(*cp))
				cp++;
			if (d >= minv && d < maxv)
				histo[c][(int)(ndiv*(d-minv)/(maxv-minv))]++;
		}
		if (c > ncols)
			ncols = c;
	}
}


printres()			/* print histogram results */
{
	register int	i, c;

	for (i = 0; i < ndiv; i++) {
		printf("%g", minv + (maxv-minv)*(i+.5)/ndiv);
		for (c = 0; c < ncols; c++)
			printf("\t%ld", histo[c][i]);
		putchar('\n');
	}
}

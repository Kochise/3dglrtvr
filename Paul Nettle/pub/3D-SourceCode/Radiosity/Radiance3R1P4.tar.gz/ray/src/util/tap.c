/*
 * Connect to a tty line (variation on tip)
 *
 * Date:	Action:					Person:
 * 94-02-05	Created w/ code for POSIX		Greg Ward
 */

#ifdef sgi
#define _POSIX_SOURCE	1
#define DEFTTY		"/dev/ttym2"
#define vfork		fork
#endif

#ifdef _AUX_SOURCE
#define _POSIX_SOURCE	1
#define DEFTTY		"/dev/tty0"
#define vfork		fork
#endif

#include <stdio.h>

#include <signal.h>

#include <fcntl.h>

#include <sys/param.h>

#ifndef DEFTTY
#define DEFTTY		"NO_DEFAULT_TTY"
#endif

#define isspace(c)	((c)==' '||(c)=='\t')

#define MAXLINE		512		/* maximum command line length */
#define MAXNAME		16		/* maximum alias name length */

#define DEFCOMS		"/usr/local/lib/tapinitrc"
#define USRCOMS		".taprc"

#define PROMPT		"\ntap: "	/* our prompt string */
#define LPROMPT		6		/* prompt string length */
#define DESCCHAR	('A'-'@')	/* default escape character */
#define DEFSPEED	9600		/* default line speed */

#define COMM_NORM	1		/* set normal communications */
#define COMM_RAW	2		/* set raw communications */

char	*home;			/* user's home directory */
char	*shell;			/* user's shell */

int	escchar = DESCCHAR;	/* escape character */
int	termbaud = DEFSPEED;	/* terminal baud rate */
char	*devfile = DEFTTY;	/* terminal device file */

int	childpid;		/* child process id */

int	devfd;			/* terminal device file descriptor */

char	combuf[MAXLINE];	/* command input buffer */
char	fnmbuf[MAXPATHLEN];	/* file name buffer */

struct alias {
	char	name[MAXNAME];		/* alias name */
	char	def[MAXLINE-MAXNAME];	/* alias command */
	struct alias	*next;		/* next in list */
}	*alist = NULL;		/* list of aliases */

extern void	_exit();
extern char	*getenv(), *strcpy(), *getcom(), *fromhome();
extern char	*malloc();
extern int	onint();


main(argc, argv)
int	argc;
char	*argv[];
{
	int	connect = 1;		/* connect right off? */
	int	i;
	register char	*cp;

	if ((home = getenv("HOME")) == NULL)
		home = "";
	if ((shell = getenv("SHELL")) == NULL)
		shell = "/bin/sh";
	for (i = 1; i < argc && argv[i][0] == '-'; i++)
		switch (argv[i][1]) {
		case 'e':		/* set escape character */
			if (argv[i][2] == '^' && argv[i][3] >= 'A'
					&& argv[i][3] <= '_')
				escchar = argv[i][3] - '@';
			else
				escchar = argv[i][2];
			break;
		case 's':		/* set line speed */
			termbaud = atoi(argv[++i]);
			break;
		case 'l':		/* device file */
			devfile = argv[++i];
			break;
		case 'c':		/* startup in command mode */
			connect = 0;
			break;
		default:
			fprintf(stderr,
			"Usage: %s [-l dev][-eESC][-s spd][-c] [com ..]\n",
					argv[0]);
			exit(1);
		}
					/* let's get going! */
	open_term();
	if (escchar < ' ')
		printf("[Command escape set to ^%c<ret>]\n", escchar+'@');
	else
		printf("[Command escape set to %c<ret>]\n", escchar);
	spawn_output(NULL);
	signal(SIGINT, onint);
					/* load startup files */
#ifdef DEFCOMS
	source_file(DEFCOMS, 0);
#endif
#ifdef USRCOMS
	source_file(fromhome(USRCOMS), 0);
#endif
					/* execute command line */
	for (cp = combuf; i < argc; i++) {
		*cp++ = ' ';
		strcpy(cp, argv[i]);
		if ((cp += strlen(cp)) >= combuf+MAXLINE) {
			fputs("Command line too long!\n", stderr);
			exit(1);
		}
	}
	if (cp > combuf)
		do_command(combuf+1);
	while (connect == 0) {		/* connect yet? */
		write(1, PROMPT, LPROMPT);
		connect = do_command(getcom(stdin));
	}
	if (connect > 0)
		input_loop();		/* loop on input */
	kill_output();			/* reap our child */
	exit(0);
}


onint()				/* on interrupt */
{
	setcomm(COMM_NORM);
	if (childpid > 0)
		wait(0);
	exit(0);
}


spawn_output(com)		/* spawn output process */
char	*com;
{
	register int	n, nw;
	char	iobuf[256];
	register char	*cp;

	childpid = fork();
	if (childpid < 0) {
		perror("fork");
		_exit(1);
	}
	if (childpid != 0)	/* parent handles input */
		return;
	if (com != NULL)	/* execute a command first */
		sys_command(com, devfd, 1);
				/* now, we're just like cat */
	while ((n = read(devfd, iobuf, sizeof(iobuf))) > 0) {
		for (cp = iobuf+n; cp > iobuf; *--cp &= 0x7f)	/* strip */
			;
		while ((nw = write(1, cp, n)) < n) {
			if (nw < 0) {
				fputs("Write error to stdout!\n", stderr);
				goto thatsallfolks;
			}
			cp += nw;
			n -= nw;
		}
	}
thatsallfolks:
	fputs("\r\n[Connection closing]\r\n", stderr);
	kill(getppid(), SIGINT);
	sleep(2);
	_exit(0);
}


kill_output()			/* kill output program */
{
	if (childpid <= 0)
		return;
	kill(childpid, SIGINT);
	wait(0);
	childpid = 0;
}


input_loop()			/* handle user input */
{
	char	buf[MAXLINE];
	int	lastchar = -1;
	int	rval;
	char	wesc = escchar;
	char	inpchar;

	setcomm(COMM_RAW);
	while (read(0, &inpchar, 1) == 1) {
		if (lastchar == escchar) {	/* twisted logic */
			lastchar = -1;
			if (inpchar == '\r' || inpchar == '\n') {
				setcomm(COMM_NORM);
				do {
					write(1, PROMPT, LPROMPT);
					rval = do_command(getcom(stdin));
				} while (rval == 0);
				if (rval < 0)
					break;
				write(1, "[Connected]\n", 12);
				setcomm(COMM_RAW);
				continue;
			} else if (write(devfd, &wesc, 1) != 1)
				break;
		} else
			lastchar = inpchar;
		if (inpchar != escchar && write(devfd, &inpchar, 1) != 1)
			break;
	}
	setcomm(COMM_NORM);
}


int
iszmcom(com)			/* identify zmodem command */
register char	*com;
{
	if (com[0] != 'r' && com[0] != 's')
		return(0);
	if (com[1] != 'z' && com[1] != 'b' && com[1] != 'x')
		return(0);
	if (!isspace(com[2]) && com[2] != '\0')
		return(0);
	return(1);
}


int
do_command(com)			/* execute a user command */
register char	*com;
{
	if (com == NULL)			/* EOF == quit */
		return(-1);
	if (com[0] == '\0')			/* nothing == return */
		return(1);
	if (iszmcom(com)) {			/* transfer using zmodem */
		kill_output();
		sys_command(com, devfd, devfd);
		write(1, "\007\n", 2);
		spawn_output(NULL);
		return(1);
	} 
	if (!strncmp(com, "sp ", 3)) {		/* change baud rate */
		setbaud(atoi(com+3));
		return(1);
	}
	if (!strcmp(com, "cd")) {		/* goto home directory */
		setdir(home);
		return(0);
	}
	if (!strncmp(com, "cd ~", 4)) {		/* chdir relative to home */
		if (!com[4])
			setdir(home);
		else if (com[4] == '/')
			setdir(fromhome(com+5));
		else
			fputs("User directory shorthand not supported\n",
					stderr);
		return(0);
	}
	if (!strncmp(com, "cd ", 3)) {		/* change directory */
		setdir(com+3);
		return(0);
	}
	if (com[0] == '!') {			/* run a system command */
		sys_command(com+1, 0, 1);
		return(0);
	}
	if (!strncmp(com, "so ", 3)) {		/* source a file */
		if (com[3] == '~' && com[4] == '/')
			source_file(fromhome(com+5), 1);
		else
			source_file(com+3, 1);
		return(0);
	}
	if (!strncmp(com, "<!", 2)) {		/* replace input (us) */
		sys_command(com+2, 0, devfd);
		return(1);
	}
	if (!strncmp(com, ">!", 2)) {		/* replace output */
		kill_output();
		spawn_output(com+2);
		return(1);
	}
	if (!strncmp(com, "df ", 3)) {		/* set an alias */
		make_alias(com+3);
		return(0);
	}
	if (com[0] == '?' && com[1] == '\0') {	/* print help */
		print_help();
		return(0);
	}
	if (!strncmp(com, "quit ", strlen(com)))	/* quit */
		return(-1);
					/* try aliases (tail recursion) */
	return(do_alias(com));

}


int
do_alias(com)			/* try and execute aliased command */
register char	*com;
{
	char	buf[MAXLINE];
	register struct alias	*ap;
	register int	i, j;

	for (i = 0; com[i] && !isspace(com[i]); i++)
		buf[i] = com[i];
	if (i == 0)
		return(0);
	buf[i] = '\0';
	for (ap = alist; ap != NULL; ap = ap->next)
		if (!strcmp(buf, ap->name)) {
			for (j = 0; (buf[j] = ap->def[j]); j++)
				;
			while ((buf[j++] = com[i++]))
				if (j >= MAXLINE) {
					fputs("Aliased command too long\n",
							stderr);
					return(0);
				}
			return(do_command(buf));
		}
	fprintf(stderr, "Unrecognized command: %s\n", com);
	return(0);
}


make_alias(as)			/* add an alias to our list */
register char	*as;
{
	register struct alias	*anew, *ap;
	struct alias	aph;
	register int	n;

	if (!*as)
		return;
	anew = (struct alias *)malloc(sizeof(struct alias));
	if (anew == NULL) {
		fputs("Out of memory!\n", stderr);
		exit(1);
	}
	for (n = 0; *as && !isspace(*as); anew->name[n++] = *as++)
		;
	anew->name[n] = '\0';
	aph.next = alist;			/* check list for old def. */
	for (ap = &aph; ap->next != NULL; ap = ap->next)
		if (!strcmp(ap->next->name, anew->name)) {	/* replace */
			free((char *)ap->next);		/* BEWARE */
			ap->next = ap->next->next;
			break;
		}
	alist = aph.next;
	while (isspace(*as))		/* skip spaces */
		as++;
	if (!*as) {			/* undefine */
		free((char *)anew);
		return;
	}
	if (!strncmp(anew->name, as, n) && (!as[n] || isspace(as[n]))) {
		fputs("Cannot alias a name to itself\n", stderr);
		free((char *)anew);
		return;
	}
	if (as[0] == 'd' && as[1] == 'f' && (!as[2] || isspace(as[2]))) {
		fputs("Cannot alias df\n", stderr);
		free((char *)anew);
		return;
	}
	strcpy(anew->def, as);
	anew->next = alist;
	alist = anew;
}


print_aliases()				/* print out our defined aliases */
{
	register struct alias	*ap;
	register char	*cp;

	for (ap = alist; ap != NULL; ap = ap->next) {
		for (cp = ap->name; *cp; cp++)
			putchar(*cp);
		while (cp++ < ap->name+MAXNAME)
			putchar(' ');
		putchar('\t');
		for (cp = ap->def; *cp; cp++)
			if (*cp < ' ') {
				putchar('^');
				putchar(*cp+'@');
			} else
				putchar(*cp);
		putchar('\n');
	}
}


print_help()			/* print out help */
{
	puts("<ret>\t\t\tReturn to terminal mode");
	puts("sz file ..\t\tSend file(s) using ZMODEM");
	puts("rz\t\t\tReceive file(s) using ZMODEM");
	puts("sb file ..\t\tSend file(s) using YMODEM");
	puts("rb\t\t\tReceive file(s) using YMODEM");
	puts("sx file\t\t\tSend file using XMODEM");
	puts("rx file\t\t\tReceive file using XMODEM");
	puts("sp speed\t\tChange baud rate");
	puts("![command]\t\tExecute command (or shell)");
	puts("<![command]\t\tReplace input process");
	puts(">![command]\t\tReplace output process");
	puts("so file\t\t\tSource a file of tap commands");
	puts("cd [dir]\t\tChange directory");
	puts("df name [tapcom]\tDefine an alias");
	puts("q[uit]\t\t\tClose connection and quit");
	puts("?\t\t\tPrint this list of commands");
	print_aliases();
	fflush(stdout);
}


setdir(dn)			/* change to specified directory */
char	*dn;
{
	extern char	*getwd();
	char	pathname[MAXPATHLEN];

	if (chdir(dn) < 0)
		perror(dn);
	else
		printf("[Working directory now %s]\n", getwd(pathname));
}


source_file(fname, eb)		/* source a file */
char	*fname;
int	eb;		/* error behavior, 0==ignore, 1==complain, 2==exit */
{
	FILE	*fp;
	char	*cp;

	if ((fp = fopen(fname, "r")) == NULL) {
		if (eb > 0)
			fprintf(stderr, "%s: cannot open\n", fname);
		if (eb < 2)
			return;
		exit(1);
	}
	while (do_command(getcom(fp)) != -1)
		;
	fclose(fp);
}


int
sys_command(com, fdi, fdo)	/* execute a system command */
char	*com;
int	fdi, fdo;		/* i/o descriptors */
{
	int	ourchild, status;

	ourchild = vfork();
	if (ourchild < 0) {
		perror("vfork");
		_exit(1);
	}
	if (ourchild == 0) {
		if (fdi != 0) {
			dup2(fdi, 0);
			if (fdi != 1 && fdi != fdo)
				close(fdi);
		}
		if (fdo != 1) {
			dup2(fdo, 1);
			if (fdo != 0)
				close(fdo);
		}
		if (com[0])
			execl(shell, shell, "-c", com, 0);
		else
			execl(shell, shell, 0);
		perror(shell);
		_exit(1);
	}
	wait(&status);		/* wait for our process to finish */
	return(status>>8 & 0xff);
}


char *
fromhome(name)			/* return path relative to home directory */
char	*name;
{
	sprintf(fnmbuf, "%s/%s", home, name);
	return(fnmbuf);
}


char *
getcom(fp)			/* read command line from stream */
register FILE	*fp;
{
	register char	*cp = combuf;
	register int	c;

	clearerr(fp);
	while (cp < combuf+MAXLINE-1 && (c = getc(fp)) != EOF && c != '\n')
		*cp++ = c;
	*cp = '\0';
	if (c == EOF && cp == combuf)
		return(NULL);
	return(combuf);
}


/*
 * System-dependent set-up code should be put here.
 * (We're using stty now because couldn't get termios to work!)
 */

setcomm(state)			/* change stdin communications */
int	state;
{
	static int	stdin_tty = -1;
	static int	cur_state = COMM_NORM;
	static char	orig_settings[128];

	if (stdin_tty < 0)
		stdin_tty = isatty(0);
	if (!stdin_tty | state == cur_state)
		return;
	if (cur_state == COMM_NORM) {		/* switching to RAW */
		if (!orig_settings[0]) {
			FILE	*fp = popen("stty -g", "r");
			strcpy(orig_settings, "stty ");
			fgets(orig_settings+5, sizeof(orig_settings)-5, fp);
			pclose(fp);
		}
		if (sys_command("stty raw cs8 -echo", 0, 1)) {
			fputs("Cannot put input terminal in raw mode\n",
					stderr);
			exit(1);
		}
	} else /* cur_state == COMM_RAW */	/* switching to NORM */
		sys_command(orig_settings, 0, 1);
	cur_state = state;
	return;
syserr:
	perror("standard input tty");
	exit(1);
}


open_term()			/* establish communication */
{
	char	sttybuf[128];
					/* open it */
	devfd = open(devfile, O_RDWR);
	if (devfd < 0) {
		perror(devfile);
		exit(1);
	}
	if (!isatty(devfd)) {
		fprintf(stderr, "%s: not a tty\n", devfile);
		exit(1);
	}
					/* set up communications parameters */
	sprintf(sttybuf, "stty raw cs8 ignbrk hupcl cread -echo %d", termbaud);
	if (sys_command(sttybuf, devfd, 1)) {
		fprintf(stderr, "Stty command failed: %s\n", sttybuf);
		exit(1);
	}
}


setbaud(br)			/* change terminal baud rate */
int	br;
{
	char	sttybuf[64];

	if (br == 0)
		return;
	sprintf(sttybuf, "stty %d", br);
	if (sys_command(sttybuf, devfd, 1))
		fprintf(stderr, "Cannot change baud rate to %d\n", br);
	else
		termbaud = br;
}

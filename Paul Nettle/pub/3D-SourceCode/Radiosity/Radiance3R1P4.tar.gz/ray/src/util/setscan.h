/* Copyright (c) 1991 Regents of the University of California */

/* SCCSid "@(#)setscan.h 2.1 11/12/91 LBL" */

/*
 * Defines for programs using setscan()
 */

#define  ANGLE		short
#define  AEND		(-1)

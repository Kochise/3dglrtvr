#ifndef lint
static char sccsid[] = "@(#)open.c	4.1 (Berkeley) 6/27/83";
#endif

openvt ()
{
}
openpl(){
}

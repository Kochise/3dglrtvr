#define  readp  scanp

#define  writep  printp

#define  writeof  printeof

#include  "hfio.c"

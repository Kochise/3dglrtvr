#ifndef lint
static char sccsid[] = "@(#)dot.c	4.1 (Berkeley) 6/27/83";
#endif

dot(){
}

/*
 *  progname.c - definition of progname for library.
 *
 *     2/24/86
 */


char  *progname = "meta";

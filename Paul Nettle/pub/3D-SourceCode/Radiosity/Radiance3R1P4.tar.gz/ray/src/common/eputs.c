/* Copyright (c) 1991 Regents of the University of California */

#ifndef lint
static char SCCSid[] = "@(#)eputs.c 2.1 11/12/91 LBL";
#endif

#include <stdio.h>

eputs(s)			/* error message */
char  *s;
{
	fputs(s, stderr);
}

/* Copyright (c) 1991 Regents of the University of California */

#ifndef lint
static char SCCSid[] = "@(#)quit.c 2.1 11/12/91 LBL";
#endif

quit(code)			/* quit program */
int  code;
{
	exit(code);
}

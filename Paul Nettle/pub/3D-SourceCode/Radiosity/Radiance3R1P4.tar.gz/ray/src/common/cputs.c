/* Copyright (c) 1991 Regents of the University of California */

#ifndef lint
static char SCCSid[] = "@(#)cputs.c 2.1 11/12/91 LBL";
#endif

cputs(s)			/* command line error */
char  *s;
{
	eputs(s);
}

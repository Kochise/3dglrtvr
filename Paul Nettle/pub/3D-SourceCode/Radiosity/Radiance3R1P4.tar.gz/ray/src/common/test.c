#include "standard.h"
#include "octree.h"
#include "object.h"

main()
{
	char	buf[128];
	OBJECT	res[MAXSET+1], os1[MAXSET+1], os2[MAXSET+1];

	while (!feof(stdin)) {
		puts("Enter set 1:");
		buf[0] = 0;
		gets(buf);
		strtoset(os1, buf);
		puts("Enter set 2:");
		buf[0] = 0;
		gets(buf);
		strtoset(os2, buf);
		setunion(res, os1, os2);
		puts("Union of set 1 and set 2 is:");
		putset(res);
		setintersect(res, os1, os2);
		puts("Intersection of set 1 and set 2 is:");
		putset(res);
	}
	exit(0);
}


strtoset(os, s)
register OBJECT *os;
register char *s;
{
	extern char	*iskip();

	os[0] = 0;
	while (isintd(s, " \t")) {
		os[++os[0]] = atoi(s);
		s = iskip(s);
	}
}


putset(os)
register OBJECT *os;
{
	register int	i;

	for (i = *os++; i-- > 0; )
		printf(" %d", *os++);
	putchar('\n');
}

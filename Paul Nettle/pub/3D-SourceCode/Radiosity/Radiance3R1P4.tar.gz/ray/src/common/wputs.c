/* Copyright (c) 1991 Regents of the University of California */

#ifndef lint
static char SCCSid[] = "@(#)wputs.c 2.1 11/12/91 LBL";
#endif

wputs(s)			/* warning */
char  *s;
{
	eputs(s);
}

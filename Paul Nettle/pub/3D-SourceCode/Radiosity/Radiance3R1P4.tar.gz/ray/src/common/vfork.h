/* Copyright (c) 1992 Regents of the University of California */

/* SCCSid "@(#)vfork.h 2.2 1/12/94 LBL" */

/*
 * Header for routines using vfork() system call.
 */


#if !defined(BSD) || defined(sparc)

#define	vfork	fork

#endif

extern int	vfork();

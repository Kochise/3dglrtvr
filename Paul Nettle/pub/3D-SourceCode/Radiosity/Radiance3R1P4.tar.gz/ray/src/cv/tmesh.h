/* Copyright (c) 1994 Regents of the University of California */

/* SCCSid "@(#)tmesh.h 2.2 7/24/96 LBL" */

/*
 * Header file for triangle mesh routines using barycentric coordinates
 */

#define TCALNAME	"tmesh.cal"	/* the name of our auxiliary file */

typedef struct {
	int	ax;		/* major axis */
	FLOAT	tm[2][3];	/* transformation */
} BARYCCM;

#ifndef COSTOL
#define COSTOL		0.99985		/* cosine of tolerance for smoothing */
#endif

				/* flat_tri() return values */
#define ISBENT		0		/* is not flat */
#define ISFLAT		1		/* is flat */
#define RVBENT		2		/* reversed and not flat */
#define RVFLAT		3		/* reversed and flat */
#define DEGEN		-1		/* degenerate (zero area) */


 Sample Map for Pulsar LMTools
 -----------------------------
 by Lord Trancos

 --------------------------------------------------
 To build the lightmaps open a command-line windows
 (dos prompt) and type:

   LMTools.bat map ha

 --------------------------------------------------
 To view the map with lightmaps run LMDx and load
 map.3.lmts.

 --------------------------------------------------
 Some of the textures used in this Sample Map where
 downloaded from here:

 www.grsites.com/textures/

//______________________________________________________________
#pragma once
#include "i_framework.h"
#include "generic.h"
#include "terrain.h"

//______________________________________________________________
// class declarations:

class Camera;
class SOARX;
typedef void* HANDLE;

//______________________________________________________________
class SOARX
{
private:
	// textures
	enum Textures {BASE, DETAIL, SCALE, SCREEN, NORMAL, CLOUD, COLOR, BUMP};
	GLuint m_texture[8];
	GLuint vertex_buffer[2];
	GLuint index_buffer[2];

	// vertex buffers
	v4f* vertex_array;
	u32* index_array;
	u32 va_index;
	u32 ia_index;
	int page;

	// rendering
	typedef void (SOARX::*Renderer)();
	Renderer renderer[4];
	const int m_max_renderer;
	int m_current_renderer;
	int m_compatibility_level;

	// misc
	v4i window_size;
	float m_time;

	// camera
	Camera* m_refinement_camera;
	Camera* m_view_camera;

	// refinement
	const bool side;
	const bool bottom;
	bool left_only;
	bool first;
	float magic;
	f32 radii[64];
	f32* detail;
	Data* base;
	Data* baseq;
	Vertex base_vertices[13];

	// file map handles
	HANDLE base_file;
	HANDLE base_file_map;
	HANDLE baseq_file;
	HANDLE baseq_file_map;
	HANDLE detail_file;
	HANDLE detail_file_map;

	int level;
	int map_levels;
	int detail_levels;
	int base_levels;
	f32 temp;

	int map_bits;
	int base_bits;
	int detail_bits;
	int embedded_bits;

	int map_size;
	int base_size;
	int detail_size;
	int embedded_size;

	float base_horizontal_resolution;
	float base_vertical_resolution;
	float base_vertical_bias;

	float detail_horizontal_resolution;
	float detail_vertical_resolution;
	float detail_vertical_bias;

	float m_threshold;
	float m_detail_multiplier;

public:
	SOARX();
	~SOARX();
	int OnRenderContextCreated();
	int OnRenderContextDestroy();
	int OnWindowResized(int width, int height);

	int Init();
	void CalculateRadii(float f);
	int CycleRendrer();
	int SetRendrer(int i_renderer);
	float SetThreshold(float i_threshold);
	float SetDetailMultiplier(float i_detail_multiplier);
	void Render(float time);
	void Render0();
	void Render1();
	void Render2();
	void Render3();
	void Render_Sky();
	void ViewTexture(u8 tex);
	void LoadTextures();
	void Setup();
	int Load(const char* path);
	void SetCamera(Camera* i_refinement_camera, Camera* i_view_camera);
	float Attach(Camera* i_camera, int attach_mode);

private:
	Vertex GetVertex(i32 x, i32 y);
	void GetVertex(Vertex& v);
	bool Active(Vertex& v, u32& planes);
	void Append(Vertex& v);
	void TurnCorner();
	void RefineTop();
	void Refine(Vertex& i, Vertex& j, bool in, bool out, u32 planes);
	void RefineL(Vertex& i, Vertex& j, bool in, u32 planes);
	void RefineR(Vertex i, Vertex& j, bool out, u32 planes);
};


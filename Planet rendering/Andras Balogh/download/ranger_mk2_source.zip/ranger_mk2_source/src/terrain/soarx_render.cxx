//______________________________________________________________
// Ranger rendering
// Modified: 11/03/2003
//
//______________________________________________________________
// Include headers:
#include "soarx.h"
#include "camera.h"

//______________________________________________________________
void SOARX::Render0()
// Full quality rendering using two passes:
// The 1st pass renders combined gradient maps onto the surface.
// The result of the 1st pass is copied to a screen sized texture.
// The 2nd pass projects generated texture onto surface and
// uses dependent texture lookup to read irradiance values.
// Ambient map and cloud shadows are also applied in this pass.
{
	// constant vector parameters
	const f32 bt = 1.0f / (base_horizontal_resolution * base_size);
	const f32 dt = 1.0f / (detail_horizontal_resolution * detail_size);
	const f32 dt2 = 0.03f;

	static f32 s1 = 0;
	static f32 t1 = 0;
	static f32 s2 = 0;
	static f32 t2 = 0;
	f32 c1 = 0.000015f;
	f32 c2 = 0.00001f;

	float s = m_time * 100.0f;
	s1 = 0.0001f * s;
	t1 = 0.00005f * s;
	s2 = 0.00005f * s;
	t2 = 0.00009f * s;

	v4f* texgen_matrix = (v4f*)m_view_camera->get_projector(window_size.x, window_size.y);

	v4f s_plane_delta_base(bt, 0, 0, 0);
	v4f t_plane_delta_base(0, 0, bt, 0);
	v4f s_plane_delta_detail(dt, 0, 0, 0);
	v4f t_plane_delta_detail(0, 0, dt, 0);
	v4f s_plane_delta_detail_2(dt2, 0, 0, 0);
	v4f t_plane_delta_detail_2(0, 0, dt2, 0);
	v4f s_plane_cloud_1(c1, 0, 0, s1);
	v4f t_plane_cloud_1(0, 0, c1, t1);
	v4f s_plane_cloud_2(c2, 0, 0, s2);
	v4f t_plane_cloud_2(0, 0, c2, t2);
	v4f constant_0_5(0.5f, 0.5f, 0.5f, 0.5f);

	// setup first pass:

	// setup texture 0: detail texture
	// using replace texture environment
	// result = detail
	// output0 = texture0
	opengl->ActiveTexture(GL_TEXTURE0);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[DETAIL]);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_delta_detail);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_delta_detail);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	// setup texture 1: detail scale texture
	// using interpolate texture environment
	// result = (detail - 0.5) * scale + 0.5
	// result = detail * (scale) + 0.5 * (1 - scale)
	// output1 = output0 * (texture1) + constant * (1 - texture1)
	opengl->ActiveTexture(GL_TEXTURE1);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[SCALE]);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_delta_base);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_delta_base);
	opengl->TexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, constant_0_5);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_INTERPOLATE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PREVIOUS);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_CONSTANT);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE2_RGB, GL_TEXTURE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND2_RGB, GL_SRC_ALPHA);

	// setup texture 2: base texture
	// using signed addition texture environment
	// result = ((detail - 0.5) * scale + 0.5) + base - 0.5
	// output2 = output1 + texture2 - 0.5 
	opengl->ActiveTexture(GL_TEXTURE2);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[BASE]);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_delta_base);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_delta_base);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_ADD_SIGNED);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PREVIOUS);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_TEXTURE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);

	// setup texture 3: detail bump map
	// using signed addition texture environment
	// result = ((detail - 0.5) * scale + 0.5) + (base - 0.5) + (bump - 0.5)
	// output3 = output2 + texture3 - 0.5 
	opengl->ActiveTexture(GL_TEXTURE3);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[BUMP]);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_delta_detail_2);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_delta_detail_2);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_ADD_SIGNED);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PREVIOUS);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_TEXTURE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);

	// final fragment color = ((detail - 0.5) * scale + 0.5) + (base - 0.5)

	// render first pass:
	opengl->Enable(GL_DEPTH_TEST);
	opengl->DepthMask(GL_TRUE);
	opengl->DepthFunc(GL_LESS);
	opengl->Enable(GL_CULL_FACE);
	opengl->FrontFace(GL_CCW);
	opengl->CullFace(GL_BACK);
	opengl->Disable(GL_BLEND);
	opengl->PolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	opengl->DrawRangeElements(GL_TRIANGLE_STRIP, 0, va_index, ia_index, GL_UNSIGNED_INT, 0);

	//____________________
	// setup second pass:
	opengl->Enable(GL_TEXTURE_SHADER_NV);

	// setup texture 0: copy image to texture rectangle
	opengl->ActiveTexture(GL_TEXTURE0);
	opengl->TexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_TEXTURE_RECTANGLE_NV);
	opengl->BindTexture(GL_TEXTURE_RECTANGLE_NV, m_texture[SCREEN]);
	opengl->CopyTexSubImage2D(GL_TEXTURE_RECTANGLE_NV, 0, 0, 0, 0, 0, window_size.x, window_size.y);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->Disable(GL_TEXTURE_GEN_R);
	opengl->Enable(GL_TEXTURE_GEN_Q);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_Q, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, texgen_matrix[0]);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, texgen_matrix[1]);
	opengl->TexGenfv(GL_Q, GL_OBJECT_PLANE, texgen_matrix[3]);

	// setup texture 1: normal texture
	// using dependent texture read:
	// n(G, B) = normal vector encoded in RGB
	// using dot3 texture environment
	// result = light_direction dprod surface_normal
	// output1 = constant dprod texture
	opengl->ActiveTexture(GL_TEXTURE1);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[NORMAL]);
	opengl->TexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_DEPENDENT_GB_TEXTURE_2D_NV);
	opengl->TexEnvi(GL_TEXTURE_SHADER_NV, GL_PREVIOUS_TEXTURE_INPUT_NV, GL_TEXTURE0);
	opengl->Disable(GL_TEXTURE_GEN_S);
	opengl->Disable(GL_TEXTURE_GEN_T);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	//opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	//opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_REPLACE);
	//opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_TEXTURE);
	//opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_ALPHA);

	opengl->ActiveTexture(GL_TEXTURE2);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[COLOR]);
	opengl->TexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_TEXTURE_2D);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->Disable(GL_TEXTURE_GEN_R);
	opengl->Disable(GL_TEXTURE_GEN_Q);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_delta_base);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_delta_base);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	opengl->ActiveTexture(GL_TEXTURE3);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[CLOUD]);
	opengl->TexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_TEXTURE_2D);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->Disable(GL_TEXTURE_GEN_R);
	opengl->Disable(GL_TEXTURE_GEN_Q);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_cloud_2);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_cloud_2);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PREVIOUS);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_TEXTURE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_ALPHA);

	//opengl->ActiveTexture(GL_TEXTURE2);
	//opengl->TexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_NONE);
	//opengl->ActiveTexture(GL_TEXTURE3);
	//opengl->TexEnvi(GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_NONE);

	// render second pass:
	opengl->DepthMask(GL_FALSE);
	opengl->DepthFunc(GL_LEQUAL);

	v4f fog_color(0.6f, 0.7f, 0.8f, 0);
	opengl->Fogi(GL_FOG_MODE, GL_EXP);
	opengl->Fogf(GL_FOG_DENSITY, 0.000010f);
	opengl->Fogi(GL_FOG_COORDINATE_SOURCE, GL_FRAGMENT_DEPTH);
	opengl->Fogfv(GL_FOG_COLOR, fog_color);
	opengl->Enable(GL_FOG);

	opengl->DrawRangeElements(GL_TRIANGLE_STRIP, 0, va_index, ia_index, GL_UNSIGNED_INT, 0);

	opengl->Disable(GL_TEXTURE_SHADER_NV);
	opengl->Disable(GL_FOG);

	opengl->ResetTextureUnits();

	Render_Sky();

	opengl->DepthMask(GL_TRUE);
}

//______________________________________________________________
void SOARX::Render1()
// One pass delta rendering, very fast, but no real lighting.
// (Basically it's the first pass of the full quality)
{
	// constant vector parameters
	const f32 bt = 1.0f / (base_horizontal_resolution * base_size);
	const f32 dt = 1.0f / (detail_horizontal_resolution * detail_size);
	const f32 dt2 = 0.07f;

	v4f s_plane_delta_base(bt, 0, 0, 0);
	v4f t_plane_delta_base(0, 0, bt, 0);
	v4f s_plane_delta_detail(dt, 0, 0, 0);
	v4f t_plane_delta_detail(0, 0, dt, 0);
	v4f s_plane_delta_detail_2(dt2, 0, 0, 0);
	v4f t_plane_delta_detail_2(0, 0, dt2, 0);
	v4f constant_0_5(0.5f, 0.5f, 0.5f, 0.5f);

	// setup first pass:

	// setup texture 0: detail texture
	// using replace texture environment
	// result = detail
	// output0 = texture0
	opengl->ActiveTexture(GL_TEXTURE0);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[DETAIL]);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_delta_detail);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_delta_detail);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	// setup texture 1: detail scale texture
	// using interpolate texture environment
	// result = (detail - 0.5) * scale + 0.5
	// result = detail * (scale) + 0.5 * (1 - scale)
	// output1 = output0 * (texture1) + constant * (1 - texture1)
	opengl->ActiveTexture(GL_TEXTURE1);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[SCALE]);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_delta_base);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_delta_base);
	opengl->TexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, constant_0_5);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_INTERPOLATE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PREVIOUS);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_CONSTANT);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE2_RGB, GL_TEXTURE1);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND2_RGB, GL_SRC_ALPHA);

	// setup texture 2: base texture
	// using signed addition texture environment
	// result = ((detail - 0.5) * scale + 0.5) + base - 0.5
	// output2 = output1 + texture2 - 0.5 
	opengl->ActiveTexture(GL_TEXTURE2);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[BASE]);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_delta_base);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_delta_base);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_ADD_SIGNED);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PREVIOUS);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_TEXTURE2);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);

	opengl->ActiveTexture(GL_TEXTURE3);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[BUMP]);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_delta_detail_2);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_delta_detail_2);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_ADD_SIGNED);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PREVIOUS);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_TEXTURE3);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_RGB, GL_SRC_COLOR);

	// final fragment color = ((detail - 0.5) * scale + 0.5) + (base - 0.5)

	// render first pass:
	opengl->Enable(GL_DEPTH_TEST);
//	opengl->Enable(GL_DEPTH_CLAMP_NV);
	opengl->DepthMask(GL_TRUE);
	opengl->DepthFunc(GL_LESS);
	opengl->Enable(GL_CULL_FACE);
	opengl->FrontFace(GL_CCW);
	opengl->CullFace(GL_BACK);
	opengl->Disable(GL_BLEND);
	opengl->PolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	opengl->DrawRangeElements(GL_TRIANGLE_STRIP, 0, va_index, ia_index, GL_UNSIGNED_INT, 0);
	opengl->ResetTextureUnits();
}

//______________________________________________________________
void SOARX::Render2()
// Solid-wireframe rendering of the geometry:
// 1st pass renders solid triangles (using polygon offset).
// 2nd pass renders the wireframe.
{
	v4f solid_color(0.0f, 0.7f, 0.6f, 0);
	v4f wire_color(1.0f, 1.0f, 1.0f, 1.0f);

	opengl->Enable(GL_DEPTH_TEST);
	opengl->Enable(GL_CULL_FACE);
	opengl->Disable(GL_BLEND);
	opengl->FrontFace(GL_CCW);
	opengl->CullFace(GL_BACK);
//	opengl->Enable(GL_DEPTH_CLAMP_NV);
	opengl->PolygonOffset(1.0f, 2.0f);

	opengl->Color4fv(solid_color);
	opengl->Enable(GL_POLYGON_OFFSET_FILL);
	opengl->PolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	opengl->DrawRangeElements(GL_TRIANGLE_STRIP, 0, va_index, ia_index, GL_UNSIGNED_INT, 0);
	opengl->Disable(GL_POLYGON_OFFSET_FILL);

	opengl->Color4fv(wire_color);
	opengl->DepthMask(GL_FALSE);
	opengl->DepthFunc(GL_LEQUAL);
	opengl->PolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	opengl->DrawRangeElements(GL_TRIANGLE_STRIP, 0, va_index, ia_index, GL_UNSIGNED_INT, 0);
	opengl->DepthFunc(GL_LESS);
	opengl->DepthMask(GL_TRUE);

	opengl->PolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}

//______________________________________________________________
void SOARX::Render_Sky()
// Renders cloud cover:
// Two alpha textures are animated and combined for the good
// looking morphing clouds effect.
{
	f32 cx = base_horizontal_resolution * base_size;

	static f32 s1 = 0;
	static f32 t1 = 0;
	static f32 s2 = 0;
	static f32 t2 = 0;
	f32 c1 = 0.000015f;
	f32 c2 = 0.00001f;

	v4f s_plane_cloud_1(c1, 0, 0, s1);
	v4f t_plane_cloud_1(0, 0, c1, t1);
	v4f s_plane_cloud_2(c2, 0, 0, s2);
	v4f t_plane_cloud_2(0, 0, c2, t2);

	float s = m_time * 80.0f;
	s1 = 0.0001f * s;
	t1 = 0.00005f * s;
	s2 = 0.00005f * s;
	t2 = 0.00009f * s;

	opengl->ActiveTexture(GL_TEXTURE0);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[CLOUD]);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->Disable(GL_TEXTURE_GEN_R);
	opengl->Disable(GL_TEXTURE_GEN_Q);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_cloud_1);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_cloud_1);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_REPLACE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_ALPHA, GL_TEXTURE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_ALPHA, GL_SRC_ALPHA);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_REPLACE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PRIMARY_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_ALPHA_SCALE, 1);

	opengl->ActiveTexture(GL_TEXTURE1);
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[CLOUD]);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->Enable(GL_TEXTURE_GEN_S);
	opengl->Enable(GL_TEXTURE_GEN_T);
	opengl->Disable(GL_TEXTURE_GEN_R);
	opengl->Disable(GL_TEXTURE_GEN_Q);
	opengl->TexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	opengl->TexGenfv(GL_S, GL_OBJECT_PLANE, s_plane_cloud_2);
	opengl->TexGenfv(GL_T, GL_OBJECT_PLANE, t_plane_cloud_2);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_SUBTRACT);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_ALPHA, GL_PREVIOUS);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_ALPHA, GL_SRC_ALPHA);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE1_ALPHA, GL_TEXTURE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND1_ALPHA, GL_SRC_ALPHA);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_REPLACE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PRIMARY_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_COLOR);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_ALPHA_SCALE, 4);

	v4f fog_color(0.6f, 0.7f, 0.8f, 0);
	opengl->Fogi(GL_FOG_MODE, GL_EXP);
	opengl->Fogf(GL_FOG_DENSITY, 0.000010f);
	opengl->Fogi(GL_FOG_COORDINATE_SOURCE, GL_FRAGMENT_DEPTH);
	opengl->Fogfv(GL_FOG_COLOR, fog_color);
	opengl->Enable(GL_FOG);

	opengl->Enable(GL_DEPTH_TEST);
	opengl->Enable(GL_BLEND);
	opengl->BlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	opengl->Disable(GL_CULL_FACE);

	opengl->Color4f(1, 1, 1, 1);
	opengl->Begin(GL_QUADS);
	opengl->TexCoord4f(0, 1, 0, 1);
	opengl->Vertex4f(-cx, 10000, -cx, 1);
	opengl->TexCoord4f(0, 0, 0, 1);
	opengl->Vertex4f(-cx, 10000, 2*cx, 1);
	opengl->TexCoord4f(1, 0, 0, 1);
	opengl->Vertex4f(2*cx, 10000, 2*cx, 1);
	opengl->TexCoord4f(1, 1, 0, 1);
	opengl->Vertex4f(2*cx, 10000, -cx, 1);
	opengl->End();

	opengl->ResetTextureUnits();

	opengl->Disable(GL_FOG);
	opengl->Disable(GL_BLEND);
	opengl->Enable(GL_CULL_FACE);
}

//______________________________________________________________

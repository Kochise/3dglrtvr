//______________________________________________________________
#include "i_framework.h"
#include "configure.h"
#include "generic.h"
#include "tbuilder.h"
#include "soarx.h"
#include "camera.h"
#include "animation.h"

//______________________________________________________________
ISystem* sys;
TBuilder* tbuilder;
SOARX* terrain;
IOpenGL* opengl;

//______________________________________________________________
class Main
{
private:
	bool avi_record;
	v4f force;
	float speed;
	float time;
	Camera camera[4];
	int camera_selector;
	int view_camera;
	int refinement_camera;
	float threshold;
	float detail;
	bool frustum;
	int walk;
	bool active;
	Animation animation;
	float playback_speed;
	bool record;
	bool playback;
public:
	Main(ISystem* i_sys);
	~Main();
	int Toggle(int i_active);
	int CompatibilityMode(int compatibility);
	int Simulate(double at, double dt);
	int Update(double at, double dt);
	int Render(double at, double dt);
	int OnButton(int type, int code, double time);
};

//______________________________________________________________
void* Factory(ISystem* i_sys)
{
	static Main instance(i_sys);
	return &instance;
}

//______________________________________________________________
Main::Main(ISystem* i_sys) :
avi_record(false),
animation(1.0f),
record(false),
playback(true),
playback_speed(1.0f),
threshold(2.0f),
detail(7.0f),
view_camera(0),
refinement_camera(0),
camera_selector(0),
frustum(true),
speed(40.0f),
walk(1),
active(false),
force(0, 0, 0, 0)
{
	sys = i_sys;
	
	opengl = static_cast<IOpenGL*>(sys->GetInterface("OpenGL"));
	tbuilder = new TBuilder();
	terrain = new SOARX();

	sys->Log("Terrain rendering module loaded (%s: %s %s)\n", BUILD_TYPE, __DATE__, __TIME__);
//	speed = 10000.0f;
	walk = static_cast<int>(sys->GetGlobalNumber("Terrain.walk"));
//	walk = 0;

	camera[0].move(14082, 8000, 12472);
	camera[0].turn(-2.5f, 0.0f, 0);
	camera[1].move(0, 8000, 0);
	camera[1].turn(-2.5f, -1.5707f, 0);
	camera[2].move(80000, 80000, 80000);
	camera[2].turn(0, -1.5707f, 0);
	camera[2].m_fovy = 100.0f;
	camera[3] = camera[0];

	terrain->SetCamera(&camera[refinement_camera], &camera[view_camera]);
	terrain->SetThreshold(2.0f);
	terrain->SetDetailMultiplier(7.0f);

	sys->Subscribe("Terrain.Toggle", Callback(this, Toggle));
}

//______________________________________________________________
Main::~Main()
{
	release(terrain);
	release(tbuilder);
	sys->Log("Terrain rendering module released.\n");
}

//______________________________________________________________
int Main::Toggle(int i_active)
{
	active = i_active == 1.0 ? true : false;

	if (!active) {
		sys->Unsubscribe("Event.Simulate", Callback(this, Simulate));
		sys->Unsubscribe("Event.Render", Callback(this, Render));
		sys->Unsubscribe("Event.Update", Callback(this, Update));
		sys->Unsubscribe("Event.OnButton", Callback(this, OnButton));
	} else {
		terrain->Init();
		std::string terrain_file;
		terrain_file.assign("maps/");
		terrain_file.append(sys->GetGlobalString("Terrain.name"));
		terrain_file.append("/");
		if (terrain->Load(terrain_file.c_str()) == 0) {
			sys->Subscribe("Event.Simulate", Callback(this, Simulate));
			sys->Subscribe("Event.Update", Callback(this, Update));
			sys->Subscribe("Event.OnButton", Callback(this, OnButton));
			sys->UnsubscribeAll("Event.Render");
			sys->Subscribe("Event.Render", Callback(this, Render));
			if (animation.Load(sys->GetGlobalString("Terrain.animation")) == -1) {
				playback = false;
			}
		}
	}

	return 0;
}

//______________________________________________________________
int Main::OnButton(int type, int code, double time)
{
	IOpenGL* opengl = static_cast<IOpenGL*>(sys->GetInterface("OpenGL"));

	if (type == 0) {
		if (code == 'x') {
			walk = 1-walk;
		} else if (code == 'z') {
			terrain->CycleRendrer();
		} else if (code == 'c') {
			frustum = !frustum;
		} else if (code == '1') { 
			camera_selector = 1;
			view_camera = 0;
			refinement_camera = 0;
			sys->Log("First person camera.\n");
		} else if (code == '2') { 
			camera_selector = 2;
			view_camera = 1;
			refinement_camera = 0;
			sys->Log("Overhead view.\n");
		} else if (code == '3') { 
			camera_selector = 3;
			view_camera = 2;
			refinement_camera = 0;
			sys->Log("Map view.\n");
		} else if (code == '4') { 
			camera_selector = 4;
			view_camera = 3; 
			refinement_camera = 0;
			sys->Log("Chasecam.\n");
		} else if (code == 'q') {
			speed *= 2.0f; 
			speed = min(speed, 100000.0f);
		} else if (code == 'e') {
			speed *= .5f; 
			speed = max(speed, 10.0f);
		} else if (code == '[') {
			threshold = terrain->SetThreshold(threshold + 0.1f);
		} else if (code == ']') { 
			threshold = terrain->SetThreshold(threshold - 0.1f);
		} else if (code == ';') {
			detail = terrain->SetDetailMultiplier(detail - 0.1f);
		} else if (code == '\'') { 
			detail = terrain->SetDetailMultiplier(detail + 0.1f);
		//} else if (code == 'b') { 
		//	animation.JumpToLastFrame(&camera[0]);
		//} else if (code == ',') { 
		//		record = !record; 
		//		if (record) {
		//			animation.Prepare(1.0);
		//		} else {
		//			animation.Save("demos/flythrough.demo");
		//		}
		//} else if (code == ' ') {
		//	playback = !playback; 
		//	if (playback) {
		//		animation.Load("demos/flythrough.demo");
		//		animation.Rewind();
		//	}
		}
	} else if (type == 1) {
		if (time == 0) {
			if (code == ' ') {
				//animation.Record(&camera[0]);
				playback = !playback;
			//} else if (code == VK_RETURN) {
			//	avi_record = !avi_record;
			} else if (code == 0x21) {
				f32 a = abs(playback_speed);
				if (a < 0.99f) {
					playback_speed += 0.1f;
				} else {
					playback_speed += 0.5f;
				}
				sys->OverlayNote("Playback speed set to %3.1fx.\n", playback_speed);
			} else if (code == 0x22) {
				f32 a = abs(playback_speed);
				if (a < 0.99f) {
					playback_speed -= 0.1f;
				} else {
					playback_speed -= 0.5f;
				}
//				playback_speed -= 0.5f;
				sys->OverlayNote("Playback speed set to %3.1fx.\n", playback_speed);
			}
		}

		if ( code == 'T') {
			camera[view_camera].m_fovy *= 0.99f;
			sys->OverlayNote("View camera FOV %3.3f\n", camera[view_camera].m_fovy);
		} else if ( code == 'G') {
			camera[view_camera].m_fovy *= (1.0f/0.99f);
			sys->OverlayNote("View camera FOV %3.3f\n", camera[view_camera].m_fovy);
		} else if ( code == 'Y') {
			camera[refinement_camera].m_fovy -= 0.1f;
			sys->OverlayNote("Refinement camera FOV %3.3f\n", camera[refinement_camera].m_fovy);
		} else if ( code == 'H') {
			camera[refinement_camera].m_fovy += 0.1f;
			sys->OverlayNote("Refinement camera FOV %3.3f\n", camera[refinement_camera].m_fovy);
		} else if ( code == 'W') {
			force.z -= 1;
		} else if ( code == 'S') { 
			force.z += 1;
		} else if ( code == 'A') { 
			force.x -= 1;
		} else if ( code == 'D') { 
			force.x += 1;
		} else if ( code == 'R') {
			force.y += 1;
		} else if ( code == 'F') {
			force.y -= 1; 
		}
	} else if (type == 2) {
		if (code == 0 && time == 0) {
			walk = !walk;
		} else if (code == 1) {
			force.z -= speed;
		} else if (code == 2) {
			force.z += speed;
		}
	}

	return 0;
}

//______________________________________________________________
int Main::Simulate(double at, double dt)
{
	time = (float)at;

	double x, y;
	sys->GetMouseMovement(x, y);

	if (camera_selector == 4) {
		camera[view_camera].m_position = camera[refinement_camera].m_position;
		camera[view_camera].turn((float)-x*0.0001f, (float)y*0.0001f, 0);
		camera[view_camera].move(0, 0, 20000);
	}

	if (playback) {
		return 0;
	}

	force.clamp(1);
	float l = force.length();
	if (l > EPS) {
		force.scale(1.0f/l*speed*(float)dt);
	}

	if (camera_selector != 4) {

		camera[0].turn((float)-x*0.0001f, (float)y*0.0001f, 0);
		camera[0].move(force.x, force.y, force.z);

		camera[1].turn((float)-x*0.0001f, 0, 0);
		camera[1].m_position = camera[0].m_position;
		camera[1].m_position.y = 80000;
	}


	//if (record) {
	//	animation.Record(dt, &camera[0]);
	//}

	return 0;
}

//______________________________________________________________
int Main::Update(double at, double dt)
{
	if (playback) {
		if (avi_record) {
			animation.Playback(1.0f/30.0f, &camera[0]);
		} else {
			animation.Playback(dt * playback_speed, &camera[0]);
		}

		camera[1].m_position = camera[0].m_position;
		camera[1].m_position.y = 9000;
	}

	terrain->SetCamera(&camera[refinement_camera], &camera[view_camera]);
	terrain->Attach(&camera[refinement_camera], walk);
	f32 view_rel_alt = terrain->Attach(&camera[view_camera], 0);

	camera[refinement_camera].update();
	camera[view_camera].update();

	sys->OverlayWrite(4, "Position: %3.1fm %3.1fm", camera[view_camera].m_position.x, camera[view_camera].m_position.z);
	sys->OverlayWrite(5, "Altitude: %3.1fm (%3.1fm)", camera[view_camera].m_position.y, view_rel_alt);
	
	if (!playback) {
		sys->OverlayWrite(6, "Speed: %3.1fKm/h", force.length() * 200.0f * 3.6f);
	}

	force(0, 0, 0, 0);
	return 0;
}

//______________________________________________________________
int Main::Render(double at, double dt)
{
	terrain->Render(time);

	if (frustum && (view_camera != refinement_camera)) {
		camera[refinement_camera].RenderFrustum();
	}

	if (avi_record) {
		IOpenGL* opengl = static_cast<IOpenGL*>(sys->GetInterface("OpenGL"));
		opengl->SaveScreen();
	}

	return 0;
}

//______________________________________________________________

//______________________________________________________________
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <string>
#include "tbuilder.h"
#include "generic.h"

static Noise n;

//______________________________________________________________
TBuilder::TBuilder()
{
	sys->Log("TBuilder services loaded (%s: %s %s)\n", BUILD_TYPE, __DATE__, __TIME__);
	sys->Subscribe("Terrain.BuildMap", Callback(this, Build));
}

//______________________________________________________________
TBuilder::~TBuilder()
{
	sys->Log("TBuilder services released.\n");
}

//______________________________________________________________
int TBuilder::Build()
{
	sys->Log("Building terrain dataset:\n");
	sys->Subscribe("Event.Update", Callback(this, BuildSteps));

	src_image = static_cast<IImage*>(sys->GetInterface("Image"));
	dst_image = static_cast<IImage*>(sys->GetInterface("Image"));

	map_bits = static_cast<int>(sys->GetGlobalNumber("Terrain.map_bits"));
	base_bits = static_cast<int>(sys->GetGlobalNumber("Terrain.base_bits"));
	detail_bits = static_cast<int>(sys->GetGlobalNumber("Terrain.detail_bits"));
	base_horizontal_resolution = static_cast<float>(sys->GetGlobalNumber("Terrain.horizontal_resolution"));
	base_vertical_resolution = static_cast<float>(sys->GetGlobalNumber("Terrain.vertical_resolution"));
	base_vertical_bias = static_cast<float>(sys->GetGlobalNumber("Terrain.vertical_bias"));
	embedded_bits = map_bits - base_bits;
	map_size = (1 << map_bits) + 1;
	base_size = (1 << base_bits) + 1;
	detail_size = 1 << detail_bits;
	embedded_size = 1 << embedded_bits;
	detail_horizontal_resolution = base_horizontal_resolution / static_cast<float>(embedded_size);
	detail_vertical_resolution = static_cast<float>(sys->GetGlobalNumber("Terrain.detail_vertical_resolution"));
	detail_vertical_bias = -32768.0f * detail_vertical_resolution;
	base_levels = base_bits << 1;

	sys->Log("Map dimensions: %dx%d (%d levels)\n", map_size, map_size, map_bits << 1);

	std::string path("maps/");
	path.append(sys->GetGlobalString("Terrain.name"));
	path.append("/");
	std::string base_file_path(path);
	std::string baseq_file_path(path);
	std::string detail_file_path(path);
	base_file_path.append("base.t");
	baseq_file_path.append("base.q");
	detail_file_path.append("detail.t");

	// map terrain file into address space
	LARGE_INTEGER base_map_size;
	LARGE_INTEGER baseq_map_size;
	LARGE_INTEGER detail_map_size;
	base_map_size.QuadPart = sizeof(Data) * (base_size * (base_size+1));
	detail_map_size.QuadPart = sizeof(f32) * (detail_size * detail_size);

	u32 n = base_bits;
	u32 t = (1<<((n<<1)+2));
	u32 r = t - ((t<<1)-8)/3 + 1;
	baseq_map_size.QuadPart = r * sizeof(Data);

	base_file = ::CreateFile(base_file_path.c_str(), GENERIC_READ | GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	detail_file = ::CreateFile(detail_file_path.c_str(), GENERIC_READ | GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	::SetFilePointerEx(base_file, base_map_size, 0, FILE_BEGIN);
	::SetEndOfFile(base_file);
	::SetFilePointerEx(detail_file, detail_map_size, 0, FILE_BEGIN);
	::SetEndOfFile(detail_file);

	base_file_map = ::CreateFileMapping(base_file, 0, PAGE_READWRITE, 0, 0, 0);
	detail_file_map = ::CreateFileMapping(detail_file, 0, PAGE_READWRITE, 0, 0, 0);
	base = reinterpret_cast<Data*>(::MapViewOfFile(base_file_map, FILE_MAP_ALL_ACCESS, 0, 0, 0));
	detail = reinterpret_cast<f32*>(::MapViewOfFile(detail_file_map, FILE_MAP_ALL_ACCESS, 0, 0, 0));

#ifdef DATA_LAYOUT_EMBEDDED_QUADTREE
	baseq_file = ::CreateFile(baseq_file_path.c_str(), GENERIC_READ | GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	::SetFilePointerEx(baseq_file, baseq_map_size, 0, FILE_BEGIN);
	::SetEndOfFile(baseq_file);
	baseq_file_map = ::CreateFileMapping(baseq_file, 0, PAGE_READWRITE, 0, 0, 0);
	baseq = reinterpret_cast<Data*>(::MapViewOfFile(baseq_file_map, FILE_MAP_ALL_ACCESS, 0, 0, 0));
#endif

	// prepare base indices
	int cx = base_size - 1;
	int ch = (base_size - 1) >> 1;
	base_indices[0] = Index(ch, ch);
	base_indices[1] = Index(ch, 0);
	base_indices[2] = Index(cx, 0);
	base_indices[3] = Index(cx, ch);
	base_indices[4] = Index(cx, cx);
    base_indices[5] = Index(ch, cx);
	base_indices[6] = Index(0, cx);
	base_indices[7] = Index(0, ch);
	base_indices[8] = Index(0, 0);

	return 0;
}

//______________________________________________________________
int TBuilder::BuildSteps()
{
	const float grad_scale = 128.0f;

	static int step = 0;
	static int counter = 0;
	static IImage::Dimensions src_dim;
	static IImage::Dimensions dst_dim;
	static int line = 0;
	static std::string progress_bar;
	static std::string image_extension(".png");
	static std::string terrain_name;
	static std::string terrain_base_color;
	static std::string terrain_base_elevation;
	static std::string terrain_base_gradient;
	static std::string terrain_detail_elevation;
	static std::string terrain_detail_gradient;
	static std::string terrain_detail_scale;
	static std::string terrain_bump_elevation;
	static std::string terrain_bump_gradient;
	static std::string terrain_cloud_color;

	if (step == 0) { // 0: setup file paths
		terrain_name.assign("maps/");
		terrain_name.append(sys->GetGlobalString("Terrain.name"));
		terrain_name.append("/");
		terrain_base_color.assign(terrain_name);
		terrain_base_color.append("base.color");
		terrain_base_color.append(image_extension);
		terrain_base_elevation.assign(terrain_name);
		terrain_base_elevation.append("base.elevation");
		terrain_base_elevation.append(image_extension);
		terrain_base_gradient.assign(terrain_name);
		terrain_base_gradient.append("base.gradient");
		terrain_base_gradient.append(image_extension);
		terrain_detail_elevation.assign(terrain_name);
		terrain_detail_elevation.append("detail.elevation");
		terrain_detail_elevation.append(image_extension);
		terrain_detail_gradient.assign(terrain_name);
		terrain_detail_gradient.append("detail.gradient");
		terrain_detail_gradient.append(image_extension);
		terrain_detail_scale.assign(terrain_name);
		terrain_detail_scale.append("detail.scale");
		terrain_detail_scale.append(image_extension);
		terrain_bump_elevation.assign(terrain_name);
		terrain_bump_elevation.append("bump.elevation");
		terrain_bump_elevation.append(image_extension);
		terrain_bump_gradient.assign(terrain_name);
		terrain_bump_gradient.append("bump.gradient");
		terrain_bump_gradient.append(image_extension);
		terrain_cloud_color.assign(terrain_name);
		terrain_cloud_color.append("cloud.color");
		terrain_cloud_color.append(image_extension);
		step = 1;

	// --- BASE ELEVATION MAP ---
	} else if (step == 1) { // 1: Prepare loading of base elevation map
		if (src_image->LoadInfo(terrain_base_elevation.c_str()) == -1) {
			sys->Log("Generating %s.\n", terrain_base_elevation.c_str());
			src_dim.width = base_size;
			src_dim.height = base_size;
			src_dim.depth = 1;
			src_dim.channels = 1;
			src_dim.bpc = 16;
			src_image->Create(src_dim);
			line = 0;
			progress_bar.clear();
			step = 3;
		} else {
			sys->Log("Loading %s.\n", terrain_base_elevation.c_str());
			step = 2;
		}
	} else if (step == 2) { // 2: Load base elevation map
		src_image->Load(terrain_base_elevation.c_str());
		src_dim = src_image->GetDimensions();
		step = 5;
	} else if (step == 3) { // 3: Generate base elevation map
		int lines_remaining = 1;
		for (int counter=0; counter<32 && lines_remaining; counter++) {
			lines_remaining = src_image->ProcessLine(line++, CreateBaseMap, this);
		}
		if (lines_remaining == 0) {
			progress_bar.append("Done.");
			step = 4;
		} else {
			progress_bar.append(1, '.');
		}
		sys->ExecuteString("Console.Write(\"Generating %s%s\")", terrain_base_elevation.c_str(), progress_bar.c_str());
	} else if (step == 4) { // 6: Save base elevation map
		src_image->Save(terrain_base_elevation.c_str());
		step = 5;
	} else if (step == 5) { // 7: Prepare processing base map
		sys->Log("Processing base elevation map.\n");
		line = 0;
		progress_bar.clear();
		step = 6;
	} else if (step == 6) { // 8: Process base elevation map
		int lines_remaining = 1;
		for (int counter=0; counter<32 && lines_remaining; counter++) {
			lines_remaining = src_image->ProcessLine(line++, ProcessBaseMap, this);
		}
		if (lines_remaining == 0) {
			progress_bar.append("Done.");
			step = 7;
		} else {
			progress_bar.append(1, '.');
		}
		sys->ExecuteString("Console.Write(\"Processing %s%s\")", terrain_base_elevation.c_str(), progress_bar.c_str());

	// --- BASE GRADIENT MAP ---
	} else if (step == 7) { // 9: Prepare generating base gradient
		sys->Log("Generating %s.\n", terrain_base_gradient.c_str());
		dst_dim = src_dim;
		dst_dim.bpc = 8;
		dst_dim.channels = 3;
		dst_dim.width -= 1;
		dst_dim.height -= 1;
		dst_image->Create(dst_dim);
		step = 8;
	} else if (step == 8) { // 10: Generate base gradient
		dst_image->CreateGradient(src_image, grad_scale * base_vertical_resolution / base_horizontal_resolution);
		step = 9;
	} else if (step == 9) { // 12: Save base gradient map
		dst_image->Save(terrain_base_gradient.c_str());
		step = 10;

	// --- DETAIL SCALE MAP ---
	} else if (step == 10) { // 13: Prepare loading of detail scale map
		if (src_image->LoadInfo(terrain_detail_scale.c_str()) == -1) {
			sys->Log("Generating %s.\n", terrain_detail_scale.c_str());
			src_dim.width = base_size - 1;
			src_dim.height = base_size - 1;
			src_dim.depth = 1;
			src_dim.channels = 1;
			src_dim.bpc = 16;
			src_image->Create(src_dim);
			line = 0;
			progress_bar.clear();
			step = 12;
		} else {
			sys->Log("Loading %s.\n", terrain_detail_scale.c_str());
			step = 11;
		}
	} else if (step == 11) { // 14: Load detail scale map
		src_image->Load(terrain_detail_scale.c_str());
		src_dim = src_image->GetDimensions();
		step = 14;
	} else if (step == 12) { // 16: Generate detail scale map
		int lines_remaining = 0;
		for (int counter=0; counter<32; counter++) {
			lines_remaining = src_image->ProcessLine(line++, CreateScaleMap, this);
		}
		if (lines_remaining == 0) {
			progress_bar.append("Done.");
			step = 13;
		} else {
			progress_bar.append(1, '.');
		}
		sys->ExecuteString("Console.Write(\"Generating %s%s\")", terrain_detail_scale.c_str(), progress_bar.c_str());
	} else if (step == 13) { // 18: Save detail scale map
		src_image->Save(terrain_detail_scale.c_str());
		step = 14;
	} else if (step == 14) { // 19: Prepare processing scale map
		sys->Log("Processing %s.\n", terrain_detail_scale.c_str());
		line = 0;
		progress_bar.clear();
		step = 15;
	} else if (step == 15) { // 8: Process scale map
		int lines_remaining = 1;
		for (int counter=0; counter<32 && lines_remaining; counter++) {
			lines_remaining = src_image->ProcessLine(line++, ProcessScaleMap, this);
		}
		if (lines_remaining == 0) {
			progress_bar.append("Done.");
			step = 16;
		} else {
			progress_bar.append(1, '.');
		}
		sys->ExecuteString("Console.Write(\"Processing %s%s\")", terrain_detail_scale.c_str() ,progress_bar.c_str());

	// --- DETAIL ELEVATION MAP ---
	} else if (step == 16) { // 21: Prepare loading of detail elevation map
		if (src_image->LoadInfo(terrain_detail_elevation.c_str()) == -1) {
			sys->Log("Generating %s.\n", terrain_detail_elevation.c_str());
			src_dim.width = detail_size;
			src_dim.height = detail_size;
			src_dim.depth = 1;
			src_dim.channels = 1;
			src_dim.bpc = 16;
			src_image->Create(src_dim);
			line = 0;
			progress_bar.clear();
			step = 18;
		} else {
			sys->Log("Loading %s.\n", terrain_detail_elevation.c_str());
			step = 17;
		}
	} else if (step == 17) { // 22: Load detail elevation map
		src_image->Load(terrain_detail_elevation.c_str());
		src_dim = src_image->GetDimensions();
		step = 20; // load successful
	} else if (step == 18) { // 24: Generate detail elevation map
		int lines_remaining = 0;
		for (int counter=0; counter<32; counter++) {
			lines_remaining = src_image->ProcessLine(line++, CreateDetailMap, this);
		}
		if (lines_remaining == 0) {
			progress_bar.append("Done.");
			step = 19;
		} else {
			progress_bar.append(1, '.');
		}
		sys->ExecuteString("Console.Write(\"Generating %s%s\")", terrain_detail_elevation.c_str() ,progress_bar.c_str());
	} else if (step == 19) { // 26: Save detail elevation map
		src_image->Save(terrain_detail_elevation.c_str());
		step = 20;
	} else if (step == 20) { // 27: Prepare processing detail map
		sys->Log("Processing %s.\n", terrain_detail_elevation.c_str());
		line = 0;
		progress_bar.clear();
		step = 21;
	} else if (step == 21) { // 28: Process detail elevation map
		int lines_remaining = 1;
		for (int counter=0; counter<32 && lines_remaining; counter++) {
			lines_remaining = src_image->ProcessLine(line++, ProcessDetailMap, this);
		}
		if (lines_remaining == 0) {
			progress_bar.append("Done.");
			step = 22;
		} else {
			progress_bar.append(1, '.');
		}
		sys->ExecuteString("Console.Write(\"Processing %s%s\")", terrain_detail_elevation.c_str() ,progress_bar.c_str());

	// --- DETAIL GRADIENT MAP ---
	} else if (step == 22) { // 29: Prepare generating detail gradient
		sys->Log("Generating %s.\n", terrain_detail_gradient.c_str());
		dst_dim = src_dim;
		dst_dim.bpc = 8;
		dst_dim.channels = 3;
		dst_image->Create(dst_dim);
		step = 23;
	} else if (step == 23) { // 30: Generate detail gradient
		dst_image->CreateGradient(src_image, grad_scale * detail_vertical_resolution / detail_horizontal_resolution);
		step = 24;
	} else if (step == 24) { // 32: Save detail gradient map
		dst_image->Save(terrain_detail_gradient.c_str());
		step = 25;

	// --- BUMP ELEVATION MAP ---
	} else if (step == 25) { // 33: Prepare loading of bump elevation map
		if (src_image->LoadInfo(terrain_bump_elevation.c_str()) == -1) {
			sys->Log("Generating %s.\n", terrain_bump_elevation.c_str());
			src_dim.width = 1024;
			src_dim.height = 1024;
			src_dim.depth = 1;
			src_dim.channels = 1;
			src_dim.bpc = 16;
			src_image->Create(src_dim);
			line = 0;
			progress_bar.clear();
			step = 27;
		} else {
			sys->Log("Loading %s.\n", terrain_bump_elevation.c_str());
			step = 26;
		}
	} else if (step == 26) { // 34: Load bump elevation map
		src_image->Load(terrain_bump_elevation.c_str());
		src_dim = src_image->GetDimensions();
		step = 29;
	} else if (step == 27) { // 36: Generate bump elevation map
		int lines_remaining = 0;
		for (int counter=0; counter<32; counter++) {
			lines_remaining = src_image->ProcessLine(line++, CreateBumpMap, this);
		}
		if (lines_remaining == 0) {
			progress_bar.append("Done.");
			step = 28;
		} else {
			progress_bar.append(1, '.');
		}
		sys->ExecuteString("Console.Write(\"Generating %s%s\")", terrain_bump_elevation.c_str() ,progress_bar.c_str());
	} else if (step == 28) { // 38: Save bump elevation map
		src_image->Save(terrain_bump_elevation.c_str());
		step = 29;

	// --- BUMP GRADIENT MAP ---
	} else if (step == 29) { // 39: Prepare generating bump gradient
		sys->Log("Generating %s.\n", terrain_bump_gradient.c_str());
		dst_dim = src_dim;
		dst_dim.bpc = 8;
		dst_dim.channels = 3;
		dst_image->Create(dst_dim);
		step = 30;
	} else if (step == 30) { // 40: Generate bump gradient
		dst_image->CreateGradient(src_image, grad_scale * detail_vertical_resolution / detail_horizontal_resolution * 0.4f);
		step = 31;
	} else if (step == 31) { // 42: Save bump gradient map
		dst_image->Save(terrain_bump_gradient.c_str());
		step = 32;

	// --- CLOUD COLOR MAP ---
	} else if (step == 32) { // 43: Prepare loading of bump color map
		if (src_image->LoadInfo(terrain_cloud_color.c_str()) == -1) {
			sys->Log("Generating %s.\n", terrain_cloud_color.c_str());
			src_dim.width = 1024;
			src_dim.height = 1024;
			src_dim.depth = 1;
			src_dim.channels = 1;
			src_dim.bpc = 16;
			src_image->Create(src_dim);
			line = 0;
			progress_bar.clear();
			step = 34;
		} else {
			sys->Log("Loading %s.\n", terrain_cloud_color.c_str());
			step = 33;
		}
	} else if (step == 33) { // 44: Load cloud color map
		src_image->Load(terrain_cloud_color.c_str());
		src_dim = src_image->GetDimensions();
		step = 50; // load successful
	} else if (step == 34) { // 46: Generate cloud color map
		int lines_remaining = 0;
		for (int counter=0; counter<32; counter++) {
			lines_remaining = src_image->ProcessLine(line++, CreateCloudMap, this);
		}
		if (lines_remaining == 0) {
			progress_bar.append("Done.");
			step = 35;
		} else {
			progress_bar.append(1, '.');
		}
		sys->ExecuteString("Console.Write(\"Generating %s%s\")", terrain_cloud_color.c_str() ,progress_bar.c_str());
	} else if (step == 35) { // 48: Save cloud color map
		src_image->Save(terrain_cloud_color.c_str());
		step = 50;

	// --- PREPROCESS DATASET ---
	} else if (step == 50) {
		sys->Log("Calculating object space errors.\n");
		step++;
	} else if (step == 51) {
		Phase1();
		step++;
	} else if (step == 52) {
		sys->Log("Propagating errors and building bounding sphere hierarchy.\n");
		step++;
	} else if (step == 53) {
		Phase2();
		sys->Log("Building embedded quadtree layout.\n");

#ifdef DATA_LAYOUT_EMBEDDED_QUADTREE
		step = 54;
#else
		step = 55;
#endif

	} else if (step == 54) {
		BuildEmbeddedQuadtree();
		step++;
	} else if (step == 55) {
		// unmap terrain file
		::UnmapViewOfFile(detail);
		::CloseHandle(detail_file_map);
		::CloseHandle(detail_file);

#ifdef DATA_LAYOUT_EMBEDDED_QUADTREE
		::UnmapViewOfFile(baseq);
		::CloseHandle(baseq_file_map);
		::CloseHandle(baseq_file);
#endif
		::UnmapViewOfFile(base);
		::CloseHandle(base_file_map);
		::CloseHandle(base_file);

		release(dst_image);
		release(src_image);
		sys->Log("Terrain dataset ready.\n");
		step++;
	} else if (step == 56) {
		sys->ExecuteString("Terrain.Toggle(1)");
		sys->Unsubscribe("Event.Update", Callback(this, BuildSteps));
		step = 0;
	}

	return 0;
}

//______________________________________________________________
int TBuilder::CreateBaseMap(int ch, int cx, int cy, int cz, int value, void* ptr)
{
	int a[] = {64, 128, 1024, 1024, 2048, 1024, 512, 256, 64, 58};

	int d = 0;
	int tx = cx<<2;
	int ty = cy<<2;

	for (int o=0; o<10; o++) {
		int c = 1024<<(12-(10-o));
		int x = cx<<(12-(10-o));
		int y = cy<<(12-(10-o));
		int p = n(x, y);
		int px = n(x-c, y);
		int py = n(x, y-c);
		int pxy = n(x-c, y-c);
		d += imul(ilerp(ty, ilerp(tx, p, px), ilerp(tx, py, pxy)), a[o]);
		d = clamp(d, 4095);
	}

	d <<= 3;
	d += 32767;

	return static_cast<u16>(d);
}

//______________________________________________________________
int TBuilder::CreateDetailMap(int ch, int cx, int cy, int cz, int value, void* ptr)
{
	int a[] = {0, 0, 0, 0, 2048, 1024, 512, 256, 96, 58};

	int d = 0;
	int tx = cx<<2;
	int ty = cy<<2;

	for (int o=4; o<10; o++) {
		int c = 1024<<(12-(10-o));
		int x = cx<<(12-(10-o));
		int y = cy<<(12-(10-o));
		int p = n(x, y);
		int px = n(x-c, y);
		int py = n(x, y-c);
		int pxy = n(x-c, y-c);
		d += imul(ilerp(ty, ilerp(tx, p, px), ilerp(tx, py, pxy)), a[o]);
		d = clamp(d, 4095);
	}

	d <<= 3;
	d += 32767;

	return static_cast<u16>(d);
}

//______________________________________________________________
int TBuilder::CreateScaleMap(int ch, int cx, int cy, int cz, int value, void* ptr)
{
	int a[] = {64, 128, 1024, 1024, 2048, 1024, 512, 5000, 4000, 4000};

	int d = 0;
	int tx = cx<<2;
	int ty = cy<<2;

	for (int o=8; o<10; o++) {
		int c = 1024<<(12-(10-o));
		int x = cx<<(12-(10-o));
		int y = cy<<(12-(10-o));
		int p = n(x, y);
		int px = n(x-c, y);
		int py = n(x, y-c);
		int pxy = n(x-c, y-c);
		d += imul(ilerp(ty, ilerp(tx, p, px), ilerp(tx, py, pxy)), a[o]);
		d = clamp(d, 4095);
	}

	d <<= 3;
	d += 40000;
	d = clamp(d, 0, 65535);
	//d <<= 4;
	//d |= 0x4000;

	return static_cast<u16>(d);
}

//______________________________________________________________
int TBuilder::CreateBumpMap(int ch, int cx, int cy, int cz, int value, void* ptr)
{
	int a[] = {64, 128, 1024, 1024, 2048, 1024, 512, 256, 64, 58};

	int d = 0;
	int tx = cx<<2;
	int ty = cy<<2;

	for (int o=0; o<10; o++) {
		int c = 1024<<(12-(10-o));
		int x = cx<<(12-(10-o));
		int y = cy<<(12-(10-o));
		int p = n(x, y);
		int px = n(x-c, y);
		int py = n(x, y-c);
		int pxy = n(x-c, y-c);
		d += imul(ilerp(ty, ilerp(tx, p, px), ilerp(tx, py, pxy)), a[o]);
		d = clamp(d, 4095);
	}

	d <<= 3;
	d += 32767;

	return static_cast<u16>(d);
}

//______________________________________________________________
int TBuilder::CreateCloudMap(int ch, int cx, int cy, int cz, int value, void* ptr)
{
	int a[] = {64, 128, 1024, 1024, 2048, 1024, 512, 256, 64, 58};

	int d = 0;
	int tx = cx<<2;
	int ty = cy<<2;

	for (int o=0; o<10; o++) {
		int c = 1024<<(12-(10-o));
		int x = cx<<(12-(10-o));
		int y = cy<<(12-(10-o));
		int p = n(x, y);
		int px = n(x-c, y);
		int py = n(x, y-c);
		int pxy = n(x-c, y-c);
		d += imul(ilerp(ty, ilerp(tx, p, px), ilerp(tx, py, pxy)), a[o]);
		d = clamp(d, 4095);
	}

	d <<= 3;
	d += 62767;
	d = clamp(d, 30000, 65535);

	return static_cast<u16>(d);
}


//______________________________________________________________
int TBuilder::ProcessBaseMap(int ch, int cx, int cy, int cz, int value, void* ptr)
{
	TBuilder* t = static_cast<TBuilder*>(ptr);
	Index i(cx, cy);
	Data* data_ptr = t->GetData(i);
	data_ptr->height = value * t->base_vertical_resolution + t->base_vertical_bias;
	data_ptr->error = 0.0f;
	data_ptr->radius = 0.0f;
	return static_cast<u16>(value);
}

//______________________________________________________________
int TBuilder::ProcessDetailMap(int ch, int cx, int cy, int cz, int value, void* ptr)
{
	TBuilder* t = static_cast<TBuilder*>(ptr);
	Index i(cx, cy);
	float* detail_ptr = t->GetDetail(i);
	*detail_ptr = (value - 32768.0f) * t->detail_vertical_resolution;
	return static_cast<u16>(value);
}

//______________________________________________________________
int TBuilder::ProcessScaleMap(int ch, int cx, int cy, int cz, int value, void* ptr)
{
	TBuilder* t = static_cast<TBuilder*>(ptr);
	Index i(cx, cy);
	Data* data_ptr = t->GetData(i);
	data_ptr->scale = value / 65535.0f;
	return static_cast<u16>(value);
}

//______________________________________________________________
inline Data* TBuilder::GetData(Index i)
{
	i.clamp(base_size - 1);
	return base + i.y * base_size + i.x;
}

//______________________________________________________________
inline f32* TBuilder::GetDetail(Index i)
{
	i &= (detail_size - 1);
	return detail + i.y * detail_size + i.x;
}

//______________________________________________________________
inline Vertex TBuilder::GetVertex(Index i)
{
	Vertex v;
	i.clamp(base_size - 1);
	Data* d = GetData(i);
	v.position(base_horizontal_resolution * i.x, d->height, base_horizontal_resolution * i.y, 1);
	v.error = d->error;
	v.radius = d->radius;
	return v;
}

//______________________________________________________________
f32 TBuilder::CalculateError(Index i, Index j)
{
	Index l(j.x + i.y - j.y, j.y + j.x - i.x);
	Index r(j.x + j.y - i.y, j.y + i.x - j.x);

	Vertex vj = GetVertex(j);
	Vertex vl = GetVertex(l);
	Vertex vr = GetVertex(r);

	v4f jp(vj.position);
	v4f lp(vl.position);
	v4f rp(vr.position);

	v4f lerp;
	lerp = lp + rp;
	lerp.scale(0.5f);

	return (jp-lerp).length();
}

//______________________________________________________________
void TBuilder::Phase1()
{
	level = 0;
	Index c = base_indices[0];
	for (u32 i=1; i<9; i++) {
		Index j = base_indices[i++];
		Phase1(c, j);
	}

}

//______________________________________________________________
void TBuilder::Phase1(Index i, Index j)
{
	level++;

	f32 err = CalculateError(i, j);
	GetData(j)->error = err;

	if (level < base_levels-1) {
		Phase1(j, Index(i, j, 0, false));
		Phase1(j, Index(i, j, 0, true));
	}

	level--;
}

//______________________________________________________________
void TBuilder::Repair(Index i, Index c)
{
	Vertex vi = GetVertex(i);
	Vertex vc = GetVertex(c);

	f32 d = (vi.position - vc.position).length() + vc.radius;

	Data* di = GetData(i);

	if (d > di->radius) {
		di->radius = d;
	}

	if (vc.error > di->error) {
		di->error = vc.error;
	}
}

//______________________________________________________________
void TBuilder::CheckChildren1(Index i, u32 shift)
{
	Index t(i);
	i <<= shift;

	u32 w = 1 << (shift-1);

	Repair(i, Index(i.x + w, i.y + w));

	if (i.x > 0 && i.y > 0) {
		Repair(i, Index(i.x - w, i.y - w));
	} 
	if (i.x > 0) {
		Repair(i, Index(i.x - w, i.y + w));
	} 
	if (i.y > 0) {
		Repair(i, Index(i.x + w, i.y - w));
	}
}

//______________________________________________________________
void TBuilder::CheckChildren2(Index i, u32 shift)
{
	Index t(i);
	i <<= shift;
	Repair(i, Index((t.x - 1) << shift, t.y << shift));
	Repair(i, Index(t.x << shift, (t.y - 1) << shift));
	Repair(i, Index((t.x + 1) << shift, t.y << shift));
	Repair(i, Index(t.x << shift, (t.y + 1) << shift));
}

//______________________________________________________________
void TBuilder::Phase2()
{
	for (u32 counter_bits=base_bits; counter_bits>0; counter_bits--) {
		u32 shift = base_bits-counter_bits; // 0..map_bits-1
		u32 counter = (1 << (counter_bits-1)); // map_size/2..1
		if (shift > 0) { // only from second level
			for (u32 y=0; y<=counter; y++) {
				for (u32 x=0; x<=counter; x++) {
					CheckChildren1(Index(((x<<1) + 1), (y<<1)), shift);
					CheckChildren1(Index((x<<1), ((y<<1) + 1)), shift);
				}
			}
		}
		for (u32 y=0; y<counter; y++) {
			for (u32 x=0; x<counter; x++) {
				CheckChildren2(Index(((x<<1) + 1), ((y<<1) + 1)), shift);
			}
		}
	}
}

//______________________________________________________________
void TBuilder::BuildEmbeddedQuadtree(Index i, Index j)
{
	if (level == base_levels - 2) {
		return;
	}

	level++;

	Index left(i, j, level & 1, false);
	BuildEmbeddedQuadtree(j, left);
	baseq[left.q] = *GetData(left);

	Index right(i, j, level & 1, true);
	BuildEmbeddedQuadtree(j, right);
	baseq[right.q] = *GetData(right);

	level--;
}

//______________________________________________________________
void TBuilder::BuildEmbeddedQuadtree()
{
	int c4 = (base_size - 1);
	int c2 = c4 >> 1;
	int c1 = c2 >> 1;
	int c3 = c2 + c1;

	Index base_indices[13];

	base_indices[0] = Index(0, 0, c4);
	base_indices[1] = Index(1, c4, c4);
	base_indices[2] = Index(2, c4, 0);
	base_indices[3] = Index(3, 0, 0);
	base_indices[4] = Index(4, c2, c2);
	base_indices[5] = Index(5, c2, 0);
	base_indices[6] = Index(6, c4, c2);
	base_indices[7] = Index(7, c2, c4);
	base_indices[8] = Index(8, 0, c2);
	base_indices[9] = Index(9, c3, c1);
	base_indices[10] = Index(14, c1, c1);
	base_indices[11] = Index(19, c1, c3);
	base_indices[12] = Index(24, c3, c3);

	for (int i=0; i<13; i++) {
		baseq[base_indices[i].q] = *GetData(base_indices[i]);
	}

	level = 1;
	BuildEmbeddedQuadtree(base_indices[8], base_indices[10]);
	BuildEmbeddedQuadtree(base_indices[8], base_indices[11]);
	BuildEmbeddedQuadtree(base_indices[7], base_indices[11]);
	BuildEmbeddedQuadtree(base_indices[7], base_indices[12]);
	BuildEmbeddedQuadtree(base_indices[6], base_indices[12]);
	BuildEmbeddedQuadtree(base_indices[6], base_indices[9]);
	BuildEmbeddedQuadtree(base_indices[5], base_indices[9]);
	BuildEmbeddedQuadtree(base_indices[5], base_indices[10]);
}

//______________________________________________________________

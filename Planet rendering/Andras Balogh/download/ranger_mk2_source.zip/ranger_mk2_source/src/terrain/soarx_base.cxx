//______________________________________________________________
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdlib>
#include <string>
#include "i_framework.h"
#include "generic.h"
#include "soarx.h"
#include "tbuilder.h"
#include "camera.h"

//______________________________________________________________
SOARX::SOARX():
side(true),
bottom(false),
left_only(true),
level(0),
va_index(0),
ia_index(0),
page(0),
m_threshold(2.0f),
m_detail_multiplier(7.0f),
m_max_renderer(3),
m_current_renderer(0),
m_compatibility_level(0)
{
}

//______________________________________________________________
SOARX::~SOARX()
{
	sys->Unsubscribe("Event.WindowResized", Callback(this, OnWindowResized));
	sys->Unsubscribe("Event.RenderContextCreated", Callback(this, OnRenderContextCreated));
	sys->Unsubscribe("Event.RenderContextDestroy", Callback(this, OnRenderContextDestroy));

	::UnmapViewOfFile(detail);
	::CloseHandle(detail_file_map);
	::CloseHandle(detail_file);

	::UnmapViewOfFile(base);
	::CloseHandle(base_file_map);
	::CloseHandle(base_file);

	::UnmapViewOfFile(baseq);
	::CloseHandle(baseq_file_map);
	::CloseHandle(baseq_file);
}

//______________________________________________________________
int SOARX::OnRenderContextCreated()
{
	if (m_compatibility_level == 2) {
		return 0;
	}

	if (m_compatibility_level == 0) {
		opengl->Enable(GL_DEPTH_CLAMP_NV);
	}

	int vertex_buffer_size = 512*1024*4*4;
	int index_buffer_size = 512*1024*4;

	opengl->GenBuffers(2, vertex_buffer);
	opengl->GenBuffers(2, index_buffer);

	opengl->BindBuffer(GL_ARRAY_BUFFER_ARB, vertex_buffer[0]);
	opengl->BufferData(GL_ARRAY_BUFFER_ARB, vertex_buffer_size, 0, GL_STREAM_DRAW_ARB);
	opengl->BindBuffer(GL_ARRAY_BUFFER_ARB, vertex_buffer[1]);
	opengl->BufferData(GL_ARRAY_BUFFER_ARB, vertex_buffer_size, 0, GL_STREAM_DRAW_ARB);

	opengl->BindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, index_buffer[0]);
	opengl->BufferData(GL_ELEMENT_ARRAY_BUFFER_ARB, index_buffer_size, 0, GL_STREAM_DRAW_ARB);
	opengl->BindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, index_buffer[1]);
	opengl->BufferData(GL_ELEMENT_ARRAY_BUFFER_ARB, index_buffer_size, 0, GL_STREAM_DRAW_ARB);

	LoadTextures();
	return 0;
}

//______________________________________________________________
int SOARX::OnRenderContextDestroy()
{
	if (m_compatibility_level == 2) {
		return 0;
	}

	opengl->DeleteBuffers(2, vertex_buffer);
	opengl->DeleteBuffers(2, index_buffer);
	opengl->DeleteTextures(8, m_texture);
	return 0;
}

//______________________________________________________________
int SOARX::OnWindowResized(int width, int height)
{
	if (m_compatibility_level == 2) {
		return 0;
	}

	window_size.x = width;
	window_size.y = height;
	magic = static_cast<float>(window_size.y) / (deg2rad(m_refinement_camera->m_fovy) * m_threshold);
	opengl->BindTexture(GL_TEXTURE_RECTANGLE_NV, m_texture[SCREEN]);
	opengl->TexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGB, window_size.x, window_size.y, 0, GL_RGB, GL_UNSIGNED_BYTE, 0);
	return 0;
}

//______________________________________________________________
int SOARX::Init()
{
	renderer[0] = Render0;
	renderer[1] = Render1;
	renderer[2] = Render2;

	sys->Subscribe("Event.WindowResized", Callback(this, OnWindowResized));
	sys->Subscribe("Event.RenderContextCreated", Callback(this, OnRenderContextCreated));
	sys->Subscribe("Event.RenderContextDestroy", Callback(this, OnRenderContextDestroy));

	window_size.x = static_cast<int>(sys->GetGlobalNumber("Window.width"));
	window_size.y = static_cast<int>(sys->GetGlobalNumber("Window.height"));
	map_bits = static_cast<int>(sys->GetGlobalNumber("Terrain.map_bits"));
	base_bits = static_cast<int>(sys->GetGlobalNumber("Terrain.base_bits"));
	detail_bits = static_cast<int>(sys->GetGlobalNumber("Terrain.detail_bits"));
	base_horizontal_resolution = static_cast<float>(sys->GetGlobalNumber("Terrain.horizontal_resolution"));
	base_vertical_resolution = static_cast<float>(sys->GetGlobalNumber("Terrain.vertical_resolution"));
	base_vertical_bias = static_cast<float>(sys->GetGlobalNumber("Terrain.vertical_bias"));
	m_threshold = 2.0f; //static_cast<float>(sys->GetGlobalNumber("Terrain.error_threshold"));
	embedded_bits = map_bits - base_bits;
	map_size = (1 << map_bits) + 1;
	base_size = (1 << base_bits) + 1;
	detail_size = 1 << detail_bits;
	embedded_size = 1 << embedded_bits;
	detail_horizontal_resolution = base_horizontal_resolution / static_cast<float>(embedded_size);
	detail_vertical_resolution = static_cast<float>(sys->GetGlobalNumber("Terrain.detail_vertical_resolution"));
	detail_vertical_bias = -32768.0f * detail_vertical_resolution;
	map_levels = map_bits << 1;
	detail_levels = detail_bits << 1;
	base_levels = base_bits << 1;

	temp = 1.0f / embedded_size;

	magic = static_cast<float>(window_size.y) / (deg2rad(m_refinement_camera->m_fovy) * m_threshold);
	CalculateRadii(m_detail_multiplier);

	int c4 = (map_size - 1);
	int c2 = c4 >> 1;
	int c1 = c2 >> 1;
	int c3 = c2 + c1;

	base_vertices[0].index = Index(0, 0, c4);
	base_vertices[1].index = Index(1, c4, c4);
	base_vertices[2].index = Index(2, c4, 0);
	base_vertices[3].index = Index(3, 0, 0);
	base_vertices[4].index = Index(4, c2, c2);
	base_vertices[5].index = Index(5, c2, 0);
	base_vertices[6].index = Index(6, c4, c2);
	base_vertices[7].index = Index(7, c2, c4);
	base_vertices[8].index = Index(8, 0, c2);
	base_vertices[9].index = Index(9, c3, c1);
	base_vertices[10].index = Index(14, c1, c1);
	base_vertices[11].index = Index(19, c1, c3);
	base_vertices[12].index = Index(24, c3, c3);

	static char* required_extensions[] = {
		"GL_ARB_vertex_buffer_object",
		"GL_ARB_multitexture",
		"GL_NV_texture_shader",
		"GL_NV_texture_rectangle",
		"GL_NV_depth_clamp"
	};

	// compatibility modes:
	// 0 - full featured
	// 1 - wireframe
	// 2 - nothing!
	static int compatibility_level[] = {
		2,
		1,
		1,
		1,
		1
	};

	for (int i=0; i<5; i++) {
		if (opengl->IsExtensionSupported(required_extensions[i]) == false) {
			sys->Log("%s extension not supported!\n", required_extensions[i]);
			m_compatibility_level = max(m_compatibility_level, compatibility_level[i]);
		}
	}

	if (m_compatibility_level == 1) {
		sys->Log("Running in compatibility mode (wireframe only)!\n");
		m_current_renderer = 2;
	} else if (m_compatibility_level == 2) {
		sys->Log("This system is not capable of running this demo.\n");
		sys->ExecuteString("Quit();");
	}

	return 0;
}

//______________________________________________________________
void SOARX::CalculateRadii(float f)
{
	f32 t = (1.0f/sqrtf(2.0f));
	radii[0] = 1.0f / (1.0f - t) * detail_horizontal_resolution * map_size * 0.5f * f;
	for (u32 i=1; i<64; i++) {
		radii[i] = radii[i-1] * t;
	}

	for (u32 i=0; i<64; i++) {
		radii[i] = radii[i] * radii[i];
	}
}

//______________________________________________________________
int SOARX::Load(const char* path)
{
	if (m_compatibility_level == 2) {
		return -1;
	}

	std::string base_file_path(path);
	std::string baseq_file_path(path);
	std::string detail_file_path(path);

	base_file_path.append("base.t");
	baseq_file_path.append("base.q");
	detail_file_path.append("detail.t");

	base_file = ::CreateFile(base_file_path.c_str(), GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	baseq_file = ::CreateFile(baseq_file_path.c_str(), GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	detail_file = ::CreateFile(detail_file_path.c_str(), GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

#ifdef DATA_LAYOUT_EMBEDDED_QUADTREE
	if (base_file == INVALID_HANDLE_VALUE || baseq_file == INVALID_HANDLE_VALUE || detail_file == INVALID_HANDLE_VALUE) {
#else
	if (base_file == INVALID_HANDLE_VALUE || detail_file == INVALID_HANDLE_VALUE) {
#endif
		tbuilder->Build();
		return -1;
	} else {
		sys->ExecuteString("Console.Toggle(0)");
	}

	base_file_map = ::CreateFileMapping(base_file, 0, PAGE_READONLY, 0, 0, 0);
	baseq_file_map = ::CreateFileMapping(baseq_file, 0, PAGE_READONLY, 0, 0, 0);
	detail_file_map = ::CreateFileMapping(detail_file, 0, PAGE_READONLY, 0, 0, 0);
	
	base = reinterpret_cast<Data*>(::MapViewOfFile(base_file_map, FILE_MAP_READ, 0, 0, 0));
	baseq = reinterpret_cast<Data*>(::MapViewOfFile(baseq_file_map, FILE_MAP_READ, 0, 0, 0));
	detail = reinterpret_cast<f32*>(::MapViewOfFile(detail_file_map, FILE_MAP_READ, 0, 0, 0));

	for (int i=0; i<13; i++) {
#ifdef DATA_LAYOUT_EMBEDDED_QUADTREE
		Data data = baseq[base_vertices[i].index.q];
		base_vertices[i].error = data.error;
		base_vertices[i].radius = data.radius;
		base_vertices[i].position.x = detail_horizontal_resolution * base_vertices[i].index.x;
		base_vertices[i].position.z = detail_horizontal_resolution * base_vertices[i].index.y;
		base_vertices[i].position.y = data.height;
#else
		GetVertex(base_vertices[i]);
#endif
	}

	OnRenderContextCreated();
	return 0;
}


//______________________________________________________________
void SOARX::Render(float time)
{
	if (m_compatibility_level == 2) {
		return;
	}

	m_time = time;

	opengl->MatrixMode(GL_PROJECTION);
	opengl->LoadTransposeMatrixf(m_view_camera->m_projection);
	opengl->MatrixMode(GL_MODELVIEW);
	opengl->LoadTransposeMatrixf(m_view_camera->m_view);

	opengl->BindBuffer(GL_ARRAY_BUFFER_ARB, vertex_buffer[page]);
	opengl->BindBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, index_buffer[page]);

	vertex_array = static_cast<v4f*>(opengl->MapBuffer(GL_ARRAY_BUFFER_ARB, GL_WRITE_ONLY_ARB));
	index_array = static_cast<u32*>(opengl->MapBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB, GL_WRITE_ONLY_ARB));

	if (vertex_array == 0) {
		return;
	}

	if (index_array == 0) {
		return;
	}

	RefineTop();

	if (opengl->UnmapBuffer(GL_ARRAY_BUFFER_ARB) == GL_FALSE) {
		return;
	}
	
	if (opengl->UnmapBuffer(GL_ELEMENT_ARRAY_BUFFER_ARB) == GL_FALSE) {
		return;
	}

	opengl->EnableClientState(GL_VERTEX_ARRAY);
	opengl->VertexPointer(4, GL_FLOAT, 0, 0);
	page = 1-page;

	opengl->ClearColor(0, 0.4f, 0.5f, 0);
	opengl->ClearColor(0.6f, 0.7f, 0.8f, 0);
	opengl->Clear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

	if (m_compatibility_level == 0) {
		(this->*renderer[m_current_renderer])();
	} else if (m_compatibility_level == 1) {
		(this->*renderer[2])();
	}

	static char* render_str[] = {
		"2 pass full quality",
		"1 pass, pseudo coloring",
		"2 pass solid wireframe"
	};

	static float passes[] = {2, 1, 2};

	float fps = sys->GetFPS();
	sys->OverlayWrite(7, "Triangles: %luK (%luK)", ia_index >> 10, va_index >> 10);
	sys->OverlayWrite(8, "Stripping ratio: %.2f", double(ia_index) / double(va_index));
	sys->OverlayWrite(9, "Throughput: %.2fMtris/sec", ia_index*fps*passes[m_current_renderer]*0.000001);
	sys->OverlayWrite(10, "Renderer: %s", render_str[m_current_renderer]);
	sys->OverlayWrite(11, "FPS: %.0f", fps);

//	ViewTexture(m_texture[BUMP]);

}

//______________________________________________________________
void SOARX::ViewTexture(u8 tex)
{
	if (tex == 0) {
		return;
	}

	opengl->MatrixMode(GL_MODELVIEW);
	opengl->PushMatrix();
	opengl->LoadIdentity();
	opengl->MatrixMode(GL_PROJECTION);
	opengl->PushMatrix();
	opengl->LoadIdentity();

	opengl->ActiveTexture(GL_TEXTURE0);
	opengl->Enable(GL_TEXTURE_2D);
	opengl->Disable(GL_DEPTH_TEST);
	opengl->BindTexture(GL_TEXTURE_2D, tex);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_REPLACE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_TEXTURE);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_OPERAND0_RGB, GL_SRC_ALPHA);
	opengl->TexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	opengl->Begin(GL_QUADS);
	opengl->TexCoord4f(0, 0, 0, 1);
	opengl->Vertex4f(-0.9f, -0.9f, 0, 1);
	opengl->TexCoord4f(2.0f, 0, 0, 1);
	opengl->Vertex4f(0.9f, -0.9f, 0, 1);
	opengl->TexCoord4f(2.0f, 2.0f, 0, 1);
	opengl->Vertex4f(0.9f, 0.9f, 0, 1);
	opengl->TexCoord4f(0, 2.0f, 0, 1);
	opengl->Vertex4f(-0.9f, 0.9f, 0, 1);
	opengl->End();

	opengl->PopMatrix();
	opengl->MatrixMode(GL_MODELVIEW);
	opengl->PopMatrix();

	opengl->Disable(GL_TEXTURE_2D);
	opengl->Enable(GL_DEPTH_TEST);
}

//______________________________________________________________
void SOARX::SetCamera(Camera* i_refinement_camera, Camera* i_view_camera)
{
	m_refinement_camera = i_refinement_camera;
	m_view_camera = i_view_camera;
}

//______________________________________________________________
float SOARX::Attach(Camera* c, int attach_mode)
{
#ifdef DATA_LAYOUT_EMBEDDED_QUADTREE
	return 0;
#else

	if (m_compatibility_level == 2) {
		return 0;
	}

	float x = c->m_position.x;
	float z = c->m_position.z;

	x /= detail_horizontal_resolution;
	z /= detail_horizontal_resolution;
	float xq = floorf(x);
	float zq = floorf(z);
	x -= xq;
	z -= zq;

	Index i0(u32(xq+0), u32(zq+0));
	Index i1(u32(xq+1), u32(zq+0));
	Index i2(u32(xq+0), u32(zq+1));
	Index i3(u32(xq+1), u32(zq+1));

	i0.clamp(map_size);
	i1.clamp(map_size);
	i2.clamp(map_size);
	i3.clamp(map_size);

	Vertex v0(i0);
	Vertex v1(i1);
	Vertex v2(i2);
	Vertex v3(i3);

	GetVertex(v0);
	GetVertex(v1);
	GetVertex(v2);
	GetVertex(v3);

	f32 height = lerp(z, lerp(x, v0.position.y, v1.position.y), lerp(x, v2.position.y, v3.position.y)) + 1.8f;

	if (attach_mode == 0) { // fly
		c->m_position.y = max(c->m_position.y, height);
	} else if (attach_mode == 1) { // walk
		c->m_position.y = height;
	}

	return c->m_position.y - height + 1.8f;

#endif

}

//______________________________________________________________
int SOARX::CycleRendrer()
{
	if (m_compatibility_level != 0) {
		return 0;
	}

	m_current_renderer++;

	if (m_current_renderer == m_max_renderer) {
		m_current_renderer = 0;
	}

	return 0;
}

//______________________________________________________________
int SOARX::SetRendrer(int i_renderer)
{
	if (i_renderer >=0 && i_renderer < m_max_renderer) {
		m_current_renderer = i_renderer;
	}
	
	return 0;
}

//______________________________________________________________
float SOARX::SetThreshold(float i_threshold)
{
	m_threshold = i_threshold;
	m_threshold = clamp(m_threshold, 1.0f, 10.0f);
	magic = static_cast<float>(window_size.y) / (deg2rad(m_refinement_camera->m_fovy) * m_threshold);
	sys->OverlayNote("Terrain error threshold set to %3.1f.\n", m_threshold);
	return m_threshold;
}

//______________________________________________________________
float SOARX::SetDetailMultiplier(float i_detail_multiplier)
{
	m_detail_multiplier = i_detail_multiplier;
	m_detail_multiplier = clamp(m_detail_multiplier, 1.0f, 20.0f);
	CalculateRadii(m_detail_multiplier);
	sys->OverlayNote("Terrain detail multiplier set to %3.1f.\n", m_detail_multiplier);
	return m_detail_multiplier;
}

//______________________________________________________________

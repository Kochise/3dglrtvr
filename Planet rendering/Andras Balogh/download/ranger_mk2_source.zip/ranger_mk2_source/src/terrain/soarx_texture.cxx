//______________________________________________________________
#include <string>
#include "soarx.h"

//______________________________________________________________
void CreateNormalTexture(GLubyte* t)
{
	const float grad_scale_inv = 1.0f / 128.0f;

	v4f lights[] = {
		v4f(1.0f, 1.5f, 1.0f, 0.0f),
		v4f(-1.0f, 1.0f, -1.0f, 0.0f),
	};

	v4f colors[] = {
		v4f(1.0f, 1.0f, 1.0f, 1.0f),
		v4f(1.0f, 1.0f, 1.0f, 1.8f),
	};

	const int n = 2;

	for (int i=0; i<n; i++) {
		lights[i].normalize();
		colors[i].hdiv();
	}

//	float grad_scale_inv = 2.0f/128.0f;
	for (int dy=-128; dy<128; dy++) {
		for (int dx=-128; dx<128; dx++) {
			v4f normal(-dx*grad_scale_inv, 1, -dy*grad_scale_inv, 0);
			normal.normalize();
			v4f color(0, 0, 0, 0); // ambient color
			for (int i=0; i<n; i++) {
				f32 angle = normal.dprod(lights[i]);
				color.max(colors[i] * max(0.0f, angle));
			}

			color *= 255.0f;
			color.clamp(0, 255.0f);
			*t++ = static_cast<u8>(color.x);
			*t++ = static_cast<u8>(color.y);
			*t++ = static_cast<u8>(color.z);
		}
	}
}

//______________________________________________________________
void SOARX::LoadTextures()
{
	if (m_compatibility_level != 0) {
		return;
	}

	static std::string image_extension(".png");
	static std::string terrain_name;
	static std::string terrain_base_color;
	static std::string terrain_base_gradient;
	static std::string terrain_detail_gradient;
	static std::string terrain_detail_scale;
	static std::string terrain_bump_gradient;
	static std::string terrain_cloud_color;

	terrain_name.assign("maps/");
	terrain_name.append(sys->GetGlobalString("Terrain.name"));
	terrain_name.append("/");
	terrain_base_color.assign(terrain_name);
	terrain_base_color.append("base.color");
	terrain_base_color.append(image_extension);
	terrain_base_gradient.assign(terrain_name);
	terrain_base_gradient.append("base.gradient");
	terrain_base_gradient.append(image_extension);
	terrain_detail_gradient.assign(terrain_name);
	terrain_detail_gradient.append("detail.gradient");
	terrain_detail_gradient.append(image_extension);
	terrain_detail_scale.assign(terrain_name);
	terrain_detail_scale.append("detail.scale");
	terrain_detail_scale.append(image_extension);
	terrain_bump_gradient.assign(terrain_name);
	terrain_bump_gradient.append("bump.gradient");
	terrain_bump_gradient.append(image_extension);
	terrain_cloud_color.assign(terrain_name);
	terrain_cloud_color.append("cloud.color");
	terrain_cloud_color.append(image_extension);

	opengl->GenTextures(8, m_texture);
	opengl->ActiveTexture(GL_TEXTURE0);

	opengl->BindTexture(GL_TEXTURE_2D, m_texture[BASE]);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	opengl->TexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 1.0f);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	opengl->LoadTexture(terrain_base_gradient.c_str());

	opengl->BindTexture(GL_TEXTURE_2D, m_texture[DETAIL]);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	opengl->TexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 1.0f);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	opengl->LoadTexture(terrain_detail_gradient.c_str());

	opengl->BindTexture(GL_TEXTURE_2D, m_texture[BUMP]);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	opengl->TexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 1.0f);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	opengl->LoadTexture(terrain_bump_gradient.c_str());

	opengl->BindTexture(GL_TEXTURE_2D, m_texture[SCALE]);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	opengl->TexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 1.0f);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	opengl->LoadTexture(terrain_detail_scale.c_str());

	// Create screen texture:
	opengl->BindTexture(GL_TEXTURE_RECTANGLE_NV, m_texture[SCREEN]);
	opengl->TexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_RGB, window_size.x, window_size.y, 0, GL_RGB, GL_UNSIGNED_BYTE, 0);

	// Load cloud texture:
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[CLOUD]);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	opengl->TexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 1.0f);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	opengl->LoadTexture(terrain_cloud_color.c_str());

	// Load color texture:
	opengl->BindTexture(GL_TEXTURE_2D, m_texture[COLOR]);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP, GL_TRUE);
	opengl->TexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 1.0f);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	opengl->LoadTexture(terrain_base_color.c_str());


	// Create normal texture:

	v4b color[] = {
		v4b(255, 255, 255, 0),
		v4b(235, 120, 0, 0),
		v4b(100, 225, 0, 0),
		v4b(100, 100, 100, 0),
		v4b(0, 0, 150, 0)
	};

	std::string str;
	int tx;
	int ty;
	GLubyte *text;
	GLubyte* t;
	float sc = 64.0f;

	tx = 256;
	ty = 256;
	float sci = 1.0f / sc;
	sci = 1.0f / 256.0f;
	t = text = new GLubyte[tx*ty*3];

	str.assign(sys->GetGlobalString("Terrain.irradiance")); 

	if (str == "simple") {
		CreateNormalTexture(text);
	} else {
		for (int j=0; j<ty; j++) {
			for (int i=0; i<tx; i++) {
				f32 x = i * sci;
				f32 z = j * sci;
				f32 xz = x*z;
				v4f c(1-x-z+xz, x-xz, z-xz, xz);

				v4f red(255.0f, 255.0f, 0.0f, 0.0f);
				v4f green(255.0f, 100.0f, 225.0f, 0.0f);
				v4f blue(255.0f, 0.0f, 0.0f, 150.0f);

				*t++ = static_cast<u8>(c.dprod(red));
				*t++ = static_cast<u8>(c.dprod(green));
				*t++ = static_cast<u8>(c.dprod(blue));
			}
		}
	}

	opengl->BindTexture(GL_TEXTURE_2D, m_texture[NORMAL]);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	opengl->TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	opengl->TexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tx, ty, 0, GL_RGB, GL_UNSIGNED_BYTE, text);
//	opengl->TexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, tx, ty, 0, GL_ALPHA, GL_UNSIGNED_BYTE, text);
//	opengl->TexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 2, 2, 0, GL_RGBA, GL_UNSIGNED_BYTE, color);
//	opengl->LoadTexture("normal.png");
	delete text;

	sys->Log("Textures loaded.\n");
}

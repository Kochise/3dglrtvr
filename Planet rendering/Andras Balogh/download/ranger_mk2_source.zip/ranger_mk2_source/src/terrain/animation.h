//______________________________________________________________
#pragma once
#include "generic.h"
#include <vector>

//______________________________________________________________
class Camera;
class Keyframe;
class Animation;

//______________________________________________________________
class Keyframe
{
public:
	f32 x;
	f32 y;
	f32 z;
	f32 heading;
	f32 pitch;
};

//______________________________________________________________
class Animation
{
private:
	std::vector<Keyframe> m_keyframes;
	f64 m_time;
	f64 m_time_resolution;
	u32 m_total_frames;
public:
	Animation(f64 time_resolution);
	~Animation();
	int Record(f64 delta_time, Camera* camera);
	int Record(Camera* camera);
	int DeleteLastFrame();
	int JumpToLastFrame(Camera* camera);
	int Playback(f64 delta_time, Camera* camera);
	int Save(const char* path);
	int Save();
	int Load(const char* path);
	int Prepare(f64 i_time_resolution);
	int Rewind();
};


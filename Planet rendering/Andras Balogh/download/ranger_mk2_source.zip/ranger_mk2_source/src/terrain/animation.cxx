//______________________________________________________________
#include "i_framework.h"
#include "animation.h"
#include "camera.h"
#include "terrain.h"

//______________________________________________________________
Animation::Animation(f64 time_resolution) :
m_time(0),
m_time_resolution(time_resolution),
m_total_frames(0)
{
}

//______________________________________________________________
Animation::~Animation()
{
}

//______________________________________________________________
int Animation::Record(f64 delta_time, Camera* camera)
{
	m_time += delta_time;
	while (m_time > m_time_resolution) {
		m_time -= m_time_resolution;
		Keyframe kf;
		kf.x = camera->m_position.x;
		kf.y = camera->m_position.y;
		kf.z = camera->m_position.z;
		kf.heading = camera->m_heading;
		kf.pitch = camera->m_pitch;
		m_keyframes.push_back(kf);
		sys->Log("Keyframe %d recorded.\n", m_total_frames);
		m_total_frames++;
	}
	return 0;
}

//______________________________________________________________
int Animation::Record(Camera* camera)
{
	Keyframe kf;
	kf.x = camera->m_position.x;
	kf.y = camera->m_position.y;
	kf.z = camera->m_position.z;
	kf.heading = camera->m_heading;
	kf.pitch = camera->m_pitch;
	m_keyframes.push_back(kf);
	sys->Log("Keyframe %d recorded.\n", m_total_frames);
	m_total_frames++;
	return 0;
}

//______________________________________________________________
int Animation::DeleteLastFrame()
{
	m_keyframes.pop_back();
	m_total_frames--;
	sys->Log("Keyframe %d removed.\n", m_total_frames);
	return 0;
}


//______________________________________________________________
int Animation::JumpToLastFrame(Camera* camera)
{
	if (m_keyframes.empty()) {
		return 0;
	}

	Keyframe kf = m_keyframes.back();
	camera->m_position.x = kf.x;
	camera->m_position.y = kf.y;
	camera->m_position.z = kf.z;
	camera->m_heading = kf.heading;
	camera->m_pitch = kf.pitch;
	return 0;
}

//______________________________________________________________
int Animation::Playback(f64 delta_time, Camera* camera)
{
	if (m_total_frames < 5) {
		return 0;
	}

	static m4f Hermite = {
		+2.0f, -3.0f, +0.0f, +1.0f,
		-2.0f, +3.0f, +0.0f, +0.0f,
		+1.0f, -2.0f, +1.0f, +0.0f,
		+1.0f, -1.0f, +0.0f, +0.0f
	};

	static v4f last_position;

	m_time += delta_time;

	int current_frame = static_cast<int>(floor(m_time / m_time_resolution));

	f32 t = static_cast<f32>((m_time - m_time_resolution * current_frame) / m_time_resolution);
	f32 t2 = t*t;
	f32 t3 = t2*t;

	current_frame %= m_total_frames;
	int next_frame = (current_frame + 1) % m_total_frames;
	int next2_frame = (current_frame + 2) % m_total_frames;
	int previous_frame = (current_frame == 0) ? (m_total_frames - 1) : (current_frame - 1);

	Keyframe cur = m_keyframes[current_frame];
	Keyframe nxt = m_keyframes[next_frame];
	Keyframe nxt2 = m_keyframes[next2_frame];
	Keyframe prv = m_keyframes[previous_frame];

	v4f vt(t3, t2, t, 1);
	v4f xc(cur.x, nxt.x, 0.5f*(nxt.x - prv.x), 0.5f*(nxt2.x - cur.x));
	v4f yc(cur.y, nxt.y, 0.5f*(nxt.y - prv.y), 0.5f*(nxt2.y - cur.y));
	v4f zc(cur.z, nxt.z, 0.5f*(nxt.z - prv.z), 0.5f*(nxt2.z - cur.z));
	v4f hc(cur.heading, nxt.heading, 0.5f*(nxt.heading - prv.heading), 0.5f*(nxt2.heading - cur.heading));
	v4f pc(cur.pitch, nxt.pitch, 0.5f*(nxt.pitch - prv.pitch), 0.5f*(nxt2.pitch - cur.pitch));

	Hermite.multiply(vt);

	camera->m_position.x = vt.dprod(xc);
	camera->m_position.y = vt.dprod(yc);
	camera->m_position.z = vt.dprod(zc);
	camera->m_heading = vt.dprod(hc);
	camera->m_pitch = vt.dprod(pc);

	camera->m_orientation.qidentity();
	camera->turn(camera->m_heading, camera->m_pitch, 0);

	v4f velocity = camera->m_position - last_position;
	f32 speed = static_cast<f32>(velocity.length() * 3.6f / delta_time);
	last_position = camera->m_position;

	sys->OverlayWrite(6, "Speed: %3.1fKm/h", speed);

	return 0;
}

//______________________________________________________________
int Animation::Save()
{
	static int file_number = 0;
	char filename[25];
	FILE* f = 0;

	for(;;) {
		sprintf(filename, "demos/fly%5.5d.demo", file_number);
		f = fopen(filename, "rb");
		if (f == 0) {
			break;
		}
		fclose(f);
		file_number++;
	}

	Save(filename);
	return 0;
}

//______________________________________________________________
int Animation::Save(const char* path)
{
	FILE* f = ::fopen(path, "wb");
	if (f == 0) {
		return -1;
	}

	::fwrite(&m_total_frames, sizeof(m_total_frames), 1, f);
	::fwrite(&m_time_resolution, sizeof(m_time_resolution), 1, f);

	for (u32 i=0; i<m_total_frames; i++) {
		::fwrite(&m_keyframes[i], sizeof(Keyframe), 1, f);
	}

	::fflush(f);
	::fclose(f);

	sys->Log("Animation %s saved (%d frames, %4.1f secs).\n", path, m_total_frames, m_total_frames * m_time_resolution);

	return 0;
}

//______________________________________________________________
int Animation::Load(const char* path)
{
	FILE* f = ::fopen(path, "rb");
	if (f == 0) {
		return -1;
	}

	m_time = 0;
	m_keyframes.clear();

	::fread(&m_total_frames, sizeof(m_total_frames), 1, f);
	::fread(&m_time_resolution, sizeof(m_time_resolution), 1, f);

	while (!feof(f)) {
		Keyframe kf;
		if (::fread(&kf, sizeof(Keyframe), 1, f) == 1) {
			m_keyframes.push_back(kf);
		}
	}
	
	::fclose(f);

	sys->Log("Animation %s loaded (%d frames, %4.1f secs).\n", path, m_total_frames, m_total_frames * m_time_resolution);

	return 0;
}

//______________________________________________________________
int Animation::Prepare(f64 i_time_resolution)
{
	m_time = 0;
	m_total_frames = 0;
	m_time_resolution = i_time_resolution;
	m_keyframes.clear();
	sys->Log("New animation prepared.\n");
	return 0;
}

//______________________________________________________________
int Animation::Rewind()
{
	m_time = 0;
	sys->Log("Animation rewind.\n");
	return 0;
}

//______________________________________________________________

#include "framework.h"
#include "kernel.h"
#include "opengl.h"

//______________________________________________________________
class Font3D :
public IFont3D
{
private:
	GLuint					dl;
public:
	Font3D();
	~Font3D();
	int Create(const char* face);
	int Create(LOGFONT lf);
	int Print(const char* string);
};

//______________________________________________________________
void* Factory_Font3D(ISystem* i_sys)
{
	return new Font3D();
}

IFont3D::~IFont3D() {}

//______________________________________________________________
Font3D::Font3D() :
dl(0)
{
}

//______________________________________________________________
Font3D::~Font3D()
{
	if (::glIsList(dl) == GL_TRUE) {
		::glDeleteLists(dl, 256);
	}
}

//______________________________________________________________
int Font3D::Create(const char* face)
{
	LOGFONT lf;
	
	lf.lfHeight			= 0;
	lf.lfWidth			= 0;
	lf.lfEscapement		= 0;
	lf.lfOrientation	= 0;
	lf.lfWeight			= 0;
	lf.lfItalic			= 0;
	lf.lfUnderline		= 0;
	lf.lfStrikeOut		= 0;
	lf.lfCharSet		= DEFAULT_CHARSET;
	lf.lfOutPrecision	= OUT_OUTLINE_PRECIS;
	lf.lfClipPrecision	= CLIP_DEFAULT_PRECIS;
	lf.lfQuality		= DEFAULT_QUALITY;
	lf.lfPitchAndFamily	= DEFAULT_PITCH | FF_DONTCARE;
	strcpy(lf.lfFaceName, face);

	Create(lf);
	return 0;
}

//______________________________________________________________
int Font3D::Create(LOGFONT lf)
{
	HDC DC = framework.kernel->GetDC();
	HFONT new_font = ::CreateFontIndirect(&lf);
	HFONT old_font = static_cast<HFONT>(::SelectObject(DC, new_font));

	if (::glIsList(dl) == GL_TRUE) {
		::glDeleteLists(dl, 256);
	}

	dl = ::glGenLists(256);

	if (::glIsList(dl) == GL_TRUE) {
		::wglUseFontOutlines(DC, 0, 256, dl, 0, 0.1f, WGL_FONT_POLYGONS, 0);
	}

	::SelectObject(DC, old_font);
	::DeleteObject(new_font);
	return 0;
}

//______________________________________________________________
int Font3D::Print(const char* string)
{
	if (::glIsList(dl) == GL_TRUE) {
		::glMatrixMode(GL_MODELVIEW);
		::glPushMatrix();
		::glListBase(dl);
		::glCallLists(int(strlen(string)), GL_UNSIGNED_BYTE, string);
		::glPopMatrix();
	}
	return 0;
}

//______________________________________________________________

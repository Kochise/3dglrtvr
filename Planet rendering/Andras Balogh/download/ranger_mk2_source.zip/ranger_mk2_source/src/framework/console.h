#pragma once
#include <deque>
#include "generic.h"

class Console
{
private:
	const int max_lines;
	const int max_history;

	IFont2D* font;
	std::deque<std::string> text;
	std::deque<std::string> cmd_line;
	int history;
	Vector<int> size;
	int font_size;
	bool active;
	int scrolling;
	int lines;
	double current_time;
	double toggle_time;
	double start_time;
	double target_time;
	int start_row;
	int current_row;
	int target_row;

private:
	int Update();
	int ScrollCmdLine(int rows);
	int Scroll(int rows, double time);
	int Zoom(int delta);

public:
	Console();
	~Console();
	int Init();
	int Toggle(int i_active);		// Toggle console On/Off explicitly
	int CommandKey(int type, int key, double time);		// Returns true if key is processed
	int Write(const char* s);			// Write string to console
	int WriteLn(const char* s);			// Write string to console
	int Render();					// Render console
	int SelectFont(const char* typeface);
};



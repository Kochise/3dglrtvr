//______________________________________________________________
#include "framework.h"
#include "system.h"
#include "generic.h"
#include "kernel.h"
#include "opengl.h"

//______________________________________________________________
class Glyph;
class Font2D;

//______________________________________________________________
class Glyph
{
public:
	bool has_image;
	Vector<float> geometry;
	Vector<float> texture;
	Vector<float> next_cell;

	int Reset();
	int Render(Vector<float>& offset) const;
};

//______________________________________________________________
int Glyph::Reset()
{
	has_image = false;
	geometry(0);
	texture(0);
	next_cell(0);
	return 0;
}

//______________________________________________________________
int Glyph::Render(Vector<float>& offset) const
{
	if (has_image) {
		Vector<float> position(offset);
		position.translate(geometry);
		position.y += 0.2f;

		::glTexCoord2f(texture.x, texture.y);
		::glVertex2fv(position);

		position.y -= geometry.w;

		::glTexCoord2f(texture.x, texture.y + texture.w);
		::glVertex2fv(position);

		position.x += geometry.z;

		::glTexCoord2f(texture.x + texture.z, texture.y + texture.w);
		::glVertex2fv(position);

		position.y += geometry.w;

		::glTexCoord2f(texture.x + texture.z, texture.y);
		::glVertex2fv(position);
	}

	offset.translate(next_cell);
	return 0;
}

//______________________________________________________________
class Font2D :
public IFont2D
{
private:
	bool reload;
	LOGFONT lf;
	Glyph glyphs[256];
	GLuint tx;
	Vector<unsigned int> tx_size;
	float m_linefeed;
	v4f m_color;
public:
	Font2D();
	~Font2D();
	int Create(const char* face, int font_height = 24, int texture_width = 256, int texture_height = 256);
	int Create();
	int SetLineFeed(float i_linefeed);
	int SetColor(float r, float g, float b, float a);
	int Print(const char* format, ... );
	int PrintX(const char* s);
	int Test() const;
	int OnRenderContextCreated();
	int OnRenderContextDestroy();
};

//______________________________________________________________
void* Factory_Font2D(ISystem* i_sys)
{
	return new Font2D();
}

IFont2D::~IFont2D() {}

//______________________________________________________________
Font2D::Font2D() :
reload(false),
tx(0),
m_linefeed(-1),
m_color(1, 1, 1, 1)
{
	framework.system->Subscribe("Event.RenderContextCreated", Callback(this, OnRenderContextCreated));
	framework.system->Subscribe("Event.RenderContextDestroy", Callback(this, OnRenderContextDestroy));
}

//______________________________________________________________
Font2D::~Font2D()
{
	if (::glIsTexture(tx) == GL_TRUE) {
		::glDeleteTextures(1, &tx);
	}
}

//______________________________________________________________
int Font2D::Create(const char* face, int font_height, int texture_width, int texture_height)
{
	lf.lfHeight			= font_height;
	lf.lfWidth			= 0;
	lf.lfEscapement		= 0;
	lf.lfOrientation	= 0;
	lf.lfWeight			= 0;
	lf.lfItalic			= 0;
	lf.lfUnderline		= 0;
	lf.lfStrikeOut		= 0;
	lf.lfCharSet		= DEFAULT_CHARSET;
	lf.lfOutPrecision	= OUT_OUTLINE_PRECIS;
	lf.lfClipPrecision	= CLIP_DEFAULT_PRECIS;
	lf.lfQuality		= ANTIALIASED_QUALITY;
	lf.lfPitchAndFamily	= DEFAULT_PITCH | FF_DONTCARE;
	strcpy(lf.lfFaceName, face);
	tx_size(texture_width, texture_height);

	reload = true;
	return 0;
}

//______________________________________________________________
int Font2D::Create()
{
	HDC DC = framework.kernel->GetDC();
	HFONT new_font = ::CreateFontIndirect(&lf);
	HFONT old_font = static_cast<HFONT>(::SelectObject(DC, new_font));

	::glPixelTransferf(GL_RED_SCALE, 4.0f);
	if (::glIsTexture(tx) == GL_TRUE) {
		::glDeleteTextures(1, &tx);
	}

	int buffer_size(tx_size.x*tx_size.y);
	char* buffer(new char[buffer_size]);
	Vector<unsigned int> tx_position(0, 0);
	unsigned int max_height(0);
	::ZeroMemory(buffer, buffer_size);

	::glGenTextures(1, &tx);
	::glBindTexture(GL_TEXTURE_2D, tx);
	::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	::glTexImage2D(GL_TEXTURE_2D, 0, GL_INTENSITY, tx_size.x, tx_size.y, 0, GL_RED, GL_UNSIGNED_BYTE, buffer);

	GLYPHMETRICS gm;

	MAT2 mat;
	mat.eM11.value = 1;
	mat.eM11.fract = 0;
	mat.eM12.value = 0;
	mat.eM12.fract = 0;
	mat.eM21.value = 0;
	mat.eM21.fract = 0;
	mat.eM22.value = 1;
	mat.eM22.fract = 0;

	for (int c=0; c<256; c++) {
		Glyph& g = glyphs[c];
		g.Reset();

		if (c < 32) continue;

		if (::GetGlyphOutline(DC, c, GGO_METRICS, &gm, 0, 0, &mat) == GDI_ERROR) continue;

		g.geometry((float)gm.gmptGlyphOrigin.x, (float)gm.gmptGlyphOrigin.y, (float)gm.gmBlackBoxX, (float)gm.gmBlackBoxY);
		g.geometry.scale(1.0f/lf.lfHeight);
		g.next_cell((float)gm.gmCellIncX, (float)gm.gmCellIncY);
		g.next_cell.scale(1.0f/lf.lfHeight);

		if (::GetGlyphOutline(DC, c, GGO_GRAY8_BITMAP, &gm, buffer_size, buffer, &mat) == GDI_ERROR) continue;

		max_height = max(max_height, gm.gmBlackBoxY);
		if (tx_position.x + gm.gmBlackBoxX >= tx_size.x) {	// start new row
			tx_position.y += max_height + 1;
			tx_position.x = 0;
			max_height = gm.gmBlackBoxY;
		}

		if (tx_position.y + gm.gmBlackBoxY >= tx_size.y) continue;

		::glTexSubImage2D(GL_TEXTURE_2D, 0, tx_position.x, tx_position.y, gm.gmBlackBoxX, gm.gmBlackBoxY, GL_RED, GL_UNSIGNED_BYTE, buffer);

		g.has_image = true;
		g.texture(
			(float) tx_position.x / tx_size.x, 
			(float) tx_position.y / tx_size.y,
			(float) gm.gmBlackBoxX / tx_size.x,
			(float) gm.gmBlackBoxY / tx_size.y
		);

		tx_position.x += gm.gmBlackBoxX + 1;
	}

	::glPixelTransferf(GL_RED_SCALE, 1.0f);

	release(buffer);

	::SelectObject(DC, old_font);
	::DeleteObject(new_font);

	reload = false;
	return 0;
}


//______________________________________________________________
int Font2D::SetLineFeed(float i_linefeed)
{
	m_linefeed = i_linefeed;
	return 0;
}

//______________________________________________________________
int Font2D::SetColor(float r, float g, float b, float a)
{
	m_color(r, g, b, a);
	return 0;
}

//______________________________________________________________
int Font2D::Print(const char* format, ... )
{
	va_list	args;
	va_start(args, format);
	char buffer[1024];
	vsprintf(buffer, format, args);
	PrintX(buffer);
	va_end(args);
	return 0;
}

//______________________________________________________________
int Font2D::PrintX(const char* text)
{
	Vector<float> offset(0, 0);

	if (reload) {
		Create();
	}

	::glBindTexture(GL_TEXTURE_2D, tx);

	::glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, m_color);
	::glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
	::glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	::glEnable(GL_TEXTURE_2D);
	::glEnable(GL_BLEND);
	::glDisable(GL_DEPTH_TEST);
	::glDisable(GL_LIGHTING);

	::glBegin(GL_QUADS);

	while (int c = *text++) {
		if (c < 0) c += 256;
		if (c == '\n') {
			offset.x = 0;
			offset.y += m_linefeed;
		} else if (c == '\t') {
			float space = glyphs[' '].next_cell.x;
			offset.x = space * 8 * ((static_cast<int>(floorf(offset.x / space)) / 8) + 1);
		}
		
		glyphs[c].Render(offset);
	}

	::glEnd();
	::glDisable(GL_BLEND);
	::glDisable(GL_TEXTURE_2D);
	return 0;
}

//______________________________________________________________
int Font2D::Test() const
{
	::glShadeModel(GL_SMOOTH);
	::glDisable(GL_BLEND);
	::glDisable(GL_LIGHTING);

	::glBindTexture(GL_TEXTURE_2D, tx);
	::glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	::glEnable(GL_TEXTURE_2D);

	::glMatrixMode(GL_MODELVIEW);
	::glPushMatrix();
	::glLoadIdentity();

	::glMatrixMode(GL_PROJECTION);
	::glPushMatrix();
	::glLoadIdentity();

	::glMatrixMode(GL_TEXTURE);
	::glPushMatrix();
	::glLoadIdentity();

	::glColor3ub(255, 255, 255);

	::glBegin(GL_QUADS);

	::glTexCoord2d(0, 0);
	::glVertex2d(-0.9, .9);

	::glTexCoord2d(0, 1);
	::glVertex2d(-0.9, -0.9);

	::glTexCoord2d(1, 1);
	::glVertex2d(.9, -0.9);

	::glTexCoord2d(1, 0);
	::glVertex2d(.9, .9);

	::glEnd();
	::glDisable(GL_TEXTURE_2D);

	::glPopMatrix();

	::glMatrixMode(GL_PROJECTION);
	::glPopMatrix();

	::glMatrixMode(GL_MODELVIEW);
	::glPopMatrix();

	return 0;
}

//______________________________________________________________
int Font2D::OnRenderContextCreated()
{
	reload = true;
	return 0;
}

//______________________________________________________________
int Font2D::OnRenderContextDestroy()
{
	::glDeleteTextures(1, &tx);
	tx = 0;
	return 0;
}

//______________________________________________________________

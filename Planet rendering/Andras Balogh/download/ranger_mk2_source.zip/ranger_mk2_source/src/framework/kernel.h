#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cassert>
#include <list>
#include "generic.h"
#include "i_framework.h"

class Kernel
{
private:

	class Button
	{
	public:
		int m_type;
		int m_code;
		double m_time;
		Button(int i_type, int i_code, double i_time = 0) : m_type(i_type), m_code(i_code), m_time(i_time) {}
		bool operator == (const Button& b) const { return (m_type == b.m_type && m_code == b.m_code);}
	};

	typedef LARGE_INTEGER large;
	typedef LRESULT (callback) (MSG msg);

	int m_event_simulate;
	int m_event_update;
	int m_event_render;
	int m_event_framework_button;
	int m_event_application_button;
	int m_event_window_resized;
	int m_event_desktop_resized;

	large m_counter_frequency;
	large m_counter_old;
	large m_counter_new;
	double m_time_resolution;
	double m_time_multiplier;
	double m_absolute_time;
	double m_delta_time;
	double m_virtual_absolute_time;
	double m_virtual_delta_time;
	double m_time_accumulator;
	double m_frame_accumulator;
	double m_fps;
	bool m_paused;

	std::list<Button> m_buttons;
	Vector<double> m_mouse_sensitivity;
	Vector<int> m_mouse_position;
	Vector<double> m_mouse_movement;
	Vector<int> m_screen_size;
	Vector<int> m_screen_center;
	Vector<int> m_window_size;
	HWND m_window_handler;
	HDC m_window_DC;
	bool m_window_fullscreen;
	bool m_window_active;
	bool m_window_minimized;
	int m_quit;

public:
	Kernel();
	~Kernel();

	int Init();
	int Run();
	int Quit();

	int SystemInfo();
	int SetTime(double time);
	int SetTimeResolution(double resolution);
	int SetTimeMultiplier(double multiplier);
	double GetTime();
	double GetFPS();
	int Pause();
	int OnButton(int key_type, int key_code, double key_time);
	int SetMouseSensitivity(double x, double y);
	int GetMouseMovement(double& x, double& y);
	int SetDisplayMode(int width, int height);
	int CreateWnd(int width, int height, int alpha, int depth, int stencil);
	int DestroyWnd();
	int SetWindowSize(int width, int height);
	Vector<int> GetWindowSize();
	HDC GetDC();
	int Update();

private:
	callback OnCreate;
	callback OnDestroy;
	callback OnClose;
	callback OnActivate;
	callback OnSize;
	callback OnSysCommand;
	callback OnKeyboardEvent;
	callback OnMouseEvent;
	static LRESULT CALLBACK Dispatcher(HWND	hWnd, UINT uMsg, WPARAM wParam,	LPARAM lParam);
};

//______________________________________________________________
#include "framework.h"
#include "console.h"
#include "kernel.h"
#include "opengl.h"
#include "system.h"

//______________________________________________________________
Console::Console() :
max_lines(1024),
max_history(32),
active(true),
font_size(24),
font(0),
scrolling(0),
lines(0),
text(max_lines),
cmd_line(max_history),
history(0),
toggle_time(-1),
start_time(0),
target_time(0),
start_row(0),
current_row(0),
target_row(0)
{
}

//______________________________________________________________
Console::~Console()
{
	delete font;
}

//______________________________________________________________
int Console::Init()
{
	font = static_cast<IFont2D*>(framework.system->GetInterface("Font2D"));
	font->Create("Verdana");

	framework.system->Subscribe("Console.Toggle", Callback(this, Toggle));
	framework.system->Subscribe("Console.Write", Callback(this, Write));
	framework.system->Subscribe("Event._OnButton", Callback(this, CommandKey));
	framework.system->Subscribe("Console.SelectFont", Callback(this, SelectFont));

	return 0;
}

//______________________________________________________________
int Console::Toggle(int i_active)
{
	if (i_active == 0) {
		active = false;
	} else if (i_active == 1) {
		active = true;
	} else {
		active = !active;
	}

	Update();

	if (current_time - toggle_time < 1.0) {
		toggle_time = 2*current_time - toggle_time - 1;
	} else {
		toggle_time = current_time;
	}

	return 0;
}

//______________________________________________________________
int Console::Update()
{
	current_time = framework.kernel->GetTime();
	size = framework.kernel->GetWindowSize();
	size.x /= font_size;
	size.y /= font_size;

	return 0;
}

//______________________________________________________________
int Console::ScrollCmdLine(int rows)
{
	history = clamp(history+rows, 0, max_history);
	if (history) {
		cmd_line[0].assign(cmd_line[history]);
	} else {
		cmd_line[0].clear();
	}

	return 0;
}

//______________________________________________________________
int Console::Scroll(int rows, double time)
{
	assert(time > 0);

	if (!rows) {
		return 0;
	}

	if (!scrolling) {
		start_row	= current_row;
		target_row	= current_row + rows;

		if (target_row > max_lines-(size.y-1)) {
			target_row = max_lines-(size.y-1);
		} 
		if (target_row < 0) {
			target_row = 0;
		}

		if (target_row != current_row) {
			start_time	= current_time;
			target_time	= current_time + time;
			scrolling	= sgn(rows);
		}

	} else {

		if (scrolling * sgn(rows) < 0) {
			target_row = current_row;
			target_time = current_time;
		} else {

			if (rows > max_lines - (size.y-1) - target_row) {
				rows = max_lines - (size.y-1) - target_row;
			} 
			if (rows < -target_row) {
				rows = -target_row;
			}

			if (rows) {
				target_time = current_time + time;
				target_row += rows;
			}
		}
	}
	return 0;
}
//______________________________________________________________
int Console::Zoom(int delta)
{
	font_size += delta;
	font_size = clamp(font_size, 12, 48);
	return 0;
}

//______________________________________________________________
int Console::CommandKey(int type, int key, double time)
{
	if (!active) {
		return 0;
	}

	if (type == 1) {
		if (time) return 0;
		Update();
		switch (key) {
		case VK_UP: ScrollCmdLine(1); return 1;
		case VK_DOWN: ScrollCmdLine(-1); return 1;
		case 0x21: Scroll(size.y-1, .8); return 1;	// PageUp
		case 0x22: Scroll(-(size.y-1), .8); return 1;	// PageDown
		case VK_HOME: Scroll(lines-(size.y-1)-target_row, .5); return 1;
		case VK_END: Scroll(-target_row, .5); return 1;
		case VK_INSERT: Zoom(4); return 1;
		case VK_DELETE: Zoom(-4); return 1;
		}
		return 0;

	} else if (type == 0) {

		static bool completed = 0;

		switch (key) {
		case '`': return 0;
		case 0x1b:
			cmd_line[0].clear(); 
			return 1;
		case 0x08:	// backspace
			if (!cmd_line[0].empty()) {
				cmd_line[0].erase(cmd_line[0].end()-1, cmd_line[0].end());
			}
			completed = 0;
			return 1;
		case 0x09:	// tab
			framework.system->AutoComplete(cmd_line[0]);
			completed = 1;
			return 1;
		case 0x0d:	// enter
			if (completed) {
				cmd_line[0].append("();");
			}
			text.pop_back();
			text.push_front(cmd_line[0]);
			lines++;
			if (lines > max_lines) {
				lines = max_lines;
			}
			framework.system->ExecuteString(cmd_line[0].c_str());
			cmd_line.pop_back();
			cmd_line.push_front(std::string());
			completed = 0;
			return 1;
		default:
			cmd_line[0].push_back(key);
			completed = 0;
			return 1;
		}
	}
	return 0;
}

//______________________________________________________________
int Console::Write(const char* str)
{
	std::string s = str;
	std::string::size_type n = s.find_first_of('\n');
	if (n == std::string::npos) {
		text.front().assign(s);
	} else {
		text.front().assign(s, 0, n);
	}
	return 0;
}

//______________________________________________________________
int Console::WriteLn(const char* str)
{
	std::string s = str;
	std::string::size_type begin = 0;
	std::string::size_type end = 0;
	std::string::size_type length = s.length();

	while (end < length) {
		if (s[end] == '\n') {
			text.pop_back();
			text.push_front(s.substr(begin, end-begin));
			lines++;
			begin = end+1;
		}
		end++;
	}

	if (end-begin) {
		text.pop_back();
		text.push_front(s.substr(begin, end));
		lines++;
	}

	if (lines > max_lines) {
		lines = max_lines;
	}
	return 0;
}

//______________________________________________________________
int Console::SelectFont(const char* typeface)
{
	const char* default_font = "Impact";
	const char* selected_font = 0;

	if (typeface) {
		selected_font = typeface;
	} else {
		selected_font = default_font;
	}

	font->Create(selected_font);
	font->SetColor(1, 1, 1, 1);
	framework.system->Log("Console font changed to %s.\n", selected_font);
	return 0;
}

//______________________________________________________________
int Console::Render()
{
	Update();

	if (!active) {
		if (current_time > toggle_time + 1.0) {
			return 0;
		}
	}

	::glMatrixMode(GL_PROJECTION);
	::glPushMatrix();
	::glLoadIdentity();
	::glOrtho(0, size.x, 0, size.y, -1, +1);

	::glMatrixMode(GL_MODELVIEW);
	::glPushMatrix();
	::glLoadIdentity();

	double	position;
	double	interpolator;
	double	row;
	double	slide;

	interpolator = 0.5*sin(PI*(clamp(current_time-toggle_time, 1.0) - 0.5))+0.5;

	if (active) {
		position = size.y * (1-interpolator);
	} else {
		position = size.y * interpolator;
	}

	if (current_time >= target_time) {
		row = start_row = target_row;
		scrolling = 0;
	} else {
		interpolator = (0.5*sin(PI*((current_time-start_time) / (target_time-start_time) - 0.5))+0.5);
		row = start_row + (target_row-start_row) * interpolator;
	}

	current_row = static_cast<int>(floor(row));
	slide = row - current_row;

	::glDisable(GL_DEPTH_TEST);
	::glDisable(GL_LIGHTING);
	::glEnable(GL_BLEND);
	::glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	::glTranslated(0, position, 0);
	::glColor4ub(0,0,0, 100);
	::glRecti(0, 1, size.x, size.y);
	::glDisable(GL_BLEND);
	::glColor4ub(255,255,255,0);

	::glTranslated(0, 1-slide, 0);
	for (int i=0; i<size.y; i++) {
		font->Print("%s", text[current_row+i].c_str());
		::glTranslated(0, 1, 0);
	}
	::glTranslated(0, -i-1+slide, 0);

	::glColor3ub(0,80,100);
	::glRecti(0, 0, size.x, 1);
	::glColor4ub(255,255,255,0);
	font->Print(">%s", cmd_line[0].c_str());

	::glPopMatrix();
	::glMatrixMode(GL_PROJECTION);
	::glPopMatrix();

	return 1;
}

//______________________________________________________________

//______________________________________________________________
#include <cstdio>
#include <cassert>
#include "system.h"
#include "framework.h"
#include "console.h"
#include "overlay.h"
#include "kernel.h"
#include "opengl.h"
#include "caller.h"

//______________________________________________________________
ISystem::~ISystem() {}

//______________________________________________________________
System::System()
{
	journal.open("journal.txt", std::ios_base::out);
}

//______________________________________________________________
System::~System()
{
	modules.clear();
	lua_close(L);
	journal.flush();
	journal.close();
}

//______________________________________________________________
void System::Init()
{
	L = lua_open();
	luaopen_base(L);
	luaopen_string(L);
	luaopen_table(L);
	luaopen_math(L);
	luaopen_io(L);
	lua_settop(L, 0);

	Subscribe("Exec", Callback(this, Exec));
	Subscribe("System.SetBasePath", Callback(this, SetBasePath));
	Subscribe("System.LoadModule", Callback(this, GetInterface));
	
	typedef void (System::*ft)(char*);
	Subscribe("Log", Callback(this, (ft)Log));

	modules["OpenGL"].SetFactory(Factory_OpenGL);
	modules["OpenAL"].SetFactory(Factory_OpenAL);
	modules["Image"].SetFactory(Factory_Image);
	modules["Font2D"].SetFactory(Factory_Font2D);
	modules["Font3D"].SetFactory(Factory_Font3D);

	Log("Scripting language:%s\n", LUA_VERSION);
}

//______________________________________________________________
float System::GetFPS()
{
	return float(framework.kernel->GetFPS());
}

//______________________________________________________________
int System::SetBasePath(const char* path)
{
	Log("Base path: %s\n", path);
	base_path = path;
	if (base_path[base_path.length()-1] != '/') base_path.push_back('/');
	return 0;
}

//______________________________________________________________
char* System::Load(const char* path)
{
	char* buffer;
	std::string p(base_path);
	p += path;

	Log("Loading \"%s\"...", p.c_str());
	FILE* f = fopen(p.c_str(), "rb");

	if (f == 0) {
		// search in zip files
		buffer = 0;
	} else {
		fseek(f, 0, SEEK_END);
		long size = ftell(f);
		fseek(f, 0, SEEK_SET);
		buffer = new char[size];
		fread(buffer, 1, size, f);
	}

	fclose(f);
	Log("Done.\n");

	return buffer;
}

//______________________________________________________________
void* System::GetInterface(const char* path)
{
	return modules[path].GetObject(path);
}

//______________________________________________________________
void System::Log(char* string)
{
	journal << string;
	if (framework.console) {
		framework.console->WriteLn(string);
	}
	if (framework.overlay) {
		framework.overlay->Write(string);
	}
	journal.flush();
}

//______________________________________________________________
void System::Log(const char* format, ... )
{
	va_list	args;
	va_start(args, format);
	char buffer[1024];
	vsprintf(buffer, format, args);
	journal << buffer;
	if (framework.console) {
		framework.console->WriteLn(buffer);
	}
	if (framework.overlay) {
		framework.overlay->Write(buffer);
	}
	va_end(args);
	journal.flush();
}

//______________________________________________________________
void System::OverlayNote(const char* format, ... )
{
	va_list	args;
	va_start(args, format);
	char buffer[1024];
	vsprintf(buffer, format, args);
	if (framework.overlay) {
		framework.overlay->Write(buffer);
	}
	va_end(args);
}

//______________________________________________________________
void System::OverlayWrite(int row, const char* format, ... )
{
	va_list	args;
	va_start(args, format);
	char buffer[1024];
	vsprintf(buffer, format, args);
	if (framework.overlay) {
		framework.overlay->WriteStat(row, buffer);
	}
	va_end(args);
}

//______________________________________________________________
void System::GetMouseMovement(double& x, double& y)
{
	framework.kernel->GetMouseMovement(x, y);
}

//______________________________________________________________
int System::GetEvent(const char* key)
{
	type_event_map::iterator i = event_map.find(key);

	if (i != event_map.end()) {
		return i->second;
	}

	event_vector.push_back(type_subscriber_list());
	int event_index = static_cast<int>(event_vector.size() - 1);
	event_map[key] = event_index;
	lua_pushnumber(L, event_index);
	lua_pushcclosure(L, LuaHook, 1);
	lua_setglobal(L, key);
	return event_index;
}

//______________________________________________________________
int System::Subscribe(const char* key, Callback callback)
{
	if (callback.m_function_sig == 0) {
		callback.m_function_sig = Caller::ParseType(callback.m_function_type->name());
		if (callback.m_function_sig == 0) {
			return -1;
		}
	}

	type_event_map::iterator i = event_map.find(key);
	int event_index;

	if (i != event_map.end()) {
		event_index = i->second;
	} else {
		event_vector.push_back(type_subscriber_list());
		event_index = static_cast<int>(event_vector.size() - 1);
		event_map[key] = event_index;

		std::string k = key;
		std::string t;
		std::string::size_type a = 0;
		std::string::size_type z = 0;

		int table = LUA_GLOBALSINDEX;

		z = k.find(".", a);
		t = k.substr(a, z);
		a = z + 1;

		while (z != std::string::npos) {
			lua_pushstring(L, t.c_str());
			lua_gettable(L, table);
			if (lua_istable(L, -1) == false) {
				lua_pop(L, 1);
				lua_pushstring(L, t.c_str());
				lua_newtable(L);
				lua_settable(L, table);
				lua_pushstring(L, t.c_str());
				lua_gettable(L, table);
			}
			table = lua_gettop(L);
			z = k.find(".", a);
			t = k.substr(a, z);
			a = z + 1;
		}

		lua_pushstring(L, t.c_str());
		lua_pushnumber(L, event_index);
		lua_pushcclosure(L, LuaHook, 1);
		lua_settable(L, table);

		lua_settop(L, 0);
	}

	event_vector[event_index].push_back(callback);
	return event_index;
}

//______________________________________________________________
void System::Unsubscribe(const char* key, Callback callback)
{
	type_event_map::iterator i = event_map.find(key);

	if (i == event_map.end()) {
		return;
	}

	int event_index = i->second;
	event_vector[event_index].remove(callback);
	return;
}

//______________________________________________________________
void System::UnsubscribeAll(const char* key)
{
	type_event_map::iterator i = event_map.find(key);

	if (i == event_map.end()) {
		return;
	}

	int event_index = i->second;
	event_vector[event_index].clear();
	return;
}

//______________________________________________________________
int System::CallSubscribers(int event)
{
	Caller caller;
	
	if (caller.Create(L) == -1) {
		Log("Error: invalid parameter types\n");
		return -1;
	}

	if (event_vector[event].size() == 0) {
		return -1;
	}

	type_subscriber_list::iterator i = event_vector[event].begin();
	type_subscriber_list::iterator j;
	type_subscriber_list::iterator end = event_vector[event].end();
	int result = 0;
	while(i != end && !result) {
		j = i;
		i++;
		result = caller.Call(*j);
	}

	return result;
}

//______________________________________________________________
int System::CallSubscribers(int event, const char* format, ... )
{
	va_list	args;
	va_start(args, format);

	for (int i=0; format[i]; i++) {
		char c = format[i];
		if (c == 'i') {
			lua_pushnumber(L, va_arg(args, int));
		} else if (c == 'f') {
			lua_pushnumber(L, va_arg(args, float));
		} else if (c == 'd') {
			lua_pushnumber(L, va_arg(args, double));
		} else if (c == 's') {
			lua_pushstring(L, va_arg(args, char*));
		} else if (c == 'u') {
			lua_pushlightuserdata(L, va_arg(args, void*));
		}
	}

	va_end(args);

	return CallSubscribers(event);
}

//______________________________________________________________
int System::GetGlobal(const char* keys)
{
	lua_pushstring(L, "loadstring");
	lua_gettable(L, LUA_GLOBALSINDEX);
	lua_pushfstring(L, "return %s;", keys);
	lua_call(L, 1, LUA_MULTRET);

	if (lua_isfunction(L, -1)) {
		int error_code = lua_pcall(L, 0, LUA_MULTRET, 0);
		if (error_code != 0) {
			Log("%s\n", lua_tostring(L, -1));
			lua_pop(L, 1);
		}
	} else {
		Log("%s\n", lua_tostring(L, -1));
		lua_pop(L, 2);
	}
	return 0;
}

//______________________________________________________________
double System::GetGlobalNumber(const char* key)
{
	GetGlobal(key);
	double value = lua_tonumber(L, -1);
	lua_pop(L, 1);
	return value;
}

//______________________________________________________________
const char* System::GetGlobalString(const char* key)
{
	GetGlobal(key);
	const char* value = lua_tostring(L, -1);
	lua_pop(L, 1);
	return value;
}

//______________________________________________________________
void System::GetGlobals(const char* keys, const char* format, ... )
{
	GetGlobal(keys);
	int globals_on_stack = lua_gettop(L);
	int globals_required = int(strlen(format));

	int n = min(globals_on_stack, globals_required);

	va_list	args;
	va_start(args, format);

	for (int i=0; i<n; i++) {
		char c = format[i];
		int s = i + 1;
		if (c == 'i') {
			int* p_int = va_arg(args, int*);
			if (lua_isnumber(L, s)) {
				*p_int = static_cast<int>(lua_tonumber(L, s));
			} else {
				*p_int = 0;
			}
		} else if (c == 'f') {
			float* p_float = va_arg(args, float*);
			if (lua_isnumber(L, s)) {
				*p_float = static_cast<float>(lua_tonumber(L, s));
			} else {
				*p_float = 0;
			}
		} else if (c == 'd') {
			double* p_double = va_arg(args, double*);
			if (lua_isnumber(L, s)) {
				*p_double = static_cast<double>(lua_tonumber(L, s));
			} else {
				*p_double = 0;
			}
		} else if (c == 's') {
			const char** p_string = va_arg(args, const char**);
			if (lua_isstring(L, s)) {
				*p_string = static_cast<const char*>(lua_tostring(L, s));
			} else {
				*p_string = 0;
			}
		} else if (c == 'u') {
			void** p_user = va_arg(args, void**);
			if (lua_isuserdata(L, s)) {
				*p_user = static_cast<void*>(lua_touserdata(L, s));
			} else {
				*p_user = 0;
			}
		}
	}

	lua_settop(L, 0);
	va_end(args);
}

//______________________________________________________________
void System::AutoComplete(std::string& cmd)
{
	static std::string original_cmd;
	static std::string current_cmd;

	type_event_map::const_iterator i;
	type_event_map::const_iterator j;
	type_event_map::const_iterator k;

	if (cmd.empty()) {
		original_cmd.assign(cmd);
		i = j = event_map.begin();
		k = event_map.end();
	} else if (cmd != current_cmd) {
		original_cmd.assign(cmd);
		i = j = event_map.lower_bound(original_cmd);
		original_cmd.at(original_cmd.length()-1)++;
		k = event_map.lower_bound(original_cmd);
		original_cmd.at(original_cmd.length()-1)--;
	} else {
		j = event_map.upper_bound(current_cmd);
		if (original_cmd.empty()) {
			i = event_map.begin();
			k = event_map.end();
		} else {
			i = event_map.lower_bound(original_cmd);
			original_cmd.at(original_cmd.length()-1)++;
			k = event_map.lower_bound(original_cmd);
			original_cmd.at(original_cmd.length()-1)--;
		}
	}

	if (i == event_map.end()) {
		return;
	}

	if (j == k) {
		j = i;
	}
	
	current_cmd.assign(j->first);
	cmd.assign(current_cmd);
	return;
}

//______________________________________________________________
int System::ExecuteFile(const char* path)
{
	Log("Execing %s...\n", path);

	lua_pushstring(L, "loadfile");
	lua_gettable(L, LUA_GLOBALSINDEX);
	lua_pushstring(L, path);
	lua_call(L, 1, LUA_MULTRET);

	if (lua_isfunction(L, -1)) {
		int error_code = lua_pcall(L, 0, LUA_MULTRET, 0);
		if (error_code != 0) {
			Log("%s\n", lua_tostring(L, -1));
			lua_pop(L, 1);
		}
	} else {
		Log("%s\n", lua_tostring(L, -1));
		lua_pop(L, 2);
		DumpStack();
		lua_settop(L, 0);
		return 1;
	}

	DumpStack();
	lua_settop(L, 0);
	return 0;
}

//______________________________________________________________
int System::ExecuteString(const char* format, ...)
{
	va_list	args;
	va_start(args, format);
	char buffer[1024];
	int length = vsprintf(buffer, format, args);
	va_end(args);

	lua_pushstring(L, "loadstring");
	lua_gettable(L, LUA_GLOBALSINDEX);
	lua_pushstring(L, buffer);
	lua_call(L, 1, LUA_MULTRET);

	if (lua_isfunction(L, -1)) {
		int error_code = lua_pcall(L, 0, LUA_MULTRET, 0);
		if (error_code != 0) {
			Log("%s\n", lua_tostring(L, -1));
			lua_pop(L, 1);
		}
	} else {
		Log("%s\n", lua_tostring(L, -1));
		lua_pop(L, 2);
	}

	DumpStack();
	lua_settop(L, 0);
	return 0;
}

//______________________________________________________________
void System::DumpStack(int i, int depth)
{
	int tab = depth << 3;

	lua_pushnil(L);
	while(lua_next(L, i)) {
		if (lua_isnumber(L, -2)) {
			if (lua_isstring(L, -1)) {
				Log("%*c[%d] = %s\n", tab, ' ', int(lua_tonumber(L, -2)), lua_tostring(L, -1));
			} else if (lua_isboolean(L, -1)) {
				Log("%*c[%d] = %s\n", tab, ' ', int(lua_tonumber(L, -2)), lua_toboolean(L, -1) ? "true" : "false");
			} else {
				Log("%*c[%d] = %s\n", tab, ' ', int(lua_tonumber(L, -2)), lua_typename(L, lua_type(L, -1)));
			}
		} else if (lua_isstring(L, -2)) {
			if (lua_isstring(L, -1)) {
				Log("%*c[%s] = %s\n", tab, ' ', lua_tostring(L, -2), lua_tostring(L, -1));
			} else if (lua_isboolean(L, -1)) {
				Log("%*c[%s] = %s\n", tab, ' ', lua_tostring(L, -2), lua_toboolean(L, -1) ? "true" : "false");
			} else {
				Log("%*c[%s] = %s\n", tab, ' ', lua_tostring(L, -2), lua_typename(L, lua_type(L, -1)));
			}
		} else {
			if (lua_isstring(L, -1)) {
				Log("%*c[%s] = %s\n", tab, ' ', lua_typename(L, lua_type(L, -2)), lua_tostring(L, -1));
			} else {
				Log("%*c[%s] = %s\n", tab, ' ', lua_typename(L, lua_type(L, -2)), lua_typename(L, lua_type(L, -1)));
			}
		}

		if (lua_istable(L, -1)) {
			DumpStack(lua_gettop(L), depth+1);
		}

		lua_pop(L, 1);
	}
}

//______________________________________________________________
void System::DumpStack(int i)
{
	std::string s = lua_typename(L, lua_type(L, i));

	if (lua_istable(L, i)) {
		Log("[%d] %s:\n", i, s.c_str());
		DumpStack(i, 1);
	} else if (lua_isstring(L, i)) {
		Log("[%d] %s: %s\n", i, s.c_str(), lua_tostring(L, i));
	} else {
		Log("[%d] %s\n", i, s.c_str());
	}
}

//______________________________________________________________
void System::DumpStack()
{
	int n = lua_gettop(L);
	for (int i=1; i<=n; i++) {
		DumpStack(i);
	}
}

//______________________________________________________________
//int System::CheckLuaError(int error_code)
//{
//	switch (error_code) {
//		case LUA_ERRRUN: Log("Lua Error: Error while running the chunk.\n"); break;
//		case LUA_ERRSYNTAX: Log("Lua Error: Syntax error during precompilation.\n"); break;
//		case LUA_ERRMEM: Log("Lua Error: Memory allocation error.\n"); break;
//		case LUA_ERRERR: Log("Lua Error: Error while generating error.\n"); break;
//		case LUA_ERRFILE: Log("Lua Error: Error opening file.\n"); break;
//		default: break;
//	}
//
//	return error_code;
//}

//______________________________________________________________
int System::LuaHook(lua_State* L)
{
	int event_index = static_cast<int>(lua_tonumber(L, lua_upvalueindex(1)));
	framework.system->CallSubscribers(event_index);
	lua_settop(L, 0);
	return 0;
}

//______________________________________________________________
int System::Exec(const char* error)
{
	if (error) {
		ExecuteFile(error);
	} else {
		Log("Usage: exec(path)\n");
	}

	return 0;
}

//______________________________________________________________

#pragma once
#include "i_framework.h"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <GL/gl.h>
#include <GL/glext.h>
#include <GL/wglext.h>

class OpenGL :
public IOpenGL
{
private:
	HDC DC;
	HGLRC RC;
	int color;
	int alpha;
	int depth;
	int stencil;
	bool error;
	int m_vsync;
	int m_event_rc_created;
	int m_event_rc_destroy;
	v4i m_window_size;
	bool m_save_screenshot;
	IImage* m_screenshot;

public:
	OpenGL();
	~OpenGL();
	int Init();
	int Setup(int i_alpha, int i_depth, int i_stencil);
	int Create(HDC i_DC);
	int Destroy();
	bool CheckError();
	int SwapBuffers();
	int ListSupportedExtensions();
	bool IsExtensionSupported(const char *string);
	int SetVSync(int vsync);
	int ToggleVSync();
	int ResetTextureUnits();
	int LoadTexture(const char* path);
	int SaveScreen();
	int SaveBMP();
	int OnWindowResized(int width, int height);

public:
	GLvoid Enable(GLenum cap);
	GLvoid EnableClientState(GLenum array);
	GLvoid Begin(GLenum mode);
	GLvoid End(void);
	GLvoid BlendFunc(GLenum sfactor, GLenum dfactor);
	GLvoid Clear(GLbitfield mask);
	GLvoid ClearAccum(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
	GLvoid ClearColor(GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha);
	GLvoid ClearDepth(GLclampd depth);
	GLvoid ClearIndex(GLfloat c);
	GLvoid ClearStencil(GLint s);
	GLvoid Color4ub(GLubyte red, GLubyte green, GLubyte blue, GLubyte alpha);
	GLvoid Color4d(GLdouble red, GLdouble green, GLdouble blue, GLdouble alpha);
	GLvoid Disable(GLenum cap);
	GLvoid DisableClientState(GLenum array);
	GLvoid DepthFunc(GLenum func);
	GLvoid DepthMask(GLboolean flag);
	GLvoid DepthRange(GLclampd zNear, GLclampd zFar);
	GLvoid Fogf(GLenum pname, GLfloat param);
	GLvoid Fogfv(GLenum pname, const GLfloat *params);
	GLvoid Fogi(GLenum pname, GLint param);
	GLvoid Fogiv(GLenum pname, const GLint *params);
	GLvoid FrontFace(GLenum mode);
	GLvoid PolygonMode(GLenum face, GLenum mode);
	GLvoid PolygonOffset(GLfloat factor, GLfloat units);
	GLvoid PolygonStipple(const GLubyte *mask);

	GLvoid Color4f(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
	GLvoid Color4fv(const GLfloat *v);
	GLvoid CullFace(GLenum mode);
	GLvoid CopyTexImage1D(GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLint border);
	GLvoid CopyTexImage2D(GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border);
	GLvoid CopyTexSubImage1D(GLenum target, GLint level, GLint xoffset, GLint x, GLint y, GLsizei width);
	GLvoid CopyTexSubImage2D(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height);
	GLvoid Vertex4f(GLfloat x, GLfloat y, GLfloat z, GLfloat w);
	GLvoid Vertex4fv(const GLfloat *v);
	GLvoid Vertex4dv(const GLdouble *v);
	GLvoid TexCoord4f(GLfloat s, GLfloat t, GLfloat r, GLfloat q);

	GLvoid MatrixMode(GLenum mode);
	GLvoid PopMatrix(void);
	GLvoid PushMatrix(void);
	GLvoid VertexPointer(GLint size, GLenum type, GLsizei stride, const GLvoid *pointer);
	GLvoid LoadIdentity(void);


	void LoadTransposeMatrixf(const float*);
	void LoadTransposeMatrixd(const double*);
	void MultTransposeMatrixf(const float*);
	void MultTransposeMatrixd(const double*);
	void ActiveTexture (GLenum texture);
	void DrawRangeElements (GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const GLvoid *indices);

	GLvoid GenTextures (GLsizei n, GLuint *textures);
	GLvoid DeleteTextures (GLsizei n, const GLuint *textures);
	GLvoid BindTexture (GLenum target, GLuint texture);
	GLvoid TexEnvf (GLenum target, GLenum pname, GLfloat param);
	GLvoid TexEnvfv (GLenum target, GLenum pname, const GLfloat *params);
	GLvoid TexEnvi (GLenum target, GLenum pname, GLint param);
	GLvoid TexEnviv (GLenum target, GLenum pname, const GLint *params);
	GLvoid TexGend (GLenum coord, GLenum pname, GLdouble param);
	GLvoid TexGendv (GLenum coord, GLenum pname, const GLdouble *params);
	GLvoid TexGenf (GLenum coord, GLenum pname, GLfloat param);
	GLvoid TexGenfv (GLenum coord, GLenum pname, const GLfloat *params);
	GLvoid TexGeni (GLenum coord, GLenum pname, GLint param);
	GLvoid TexGeniv (GLenum coord, GLenum pname, const GLint *params);
	GLvoid TexImage1D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLint border, GLenum format, GLenum type, const GLvoid *pixels);
	GLvoid TexImage2D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const GLvoid *pixels);
	GLvoid TexParameterf (GLenum target, GLenum pname, GLfloat param);
	GLvoid TexParameterfv (GLenum target, GLenum pname, const GLfloat *params);
	GLvoid TexParameteri (GLenum target, GLenum pname, GLint param);
	GLvoid TexParameteriv (GLenum target, GLenum pname, const GLint *params);
	GLvoid TexSubImage1D (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLenum type, const GLvoid *pixels);
	GLvoid TexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels);

	GLvoid BindBuffer(GLenum target, GLuint buffer);
	GLvoid DeleteBuffers(GLsizei n, const GLuint *buffers);
	GLvoid GenBuffers(GLsizei n, GLuint *buffers);
	GLboolean IsBuffer(GLuint buffer);
	GLvoid BufferData(GLenum target, GLsizeiptr size, const GLvoid *data, GLenum usage);
	GLvoid BufferSubData(GLenum target, GLintptr offset, GLsizeiptr size, const GLvoid *data);
	GLvoid GetBufferSubData(GLenum target, GLintptr offset, GLsizeiptr size, GLvoid *data);
	GLvoid *MapBuffer(GLenum target, GLenum access);
	GLboolean UnmapBuffer(GLenum target);
	GLvoid GetBufferParameteriv(GLenum target, GLenum pname, GLint *params);
	GLvoid GetBufferPoGLinterv(GLenum target, GLenum pname, GLvoid **params);

private:
	// transpose matrix
	PFNGLLOADTRANSPOSEMATRIXFPROC glLoadTransposeMatrixf;
	PFNGLLOADTRANSPOSEMATRIXDPROC glLoadTransposeMatrixd;
	PFNGLMULTTRANSPOSEMATRIXFPROC glMultTransposeMatrixf;
	PFNGLMULTTRANSPOSEMATRIXDPROC glMultTransposeMatrixd;

	// texturing
	PFNGLTEXIMAGE3DPROC glTexImage3D;
	PFNGLTEXSUBIMAGE3DPROC glTexSubImage3D;
	PFNGLCOPYTEXSUBIMAGE3DPROC glCopyTexSubImage3D;
	PFNGLACTIVETEXTUREPROC glActiveTexture;
	PFNGLMULTITEXCOORD4DPROC glMultiTexCoord4d;
	PFNGLCOMPRESSEDTEXIMAGE1DPROC glCompressedTexImage1D;
	PFNGLCOMPRESSEDTEXIMAGE2DPROC glCompressedTexImage2D;
	PFNGLCOMPRESSEDTEXIMAGE3DPROC glCompressedTexImage3D;

	// miscellaneous
	PFNGLPOINTPARAMETERFPROC glPointParameterf;
	PFNGLDRAWRANGEELEMENTSPROC glDrawRangeElements;

	// ARB_vertex_buffer_object
	PFNGLBINDBUFFERARBPROC glBindBuffer;
	PFNGLDELETEBUFFERSARBPROC glDeleteBuffers;
	PFNGLGENBUFFERSARBPROC glGenBuffers;
	PFNGLISBUFFERARBPROC glIsBuffer;
	PFNGLBUFFERDATAARBPROC glBufferData;
	PFNGLBUFFERSUBDATAARBPROC glBufferSubData;
	PFNGLGETBUFFERSUBDATAARBPROC glGetBufferSubData;
	PFNGLMAPBUFFERARBPROC glMapBuffer;
	PFNGLUNMAPBUFFERARBPROC glUnmapBuffer;
	PFNGLGETBUFFERPARAMETERIVARBPROC glGetBufferParameteriv;
	PFNGLGETBUFFERPOINTERVARBPROC glGetBufferPointerv;

	// WGL
	PFNWGLGETEXTENSIONSSTRINGARBPROC wglGetExtensionsString;
	PFNWGLSWAPINTERVALEXTPROC wglSwapInterval;

private:
	int InitExtensions();
};


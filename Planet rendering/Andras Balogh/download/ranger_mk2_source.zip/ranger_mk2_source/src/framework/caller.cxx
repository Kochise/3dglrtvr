//______________________________________________________________
// This file contains very platform/compiler specific code to
// handle Lua binding. Warning, lots of inline assembly!
//______________________________________________________________
#include <lua.h>
#include <string>
#include "generic.h"
#include "caller.h"

//______________________________________________________________
enum TypeID
{
	t_fatal = 'U',
	t_void = 'V',
	t_pointer = '*',
	t_i8 = 'C',
	t_i16 = 'S',
	t_i32 = 'I',
	t_f32 = 'F',
	t_f64 = 'D',
	t_stdcall = '1',
	t_cdecl = '2',
	t_thiscall = '3'
};

//______________________________________________________________
Caller::Caller() :
valnum(0),
values(0),
types(0)
{
}

//______________________________________________________________
Caller::~Caller()
{
	delete [] values;
	delete [] types;
}

//______________________________________________________________
Caller::Create(lua_State* L)
{
	valnum = lua_gettop(L); // number of parameters
	int buffer_size = 0;

	// determine required buffer size
	for (int i=1; i<=valnum; i++) {
		switch (lua_type(L, i)) {
			case LUA_TUSERDATA:
			case LUA_TLIGHTUSERDATA:
			case LUA_TSTRING: buffer_size += 1; break;
			case LUA_TNUMBER: buffer_size += 2; break;
			case LUA_TNIL:
			case LUA_TNONE:
			case LUA_TTABLE:
			case LUA_TTHREAD:
			case LUA_TFUNCTION: return -1; // invalid types on stack
			default: break;
		}
	}

	// create buffers
	values = new int[buffer_size];
	types = new char[valnum];

	int* vptr = values;
	char* tptr = types;

	// pack Lua parameters into buffers
	for (int i=1; i<=valnum; i++) {
		if (lua_isnumber(L, i)) {
			double t = lua_tonumber(L, i);
			__asm {
				lea esi, t
				mov edi, [vptr]
				movsd
				movsd
			}
			*tptr++ = t_f64;
			vptr += 2;
		} else if (lua_isstring(L, i)) {
			const void* t = lua_tostring(L, i);
			__asm {
				lea esi, t
				mov edi, [vptr]
				movsd
			}
			*tptr++ = t_pointer;
			vptr++;
		} else if (lua_isuserdata(L, i)) {
			const void* t = lua_touserdata(L, i);
			__asm {
				lea esi, t
				mov edi, [vptr]
				movsd
			}
			*tptr++ = t_pointer;
			vptr++;
		}
	}

	// clear stack after saving values (enables nested calls)
	lua_settop(L, 0);

	return 0;
}

//______________________________________________________________
int Caller::Call(Callback& c)
{
	char* sig = c.m_function_sig;
	void* obj = c.m_object_ptr;
	void* fun = c.m_function_ptr;
	int* buffer = 0;
	int* buffer_ptr = 0;
	int buffer_size = 0;
	int* vptr = values;
	char* tptr = types;

	if (sig[2] != t_void) { // if the function has parameters

		int p = 0; // number of parameters required
		for (p=0; sig[p+2]; p++) {
			switch (sig[p+2]) {
				case t_f64: buffer_size += 2; break;
				default: buffer_size += 1; break;
			}
		}

		int real_buffer_size = valnum * 2;
		buffer_ptr = buffer = new int[real_buffer_size];

		// clear buffer
		__asm {
			mov edi, [buffer]
			mov ecx, [real_buffer_size]
			xor eax, eax
			rep stosd
		}

		int n = min(p, valnum);

		for (int i=0; i<n; i++) {
			char f = sig[i+2];
			if (*tptr == t_f64) { // source is a double
				double tmp_f64 = 0;
				__asm {
					mov esi, [vptr]
					lea edi, tmp_f64
					movsd
					movsd
				}
				if (f == t_f64) {
					__asm {
						lea esi, tmp_f64
						mov edi, [buffer_ptr]
						movsd
						movsd
					}
					buffer_ptr += 2;
				} else if (f == t_f32) {
					float t = static_cast<float>(tmp_f64);
					__asm {
						lea esi, t
						mov edi, [buffer_ptr]
						movsd
					}
					buffer_ptr++;
				} else if (f == t_i32) {
					int t = static_cast<int>(tmp_f64);
					__asm {
						lea esi, t
						mov edi, [buffer_ptr]
						movsd
					}
					buffer_ptr++;
				} else if (f == t_i8) {
					int t = static_cast<char>(tmp_f64);
					__asm {
						lea esi, t
						mov edi, [buffer_ptr]
						movsd
					}
					buffer_ptr++;
				}
				vptr += 2;
			} else if (*tptr == t_pointer) {
				__asm {
					mov esi, [vptr]
					mov edi, [buffer_ptr]
					movsd
				}
				buffer_ptr++;
				vptr++;
			}
			tptr++;
		}
	}

	int result = 0;

	// thiscall: callee cleans stack, this ptr in ecx
	if (sig[0] == t_thiscall) {
		__asm {
			mov esi, [buffer]
			mov ecx, [buffer_size]
			shl ecx, 2
			sub esp, ecx
			shr ecx, 2
			mov edi, esp;
			rep movsd
			mov ecx, [obj]
			call [fun]
			mov [result], eax
		}
	}

	delete [] buffer;
	return result;
}

//______________________________________________________________
char* Caller::ParseType(const char* name)
{
	struct KeywordSignature
	{
		char* keyword;
		TypeID signature;
	};

	static KeywordSignature ks[] = {
		{"...", t_fatal},
		{"stdcall", t_stdcall},
		{"cdecl", t_cdecl},
		{"thiscall", t_thiscall},
		{"class", t_fatal},
		{"void", t_void},
		{"short", t_i16},
		{"long", t_i32},
		{"int", t_i32},
		{"char", t_i8},
		{"float", t_f32},
		{"double", t_f64}
	};

	#define ParseX(j) \
	{ \
		for (int k=0; k<sizeof(ks); k++) { \
			if (s.find(ks[k].keyword, i) < j) { \
				TypeID t = ks[k].signature; \
				if (t == t_fatal) { \
					return 0; \
				} \
				sig += t; \
				break; \
			} \
		} \
	} \

	std::string s = name;
	std::string sig;
	std::string::size_type i = 0;
	std::string::size_type j = 0;

	// determine function type
	ParseX(std::string::npos);

	// determine return type
	j = s.find_first_of("*&(");
	if (s[j] == '(') { // function returns a value
		ParseX(j);
	} else { // function returns a pointer
		sig += t_pointer;
	}

	// parse arguments
	i = s.find(")(", j) + 2;
	for (;;) {
		j = s.find_first_of("&*,)", i);
		if (s[j] == ')') { // end of argument list
			ParseX(j);
			break;
		} else if (s[j] == ',') { // value argument
			ParseX(j);
			i = j+1;
		} else { // pointer argument
			sig += t_pointer;
			i = s.find_first_of(",)", j+1);
			if (s[i] == ')') {
				break;
			} else {
				i = i+1;
			}
		}
	} 

	char* function_sig = new char[sig.length()+1];
	strcpy(function_sig, sig.c_str());

	return function_sig;
}


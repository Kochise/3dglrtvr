//______________________________________________________________
#include "framework.h"
#include "system.h"
#include "kernel.h"
#include "opengl.h"
#include "console.h" // get rid of them
#include "overlay.h"

//______________________________________________________________
Kernel::Kernel() :
m_paused(false),
m_time_resolution(0.005),
m_time_multiplier(1),
m_absolute_time(0),
m_delta_time(0),
m_virtual_absolute_time(0),
m_virtual_delta_time(0),
m_time_accumulator(0),
m_frame_accumulator(0),
m_fps(0),
m_window_handler(0),
m_window_active(false),
m_mouse_sensitivity(0.01),
m_mouse_movement(0),
m_quit(0)
{
}

//______________________________________________________________
Kernel::~Kernel()
{
	DestroyWnd();
	::UnregisterClass("OpenGL", 0);
	::ChangeDisplaySettingsEx(0, 0, 0, 0, 0);
}

//______________________________________________________________
int Kernel::Init()
{
	WNDCLASS wc;
	wc.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = Dispatcher;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = 0;
	wc.hIcon = 0;
	wc.hCursor = ::LoadCursor(NULL, IDC_CROSS);
	wc.hbrBackground = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "OpenGL";
	::RegisterClass(&wc);

	QueryPerformanceFrequency(&m_counter_frequency);
	QueryPerformanceCounter(&m_counter_old);

	m_event_simulate = framework.system->GetEvent("Event.Simulate");
	m_event_update = framework.system->GetEvent("Event.Update");
	m_event_render = framework.system->GetEvent("Event.Render");
	m_event_framework_button = framework.system->GetEvent("Event._OnButton");
	m_event_application_button = framework.system->GetEvent("Event.OnButton");
	m_event_window_resized = framework.system->GetEvent("Event.WindowResized");
	m_event_desktop_resized = framework.system->GetEvent("Event.DesktopResized");

	framework.system->Subscribe("Event._OnButton", Callback(this, OnButton));
	framework.system->Subscribe("Window.SetSize", Callback(this, SetWindowSize));
	framework.system->Subscribe("Window.Create", Callback(this, CreateWnd));
	framework.system->Subscribe("Display.SetMode", Callback(this, SetDisplayMode));
	framework.system->Subscribe("System.Info", Callback(this, SystemInfo));
	framework.system->Subscribe("Input.SetMouseSensitivity", Callback(this, SetMouseSensitivity));
	framework.system->Subscribe("Timer.SetTime", Callback(this, SetTimer));
	framework.system->Subscribe("Timer.SetTimeResolution", Callback(this, SetTimeResolution));
	framework.system->Subscribe("Timer.SetTimeMultiplier", Callback(this, SetTimeMultiplier));
	framework.system->Subscribe("Quit", Callback(this, Quit));

	return 0;
}

//______________________________________________________________
int Kernel::SystemInfo()
{
	const int size(255);
	char computer_name[size];
	char user_name[size];
	DWORD computer_size(size);
	DWORD user_size(size);
	SYSTEM_INFO sysinfo;
	MEMORYSTATUS memory;
	DISPLAY_DEVICE dd;
	OSVERSIONINFOEX os;
	os.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	::GetComputerName(computer_name, &computer_size);
	::GetUserName(user_name, &user_size);
	::GetSystemInfo(&sysinfo);
	::GlobalMemoryStatus(&memory);
	::GetVersionEx((OSVERSIONINFO*)&os);

	dd.cb = sizeof(DISPLAY_DEVICE);
	for (int i=0; ::EnumDisplayDevices(0, i, &dd, 0); i++) {
		if (dd.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE) break;
	}

	framework.system->Log(
		"User: %s @ %s\n"
		"OS: Windows %d.%d.%d %s\n"
		"CPU: Level %d Model %d Stepping %d\n"
		"Memory: %luMB free / %luMB total\n"
		"Display device: %s\n",
		user_name, 
		computer_name,
		os.dwMajorVersion,
		os.dwMinorVersion,
		os.dwBuildNumber,
		os.szCSDVersion,
		sysinfo.wProcessorLevel,
		sysinfo.wProcessorRevision >> 8,
		sysinfo.wProcessorRevision & 0x00ff,
		memory.dwAvailPhys >> 20,
		memory.dwTotalPhys >> 20,
		dd.DeviceString
	);

	return 0;
}

//______________________________________________________________
int Kernel::Run()
{
	MSG	msg;

	if (m_window_handler == 0) {
		framework.system->Log("Error: Client window not created.\n");
		m_quit++;
	}

	for(;;) {
		while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
			if (msg.message == WM_QUIT) {
				return int(msg.wParam);
			}
			DispatchMessage(&msg);
		}

		if (!m_quit) {
			Update();
		} else if (m_quit == 1) {
			DestroyWnd();
			::PostQuitMessage(0);
			m_quit++;
		}

	}
}

//______________________________________________________________
int Kernel::Quit()
{
	m_quit++;
	framework.system->Log("Quitting...\n");
	return 0;
}

//______________________________________________________________
int Kernel::SetTime(double i_time) 
{
	m_virtual_absolute_time = i_time;
	return 0;
}

//______________________________________________________________
int Kernel::SetTimeResolution(double i_resolution)
{
	m_time_resolution = i_resolution;

	framework.system->Log(
		"Simulation resolution set to %4.1fHz (%1.4f secs).\n",
		1.0/m_time_resolution,
		m_time_resolution
	);
	return 0;
}

//______________________________________________________________
int Kernel::SetTimeMultiplier(double i_multiplier)
{
	m_time_multiplier = i_multiplier;
	framework.system->Log("Simulation multiplier set to %2.3fx.\n", m_time_multiplier);
	return 0;
}

//______________________________________________________________
double Kernel::GetFPS()
{
	return m_fps;
}

//______________________________________________________________
double Kernel::GetTime()
{
	return m_absolute_time;
}

//______________________________________________________________
int Kernel::Pause()
{
	m_paused = !m_paused;
	if (m_paused) {
		framework.system->Log("Simulation paused.\n");
	} else {
		framework.system->Log("Simulation running.\n");
	}

	return 0;
}

//______________________________________________________________
int Kernel::SetDisplayMode(int width, int height)
{
	DEVMODE tmp;
	tmp.dmSize = sizeof(DEVMODE);
	tmp.dmDriverExtra = 0;

	DEVMODE	dm;
	dm.dmSize = sizeof(DEVMODE);
	dm.dmDriverExtra = 0;
	dm.dmDisplayFrequency = 0;
	dm.dmPelsWidth = width;
	dm.dmPelsHeight = height;
	dm.dmBitsPerPel = 0;

	for (int i=0; ::EnumDisplaySettings(0, i, &tmp); i++) {
		if (
			tmp.dmPelsWidth == dm.dmPelsWidth &&
			tmp.dmPelsHeight == dm.dmPelsHeight &&
			tmp.dmBitsPerPel >= dm.dmBitsPerPel &&
			tmp.dmDisplayFrequency >= dm.dmDisplayFrequency
		) {
			::EnumDisplaySettings(0, i, &dm);
		}
	}

	if (dm.dmDisplayFrequency == 0) {
		::EnumDisplaySettings(0, ENUM_CURRENT_SETTINGS, &dm);
	}

	dm.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT | DM_DISPLAYFREQUENCY;
	::ChangeDisplaySettingsEx(0, &dm, 0, 0, 0);

	m_screen_size(dm.dmPelsWidth, dm.dmPelsHeight);

	framework.system->Log(
		"Display mode: %dx%dx%d@%d\n",
		dm.dmPelsWidth,
		dm.dmPelsHeight,
		dm.dmBitsPerPel,
		dm.dmDisplayFrequency	
	);

//	framework.system->CallSubscribers(m_event_desktop_resized);

	return 0;
}

//______________________________________________________________
int Kernel::CreateWnd(int width, int height, int alpha, int depth, int stencil)
{
	DestroyWnd();
	m_buttons.clear();
	framework.opengl->Setup(alpha, depth, stencil);

	if (width == 0 || height == 0) {
		m_window_size(m_screen_size);
		m_window_fullscreen = true;
	} else {
		m_window_size(width, height);
		m_window_fullscreen = false;
	}

	framework.system->Log(
		"Create window: %dx%d (%s)\n",
		m_window_size.x,
		m_window_size.y,
		m_window_fullscreen ? "fullscreen" : "windowed"
	);

	::CreateWindow(
		"OpenGL",
		"bnd Framework",
		(m_window_fullscreen ? WS_POPUP : WS_OVERLAPPEDWINDOW) |
		WS_VISIBLE | 
		WS_CLIPCHILDREN | 
		WS_CLIPSIBLINGS,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		m_window_size.x,
		m_window_size.y,
		0, 0, 0, 0
	);

	return 0;
}

//______________________________________________________________
int Kernel::DestroyWnd()
{
	if (m_window_handler) {
		::DestroyWindow(m_window_handler);
		m_window_handler = 0;
	}
	return 0;
}

//______________________________________________________________
int Kernel::SetWindowSize(int width, int height)
{
	LONG style = WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS;

	if (width == 0 || height == 0) {
		if (!m_window_fullscreen) {
			::ShowCursor(FALSE);
		}
		m_window_size(m_screen_size);
		m_window_fullscreen = true;
		::SetWindowLongPtrW(m_window_handler, GWL_STYLE, WS_POPUP | style);
		::SetWindowPos(m_window_handler, HWND_TOP, 0, 0, m_window_size.x, m_window_size.y, SWP_FRAMECHANGED);
	} else {
		if (m_window_fullscreen)	{
			::ShowCursor(TRUE);
		}
		m_window_size(width, height);
		m_window_fullscreen = false;
		::SetWindowLongPtrW(m_window_handler, GWL_STYLE, WS_OVERLAPPEDWINDOW | style);
		::SetWindowPos(m_window_handler, HWND_TOP, 0, 0, m_window_size.x, m_window_size.y, SWP_FRAMECHANGED);
	}

	framework.system->Log(
		"Resize window\t: %dx%d (%s)\n",
		m_window_size.x,
		m_window_size.y,
		m_window_fullscreen ? "m_window_fullscreen" : "windowed"
	);

	return 0;
}

//______________________________________________________________
Vector<int> Kernel::GetWindowSize()
{
	return m_window_size;
}

//______________________________________________________________
HDC	Kernel::GetDC()
{
	return m_window_DC;
}

//______________________________________________________________
LRESULT Kernel::OnCreate(MSG msg)
{
	m_window_handler = msg.hwnd;
	m_window_DC = ::GetDC(m_window_handler);
	framework.opengl->Create(m_window_DC);
	return 0;
}

//______________________________________________________________
LRESULT Kernel::OnDestroy(MSG msg)
{
	framework.opengl->Destroy();
	if (m_window_DC) {
		::ReleaseDC(m_window_handler, m_window_DC);
		m_window_DC = 0;
	}
	framework.system->Log("Window destroyed.\n");
	return 0;
}

//______________________________________________________________
LRESULT Kernel::OnSize(MSG msg)
{
	if (msg.wParam == SIZE_MINIMIZED) {
		m_window_minimized = true;
	} else {
		m_window_minimized = false;
		m_window_size(LOWORD(msg.lParam), HIWORD(msg.lParam));

		if (m_window_fullscreen) {
			m_mouse_position.x = m_screen_center.x = m_window_size.x >> 1;
			m_mouse_position.y = m_screen_center.y = m_window_size.y >> 1;
			::SetCursorPos(m_screen_center.x, m_screen_center.y);
		}

		framework.system->ExecuteString(
			"Window.width = %d;\n"
			"Window.height = %d;\n",
			m_window_size.x,
			m_window_size.y
		);

		framework.system->CallSubscribers(m_event_window_resized, "ii", m_window_size.x, m_window_size.y);
	}

	return 0;
}

//______________________________________________________________
LRESULT Kernel::OnClose(MSG msg)
{
	Quit();
	return 0;
}

//______________________________________________________________
LRESULT Kernel::OnSysCommand(MSG msg)
{
	if (msg.wParam == SC_SCREENSAVE) {
		return 0;
	} else {
		return ::DefWindowProc(m_window_handler, WM_SYSCOMMAND, msg.wParam, msg.lParam);
	}
}

//______________________________________________________________
LRESULT Kernel::OnActivate(MSG msg)
{
	if (LOWORD(msg.wParam) == WA_INACTIVE) {
		m_window_active = false;
		if (m_window_fullscreen) {
			::ShowCursor(TRUE);
		} else {
		}
	} else {
		m_window_active = true;
		if (m_window_fullscreen) {
			::ShowCursor(FALSE);
			::SetCursorPos(m_screen_center.x, m_screen_center.y);
		} else {
		}

	}
	return 0;
}

//______________________________________________________________
LRESULT Kernel::OnKeyboardEvent(MSG key_msg)
{
	static int last_key_code = 0;
	MSG char_msg;

	::TranslateMessage(&key_msg);
	::PeekMessage(&char_msg, 0, 0, 0, PM_NOREMOVE);

	if (char_msg.message == WM_CHAR) {
		::PeekMessage(&char_msg, 0, 0, 0, PM_REMOVE);
		int char_code = static_cast<int>(char_msg.wParam & 0xff);
		if (framework.system->CallSubscribers(m_event_framework_button, "ii", 0, char_code)) {
			return 0;
		}

		framework.system->CallSubscribers(m_event_application_button, "ii", 0, char_code);
	}

	const int key_up = 0x80000000;
	int key_code = static_cast<int>(key_msg.wParam & 0xff);

	if (key_msg.lParam & key_up) {
		m_buttons.remove(Button(1, key_code));
		last_key_code = 0;
	} else {
		if (key_code == last_key_code) { // so that keydown is registered only once!
			return 0;
		}

		last_key_code = key_code;
		double time = GetTime();
		m_buttons.push_back(Button(1, key_code, time));
	}
	return 0;
}

//______________________________________________________________
LRESULT Kernel::OnMouseEvent(MSG msg)
{
	if (msg.message == WM_MOUSEMOVE) {
		m_mouse_position(LOWORD(msg.lParam), HIWORD(msg.lParam));
		return 0;
	}

	double time = GetTime();
	double down_time = 0;
	int button_codes[] = {MK_LBUTTON, MK_RBUTTON, MK_MBUTTON};

	for (int i=0; i<3; i++) {
		if (msg.wParam & button_codes[i]) {
			m_buttons.push_back(Button(2, i, time));
		} else {
			m_buttons.remove(Button(2, i));
		}
	}
	return 0;
}

//______________________________________________________________
int Kernel::SetMouseSensitivity(double x, double y)
{
	m_mouse_sensitivity(x, y);
	return 0;
}

//______________________________________________________________
int Kernel::GetMouseMovement(double& x, double& y)
{
	x = m_mouse_movement.x;
	y = m_mouse_movement.y;
	m_mouse_movement(0);
	return 0;
}

//______________________________________________________________
int Kernel::OnButton(int key_type, int key_code, double key_time)
{
	if (key_type == 0) {
	} else if (key_type == 1) {
		if (key_time == 0) {
			switch (key_code) {
				case VK_ESCAPE: framework.system->ExecuteString("Quit();"); break;
				case 192: framework.console->Toggle(2); break;
				case VK_TAB: framework.overlay->Toggle(); break;
				case VK_F11: framework.opengl->ToggleVSync(); break;
				case VK_F7: SetTimeResolution(m_time_resolution * 2.0); break;
				case VK_F8: SetTimeResolution(m_time_resolution * 0.5); break;
				case VK_F9: SetTimeMultiplier(m_time_multiplier * 2.0); break;
				case VK_F10: SetTimeMultiplier(m_time_multiplier * 0.5); break;
				case VK_PAUSE: framework.kernel->Pause(); break;
				case VK_CONTROL: framework.opengl->SaveScreen(); break;
			}
		}
	}

	return 0;
}

//______________________________________________________________
int Kernel::Update()
{
	if (m_window_active) {
		for (std::list<Button>::iterator i = m_buttons.begin(); i != m_buttons.end(); i++) {
			double down_time = GetTime() - i->m_time;
			if (!framework.system->CallSubscribers(m_event_framework_button, "iid", i->m_type, i->m_code, down_time)) {
				framework.system->CallSubscribers(m_event_application_button, "iid", i->m_type, i->m_code, down_time);
			}
		}

		if (m_window_fullscreen) {
			m_mouse_movement.x += m_mouse_sensitivity.x * (m_mouse_position.x - m_screen_center.x);
			m_mouse_movement.y -= m_mouse_sensitivity.y * (m_mouse_position.y - m_screen_center.y);
			::SetCursorPos(m_screen_center.x, m_screen_center.y);
		}
	} else {
	}

	QueryPerformanceCounter(&m_counter_new);
	m_delta_time = static_cast<double>(m_counter_new.QuadPart - m_counter_old.QuadPart) / m_counter_frequency.QuadPart;

	if (m_delta_time > 0.1f) {
		m_delta_time = 0.1f;
	}

	m_absolute_time += m_delta_time;
	if (!m_paused) {
		m_virtual_delta_time += m_delta_time * m_time_multiplier;
	}

	m_counter_old = m_counter_new;
	m_time_accumulator += m_delta_time;
	if (m_time_accumulator > 0.1) {
		m_fps = m_frame_accumulator / m_time_accumulator;
		m_time_accumulator = 0;
		m_frame_accumulator = 0;
	}

	while (m_virtual_delta_time > m_time_resolution) {
			m_virtual_delta_time -= m_time_resolution;
			m_virtual_absolute_time += m_time_resolution;
			framework.system->CallSubscribers(m_event_simulate, "dd", m_virtual_absolute_time, m_time_resolution);
	}

	if (!m_window_minimized && m_window_active) {
		m_frame_accumulator++;
		framework.system->CallSubscribers(m_event_update, "dd", m_absolute_time, m_delta_time);

		if (framework.system->CallSubscribers(m_event_render, "dd", m_absolute_time, m_delta_time)) {
			::glClearColor(0, 0, 0, 0);
			::glClear(GL_COLOR_BUFFER_BIT);
		}

		if (framework.console->Render() == 0) {
			framework.overlay->Render();
		}

		framework.opengl->SwapBuffers();
	}

	return 0;
}

//______________________________________________________________
LRESULT CALLBACK Kernel::Dispatcher(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	MSG msg;
	
	msg.hwnd = hWnd;
	msg.message = uMsg;
	msg.wParam = wParam;
	msg.lParam = lParam;
	msg.time = 0;
	msg.pt.x = 0;
	msg.pt.y = 0;

	switch (msg.message) {
		case WM_CREATE: return framework.kernel->OnCreate(msg);
		case WM_DESTROY: return framework.kernel->OnDestroy(msg);
		case WM_CLOSE: return framework.kernel->OnClose(msg);
		case WM_SIZE: return framework.kernel->OnSize(msg);
		case WM_ACTIVATE: return framework.kernel->OnActivate(msg);
		case WM_SYSCOMMAND: return framework.kernel->OnSysCommand(msg);
		case WM_SYSKEYDOWN:
		case WM_SYSKEYUP:
		case WM_KEYDOWN:
		case WM_KEYUP: return framework.kernel->OnKeyboardEvent(msg);
		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_RBUTTONDOWN:
		case WM_RBUTTONUP:
		case WM_MBUTTONDOWN:
		case WM_MBUTTONUP:		
		case WM_MOUSEMOVE: return framework.kernel->OnMouseEvent(msg);
		case WM_COMPACTING:
		case WM_DEVMODECHANGE:
		case WM_TIMER:
		default: return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
}
//______________________________________________________________

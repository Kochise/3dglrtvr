//______________________________________________________________
#include "framework.h"
#include "system.h"
#include "overlay.h"
#include "kernel.h"
#include "opengl.h"

//______________________________________________________________
Overlay::Overlay() :
max_lines(4),
font_size(24),
font(0),
timeout(3),
active(true),
lines(max_lines),
stats(20)
{
}

//______________________________________________________________
int Overlay::Init()
{
	font = static_cast<IFont2D*>(framework.system->GetInterface("Font2D"));
	font->Create("Impact");
	framework.system->Subscribe("Overlay.SelectFont", Callback(this, SelectFont));
	return 0;
}

//______________________________________________________________
int Overlay::Toggle()
{
	active = !active;
	return 0;
}

//______________________________________________________________
int Overlay::Write(const char* str)
{
	if (!active) {
		return 0;
	}

	double time = framework.kernel->GetTime() + timeout;

	std::string s = str;
	std::string::size_type begin = 0;
	std::string::size_type end = 0;
	std::string::size_type length = s.length();

	while (end < length) {
		if (s[end] == '\n') {
			lines.pop_front();
			lines.push_back(entry(s.substr(begin, end), time));
			begin = end+1;
		}
		end++;
	}

	if (end-begin) {
		lines.pop_front();
		lines.push_back(entry(s.substr(begin, end), time));
	}

	return 0;
}

//______________________________________________________________
int Overlay::WriteStat(int row, const char* s)
{
	stats[row].assign(s);
	return 0;
}

//______________________________________________________________
int Overlay::Render()
{
	if (!active) {
		return 0;
	}

	Vector<int>	size;
	double time = framework.kernel->GetTime();
	size = framework.kernel->GetWindowSize();
	size.x /= font_size;
	size.y /= font_size;

	::glMatrixMode(GL_PROJECTION);
	::glPushMatrix();
	::glLoadIdentity();
	::glOrtho(0, size.x, 0, size.y, -1, +1);

	::glMatrixMode(GL_MODELVIEW);
	::glPushMatrix();
	::glLoadIdentity();
	::glTranslated(0, size.y-1, 0);
	::glColor4ub(255,255,255,0);

	for (int i=0; i<max_lines; i++) {
		std::string& s = lines[i].first;
		double t = lines[i].second;
		if (!s.empty()) {
			if (time > t) {
				s.clear();
			} else {
				font->Print("%s", s.c_str());
				::glTranslated(0, -1, 0);
			}
		}
	}

	// Print stats:
	::glLoadIdentity();
	::glTranslated(0, size.y-1, 0);
	::glColor4ub(255,255,255,0);

	for (int i=0; i<20; i++) {
		font->Print("%s", stats[i].c_str());
		::glTranslated(0, -1, 0);
	}


	//::glColor4ub(255,255,255,0);
	//::glLoadIdentity();
	//::glTranslated(size.x - 4, size.y-1, 0);
	//font->Print("%4.0fFPS", framework.kernel->GetFPS());

	::glPopMatrix();

	::glMatrixMode(GL_PROJECTION);
	::glPopMatrix();

	return 0;
}

//______________________________________________________________
int Overlay::SelectFont(const char* typeface)
{
	const char* default_font = "Impact";
	const char* selected_font = 0;

	if (typeface) {
		selected_font = typeface;
	} else {
		selected_font = default_font;
	}

	font->Create(selected_font); //, font_size);
	font->SetColor(1, 1, 1, 1);
	framework.system->Log("Overlay font changed to %s.\n", selected_font);

	return 0;
}

//______________________________________________________________

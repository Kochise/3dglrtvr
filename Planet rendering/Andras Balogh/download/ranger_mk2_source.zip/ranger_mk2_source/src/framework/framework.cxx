//______________________________________________________________
#include "configure.h"
#include "framework.h"
#include "generic.h"
#include "kernel.h"
#include "system.h"
#include "opengl.h"
#include "console.h"
#include "overlay.h"

Framework framework;

//______________________________________________________________
int main(int argc, char** argv)
{
	framework.Startup(argc, argv);
	return framework.kernel->Run();
}

//______________________________________________________________
Framework::Framework() :
kernel(0),
system(0),
opengl(0),
openal(0),
console(0),
overlay(0)
{
}

//______________________________________________________________
Framework::~Framework()
{
	Shutdown();
}

//______________________________________________________________
int Framework::Startup(int argc, char** argv)
{
	for (int i=0; i<argc; i++) {
		args.push_back(argv[i]);
	}

	static char built_in_script[] = 
		"System.Info();\n"
		"Display.SetMode(0, 0);\n"
		"Window.Create(0, 0, 0, 24);\n"
		"System.SetBasePath(\"Haller\");\n"
		"Console.SelectFont(\"Comic Sans MS\");\n"
		"Overlay.SelectFont(\"Verdana\");\n";

	kernel = new Kernel;
	system = new System;
	console = new Console;
	overlay = new Overlay;

	system->Log("Framework loaded (%s: %s %s)\n", BUILD_TYPE, __DATE__, __TIME__);

	system->Init();
	system->Subscribe("Event.Update", Callback(this, Init));

	opengl = static_cast<OpenGL*>(system->GetInterface("OpenGL"));
	openal = static_cast<IOpenAL*>(system->GetInterface("OpenAL"));
	kernel->Init();
	opengl->Init();
	console->Init();
	overlay->Init();

	if (system->ExecuteFile("scripts/main.lua")) {
		system->ExecuteString(built_in_script);
	}

	return 0;
}

//______________________________________________________________
int Framework::Init()
{
	static int frame = 0;

	switch (frame) {
		case 0: 
			frame++;
			break;
		case 1:
			frame++;
			break;
		case 2:
			if (args.size() == 2) {
				system->ExecuteFile(args[1].c_str());
				system->GetInterface("terrain.dll");
				system->ExecuteString("Terrain.Toggle(1)");
			}
			frame++;
			break;
		case 3:
			frame++;
			break;
		case 4:
			frame++;
			break;
		default:
			break;
	}

	return 0;
}

//______________________________________________________________
int Framework::Shutdown()
{
	release(overlay);
	release(console);
	release(kernel);
	system->Log("Framework closed.\n");
	release(system);
	return 0;
}

//______________________________________________________________

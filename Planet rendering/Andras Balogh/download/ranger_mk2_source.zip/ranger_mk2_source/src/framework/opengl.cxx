//______________________________________________________________
#include <stdlib.h>
#include <string.h>
#include <png.h>
#include "framework.h"
#include "system.h"
#include "kernel.h"
#include "opengl.h"
#include "generic.h"

//______________________________________________________________
void* Factory_OpenGL(ISystem* i_sys)
{
	static OpenGL instance;
	return &instance;
}

IOpenGL::~IOpenGL() {}

//______________________________________________________________
OpenGL::OpenGL() :
error(false),
m_save_screenshot(false),
m_vsync(0)
{
}

//______________________________________________________________
OpenGL::~OpenGL()
{
	Destroy();
}

//______________________________________________________________
int OpenGL::Init()
{
	m_event_rc_created = framework.system->GetEvent("Event.RenderContextCreated");
	m_event_rc_destroy = framework.system->GetEvent("Event.RenderContextDestroy");
	framework.system->Subscribe("OpenGL.ToggleVSync", Callback(this, ToggleVSync));
	framework.system->Subscribe("OpenGL.SetVSync", Callback(this, SetVSync));
	framework.system->Subscribe("OpenGL.ListExtensions", Callback(this, ListSupportedExtensions));
	framework.system->Subscribe("Event.WindowResized", Callback(this, OnWindowResized));
	return 0;
}

//______________________________________________________________
int OpenGL::Setup(int i_alpha, int i_depth, int i_stencil)
{
	DEVMODE	dm;
	::EnumDisplaySettings(0, ENUM_CURRENT_SETTINGS, &dm);
	color = dm.dmBitsPerPel;
	alpha = i_alpha;
	depth = i_depth;
	stencil = i_stencil;
	return 0;
}

//______________________________________________________________
int OpenGL::Create(HDC i_DC)
{
	DC = i_DC;

	PIXELFORMATDESCRIPTOR pfd;
	pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_SUPPORT_OPENGL | PFD_DRAW_TO_WINDOW | PFD_DOUBLEBUFFER | PFD_GENERIC_ACCELERATED;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = color;
	pfd.cRedBits = 0;
	pfd.cRedShift = 0;
	pfd.cGreenBits = 0;
	pfd.cGreenShift = 0;
	pfd.cBlueBits = 0;
	pfd.cBlueShift = 0;
	pfd.cAlphaBits = alpha;
	pfd.cAlphaShift = 0;
	pfd.cAccumBits = 0;
	pfd.cAccumRedBits = 0;
	pfd.cAccumGreenBits = 0;
	pfd.cAccumBlueBits = 0;
	pfd.cAccumAlphaBits = 0;
	pfd.cDepthBits = depth;
	pfd.cStencilBits = stencil;
	pfd.cAuxBuffers = 0;
	pfd.iLayerType = 0;
	pfd.bReserved = 0;
	pfd.dwLayerMask = 0;
	pfd.dwVisibleMask = 0;
	pfd.dwDamageMask = 0;

	int pf = ::ChoosePixelFormat(DC, &pfd);
	::DescribePixelFormat(DC, pf, sizeof(PIXELFORMATDESCRIPTOR), &pfd);

	//if (pfd.dwFlags && PFD_GENERIC_ACCELERATED) {
	//} else {
	//}

	::SetPixelFormat(DC, pf, &pfd);
	RC = ::wglCreateContext(DC);
	::wglMakeCurrent(DC, RC);

	framework.system->Log(
		"Bitplanes: %d color, %d alpha, %d depth, %d stencil\n", 
		pfd.cColorBits, 
		pfd.cAlphaBits, 
		pfd.cDepthBits, 
		pfd.cStencilBits
	);

	framework.system->Log(
		"OpenGL driver: %s %s %s\n",
		::glGetString(GL_VENDOR),
		::glGetString(GL_RENDERER),
		::glGetString(GL_VERSION)
	);

	int	glInfo(0);

	::glGetIntegerv(GL_MAX_TEXTURE_SIZE, &glInfo);
	framework.system->Log("Texture size: %d\n", glInfo);
	::glGetIntegerv(GL_MAX_TEXTURE_UNITS, &glInfo);
	framework.system->Log("Texture units: %d\n", glInfo);

	InitExtensions();

	SetVSync(m_vsync);

	m_screenshot = static_cast<IImage*>(framework.system->GetInterface("Image"));

	framework.system->CallSubscribers(m_event_rc_created);

	return 0;
}

//______________________________________________________________
int OpenGL::Destroy()
{
	framework.system->CallSubscribers(m_event_rc_destroy);

	if (RC) {
		::wglMakeCurrent(NULL, NULL);
		::wglDeleteContext(RC);
		RC = 0;
	}

	release(m_screenshot);

	return 0;
}

//______________________________________________________________
int OpenGL::InitExtensions()
{
	wglSwapInterval = (PFNWGLSWAPINTERVALEXTPROC) wglGetProcAddress("wglSwapIntervalEXT");
	glLoadTransposeMatrixf = (PFNGLLOADTRANSPOSEMATRIXFPROC) wglGetProcAddress("glLoadTransposeMatrixf");
	glLoadTransposeMatrixd = (PFNGLLOADTRANSPOSEMATRIXDPROC) wglGetProcAddress("glLoadTransposeMatrixd");
	glMultTransposeMatrixf = (PFNGLMULTTRANSPOSEMATRIXFPROC) wglGetProcAddress("glMultTransposeMatrixf");
	glMultTransposeMatrixd = (PFNGLMULTTRANSPOSEMATRIXDPROC) wglGetProcAddress("glMultTransposeMatrixd");
	glPointParameterf = (PFNGLPOINTPARAMETERFPROC) wglGetProcAddress("glPointParameterf");
	glActiveTexture = (PFNGLACTIVETEXTUREPROC) wglGetProcAddress("glActiveTexture");
	glMultiTexCoord4d = (PFNGLMULTITEXCOORD4DPROC) wglGetProcAddress("glMultiTexCoord4d");

	glDrawRangeElements = (PFNGLDRAWRANGEELEMENTSPROC) wglGetProcAddress("glDrawRangeElements");
	glTexImage3D = (PFNGLTEXIMAGE3DPROC) ::wglGetProcAddress("glTexImage3D");
	glTexSubImage3D = (PFNGLTEXSUBIMAGE3DPROC) ::wglGetProcAddress("glTexSubImage3D");
	glCopyTexSubImage3D = (PFNGLCOPYTEXSUBIMAGE3DPROC) ::wglGetProcAddress("glCopyTexSubImage3D");

	glBindBuffer = (PFNGLBINDBUFFERARBPROC) wglGetProcAddress("glBindBufferARB");
	glDeleteBuffers = (PFNGLDELETEBUFFERSARBPROC) wglGetProcAddress("glDeleteBuffersARB");
	glGenBuffers = (PFNGLGENBUFFERSARBPROC) wglGetProcAddress("glGenBuffersARB");
	glIsBuffer = (PFNGLISBUFFERARBPROC) wglGetProcAddress("glIsBufferARB");
	glBufferData = (PFNGLBUFFERDATAARBPROC) wglGetProcAddress("glBufferDataARB");
	glBufferSubData = (PFNGLBUFFERSUBDATAARBPROC) wglGetProcAddress("glBufferSubDataARB");
	glGetBufferSubData = (PFNGLGETBUFFERSUBDATAARBPROC) wglGetProcAddress("glGetBufferSubDataARB");
	glMapBuffer = (PFNGLMAPBUFFERARBPROC) wglGetProcAddress("glMapBufferARB");
	glUnmapBuffer = (PFNGLUNMAPBUFFERARBPROC) wglGetProcAddress("glUnmapBufferARB");
	glGetBufferParameteriv = (PFNGLGETBUFFERPARAMETERIVARBPROC) wglGetProcAddress("glGetBufferParameterivARB");
	glGetBufferPointerv = (PFNGLGETBUFFERPOINTERVARBPROC) wglGetProcAddress("glGetBufferPointervARB");

	return 0;
}

//______________________________________________________________
int OpenGL::ListSupportedExtensions()
{
	framework.system->Log("Extensions\t:\n");

	GLubyte *extensions = new GLubyte[strlen((char *)glGetString(GL_EXTENSIONS))+1];
	strcpy((char *)extensions, (char *)glGetString(GL_EXTENSIONS));

	unsigned int	a = 0;
	unsigned int	z = 0;

	for (z=0; extensions[z] != '\0'; z++) {
		if (extensions[z] == ' ') {
			extensions[z] = '\0';
			framework.system->Log("\t%s\n", (char *)&extensions[a]);
			extensions[z] = ' ';
			a = z+1;
		}
	}

	delete [] extensions;

	wglGetExtensionsString = (PFNWGLGETEXTENSIONSSTRINGARBPROC) wglGetProcAddress("wglGetExtensionsStringARB");

	extensions = new GLubyte[strlen((char *)wglGetExtensionsString(DC))+1];
	strcpy((char *)extensions, (char *)wglGetExtensionsString(DC));

	a = 0;
	for (z=0; extensions[z] != '\0'; z++) {
		if (extensions[z] == ' ') {
			extensions[z] = '\0';
			framework.system->Log("\t%s\n", (char *)&extensions[a]);
			extensions[z] = ' ';
			a = z+1;
		}
	}

	delete [] extensions;
	return 0;
}

//______________________________________________________________
bool OpenGL::CheckError()
{
	error = false;

	char* error_strings[7] = {
		"invalid enum",
		"invalid value",
		"invalid operation",
		"stack overflow",
		"stack underflow",
		"out of memory",
		"unknown error"
	};

	int error_index;

	while (GLenum error_code = ::glGetError() != GL_NO_ERROR) {
		switch (error_code) {
			case GL_INVALID_ENUM:		error_index = 0; break;
			case GL_INVALID_VALUE:		error_index = 1; break;
			case GL_INVALID_OPERATION:	error_index = 2; break;
			case GL_STACK_OVERFLOW:		error_index = 3; break;
			case GL_STACK_UNDERFLOW:	error_index = 4; break;
			case GL_OUT_OF_MEMORY:		error_index = 5; break;
			default:					error_index = 6; break;
		}

		framework.system->Log("OpenGL Error: %s\n", error_strings[error_index]);
		error = true;
	}

	assert(error == false);

	return error;
}

//______________________________________________________________
int OpenGL::SwapBuffers()
{
	if (m_save_screenshot) {
		SaveBMP();
		m_save_screenshot = false;
	}

	if (!error) {
		CheckError();
	}
	::SwapBuffers(DC);
	return 0;
}

//______________________________________________________________
bool OpenGL::IsExtensionSupported(const char *string)
{
	unsigned int	a = 0;
	unsigned int	z = 0;
	bool		result = false;

	GLubyte* extensions = new GLubyte[strlen((char *)glGetString(GL_EXTENSIONS))+1];
	strcpy((char *)extensions, (char *)glGetString(GL_EXTENSIONS));
	
	for (z=0; extensions[z] != '\0'; z++) {
		if (extensions[z] == ' ') {
			extensions[z] = '\0';

			if (!strcmp(string, (char *)&extensions[a])) {
				result = true;
			}
			extensions[z] = ' ';
			a = z+1;
		}
	}

	delete [] extensions;
	return result;
}

//______________________________________________________________
int OpenGL::SetVSync(int vsync)
{
	if (wglSwapInterval) {
		wglSwapInterval(vsync);
	}

	m_vsync = vsync;
	framework.system->Log("OpenGL: Vertical Synchronization is %s.\n", vsync ? "ON" : "OFF");
	return 0;
}

//______________________________________________________________
int OpenGL::ToggleVSync()
{
	if (wglSwapInterval) {
		if (m_vsync) {
			m_vsync = 0;
		} else {
			m_vsync = 1;
		}
	}
	SetVSync(m_vsync);
	return 0;
}

//______________________________________________________________
int OpenGL::ResetTextureUnits()
{
	::glMatrixMode(GL_TEXTURE);

	for (int i=0; i<4; i++) {
		glActiveTexture(GL_TEXTURE0 + i);
		::glLoadIdentity();
		::glDisable(GL_TEXTURE_GEN_S);
		::glDisable(GL_TEXTURE_GEN_T);
		::glDisable(GL_TEXTURE_GEN_R);
		::glDisable(GL_TEXTURE_GEN_Q);
		::glDisable(GL_TEXTURE_3D);
		::glDisable(GL_TEXTURE_2D);
		::glDisable(GL_TEXTURE_1D);
		::glDisable(GL_TEXTURE_RECTANGLE_NV);
	}

	glActiveTexture(GL_TEXTURE0);

	::glMatrixMode(GL_MODELVIEW);

	return 0;
}

//______________________________________________________________
int OpenGL::LoadTexture(const char* path)
{
	GLint iformat[] = {GL_ALPHA, GL_LUMINANCE_ALPHA, GL_RGB, GL_RGBA};
//	GLint iformat[] = {GL_COMPRESSED_ALPHA, GL_COMPRESSED_LUMINANCE_ALPHA, GL_COMPRESSED_RGB, GL_COMPRESSED_RGBA};
	GLint format[] = {GL_ALPHA, GL_LUMINANCE_ALPHA, GL_RGB, GL_RGBA};
	GLenum type[] = {GL_UNSIGNED_BYTE, GL_UNSIGNED_SHORT, GL_UNSIGNED_INT};

	IImage* img = static_cast<IImage*>(framework.system->GetInterface("Image"));
	if (img->Load(path) == -1) {
		return -1;
	}
	IImage::Dimensions dim = img->GetDimensions();
	char* d = img->GetData();

	if (d != 0) {
		if (dim.depth > 1 ) {
			glTexImage3D(GL_TEXTURE_3D, 0, iformat[dim.channels-1], dim.width, dim.height, dim.depth, 0, format[dim.channels-1], type[(dim.bpc >> 3) - 1], d);
		} else if (dim.height > 1) {
			::glTexImage2D(GL_TEXTURE_2D, 0, iformat[dim.channels-1], dim.width, dim.height, 0, format[dim.channels-1], type[(dim.bpc >> 3) - 1], d);
		} else if (dim.width >= 1) {
			::glTexImage1D(GL_TEXTURE_1D, 0, iformat[dim.channels-1], dim.width, 0, format[dim.channels-1], type[(dim.bpc >> 3) - 1], d);
		}

	}

	release(img);
	return 0;
}

//______________________________________________________________
int OpenGL::OnWindowResized(int width, int height)
{
	m_window_size.x = width;
	m_window_size.y = height;
	::glViewport(0, 0, m_window_size.x, m_window_size.y);
	IImage::Dimensions dim;
	dim.width = width;
	dim.height = height;
	dim.depth = 1;
	dim.channels = 3;
	dim.bpc = 8;
	m_screenshot->Create(dim);
	return 0;
}

//______________________________________________________________
int OpenGL::SaveScreen()
{
	m_save_screenshot = true;
	return 0;
}

//______________________________________________________________
int OpenGL::SaveBMP()
{
	static int file_number = 0;
	char filename[25];
	FILE* f = 0;

	for(;;) {
		sprintf(filename, "screenshots/scr%5.5d.bmp", file_number);
		f = fopen(filename, "rb");
		if (f == 0) {
			break;
		}
		fclose(f);
		file_number++;
	}

	::glReadPixels(0, 0, m_window_size.x, m_window_size.y, GL_BGR, GL_UNSIGNED_BYTE, m_screenshot->GetData());

	m_screenshot->Save(filename);
	framework.system->Log("Screenshot %s saved.\n", filename);

	return 0;
}

//______________________________________________________________
void OpenGL::LoadTransposeMatrixf(const float* m)
{
	if (glLoadTransposeMatrixf != 0) {
		glLoadTransposeMatrixf(m);
	}
}

//______________________________________________________________
void OpenGL::LoadTransposeMatrixd(const double* m)
{
	if (glLoadTransposeMatrixd != 0) {
		glLoadTransposeMatrixd(m);
	}
}

//______________________________________________________________
void OpenGL::MultTransposeMatrixf(const float* m)
{
	if (glMultTransposeMatrixf != 0) {
		glMultTransposeMatrixf(m);
	}
}

//______________________________________________________________
void OpenGL::MultTransposeMatrixd(const double* m)
{
	if (glMultTransposeMatrixd != 0) {
		glMultTransposeMatrixd(m);
	}
}

//______________________________________________________________
void OpenGL::ActiveTexture(GLenum texture)
{
	if (glActiveTexture != 0) {
		glActiveTexture(texture);
	}
}

//______________________________________________________________
GLvoid OpenGL::GenTextures(GLsizei n, GLuint *textures)
{
	::glGenTextures(n, textures);
}

//______________________________________________________________
GLvoid OpenGL::DeleteTextures(GLsizei n, const GLuint *textures)
{
	::glDeleteTextures(n, textures);
}

//______________________________________________________________
GLvoid OpenGL::BindTexture(GLenum target, GLuint texture)
{
	::glBindTexture(target, texture);
}

//______________________________________________________________
GLvoid OpenGL::TexEnvf(GLenum target, GLenum pname, GLfloat param)
{
	::glTexEnvf(target, pname, param);
}

//______________________________________________________________
GLvoid OpenGL::TexEnvfv(GLenum target, GLenum pname, const GLfloat *params)
{
	::glTexEnvfv(target, pname, params);
}

//______________________________________________________________
GLvoid OpenGL::TexEnvi(GLenum target, GLenum pname, GLint param)
{
	::glTexEnvi(target, pname, param);
}

//______________________________________________________________
GLvoid OpenGL::TexEnviv(GLenum target, GLenum pname, const GLint *params)
{
	::glTexEnviv(target, pname, params);
}

//______________________________________________________________
GLvoid OpenGL::TexGend(GLenum coord, GLenum pname, GLdouble param)
{
	::glTexGend(coord, pname, param);
}

//______________________________________________________________
GLvoid OpenGL::TexGendv(GLenum coord, GLenum pname, const GLdouble *params)
{
	::glTexGendv(coord, pname, params);
}

//______________________________________________________________
GLvoid OpenGL::TexGenf(GLenum coord, GLenum pname, GLfloat param)
{
	::glTexGenf(coord, pname, param);
}

//______________________________________________________________
GLvoid OpenGL::TexGenfv(GLenum coord, GLenum pname, const GLfloat *params)
{
	::glTexGenfv(coord, pname, params);
}

//______________________________________________________________
GLvoid OpenGL::TexGeni(GLenum coord, GLenum pname, GLint param)
{
	::glTexGeni(coord, pname, param);
}

//______________________________________________________________
GLvoid OpenGL::TexGeniv(GLenum coord, GLenum pname, const GLint *params)
{
	::glTexGeniv(coord, pname, params);
}

//______________________________________________________________
GLvoid OpenGL::TexImage1D(GLenum target, GLint level, GLint internalformat, GLsizei width, GLint border, GLenum format, GLenum type, const GLvoid *pixels)
{
	::glTexImage1D(target, level, internalformat, width, border, format, type, pixels);
}

//______________________________________________________________
GLvoid OpenGL::TexImage2D(GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const GLvoid *pixels)
{
	::glTexImage2D(target, level, internalformat, width, height, border, format, type, pixels);
}

//______________________________________________________________
GLvoid OpenGL::TexParameterf(GLenum target, GLenum pname, GLfloat param)
{
	::glTexParameterf(target, pname, param);
}

//______________________________________________________________
GLvoid OpenGL::TexParameterfv(GLenum target, GLenum pname, const GLfloat *params)
{
	::glTexParameterfv(target, pname, params);
}

//______________________________________________________________
GLvoid OpenGL::TexParameteri(GLenum target, GLenum pname, GLint param)
{
	::glTexParameteri(target, pname, param);
}

//______________________________________________________________
GLvoid OpenGL::TexParameteriv(GLenum target, GLenum pname, const GLint *params)
{
	::glTexParameteriv(target, pname, params);
}

//______________________________________________________________
GLvoid OpenGL::TexSubImage1D(GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLenum type, const GLvoid *pixels)
{
	::glTexSubImage1D(target, level, xoffset, width, format, type, pixels);
}

//______________________________________________________________
GLvoid OpenGL::TexSubImage2D(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels)
{
	::glTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, pixels);
}

//______________________________________________________________
void OpenGL::DrawRangeElements(GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const GLvoid *indices)
{
	if (glDrawRangeElements != 0) {
		glDrawRangeElements(mode, start, end, count, type, indices);
	}

}

//______________________________________________________________
GLvoid OpenGL::BindBuffer(GLenum target, GLuint buffer)
{
	if (glBindBuffer != 0) {
		glBindBuffer(target, buffer);
	}
}

//______________________________________________________________
GLvoid OpenGL::DeleteBuffers(GLsizei n, const GLuint *buffers)
{
	if (glDeleteBuffers != 0) {
		glDeleteBuffers(n, buffers);
	}
}

//______________________________________________________________
GLvoid OpenGL::GenBuffers(GLsizei n, GLuint *buffers)
{
	if (glGenBuffers != 0) {
		glGenBuffers(n, buffers);
	}
}

//______________________________________________________________
GLboolean OpenGL::IsBuffer(GLuint buffer)
{
	if (glIsBuffer != 0) {
		return glIsBuffer(buffer);
	} else {
		return false;
	}
}

//______________________________________________________________
GLvoid OpenGL::BufferData(GLenum target, GLsizeiptr size, const GLvoid *data, GLenum usage)
{
	if (glBufferData != 0) {
		glBufferData(target, size, data, usage);
	}
}

//______________________________________________________________
GLvoid OpenGL::BufferSubData(GLenum target, GLintptr offset, GLsizeiptr size, const GLvoid *data)
{
}

//______________________________________________________________
GLvoid OpenGL::GetBufferSubData(GLenum target, GLintptr offset, GLsizeiptr size, GLvoid *data)
{
}

//______________________________________________________________
GLvoid* OpenGL::MapBuffer(GLenum target, GLenum access)
{
	if (glMapBuffer != 0) {
		return glMapBuffer(target, access);
	} else {
		return 0;
	}
}

//______________________________________________________________
GLboolean OpenGL::UnmapBuffer(GLenum target)
{
	if (glUnmapBuffer != 0) {
		return glUnmapBuffer(target);
	} else {
		return true;
	}
}

//______________________________________________________________
GLvoid OpenGL::GetBufferParameteriv(GLenum target, GLenum pname, GLint *params)
{
//	glGetBufferParameteriv(target, pname, params);
}

//______________________________________________________________
GLvoid OpenGL::GetBufferPoGLinterv(GLenum target, GLenum pname, GLvoid **params)
{
//	glGetBufferPoGLinterv(target, pname, params);
}

//______________________________________________________________
GLvoid OpenGL::Enable(GLenum cap)
{
	::glEnable(cap);
}

//______________________________________________________________
GLvoid OpenGL::EnableClientState(GLenum array)
{
	::glEnableClientState(array);
}

//______________________________________________________________
GLvoid OpenGL::Begin(GLenum mode)
{
	::glBegin(mode);
}

//______________________________________________________________
GLvoid OpenGL::End(void)
{
	::glEnd();
}

//______________________________________________________________
GLvoid OpenGL::BlendFunc(GLenum sfactor, GLenum dfactor)
{
	::glBlendFunc(sfactor, dfactor);
}

//______________________________________________________________
GLvoid OpenGL::Clear(GLbitfield mask)
{
	::glClear(mask);
}

//______________________________________________________________
GLvoid OpenGL::ClearAccum(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha)
{
	::glClearAccum(red, green, blue, alpha);
}

//______________________________________________________________
GLvoid OpenGL::ClearColor(GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha)
{
	::glClearColor(red, green, blue, alpha);
}

//______________________________________________________________
GLvoid OpenGL::ClearDepth(GLclampd depth)
{
	::glClearDepth(depth);
}

//______________________________________________________________
GLvoid OpenGL::ClearIndex(GLfloat c)
{
	::glClearIndex(c);
}

//______________________________________________________________
GLvoid OpenGL::ClearStencil(GLint s)
{
	::glClearStencil(s);
}

//______________________________________________________________
GLvoid OpenGL::Color4ub(GLubyte red, GLubyte green, GLubyte blue, GLubyte alpha)
{
	::glColor4ub(red, green, blue, alpha);
}

//______________________________________________________________
GLvoid OpenGL::Color4d(GLdouble red, GLdouble green, GLdouble blue, GLdouble alpha)
{
	::glColor4d(red, green, blue, alpha);
}

//______________________________________________________________
GLvoid OpenGL::Disable(GLenum cap)
{
	::glDisable(cap);
}

//______________________________________________________________
GLvoid OpenGL::DisableClientState(GLenum array)
{
	::glDisableClientState(array);
}

//______________________________________________________________
GLvoid OpenGL::DepthFunc(GLenum func)
{
	::glDepthFunc(func);
}

//______________________________________________________________
GLvoid OpenGL::DepthMask(GLboolean flag)
{
	::glDepthMask(flag);
}

//______________________________________________________________
GLvoid OpenGL::DepthRange(GLclampd zNear, GLclampd zFar)
{
	::glDepthRange(zNear, zFar);
}

//______________________________________________________________
GLvoid OpenGL::Fogf(GLenum pname, GLfloat param)
{
	::glFogf(pname, param);
}

//______________________________________________________________
GLvoid OpenGL::Fogfv(GLenum pname, const GLfloat *params)
{
	::glFogfv(pname, params);
}

//______________________________________________________________
GLvoid OpenGL::Fogi(GLenum pname, GLint param)
{
	::glFogi(pname, param);
}

//______________________________________________________________
GLvoid OpenGL::Fogiv(GLenum pname, const GLint *params)
{
	::glFogiv(pname, params);
}

//______________________________________________________________
GLvoid OpenGL::FrontFace(GLenum mode)
{
	::glFrontFace(mode);
}

//______________________________________________________________
GLvoid OpenGL::PolygonMode(GLenum face, GLenum mode)
{
	::glPolygonMode(face, mode);
}

//______________________________________________________________
GLvoid OpenGL::PolygonOffset(GLfloat factor, GLfloat units)
{
	::glPolygonOffset(factor, units);
}

//______________________________________________________________
GLvoid OpenGL::PolygonStipple(const GLubyte *mask)
{
	::glPolygonStipple(mask);
}

//______________________________________________________________
GLvoid OpenGL::Color4f(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha)
{
	::glColor4f(red, green, blue, alpha);
}

//______________________________________________________________
GLvoid OpenGL::Color4fv(const GLfloat *v)
{
	::glColor4fv(v);
}

//______________________________________________________________
GLvoid OpenGL::CullFace(GLenum mode)
{
	::glCullFace(mode);
}

//______________________________________________________________
GLvoid OpenGL::CopyTexImage1D(GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLint border)
{
	::glCopyTexImage1D(target, level, internalFormat, x, y, width, border);
}

//______________________________________________________________
GLvoid OpenGL::CopyTexImage2D(GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border)
{
	::glCopyTexImage2D(target, level, internalFormat, x, y, width, height, border);
}

//______________________________________________________________
GLvoid OpenGL::CopyTexSubImage1D(GLenum target, GLint level, GLint xoffset, GLint x, GLint y, GLsizei width)
{
	::glCopyTexSubImage1D(target, level, xoffset, x, y, width);
}

//______________________________________________________________
GLvoid OpenGL::CopyTexSubImage2D(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height)
{
	::glCopyTexSubImage2D(target, level, xoffset, yoffset, x, y, width, height);
}

//______________________________________________________________
GLvoid OpenGL::Vertex4f(GLfloat x, GLfloat y, GLfloat z, GLfloat w)
{
	::glVertex4f(x, y, z, w);
}

//______________________________________________________________
GLvoid OpenGL::Vertex4fv(const GLfloat *v)
{
	::glVertex4fv(v);
}

//______________________________________________________________
GLvoid OpenGL::Vertex4dv(const GLdouble *v)
{
	::glVertex4dv(v);
}

//______________________________________________________________
GLvoid OpenGL::TexCoord4f(GLfloat s, GLfloat t, GLfloat r, GLfloat q)
{
	::glTexCoord4f(s, t, r, q);
}

//______________________________________________________________
GLvoid OpenGL::MatrixMode(GLenum mode)
{
	::glMatrixMode(mode);
}

//______________________________________________________________
GLvoid OpenGL::PopMatrix(void)
{
	::glPopMatrix();
}

//______________________________________________________________
GLvoid OpenGL::PushMatrix(void)
{
	::glPushMatrix();
}

//______________________________________________________________
GLvoid OpenGL::VertexPointer(GLint size, GLenum type, GLsizei stride, const GLvoid* pointer)
{
	::glVertexPointer(size, type, stride, pointer);
}

//______________________________________________________________
GLvoid OpenGL::LoadIdentity(void)
{
	::glLoadIdentity();
}

//______________________________________________________________



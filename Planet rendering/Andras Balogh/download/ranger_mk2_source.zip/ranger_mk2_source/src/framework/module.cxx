//______________________________________________________________
#include "framework.h"
#include "system.h"
#include "module.h"

//______________________________________________________________
Module::Module(): 
handler(0),
factory(0)
{}

//______________________________________________________________
Module::~Module()
{ 
	Release();
}

//______________________________________________________________
void Module::SetFactory(TFactory i_factory)
{
	factory = i_factory;
}

//______________________________________________________________
void* Module::GetObject(const char* path)
{
	ISystem* isys = static_cast<ISystem*>(framework.system);

	if (factory) {
		return factory(isys);
	}

	handler = ::LoadLibrary(path);
	if (handler == 0) {
		isys->Log("Error: loading module %s failed.\n", path);
		return 0;
	}

	factory = (TFactory)GetProcAddress(handler, "Factory");

	if (factory == 0) {
		isys->Log("Error: invalid module format in %s.\n", path);
		Release();
		return 0;
	}

	return factory(isys);
}

//______________________________________________________________
void Module::Release()
{
	if (handler) {
		::FreeLibrary(handler);
		handler = 0;
	}
	factory = 0;
}

//______________________________________________________________

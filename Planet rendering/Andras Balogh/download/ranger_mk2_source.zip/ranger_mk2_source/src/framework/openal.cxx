//______________________________________________________________
#include <windows.h>
#include <mmreg.h>
#include <msacm.h>
#include <al.h>
#include <alc.h>
#include <cassert>
#include <cstdio>
#include "framework.h"
#include "system.h"

//______________________________________________________________
class OpenAL :
public IOpenAL
{
private:
	ALCdevice* ADC;
	ALCcontext* ARC;
	ALuint buffers[64];
	ALuint sources[64];
public:
	OpenAL();
	~OpenAL();
	int Play();
	int CheckErrors();
	int LoadMP3(const char* path, int secs);
	int EnumACMDrivers();
	static BOOL ACMDriverEnumCallback(HACMDRIVERID driver_id, DWORD_PTR user_data, DWORD support);
};

//______________________________________________________________
void* Factory_OpenAL(ISystem* i_sys)
{
	static OpenAL instance;
	return &instance;
}

IOpenAL::~IOpenAL() {}

//______________________________________________________________
OpenAL::OpenAL()
{
	ADC = ::alcOpenDevice(0);
	ARC = ::alcCreateContext(ADC, 0);
	::alcMakeContextCurrent(ARC);
	assert(ARC == ::alcGetCurrentContext());
	assert(ADC == ::alcGetContextsDevice(ARC));
//	::alcProcessContext(ARC);

	int result[64];
	::alcGetIntegerv(ADC, ALC_MAJOR_VERSION, 64, &result[0]);
	::alcGetIntegerv(ADC, ALC_MINOR_VERSION, 63, &result[1]);

	framework.system->Log("OpenAL v%d.%d device: %s\n", result[0], result[1], ::alcGetString(ADC, ALC_DEFAULT_DEVICE_SPECIFIER));

	framework.system->Subscribe("Sound.EnumACM", Callback(this, EnumACMDrivers));
	framework.system->Subscribe("Sound.LoadMP3", Callback(this, LoadMP3));
	framework.system->Subscribe("Sound.Play", Callback(this, Play));
	::alListenerf(AL_GAIN, 0.5f);

	//ALfloat position[] = {0.0f, 0.0f, 0.0f};
	//ALfloat velocity[] = {0.0f, 0.0f, 0.0f};
	//ALfloat orientation[] = {0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f};
//	::alListenerfv(AL_POSITION, position);
//	::alListenerfv(AL_VELOCITY, velocity);
//	::alListenerfv(AL_ORIENTATION, orientation);

	::alGenSources(1, sources);
	assert(::alIsSource(sources[0]) == AL_TRUE);
}

//______________________________________________________________
OpenAL::~OpenAL()
{
	if (::alIsSource(sources[0]) == AL_TRUE) {
		::alDeleteSources(1, sources);
	}
	if (::alIsBuffer(buffers[0]) == AL_TRUE) {
		::alDeleteBuffers(1, buffers);
	}

	::alcSuspendContext(ARC);
	::alcMakeContextCurrent(0);
	::alcDestroyContext(ARC);
	::alcCloseDevice(ADC);
}

//______________________________________________________________
int OpenAL::CheckErrors()
{
	switch (::alcGetError(ADC)) {
		case ALC_NO_ERROR: framework.system->Log("No Error\n");					break;
		case ALC_INVALID_DEVICE: framework.system->Log("Invalid device.\n");		break;
		case ALC_INVALID_CONTEXT: framework.system->Log("Invalid context\n");	break;
		case ALC_INVALID_ENUM: framework.system->Log("Invalid enum\n");			break;
		case ALC_INVALID_VALUE: framework.system->Log("Invalid value\n");		break;
		default: break;
	}
	return 0;
}

//______________________________________________________________
inline int bits(unsigned char c, int lo, int hi){return ((c >> lo) & (0xff >> (7 - (hi - lo))));}
inline int bit(unsigned char c, int p){return ((c >> p) & (0xff >> (8 - p)));}

//______________________________________________________________
int OpenAL::LoadMP3(const char* path, int secs)
{
	static const int bitrate_table[][16] = {
		{0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, -1},	// MPEG 1, layer 1
		{0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, -1},	// MPEG 1, layer 2
		{0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, -1},		// MPEG 1, layer 3
		{0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, -1},	// MPEG 2, layer 1
		{0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, -1}			// MPEG 2, layer 2-3
	};

	static const int frequency_table[][4] = {
		{44100, 48000, 32000 , -1},	// MPEG 1
		{22050, 24000, 16000 , -1}	// MPEG 2
	};

	static const int bitrate_indexer[2][3] = {
		{0, 1, 2},
		{3, 4, 4}
	};

	unsigned char mpeg_header[4];

	FILE* f = fopen(path, "rb");
	if (f == 0) {
		return 0;
	}
	fread(mpeg_header, 1, sizeof(mpeg_header), f);
	fclose(f);

	if (mpeg_header[0] != 0xff) {
		return 0;
	}

	if (bits(mpeg_header[1], 4, 7) != 0x0f) {
		return 0;
	}

	int version = (bit(mpeg_header[1], 3)) ? 1 : 2;
	int layer;
	switch (bits(mpeg_header[1], 1, 2)) {
		case 1: layer = 3; break;
		case 2: layer = 2; break;
		case 3: layer = 1; break;
		default: return 0;
	}

	int CRC = bit(mpeg_header[1], 1);
	int	bitrate = bitrate_table[bitrate_indexer[version-1][layer-1]][bits(mpeg_header[2], 4, 7)];
	int frequency = frequency_table[version-1][bits(mpeg_header[2], 2, 3)];
	int padding = bit(mpeg_header[2], 1);
	int channels = bits(mpeg_header[3], 6, 7) == 3 ? 1 : 2;
	framework.system->Log("%s: MPEG %d Layer %d, %dkbps, %dHz, %s\n", path, version, layer, bitrate, frequency, channels == 1 ? "mono": "stereo");

	WAVEFORMATEX wfx_mp3;
	wfx_mp3.wFormatTag = WAVE_FORMAT_MPEGLAYER3;
	wfx_mp3.nChannels = channels;
	wfx_mp3.nSamplesPerSec = frequency;
	wfx_mp3.wBitsPerSample = 0;
	wfx_mp3.nBlockAlign = 1152;
	wfx_mp3.nAvgBytesPerSec = bitrate*(1000/8);
	wfx_mp3.cbSize = MPEGLAYER3_WFX_EXTRA_BYTES;

	MPEGLAYER3WAVEFORMAT mp3;
	mp3.wfx = wfx_mp3;
	mp3.wID = MPEGLAYER3_ID_MPEG;
	mp3.fdwFlags = MPEGLAYER3_FLAG_PADDING_ISO;
	mp3.nBlockSize = 1152;
	mp3.nCodecDelay = 0;	// 1393?
	mp3.nFramesPerBlock = 1;

	WAVEFORMATEX pcm;
	pcm.wFormatTag = WAVE_FORMAT_PCM;
	pcm.nChannels = channels;
	pcm.nSamplesPerSec = frequency;
	pcm.wBitsPerSample = 16;
	pcm.nBlockAlign	= 2*channels;
	pcm.nAvgBytesPerSec = frequency*channels*2;
	pcm.cbSize = 0;

	if (::acmStreamOpen(0, 0, (WAVEFORMATEX*)&mp3, &pcm, 0, 0, 0, ACM_STREAMOPENF_QUERY)) { // | ACM_STREAMOPENF_NONREALTIME)) {
		return 0;
	}

	HACMSTREAM	stream;

	::acmStreamOpen(&stream, 0, (WAVEFORMATEX*)&mp3, &pcm, 0, 0, 0, 0); //ACM_STREAMOPENF_NONREALTIME);
	f = fopen(path, "rb");
	fseek(f, 0, SEEK_END);
	int source_length = ftell(f);
	fseek(f, 0, SEEK_SET);
	unsigned char* source_buffer = new unsigned char[source_length];
	int destination_length = frequency*channels*2*secs;
	unsigned char* destination_buffer = new unsigned char[destination_length];
	fread(source_buffer, 1, source_length, f);
	fclose(f);

	ACMSTREAMHEADER	header;
	header.cbStruct = sizeof(header);
	header.fdwStatus = 0;
	header.dwUser = 0;
	header.pbSrc = (BYTE*)source_buffer;
	header.cbSrcLength = source_length;
	header.cbSrcLengthUsed = 0;
	header.dwSrcUser = 0;
	header.pbDst = (BYTE*)destination_buffer;
	header.cbDstLength = destination_length;
	header.cbDstLengthUsed = 0;
	header.dwDstUser = 0;

	::acmStreamPrepareHeader(stream, &header, 0);
	::acmStreamConvert(stream, &header, ACM_STREAMCONVERTF_BLOCKALIGN);
	::acmStreamClose(stream, 0);
	delete [] source_buffer;

	if (::alIsBuffer(buffers[0]) == AL_TRUE) {
		::alDeleteBuffers(1, buffers);
	}
	::alGenBuffers(1, buffers);
	assert(::alIsBuffer(buffers[0]) == AL_TRUE);
	::alBufferData(buffers[0], channels == 1 ? AL_FORMAT_MONO16 : AL_FORMAT_STEREO16, destination_buffer, header.cbDstLengthUsed, frequency);
	delete [] destination_buffer;

	return 0;
}

//______________________________________________________________
int OpenAL::Play()
{
	::alSourcei(sources[0], AL_BUFFER, buffers[0]);
	::alSourcei(sources[0], AL_LOOPING, FALSE);
	::alSourcePlay(sources[0]);

//	::alcProcessContext(ARC);
	return 0;
}

//______________________________________________________________
BOOL OpenAL::ACMDriverEnumCallback(HACMDRIVERID driver_id, DWORD_PTR, DWORD support)
{
	//if (support & ACMDRIVERDETAILS_SUPPORTF_ASYNC)
	//if (support & ACMDRIVERDETAILS_SUPPORTF_CODEC)
	//if (support & ACMDRIVERDETAILS_SUPPORTF_CONVERTER)
	//if (support & ACMDRIVERDETAILS_SUPPORTF_DISABLED)
	//if (support & ACMDRIVERDETAILS_SUPPORTF_FILTER)

	ACMDRIVERDETAILS details;
	details.cbStruct = sizeof(ACMDRIVERDETAILS);
	details.fccType = ACMDRIVERDETAILS_FCCTYPE_AUDIOCODEC;
	details.fccComp = ACMDRIVERDETAILS_FCCCOMP_UNDEFINED;
	details.wMid = 0;
	details.wPid = 0;

	::acmDriverDetails(driver_id, &details, 0);
	framework.system->Log("%s (version %d.%d.%d)\n",
		details.szLongName,
		details.vdwDriver >> 24,
		(details.vdwDriver >> 16) & 0xff,
		details.vdwDriver & 0xffff
	);
	framework.system->Log("%s\n", details.szFeatures);
	framework.system->Log("%s\n", details.szCopyright);
	framework.system->Log("%s\n", details.szLicensing);
	framework.system->Log("\n");

	return TRUE;
}

//______________________________________________________________
int OpenAL::EnumACMDrivers()
{
	framework.system->Log("Enumerating ACM drivers:\n");

	HRESULT err = ::acmDriverEnum((ACMDRIVERENUMCB)ACMDriverEnumCallback, 0, ACM_DRIVERENUMF_DISABLED | ACM_DRIVERENUMF_NOLOCAL);

	__asm { // make the compiler save these registers, as some driver might be broken
		mov eax, eax
		mov ebx, ebx
		mov ecx, ecx
		mov edx, edx
		mov esi, esi
		mov edi, edi
	}
	return 0;
}

//______________________________________________________________

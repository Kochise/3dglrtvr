#pragma once
#include <deque>
#include "generic.h"

class Overlay
{
private:
	const int max_lines;
	const int font_size;
	const int timeout;
	IFont2D* font;
	typedef std::pair<std::string, double>	entry;
	std::deque<entry> lines;
	std::deque<std::string> stats;
	bool active;
public:
	Overlay();
	int Init();
	int SelectFont(const char* typeface);
	int Toggle();			// Toggle overlay On/Off
	int Write(const char* s);	// Write string to pager
	int WriteStat(int row, const char* s);	// Write statistics
	int Render();			// Render overlay
};

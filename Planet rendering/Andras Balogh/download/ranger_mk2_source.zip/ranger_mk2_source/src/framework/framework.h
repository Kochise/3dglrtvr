//______________________________________________________________
#pragma once
#include "i_framework.h"
#include <string>
#include <vector>

class Kernel;
class System;
class OpenGL;
class IOpenAL;
class Console;
class Overlay;

class Framework
{
public:
	std::vector<std::string> args;

	Kernel* kernel;
	System* system;
	OpenGL* opengl;
	IOpenAL* openal;
	Console* console;
	Overlay* overlay;

public:
	Framework();
	~Framework();

	int Startup(int argc, char** argv);
	int Init();
	int Shutdown();
};

extern Framework framework;
//______________________________________________________________
#pragma once
#include "module.h"
#include <map>
#include <list>
#include <vector>
#include <string>
#include <fstream>
#include <cstdarg>
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

//______________________________________________________________
class System : 
public ISystem
{
private:
	typedef std::list<Callback> type_subscriber_list;
	typedef std::vector<type_subscriber_list> type_event_vector;
	typedef std::map<std::string, int> type_event_map;
	type_event_map event_map;
	type_event_vector event_vector;
	lua_State* L;

	std::map<std::string, Module> modules;
	std::string base_path;
	std::fstream journal;

public:
	System();
	~System();
	void Init();
	float GetFPS();
	void Log(char* string);
	void Log(const char* format, ... );
	void OverlayNote(const char* format, ... );
	void OverlayWrite(int row, const char* format, ... );
	int SetBasePath(const char* path);
	void* GetInterface(const char* path);
	char* Load(const char* path);
	void GetMouseMovement(double& x, double& y);
	void PrepareBuffer(const char* format);
	int Call(Callback& c);
	int GetEvent(const char* key);
	int Subscribe(const char* key, Callback callback);
	void Unsubscribe(const char* key, Callback callback);
	void UnsubscribeAll(const char* key);
	int CallSubscribers(int event);
	int CallSubscribers(int event, const char* format, ... );
	int ExecuteFile(const char* path);
	int ExecuteString(const char* format, ...);
	int GetGlobal(const char* key);
	double GetGlobalNumber(const char* key);
	const char* GetGlobalString(const char* key);
	void GetGlobals(const char* keys, const char* format, ... );
	void AutoComplete(std::string& cmd);
	void DumpStack(int i, int depth);
	void DumpStack(int index);
	void DumpStack();
//	int CheckLuaError(int error_code);
	static int LuaHook(lua_State* L);
	int Exec(const char* error);
};

//______________________________________________________________
extern TFactory Factory_OpenGL;
extern TFactory Factory_OpenAL;
extern TFactory Factory_Image;
extern TFactory Factory_Font2D;
extern TFactory Factory_Font3D;

//______________________________________________________________

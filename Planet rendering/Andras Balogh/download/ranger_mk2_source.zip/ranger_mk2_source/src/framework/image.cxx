//______________________________________________________________
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <png.h>
#include <cstring>
#include "i_framework.h"
#include "generic.h"

//______________________________________________________________
class Image :
public IImage
{
private:
	IImage::Dimensions m_dimensions;
	int m_data_size;
	char* m_image;
public:
	Image();
	~Image();
	int Create(IImage::Dimensions d);
	int ProcessImage(ImageProc fp, void* ptr);
	int ProcessLine(int line, ImageProc fp, void* ptr);
	int CreateGradient(IImage* src_image, float scale);
	int Load(const char* path);
	int LoadInfo(const char* path);
	int Save(const char* path);
	Dimensions GetDimensions();
	char* GetData();
	int GetPixel(int c, int x, int y = 0, int z = 0);
	int SetPixel(int v, int c, int x, int y = 0, int z = 0);

private:
	int Load(const char* path, bool info);

	int Load_BMP(FILE* f, bool info);
	int Load_TGA(FILE* f, bool info);
	int Load_PNG(FILE* f, bool info);
	int Load_JPEG(FILE* f, bool info);

	int Save_BMP(FILE* f);
	int Save_TGA(FILE* f);
	int Save_PNG(FILE* f);
	int Save_JPEG(FILE* f);
};

//______________________________________________________________
void* Factory_Image(ISystem* i_sys)
{
	return new Image();
}

//______________________________________________________________
IImage::~IImage() {}

//______________________________________________________________
Image::Image() :
m_data_size(0),
m_image(0)
{
	m_dimensions.width = 0;
	m_dimensions.height = 0;
	m_dimensions.depth = 0;
	m_dimensions.channels = 1;
	m_dimensions.bpc = 8;
}

//______________________________________________________________
Image::~Image()
{
	releasev(m_image);
}

//______________________________________________________________
int Image::Create(IImage::Dimensions d)
{
	d.width = max(d.width, 1);
	d.height = max(d.height, 1);
	d.depth = max(d.depth, 1);
	d.channels = clamp(d.channels, 1, 4);
	d.bpc &= (8 | 16 | 32);
	m_data_size = d.width * d.height * d.depth * d.channels * (d.bpc >> 3);
	m_dimensions = d;
	releasev(m_image);
	m_image = new char[m_data_size];
	return m_data_size;
}

//______________________________________________________________
int Image::GetPixel(int c, int x, int y, int z)
{
	int cx = m_dimensions.width;
	int cy = m_dimensions.height;

	x += x < 0 ? cx : 0;
	x -= x >= cx ? cx : 0;

	y += y < 0 ? cy : 0;
	y -= y >= cy ? cy : 0;

	z = 0;

	int component_size = (m_dimensions.bpc >> 3);
	int pixel_size =  component_size * m_dimensions.channels;
	int line_size = m_dimensions.width * pixel_size;
	int page_size = m_dimensions.height * line_size;
	int position = z*page_size + y*line_size + x*pixel_size + c*component_size;

	int result = 0;

	if (component_size == 1) {
		u8* p = (u8*)(m_image + position);
		result = *p;
	} else if (component_size == 2) {
		u16* p = (u16*)(m_image + position);
		result = *p;
	} else {
	}

	return result;
}

//______________________________________________________________
int Image::SetPixel(int v, int c, int x, int y, int z)
{
	int cx = m_dimensions.width;
	int cy = m_dimensions.height;

	x += x < 0 ? cx : 0;
	x -= x >= cx ? cx : 0;

	y += y < 0 ? cy : 0;
	y -= y >= cy ? cy : 0;

	z = 0;

	int component_size = (m_dimensions.bpc >> 3);
	int pixel_size =  component_size * m_dimensions.channels;
	int line_size = m_dimensions.width * pixel_size;
	int page_size = m_dimensions.height * line_size;
	int position = z*page_size + y*line_size + x*pixel_size + c*component_size;

	int result = 0;

	if (component_size == 1) {
		u8* p = (u8*)(m_image + position);
		result = *p;
		*p = v;
	} else if (component_size == 2) {
		u16* p = (u16*)(m_image + position);
		result = *p;
		*p = v;
	} else {
	}

	return result;
}

//______________________________________________________________
int Image::ProcessImage(ImageProc fp, void* ptr)
{
	char* d = m_image;
	for (int z=0; z<m_dimensions.depth; z++) {
		for (int y=0; y<m_dimensions.height; y++) {
			for (int x=0; x<m_dimensions.width; x++) {
				for (int c=0; c<m_dimensions.channels; c++) {
					if (m_dimensions.bpc == 8) {
						u8* v = (u8*)d;
						*v = fp(c, x, y, z, *v, ptr);
						v++;
						d = (char*)v;
					} else if (m_dimensions.bpc == 16) {
						u16* v = (u16*)d;
						*v = fp(c, x, y, z, *v, ptr);
						v++;
						d = (char*)v;
					} else if (m_dimensions.bpc == 32) {
						u32* v = (u32*)d;
						*v = fp(c, x, y, z, *v, ptr);
						v++;
						d = (char*)v;
					}
				}
			}
		}
	}

	return 0;
}

//______________________________________________________________
int Image::ProcessLine(int line, ImageProc fp, void* ptr)
{
	char* d = m_image;

	int line_size = (m_dimensions.bpc >> 3) * m_dimensions.channels * m_dimensions.width;
	int number_of_lines = m_data_size / line_size;
	d += line_size * line;

	int z = line / m_dimensions.height;
	int y = line % m_dimensions.height;

	for (int x=0; x<m_dimensions.width; x++) {
		for (int c=0; c<m_dimensions.channels; c++) {
			if (m_dimensions.bpc == 8) {
				u8* v = (u8*)d;
				*v = fp(c, x, y, z, *v, ptr);
				v++;
				d = (char*)v;
			} else if (m_dimensions.bpc == 16) {
				u16* v = (u16*)d;
				*v = fp(c, x, y, z, *v, ptr);
				v++;
				d = (char*)v;
			} else if (m_dimensions.bpc == 32) {
				u32* v = (u32*)d;
				*v = fp(c, x, y, z, *v, ptr);
				v++;
				d = (char*)v;
			}
		}
	}

	return number_of_lines - line - 1;
}

//______________________________________________________________
int Image::Load(const char* path)
{
	return Load(path, false);
}

//______________________________________________________________
int Image::LoadInfo(const char* path)
{
	return Load(path, true);
}

//______________________________________________________________
int Image::Load(const char* path, bool info)
{
	int l = static_cast<int>(strlen(path));
	FILE* f = 0;

	if (!strcmp(path + l - 4, ".png")) {
		f = fopen(path, "rb");
		if (f != 0) {
			Load_PNG(f, info);
		}
	} else if (!strcmp(path + l - 4, ".bmp")) {
		f = fopen(path, "rb");
		if (f != 0) {
			Load_BMP(f, info);
		}
	} else if (!strcmp(path + l - 4, ".tga")) {
		f = fopen(path, "rb");
		if (f != 0) {
			Load_TGA(f, info);
		}
	} else if (!strcmp(path + l - 4, ".jpg")) {
		f = fopen(path, "rb");
		if (f != 0) {
			Load_JPEG(f, info);
		}
	} else if (!strcmp(path + l - 5, ".jpeg")) {
		f = fopen(path, "rb");
		if (f != 0) {
			Load_JPEG(f, info);
		}
	}

	if (f != 0) {
		fclose(f);
		m_data_size = m_dimensions.width * m_dimensions.height * m_dimensions.depth * m_dimensions.channels * (m_dimensions.bpc >> 3);
		return 0;
	} else {
		return -1;
	}
}

//______________________________________________________________
int Image::Save(const char* path)
{
	int l = static_cast<int>(strlen(path));
	FILE* f = 0;

	if (!strcmp(path + l - 4, ".png")) {
		f = fopen(path, "wb");
		if (f != 0) {
			Save_PNG(f);
		}
	} else if (!strcmp(path + l - 4, ".bmp")) {
		f = fopen(path, "wb");
		if (f != 0) {
			Save_BMP(f);
		}
	} else if (!strcmp(path + l - 4, ".tga")) {
		f = fopen(path, "wb");
		if (f != 0) {
			Save_TGA(f);
		}
	} else if (!strcmp(path + l - 4, ".jpg")) {
		f = fopen(path, "wb");
		if (f != 0) {
			Save_JPEG(f);
		}
	} else if (!strcmp(path + l - 5, ".jpeg")) {
		f = fopen(path, "wb");
		if (f != 0) {
			Save_JPEG(f);
		}
	}

	if (f != 0) {
		fclose(f);
	}

	return 0;
}

//______________________________________________________________
int Image::Save_BMP(FILE* f)
{
	BITMAPFILEHEADER bmfh;
	BITMAPINFOHEADER bmih;
	int header_size = sizeof(BITMAPFILEHEADER) + sizeof (BITMAPINFOHEADER);
	int file_size = m_data_size + header_size;

	bmfh.bfType = ('M' << 8) | ('B');
	bmfh.bfSize = file_size;
	bmfh.bfReserved1 = 0;
	bmfh.bfReserved2 = 0;
	bmfh.bfOffBits = header_size;
	bmih.biSize = sizeof(BITMAPINFOHEADER);
	bmih.biWidth = m_dimensions.width;
	bmih.biHeight = m_dimensions.height;
	bmih.biPlanes = 1;
	bmih.biBitCount = m_dimensions.bpc * m_dimensions.channels;
	bmih.biCompression = BI_RGB;
	bmih.biSizeImage = 0;
	bmih.biXPelsPerMeter = 0;
	bmih.biYPelsPerMeter = 0;
	bmih.biClrUsed = 0;
	bmih.biClrImportant = 0;

	fwrite(&bmfh, sizeof(BITMAPFILEHEADER), 1, f);
	fwrite(&bmih, sizeof(BITMAPINFOHEADER), 1, f);
	fwrite(m_image, m_data_size, 1, f);
	return 0;
}

//______________________________________________________________
int Image::Save_TGA(FILE* f)
{
	return 0;
}

//______________________________________________________________
int Image::Save_PNG(FILE* f)
{
	png_structp png = png_create_write_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);
	png_infop pngi = png_create_info_struct(png);
	png_init_io(png, f);

	int row_size = m_dimensions.width * m_dimensions.channels * (m_dimensions.bpc >> 3);
	char* row = m_image;
	int color_type[] = {PNG_COLOR_TYPE_GRAY, PNG_COLOR_TYPE_GRAY_ALPHA, PNG_COLOR_TYPE_RGB, PNG_COLOR_TYPE_RGBA};
	png_set_IHDR(png, pngi, m_dimensions.width, m_dimensions.height, m_dimensions.bpc, color_type[m_dimensions.channels-1], PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
	png_write_info(png, pngi);

	if (m_dimensions.bpc == 16) {
		png_set_swap(png);
	}

	for (int y=0; y<m_dimensions.height; y++) {
		png_write_row(png, (png_bytep)row);
		row += row_size;
	}

	png_write_end(png, 0);
	png_destroy_write_struct(&png, &pngi);
	fclose(f);
	return 0;
}

//______________________________________________________________
int Image::Save_JPEG(FILE* f)
{
	return 0;
}

//______________________________________________________________
int Image::Load_BMP(FILE* f, bool info)
{
	return 0;
}

//______________________________________________________________
int Image::Load_TGA(FILE* f, bool info)
{
	return 0;
}

//______________________________________________________________
int Image::Load_PNG(FILE* f, bool info)
{
	png_structp png = png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);
	png_infop pngi = png_create_info_struct(png);
	png_init_io(png, f);
	png_read_info(png, pngi);

	int color_type;
	int interlace_type;
	int compression_type;
	int filter_type;

	png_get_IHDR(png, pngi, (png_uint_32*)&m_dimensions.width, (png_uint_32*)&m_dimensions.height, &m_dimensions.bpc, &color_type, &interlace_type, &compression_type, &filter_type);
	m_dimensions.depth = 1;

	switch (color_type) {
		case PNG_COLOR_TYPE_GRAY: m_dimensions.channels = 1;	break;
		case PNG_COLOR_TYPE_GRAY_ALPHA:	m_dimensions.channels = 2; break;
		case PNG_COLOR_TYPE_RGB: m_dimensions.channels = 3; break;
		case PNG_COLOR_TYPE_RGBA: m_dimensions.channels = 4; break;
	}

	if (m_dimensions.bpc == 16) {
		png_set_swap(png);
	}

	if (!info) {
		int row_size = m_dimensions.width * m_dimensions.channels * (m_dimensions.bpc >> 3);

		releasev(m_image);
		m_image = new char[m_dimensions.height * row_size];
		char* row = m_image;

		for (int y=0; y<m_dimensions.height; y++) {
			png_read_row(png, (png_bytep)row, 0);
			row += row_size;
		}
		png_read_end(png, 0);
	}

	png_destroy_read_struct(&png, &pngi, 0);
	return 0;
}

//______________________________________________________________
int Image::Load_JPEG(FILE* f, bool info)
{
	return 0;
}

//______________________________________________________________
IImage::Dimensions Image::GetDimensions()
{
	return m_dimensions;
}

//______________________________________________________________
char* Image::GetData()
{
	return m_image;
}

//______________________________________________________________
int Image::CreateGradient(IImage* src_image, float scale)
{
	Image* s = (Image*)src_image;

	for (int i=0; i<m_dimensions.width; i++) {
		for (int j=0; j<m_dimensions.height; j++) {
			int o = s->GetPixel(0, i, j);
			float h = scale * (s->GetPixel(0, i+1, j) - o) + 128.0f;
			float v = scale * (s->GetPixel(0, i, j+1) - o) + 128.0f;
			h = clamp(h, 0.0f, 255.0f);
			v = clamp(v, 0.0f, 255.0f);
			SetPixel((unsigned char)h, 1, i, j);
			SetPixel((unsigned char)v, 2, i, j);
		}
	}
	return 0;
}

//______________________________________________________________

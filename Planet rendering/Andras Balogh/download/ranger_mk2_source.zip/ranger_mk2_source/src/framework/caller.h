#include "i_framework.h"

//______________________________________________________________
class Caller
{
private:
	int valnum;
	int* values;
	char* types;
public:
	Caller();
	~Caller();
	int Create(lua_State* L);
	int Call(Callback& c);
	static char* ParseType(const char* name);
};

//______________________________________________________________

#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "i_framework.h"

class Module
{
private:
	typedef void* (*TFactory)(ISystem* sys);
	HINSTANCE handler;
	TFactory factory;
public:
	Module();
	~Module();
	void SetFactory(TFactory i_factory);
	void* GetObject(const char* path);
	void Release();
};

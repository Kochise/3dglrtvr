#pragma once

class Main
{
public:
		Main();
		~Main();
	void	init( int argc, char **argv );
	void	kill();
	int	run();
};


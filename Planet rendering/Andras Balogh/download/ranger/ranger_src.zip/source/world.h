#ifndef	__WORLD_H__
#define	__WORLD_H__

#include "math.h"
#include "terrain.h"
#include "hud.h"
#include "player.h"
#include "ball.h"

class World
{
private:
	Terrain*	m_terrain;
	HUD*		m_hud;
	Player*		m_player;
	Ball*		m_ball;
public:
			World();
			~World();
	void		update();
	void		render();
	Player*		getPlayer() { return m_player; }
	Terrain*	getTerrain() { return m_terrain; }
	HUD*		getHUD() { return m_hud; }
	Ball*		getBall() { return m_ball; }
	bool		m_normals;
	bool		m_flat;
	bool		m_multitexture;

};

extern World* world;

#endif
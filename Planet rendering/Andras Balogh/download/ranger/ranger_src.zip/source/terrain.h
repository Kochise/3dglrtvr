#ifndef	__TERRAIN_H__
#define	__TERRAIN_H__

#include "def.h"
#include "image.h"
#include "math.h"
#include "player.h"

class Terrain;

class Terrain
{
private:
	Image*	groundtex;
	Image*	watertex;
	Image*	cloudtex;
	f32*	ground;
	f32*	water;
	f32*	cloud;
	u16*	gIndex;

	void	render_sun();
	void	render_sky();
	void	render_ground();
	void	render_water();
	void	render_normals();
	void	render_frustum();

public:
	Terrain();
	~Terrain();

	void	update();
	void	render();

	f32	getHeight( f64 x, f64 z );
	void	getNormal( f64 x, f64 z, v3d& normal );
	f32	get_distance(v3d& i_position);
};

#endif

//______________________________________________________________
#include <windows.h>
#include "timer.h"

//______________________________________________________________
Timer::Timer
()
{
	reset();
	return;
}

//______________________________________________________________
Timer::~Timer
()
{
	return;
}

//______________________________________________________________
void 
Timer::reset
()
{
	paused		= false;
	frames		= 0;
	time		= 0;
	dt		= 0;
	fps		= 0;
	acc_time	= 0;
	acc_frames	= 0;
	meta_time	= 0;

	QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&old_time);
	return;
}

//______________________________________________________________
void 
Timer::update
()
{
	QueryPerformanceCounter(&new_time);
	dt = (f32)(new_time.QuadPart - old_time.QuadPart) / freq.QuadPart;
	meta_time += dt;
	frames++;

	acc_time += dt;
	acc_frames++;

	if (acc_time > 0.1) {
		fps = acc_frames / acc_time;
		acc_time = 0;
		acc_frames = 0;
	}

	if (!paused) {
		time += dt;
	}

	old_time = new_time;
	return;
}

//______________________________________________________________
void 
Timer::pause
()
{
	paused = !paused;
	return;
}

//______________________________________________________________

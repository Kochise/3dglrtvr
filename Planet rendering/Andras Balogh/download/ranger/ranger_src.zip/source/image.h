#pragma once

#include "def.h"
#include "opengl.h"

class Image
{
private:
	u16	width;
	u16	height;
	u16	bpp;
	GLuint	htext;
	GLubyte	*text;
	GLenum	format;
	bool	isTexture;
public:
	Image();
	Image(Image &image);
	~Image();
	void load(u16 width, u16 height, u8 *data);
	void loadBMP(const char *path);
	void loadTGA(const char *path);
	void loadDEF();
	void createTexture();
	void destroyTexture();
	void bind(GLint env = GL_REPLACE, GLint wrap = GL_REPEAT, GLint minfilter = GL_LINEAR_MIPMAP_LINEAR, GLint magfilter = GL_LINEAR);
	void free();
	GLubyte *dump();
};


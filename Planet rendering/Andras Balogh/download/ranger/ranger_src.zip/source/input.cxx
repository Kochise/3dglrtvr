//______________________________________________________________
#include <windows.h>
#include <memory.h>
#include "input.h"

//______________________________________________________________
Input::Input()
{
	m_move.set(0.0f);
	memset(m_keyboard, 0, 256);
	memset(m_mouse, 0, 3);
	active = false;
	SetCursorPos(256, 256);
	return;
}

//______________________________________________________________
Input::~Input()
{
	return;
}

//______________________________________________________________
void 
Input::update
()
{
	if (!active) return;

	POINT	cursor;
	
	GetCursorPos(&cursor);

	m_move[0] += cursor.x-256;
	m_move[2] += cursor.y-256;

	SetCursorPos(256, 256);

	return;
}

//______________________________________________________________
void 
Input::getMove
(
	v3f& move
)
{
	move = m_move;
	m_move.set(0.0f);
	return;
}

//______________________________________________________________
void 
Input::keydown
(
	u8 i
)
{
	m_keyboard[i] |= 0x01;
	return;
}

//______________________________________________________________
void 
Input::keyup
(
	u8 i
)
{
	m_keyboard[i] = 0x00;
	return;
}

//______________________________________________________________
bool 
Input::keyd
(
	u8 i
)
{
	if (m_keyboard[i]) {
		m_keyboard[i] |= 0x02;
		return true;
	} else {
		return false;
	}
}

//______________________________________________________________
bool 
Input::keyp
(
	u8 i
)
{
	if (m_keyboard[i] == 0x01) {
		m_keyboard[i] |= 0x02;
		return true;
	} else {
		return false;
	}
}

//______________________________________________________________
void 
Input::buttondown
(
	u8 i
)
{
	m_mouse[i] |= 0x01;
	return;
}

//______________________________________________________________
void 
Input::buttonup
(
	u8 i
)
{
	m_mouse[i] = 0x00;
	return;
}

//______________________________________________________________
bool 
Input::buttond
(
	u8 i
)
{
	if (m_mouse[i]) {
		m_mouse[i] |= 0x02;
		return true;
	} else {
		return false;
	}
}

//______________________________________________________________
bool 
Input::buttonp
(
	u8 i
)
{
	if (m_mouse[i] == 0x01) {
		m_mouse[i] |= 0x02;
		return true;
	} else {
		return false;
	}
}

//______________________________________________________________
bool
Input::toggle
()
{
	if (active) {
	} else {
		SetCursorPos(256, 256);
		m_move.set(0.0f);
	}
	
	active = !active;

	return active;
}

//______________________________________________________________

#pragma once

#include <windows.h>

class Window
{
private:
	HINSTANCE	m_hInstance;
	HWND		m_hWnd;
	HDC		m_hDC;
	HGLRC		m_hRC;
	int		m_width;
	int		m_height;
	int		m_color;
	int		m_depth;
	int		m_stencil;
	int		m_alpha;
	bool		m_fullscreen;

public:
		Window();
		~Window();
	void	create(int width, int height, bool fullscreen);
	void	destroy();
	void	resize();
	void	swapbuffers();
	void	sysinfo();
	static LRESULT CALLBACK dispatcher(HWND	hWnd, UINT uMsg, WPARAM wParam,	LPARAM lParam);
};

extern Window* window;


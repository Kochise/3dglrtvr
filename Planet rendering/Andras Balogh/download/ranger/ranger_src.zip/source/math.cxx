//______________________________________________________________
#include "console.h"
#include "opengl.h"
#include "math.h"
using namespace Math;

//______________________________________________________________
Matrix::Matrix(u32 n)
{
	n = n ? n : 1;
	this->n = n;
	nn = n*n;
	data = new f64[nn];
	return;
}

//______________________________________________________________
Matrix::Matrix(Matrix &m)
{
	n = m.n;
	nn = m.nn;
	data = new f64[nn];
	for (u32 i=0; i<nn; i++) data[i] = m.data[i];
	return;
}

//______________________________________________________________
Matrix::~Matrix()
{
	delete [] data;
	return;
}

//______________________________________________________________
f64& Matrix::cell(u32 i, u32 j)
{
	return data[i*n+j];
}

//______________________________________________________________
f64* Matrix::dump()
{
	return data;
}

//______________________________________________________________
Matrix& Matrix::load(f64 f)
{
	for (u32 i=0; i<nn; i++) data[i] = f;
	return *this;
}

//______________________________________________________________
Matrix& Matrix::load(f64 *m)
{
	for (u32 i=0; i<nn; i++) data[i] = m[i];
	return *this;
}

//______________________________________________________________
Matrix& Matrix::load(Matrix &m)
{
	if (n != m.n) {
		n = m.n;
		nn = m.nn;
		delete [] data;
		data = new f64[nn];
	}

	for (u32 i=0; i<nn; i++) data[i] = m.data[i];
	return *this;
}

//______________________________________________________________
Matrix& Matrix::identity()
{
	for (u32 i=0; i<n; i++) {
		for (u32 j=0; j<n; j++) {
			cell(i,j) = (i==j ? 1.0f : 0.0f);
		}
	}

	return *this;
}

//______________________________________________________________
Matrix& Matrix::add(f64 f)
{
	for (u32 i=0; i<nn; i++) data[i] += f;
	return *this;
}

//______________________________________________________________
Matrix& Matrix::add(Matrix &m)
{
	if (n != m.n) return *this;

	for (u32 i=0; i<n; i++) {
		for (u32 j=0; j<n; j++) {
			cell(i,j) += m.cell(i,j);
		}
	}

	return *this;
}

//______________________________________________________________
Matrix& Matrix::multiply(f64 f)
{
	for (u32 i=0; i<nn; i++) data[i] *= f;
	return *this;
}

//______________________________________________________________
Matrix& Matrix::multiply(Matrix &m)
{
	if (n != m.n) return *this;

	Matrix	t(*this);
	for (u32 i=0; i<n; i++) {
		for (u32 j=0; j<n; j++) {
			cell(i,j) = 0;
			for (u32 k=0; k<n; k++) {
				cell(i,j) += t.cell(i,k) * m.cell(k,j);
			}
		}
	}

	return *this;
}

//______________________________________________________________
f64 *Matrix::multiply(f64 *v)
{
	f64	*t = new f64[n];

	for (u32 i=0; i<n; i++) {
		t[i] = 0;
		for (u32 k=0; k<n; k++) {
			t[i] += cell(i,k) * v[k];
		}
	}

	for (i=0; i<n; i++) {
		v[i] = t[i];
	}

	return v;
}

//______________________________________________________________
v3d& Matrix::multiply(v3d& u)
{
	v3d	t;

	for (u32 i=0; i<3; i++) {
		t[i] = cell(i, 3);
		for (u32 k=0; k<3; k++) {
			t[i] += cell(i,k) * u[k];
		}
	}

	u = t;

	return u;
}

//______________________________________________________________
void Matrix::transform(f32* u, u32 n)
{
	v3f	t;
	f32	w;

	for (u32 l=0; l<n; l++) {
		for (u32 i=0; i<3; i++) {
			t[i] = cell(i, 3);
			for (u32 k=0; k<3; k++) {
				t[i] += cell(i,k) * u[k];
			}
		}
		w = u[0]*cell(3, 0) + u[1]*cell(3, 1) + u[2]*cell(3, 2) + cell(3, 3);
		
		u[0] = t[0] / w;
		u[1] = t[1] / w;
		u[2] = t[2] / w;
		u += 3;
	}
	return;
}

//______________________________________________________________
Matrix& Matrix::addRow(u32 i1, u32 i2, f64 f)
{
	f64	*p1 = &data[i1*n];
	f64	*p2 = &data[i2*n];

	for (u32 j=0; j<n; j++) {
		*p1++ += *p2++ * f;
	}

	return *this;
}

//______________________________________________________________
Matrix& Matrix::addCol(u32 j1, u32 j2, f64 f)
{
	f64	*p1 = &data[j1];
	f64	*p2 = &data[j2];

	for (u32 i=0; i<n; i++) {
		*p1 += *p2 * f;
		p1 += n;
		p2 += n;
	}

	return *this;
}

//______________________________________________________________
Matrix& Matrix::swpRow(u32 i1, u32 i2)
{
	f64	*p1 = &data[i1*n];
	f64	*p2 = &data[i2*n];
	f64	t;

	for (u32 j=0; j<n; j++) {
		t = *p1;
		*p1++ = *p2;
		*p2++ = t;
	}


	return *this;
}

//______________________________________________________________
Matrix& Matrix::swpCol(u32 j1, u32 j2)
{
	f64	*p1 = &data[j1];
	f64	*p2 = &data[j2];
	f64	t;

	for (u32 i=0; i<n; i++) {
		t = *p1;
		*p1 = *p2;
		*p2 = t;
		p1 += n;
		p2 += n;
	}


	return *this;
}

//______________________________________________________________
Matrix& Matrix::transpose()
{
	for (u32 i=1; i<n; i++) {
		for (u32 j=0; j<i; j++) {
			f64 t = cell(i,j);
			cell(i,j) = cell(j,i);
			cell(j,i) = t;
		}
	}
	return *this;
}

//______________________________________________________________
Matrix& Matrix::fastinvert()
{
	for (u32 i=1; i<3; i++) {
		for (u32 j=0; j<i; j++) {
			f64 t = cell(i,j);
			cell(i,j) = cell(j,i);
			cell(j,i) = t;
		}
	}

	f64	*m = data;
	f64	t3, t7, t11;

	t3  = - (m[3]*m[0] + m[7]*m[1] + m[11]*m[ 2]);
	t7  = - (m[3]*m[4] + m[7]*m[5] + m[11]*m[ 6]);
	t11 = - (m[3]*m[8] + m[7]*m[9] + m[11]*m[10]);

	m[3] = t3;
	m[7] = t7;
	m[11] = t11;
	
	return *this;
}

//______________________________________________________________
Matrix& Matrix::invert()
{
	u32	i;
	u32	k;
	f64	f;
	Matrix	m(n);

	m.identity();

	for (i=0; i<n; i++) {
		for (k=i; k<n && fabs(cell(k,i)) < Math::EPS; k++);
		if (k == n) {
			identity();
			console->write("ERROR (Matrix::invert): singular matrix!\n");
			return *this;
		}

		swpRow(i,k);
		m.swpRow(i,k);

		f = cell(i,i);

		addRow(i, i, 1/f-1);
		m.addRow(i, i, 1/f-1);

		for (k=i+1; k<n; k++) {
			f = cell(k,i);
			addRow(k, i, -f);
			m.addRow(k, i, -f);
		}
	}

	for (i=n-1; i; i--) {
		for (k=i-1; k<i; k--) {
			f = cell(k,i);
			addRow(k, i, -f);
			m.addRow(k, i, -f);
		}
	}

	load(m);
	
	return *this;
}

//______________________________________________________________
Matrix& Matrix::scale(v3d u)
{
	Matrix	t(4);
	f64	*m = t.data;

	m[ 0] = u[0];	m[ 1] = 0;	m[ 2] = 0;	m[ 3] = 0;
	m[ 4] = 0;	m[ 5] = u[1];	m[ 6] = 0;	m[ 7] = 0;
	m[ 8] = 0;	m[ 9] = 0;	m[10] = u[2];	m[11] = 0;
	m[12] = 0;	m[13] = 0;	m[14] = 0;	m[15] = 1;

	multiply(t);
	return *this;
}

//______________________________________________________________
Matrix& Matrix::translate(v3d u)
{
	Matrix	t(4);
	f64	*m = t.data;

	m[ 0] = 1;	m[ 1] = 0;	m[ 2] = 0;	m[ 3] = u[0];
	m[ 4] = 0;	m[ 5] = 1;	m[ 6] = 0;	m[ 7] = u[1];
	m[ 8] = 0;	m[ 9] = 0;	m[10] = 1;	m[11] = u[2];
	m[12] = 0;	m[13] = 0;	m[14] = 0;	m[15] = 1;

	multiply(t);
	return *this;
}

//______________________________________________________________
Matrix& Matrix::rotate(Quaternion& q)
{
	f64 x, y, z, w;
	q.getH(x, y, z, w);

	f64 xx = 2*x*x;
	f64 xy = 2*x*y;
	f64 xz = 2*x*z;
	f64 xw = 2*x*w;

	f64 yy = 2*y*y;
	f64 yz = 2*y*z;
	f64 yw = 2*y*w;
	
	f64 zz = 2*z*z;
	f64 zw = 2*z*w;

	Matrix	t(4);
	f64	*m = t.data;

	m[ 0] = 1-yy-zz;	m[ 1] =   xy-zw;	m[ 2] =   xz+yw;	m[ 3] = 0;
	m[ 4] =   xy+zw;	m[ 5] = 1-xx-zz;	m[ 6] =   yz-xw;	m[ 7] = 0;
	m[ 8] =   xz-yw;	m[ 9] =   yz+xw;	m[10] = 1-xx-yy;	m[11] = 0;
	m[12] =       0;	m[13] =       0;	m[14] =       0;	m[15] = 1;

	multiply(t);

	return *this;
}

//______________________________________________________________
Matrix& Matrix::ortho
(
	f64	left,
	f64	right,
	f64	bottom,
	f64	top,
	f64	n,
	f64	f
)
{
	Matrix	t(4);
	f64	*m = t.data;

	m[ 0] = 2.0f/(right-left);	m[ 1] = 0;			m[ 2] = 0;		m[ 3] = -(right+left)/(right-left);
	m[ 4] = 0;			m[ 5] = 2.0f/(top-bottom);	m[ 6] = 0;		m[ 7] = -(top+bottom)/(top-bottom);
	m[ 8] = 0;			m[ 9] = 0;			m[10] = -2.0f/(f-n);	m[11] = -(f+n)/(f-n);
	m[12] = 0;			m[13] = 0;			m[14] = 0;		m[15] = 1;

	multiply(t);
	return *this;
}

//______________________________________________________________
Matrix& Matrix::perspective
(
	f64	left,
	f64	right,
	f64	bottom,
	f64	top,
	f64	n,
	f64	f
)
{
	Matrix	t(4);
	f64	*m = t.data;

	m[ 0] = 2*n/(right-left);	m[ 1] = 0;			m[ 2] = (right+left)/(right-left);	m[ 3] = 0;
	m[ 4] = 0;			m[ 5] = 2*n/(top-bottom);	m[ 6] = (top+bottom)/(top-bottom);	m[ 7] = 0;
	m[ 8] = 0;			m[ 9] = 0;			m[10] = -(f+n)/(f-n);			m[11] = -2*f*n/(f-n);
	m[12] = 0;			m[13] = 0;			m[14] = -1;				m[15] = 0;

	multiply(t);
	return *this;
}

//______________________________________________________________
Matrix&	
Matrix::perspective
(
	f64	fovy, 
	f64	aspect, 
	f64	n, 
	f64	f
)
{
	f64	t = Math::DEG2RAD*fovy/2.0f;
	f64	right = (f64)(n * tan(t) * aspect);
	f64	top = (f64)(n * tan(t));
	return	perspective(-right, right, -top, top, n, f);
}

//______________________________________________________________
Matrix& Matrix::apply(f64 (*func)(f64))
{
	for (u32 i=0; i<nn; i++) data[i] = func(data[i]);
	return *this;
}

//______________________________________________________________
Matrix& Matrix::setModelview()
{
	glMatrixMode(GL_MODELVIEW);
	opengl->LoadTransposeMatrixd(data);
	return *this;
}

//______________________________________________________________
Matrix& Matrix::setProjection()
{
	glMatrixMode(GL_PROJECTION);
	opengl->LoadTransposeMatrixd(data);
	return *this;
}

//______________________________________________________________
Matrix& Matrix::setTexture()
{
	glMatrixMode(GL_TEXTURE);
	opengl->LoadTransposeMatrixd(data);
	return *this;
}

//______________________________________________________________
Matrix& Matrix::setColor()
{
	glMatrixMode(GL_COLOR);
	opengl->LoadTransposeMatrixd(data);
	return *this;
}

//______________________________________________________________
void Matrix::print(const char *string)
{

	console->write("\n%s (%dx%d):\n", string, n, n);
	for (u32 i=0; i<n; i++) {
		for (u32 j=0; j<n; j++) {
			console->write("%7.2f ", cell(i,j));
		}
		console->write("\n");
	}

	return;
}

//______________________________________________________________
Quaternion::Quaternion()
{
	identity();
	return;
}

//______________________________________________________________
Quaternion::Quaternion(Quaternion& q)
{
	h	= q.h;
	fwd	= q.fwd;
	up	= q.up;
	left	= q.left;
	return;
}

//______________________________________________________________
Quaternion::~Quaternion()
{
	return;
}

//______________________________________________________________
Quaternion& Quaternion::identity()
{
	h.set(0, 0, 0, 1);
	fwd.set(0, 0, 1);
	up.set(0, 1, 0);
	left.set(1, 0, 0);
	return *this;
}

//______________________________________________________________
Quaternion& Quaternion::conjugate()
{
	h.negate();
	return *this;
}

//______________________________________________________________
Quaternion& Quaternion::rotate(f64 angle, v3d& v)
{
	v4d	t;

	f64 s = ( f64 ) sin( angle/2 );
	f64 w = ( f64 ) cos( angle/2 );

	f64 x = v[0] * s;
	f64 y = v[1] * s;
	f64 z = v[2] * s;

	t[0] = + h[0] * w - h[1] * z + h[2] * y + h[3] * x ;
	t[1] = + h[0] * z + h[1] * w - h[2] * x + h[3] * y ;
	t[2] = - h[0] * y + h[1] * x + h[2] * w + h[3] * z ;
	t[3] = - h[0] * x - h[1] * y - h[2] * z + h[3] * w ;

	h = t;

	return *this;
}

//______________________________________________________________
Quaternion& Quaternion::rotate(f64 heading, f64 pitch, f64 roll)
{
	orient().rotate(heading,   up);
	orient().rotate(  pitch, left);
	orient().rotate(   roll,  fwd);
	return *this;
}

//______________________________________________________________
Quaternion& Quaternion::orient()
{
	fwd.set(0, 0, 1);
	up.set(0, 1, 0);
	left.set(1, 0, 0);

	Matrix t(4);
	t.identity();
	t.rotate(*this);
	t.multiply(fwd);
	t.multiply(up);
	left.xprod(up, fwd);
	return *this;
}

//______________________________________________________________
Quaternion& Quaternion::orient(f64 heading, f64 pitch, f64 roll)
{
	identity();
	rotate(heading, pitch, roll);
	return *this;
}

//______________________________________________________________
Quaternion Quaternion::SLERP(Quaternion& q, f64 t)
{
	Quaternion slerp;

	f64 theta = (f64)acos(h.dprod(q.h));
	f64 a = (f64)(sin((1-t)*theta)/sin(theta));
	f64 b = (f64)(sin(t*theta)/sin(theta));

	slerp.h[0] = a*h[0] + b*q.h[0];
	slerp.h[1] = a*h[1] + b*q.h[1];
	slerp.h[2] = a*h[2] + b*q.h[2];
	slerp.h[3] = a*h[3] + b*q.h[3];

	return slerp;
}

//______________________________________________________________
Quaternion& Quaternion::getH(f64& x, f64& y, f64& z, f64& w)
{
	x = h[0];
	y = h[1];
	z = h[2];
	w = h[3];

	return *this;
}

//______________________________________________________________


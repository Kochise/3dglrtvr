#ifndef	__CAMERA_H__
#define	__CAMERA_H__

#include "math.h"

class Camera;

class Camera
{
protected:
	Quaternion	m_orientation;
	v3d		m_position;
	f64		m_fovy;
	f64		m_aspect;
	Matrix		m_view;
	Matrix		m_projection;
public:
			Camera();
			~Camera();

	void		reset();
	void		move(f32 x, f32 y, f32 z);
	void		turn(f32 heading, f32 pitch, f32 roll);
	void		load(Matrix& model);
	f64&		r_fovy() { return m_fovy; }
	f64&		r_aspect() { return m_aspect; }
	Matrix&		r_view() { return m_view; }
	Matrix&		r_projection() { return m_projection; }
	void		getPosition(v3d& u);
};

#endif
//______________________________________________________________
#include <memory.h>
#include "math.h"
#include "file.h"
#include "image.h"

//______________________________________________________________
Image::Image()
{
	width		= 0;
	height		= 0;
	bpp		= 0;
	text		= NULL;
	isTexture	= false;
	return;
}

//______________________________________________________________
Image::Image(Image &image)
{
	width	= image.width;
	height	= image.height;
	text	= new u8[width*height*3];
	memcpy(text, image.text, width*height*3);

	return;
}

//______________________________________________________________
Image::~Image()
{
	destroyTexture();
	free();
	return;
}

//______________________________________________________________
void Image::load(u16 width, u16 height, u8 *data)
{
	u32	x, y, i, j;

	i = j = 0;

	this->width = width;
	this->height = height;

	text = new u8[width*height*3];

	for (y=0; y<height; y++) {
		for (x=0; x<width; x++) {
			text[i++] = data[j++];
			text[i++] = data[j++];
			text[i++] = data[j++];
		}
	}

	return;
}

//______________________________________________________________
void Image::loadBMP(const char *path)
{
	char	*code;
	u32	pad;
	u32	x, y, i, j;

	code = file->load(path);
	
	if (code == NULL) {
		return;
	}

	if(code[0] != 'B' || code[1] != 'M') {
		return;
	}

	width	= (u16) *(u32 *)(code+18);
	height	= (u16) *(u32 *)(code+22);
	pad	= width % 4;

	text = new u8[width*height*3];

	i = 0;
	j = *(u32 *)(code+10);
	for (y=0; y<height; y++) {
		for (x=0; x<width; x++) {
			text[i+0] = code[j+2];
			text[i+1] = code[j+1];
			text[i+2] = code[j+0];
			i += 3;
			j += 3;
		}
		j += pad;
	}

	bpp = 24;
	format = GL_RGB;

	delete	[] code;

	return;
}

//______________________________________________________________
void Image::loadTGA(const char *path)
{

	char	*code;
	u32	size;
	u32	i;

	code = file->load(path);
	
	if (code == NULL) {
		return;
	}

	width	= (code[12] + code[13]) << 8;
	height	= (code[14] + code[15]) << 8;
	bpp	= code[16];

	size = width * height * bpp / 8;
	text = new GLubyte[size];

	code += 18;
	if (bpp == 8) {
		format = GL_ALPHA;
		for (i=0; i<size; i++) {
			text[i] = code[i];
		}
	} else if (bpp == 24) {
		format = GL_RGB;
		for (i=0; i<size; i+=3) {
			text[i+0] = code[i+2];
			text[i+1] = code[i+1];
			text[i+2] = code[i+0];
		}
	} else if (bpp == 32) {
		format = GL_RGBA;
		for (i=0; i<size; i+=4) {
			text[i+0] = code[i+2];
			text[i+1] = code[i+1];
			text[i+2] = code[i+0];
			text[i+3] = code[i+3];
		}
	} else {
		return;
	}
	code -= 18;
	
	delete [] code;

	return;
}

//______________________________________________________________
void Image::loadDEF()
{
	u8	*tx;
	u8	r, g, b;
	u32	x, y, i, j;
	f32	t;

	tx = new u8[256*256*3];
	memset(tx, 0, 256*256*3);

	for (t=0; t<1000; t+=0.1f) {
		x = (u32)(100 * sin(4*t) + 128);
		y = (u32)(100 * cos(3*t) + 128);

		r = (u8)(63 * cos(2*t) + 192);
		g = (u8)(63 * cos(3*t) + 192);
		b = (u8)(63 * sin(4*t) + 192);
		
		i = 3*((y<<8) + x);

		for (j=0; j<5; j++) {
			tx[i++] = r;
			tx[i++] = g;
			tx[i++] = b;
		}
	}

	load(256, 256, tx);

	bpp = 24;
	format = GL_RGB;

	delete [] tx;

	return;
}

//______________________________________________________________
void Image::createTexture()
{
	if (isTexture) {
		return;
	}

	glGenTextures(1, &htext);
	glBindTexture(GL_TEXTURE_2D, htext);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	gluBuild2DMipmaps(GL_TEXTURE_2D, format, width, height, format, GL_UNSIGNED_BYTE, text);
	isTexture = true;

	return;	
}
//______________________________________________________________
void Image::destroyTexture()
{
	if (!isTexture) {
		return;
	}

	glDeleteTextures(1, &htext);
	isTexture = false;

	return;
}

//______________________________________________________________
void Image::bind(GLint env, GLint wrap, GLint minfilter, GLint magfilter)
{
	glBindTexture(GL_TEXTURE_2D, htext);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, env);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minfilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magfilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrap);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrap);
	return;
}

//______________________________________________________________
void Image::free()
{
	if (text) {
		delete [] text;
		text = NULL;
	}
	return;
}

//______________________________________________________________
GLubyte *Image::dump()
{
	return text;
}

//______________________________________________________________

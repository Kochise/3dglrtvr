//______________________________________________________________
#include <stdio.h>
#include <stdarg.h>
#include <memory.h>
#include "timer.h"
#include "opengl.h"
#include "font.h"
#include "file.h"
#include "console.h"

//______________________________________________________________
Console::Console
(
	u16	i_cols, 
	u16	i_rows
) : 
view(4), 
projection(4)
{
	text	= new char[65536];
	command	= new char[256];
	command[0] = '_';
	command[1] = '\0';

	cols	= i_cols;
	rows	= i_rows;
	cPos	= 0;
	dPos	= 0;
	wPos	= 0;

	speed	= 10.0f;
	offset	= 0.0f;
	target	= 0;

	view.identity();
	projection.identity().ortho(0, (f32)cols, (f32)rows+1, 0, 0, 1);

	active	= false;

	memset(text, 0, 65536);
	
	time = 0;

	return;
}

//______________________________________________________________
Console::~Console
()
{
	delete [] command;
	delete [] text;
	return;
}

//______________________________________________________________
void 
Console::cmd
(
	u8 c
)
{
	if (c == '`') {
		active = !active;
	} else if (!active) {
		return;
	} else if (c == 8) {
		if (cPos) {
			cPos--;
		}
	} else if (c == 13) {
		command[cPos] = '\0';
		write("%s\n", command);
		cPos = 0;
	} else {
		command[cPos++] = c;
	}

	command[cPos] = '_';
	command[cPos+1] = '\0';

	return;
}

//______________________________________________________________
void 
Console::write
(
	const char *format, 
	...
)
{
	va_list	args;
	va_start(args, format);
	char buffer[1024];
	vsprintf(buffer, format, args);
	load(buffer);
	va_end(args);
	return;
}

//______________________________________________________________
void 
Console::load
(
	char *string
)
{
	if (string == NULL) return;
	u32 i=0;
	while(text[wPos++] = string[i++]);
	wPos--;
	end();
	return;
}
//______________________________________________________________
void 
Console::home
()
{
	while (text[dPos]) dPos--;
	dPos++;
	return;
}

//______________________________________________________________
void
Console::end
()
{
	dPos = wPos;
	dPos--;
	jump(-rows);
	return;
}

//______________________________________________________________
void
Console::jump
(
	int lines
)
{
	target = 0;
	offset = 0.0f;

	if (lines > 0) {
		while (text[dPos] && lines > 0) {
			if (text[dPos] == '\n') {
				lines--;
			}
			dPos++;
		}
		if (!text[dPos]) {
			dPos--;
			jump(0);
		}
	} else if (lines <= 0) {
		lines--;
		while (text[dPos] && lines < 0) {
			dPos--;
			if (text[dPos] == '\n') {
				lines++;
			}
		}
		dPos++;
	}
}

//______________________________________________________________
void 
Console::scroll
(
	int lines, 
	f32 speed
)
{
	if (
		lines < 0 && target > 0 ||
		lines > 0 && target < 0
	) {
		target = 0;
	} else {
		this->speed = speed;
		target += lines;
	}

	return;
}

//______________________________________________________________
void
Console::page
(
	int pages, 
	f32 speed
)
{
	scroll(pages*rows, speed);
	return;
}

//______________________________________________________________
void 
Console::update
()
{
	int lines;

	if (target == 0) {
		return;
	} else if (target < 0) {
		offset -= speed*timer->get_dt();
		lines = (int)floor(offset)+1;
		offset -= lines;
		if (lines <= target) {
			lines = target;
			offset = 0.0f;
		}
	} else if (target > 0) {
		offset += speed*timer->get_dt();
		lines = (int)floor(offset);
		offset -= lines;
		if (lines >= target) {
			lines = target;
			offset = 0.0f;
		}
	}

	target -= lines;

	if (lines > 0) {
		while (text[dPos] && lines > 0) {
			if (text[dPos] == '\n') {
				lines--;
			}
			dPos++;
		}
		if (!text[dPos]) {
			dPos--;
			jump(0);
		}
	} else if (lines < 0) {
		lines--;
		while (text[dPos] && lines < 0) {
			dPos--;
			if (text[dPos] == '\n') {
				lines++;
			}
		}
		if (!text[dPos]) {
			dPos++;
			jump(0);
		} else {
			dPos++;
		}
	} else if (lines == 0 && offset < 0) {
		dPos--;
		while (text[dPos] && text[dPos] != '\n') dPos--;
		if (!text[dPos]) {
			target = 0;
			offset = 0.0f;
		}
		dPos++;
	}

	return;
}

//______________________________________________________________
void 
Console::render
()
{
	if (active) {
		if (time < 1.0f) {
			time += timer->get_dt();
		}
	} else {
		if (time > 0.0f) {
			time -= timer->get_dt();
		} else {
			return;
		}
	}

	glDisable(GL_DEPTH_TEST);

	view.setModelview();
	f32 d = -rows * (time-1) * (time-1);
	glTranslatef(0, d, 0);
	projection.setProjection();

	glEnable(GL_BLEND);

	glBegin(GL_TRIANGLE_STRIP); {
		glColor4ub(  0,   0,   0, 100); glVertex2i(   0,    0);
		glColor4ub(  0,   0,   0, 100); glVertex2i(   0, rows);
		glColor4ub(  0, 0, 0, 100); glVertex2i(cols,    0);
		glColor4ub(  0, 0, 0, 100); glVertex2i(cols, rows);
	}; glEnd();

	glDisable(GL_BLEND);

	font->set_color(255, 255, 255, 255);
	font->render(text, dPos, 0, -offset-1.0f, cols, rows+1.0f);

	glBegin(GL_TRIANGLE_STRIP); {
		glColor3ub(  0, 100, 150); glVertex2i(   0,   rows);
		glColor3ub(  0, 100, 150); glVertex2i(   0, rows+1);
		glColor3ub(  0, 100, 150); glVertex2i(cols,   rows);
		glColor3ub(  0, 100, 150); glVertex2i(cols, rows+1);
	}; glEnd();
	
	font->set_color(255, 255, 255, 255);
	font->render(command, 0, 0, rows, cols, rows+1.0f);


	glEnable(GL_DEPTH_TEST);

	return;
}

//______________________________________________________________
bool Console::isActive()
{
	return active;
}

//______________________________________________________________

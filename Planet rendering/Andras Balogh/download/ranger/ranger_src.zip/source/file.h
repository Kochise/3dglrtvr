#pragma once

#include <stdio.h>

//______________________________________________________________
const u32 
RINGSIZE	= 4096,			// ring buffer's size (12 bits)
THRESHOLD	= 3,			// decides wether is it worth coding
TEXTSIZE	= 16+THRESHOLD-1,	// maximum length of match (4 bits)
CODESIZE	= 1+2*8,		// buffer length for coded output
LOOKUPSIZE	= 32;			// the size of lookup table per char

//______________________________________________________________
#pragma pack(push, paq)
#pragma pack(1)

struct Info
{
	u32	FilesNbr;
	u32	DirecNbr;
	u32	TextSize;
	u32	CodeSize;
	u32	EntryBlockLen;
	u32	PathBlockLen;
};

struct Entry
{
	u32	PathPos;
	u32	PathLen;
	u32	Position;
	u32	TextSize;
	u32	CodeSize;
};

struct Boot
{
	u32	EntryBlockPos;
	u32	EntryBlockLen;
	u32	PathBlockPos;
	u32	PathBlockLen;
};

struct Tree
{
	char	*Path;
	u32	PathLen;
	u32	TextSize;
	Tree	*prv;
	Tree	*nxt;
};

struct ScanData
{
	Info	*info;
	Entry	*EntryBlock;
	char	*PathBlock;
};

#pragma pack(pop, paq)

//______________________________________________________________

class File
{
private:
	char*	m_base;
	char*	load_paq(const char* path, FILE* PackFile);
	char*	decode(Entry *FileInfo, char *path, FILE *PackFile);
public:
		File();
		~File();
	void	set_base(const char* base = "data");
	char*	load(const char* path);
	u32	save(const char* path, const char* buffer, u32 size);
	u32	append(const char* path, const char* buffer, u32 size);
};

extern File* file;


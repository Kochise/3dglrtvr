//______________________________________________________________
#include "timer.h"
#include "opengl.h"
#include "math.h"
#include "world.h"
#include "player.h"
#include "terrain.h"

#pragma warning (disable:4244 4305)

using namespace Math;

//______________________________________________________________
f32 obox_vertices[] = {
	-1.0, -1.0, -1.0,
	-1.0, -1.0, +1.0,
	-1.0, +1.0, -1.0,
	-1.0, +1.0, +1.0,
	+1.0, -1.0, -1.0,
	+1.0, -1.0, +1.0,
	+1.0, +1.0, -1.0,
	+1.0, +1.0, +1.0
};

f32 box_vertices[24];

unsigned char box_indices[] = {
	1, 5, 7, 3,	// back
	5, 4, 6, 7,	// right
	4, 0, 2, 6,	// front
	0, 1, 3, 2,	// left
	3, 7, 6, 2,	// top
	1, 0, 4, 5	// bottom

};

//______________________________________________________________
inline f32 groundh(f32 x, f32 z){
	return	3*sin(0.04*x+0.2) + 0.2*sin(0.6*x+0.7) +
		0.4*sin(0.7*z+0.3) + 0.3*sin(0.5*z+0.1);
}
inline void groundn(v3f& n, f32 x, f32 z){
	n[0] =	-0.12*cos(0.04*x+0.2) - 0.12*cos(0.6*x+0.7);
	n[2] =	-0.28*cos(0.7*z+0.3) - 0.15*cos(0.5*z+0.1);
	n[1] = 1;
	n.normalize();
	return;
}
inline f32 waterh(f32 x, f32 z, f32 t){
	return 	0.1*sin(-1.7*x+3*t) + 0.1*sin(0.9*z+t);
}
inline void watern(v3f& n, f32 x, f32 z, f32 t){
	n[0] =	0.17*cos(-1.7*x+3*t);
	n[2] =	-0.09*cos(0.9*z+t);
	n[1] = 1;
	n.normalize();
	return;
}
//______________________________________________________________
Terrain::Terrain()
{
	groundtex = new Image();
	groundtex->loadBMP("Landscape5.bmp");
	groundtex->createTexture();

	watertex = new Image();
	watertex->loadTGA("water.tga");
	watertex->createTexture();

	cloudtex = new Image();
	cloudtex->loadTGA("cloud.tga");
	cloudtex->createTexture();

	ground	= new f32[10000*(2+3+3)];
	water	= new f32[10000*(2+3+3)];
	cloud	= new f32[10000*(2+3+3)];
	gIndex	= new u16[10000];

	return;
}

//______________________________________________________________
Terrain::~Terrain()
{
	delete cloud;
	delete ground;
	delete water;
	delete gIndex;
	delete cloudtex;
	delete groundtex;
	delete watertex;
	return;
}

//______________________________________________________________
f32
Terrain::get_distance
(
	v3d& i_position
)
{
	v3d terrain_height(i_position[0], getHeight(i_position[0], i_position[2]), i_position[2]);
	v3d terrain_normal;
	v3d tmp;

	getNormal(i_position[0], i_position[2], terrain_normal);

	tmp.sub(i_position, terrain_height);
	return tmp.dprod(terrain_normal);	
}

//______________________________________________________________
f32 Terrain::getHeight( f64 x, f64 z )
{
	f32 t = timer->get_time();
	f32 w = waterh(x, z, t);
	f32 g = groundh(x, z);
	return w > g ? w : g;
}

//______________________________________________________________
void Terrain::getNormal( f64 x, f64 z, v3d& normal )
{
	f32 t = timer->get_time();
	f32 w = waterh(x, z, t);
	f32 g = groundh(x, z);
	v3f norm1;
	w > g ? watern(norm1, x, z, t) : groundn(norm1, x, z);
	normal[0] = norm1[0];
	normal[1] = norm1[1];
	normal[2] = norm1[2];
	return;
}

//______________________________________________________________
void Terrain::update()
{
	f32	t = timer->get_time();
	v3d	pos;
	f32	x, z, xo, zo;
	f32	r = 0.5f;

	world->getPlayer()->getPosition(pos);

	u16 i = 0, j = 0, k = 0, l = 0, c = 0;

	for (zo=-10; zo<=10; zo+=r) {
		for (xo=-10; xo<=10; xo+=r) {
			x = (int)pos[0]+xo;
			z = (int)pos[2]+zo;

			watern(*(v3f *)(water+i), x, z, t); i += 3;
			water[i++] = x;
			water[i++] = waterh(x, z, t);
			water[i++] = z;

			groundn(*(v3f *)(ground+j), x, z); j += 3;
			ground[j++] = x;
			ground[j++] = groundh(x, z);
			ground[j++] = z;
			
			x = (int)pos[0]+10*xo;
			z = (int)pos[2]+10*zo;
			cloud[c++] = x;
			cloud[c++] = 10;
			cloud[c++] = z;

			gIndex[k++] = l;
			gIndex[k++] = l+41;
			l++;
		}
	}
	return;
}

//______________________________________________________________
void Terrain::render()
{
	glClearColor(0.2f, 0.4f, 0.6f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	if (world->m_flat) {
		glShadeModel(GL_FLAT);
	} else {
		glShadeModel(GL_SMOOTH);
	}

	glEnable(GL_CULL_FACE);

	render_sun();
	render_sky();

	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);

	render_water();
	render_ground();

	opengl->ActiveTexture(GL_TEXTURE0_ARB);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);

	glDisable(GL_LIGHTING);

	if (world->m_normals) {
		render_normals();
	}
//	render_frustum();


	return;
}

//______________________________________________________________
void Terrain::render_sun()
{
	v4f lightmodel_Ka(0.0, 0.0, 0.0, 1);
	v4f light_pos(-1, 1, -1, 0);
	v4f light_Ka(0.2, 0.2, 0.2, 1);
	v4f light_Kd(0.8, 0.8, 0.8, 1);

	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lightmodel_Ka);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_Ka);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_Kd);
	glLightfv(GL_LIGHT0, GL_POSITION, light_pos);
	glEnable(GL_LIGHT0);
	return;
}

//______________________________________________________________
void Terrain::render_sky()
{
	if (!world->m_flat) {
		opengl->ActiveTexture(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		cloudtex->bind(GL_BLEND);
		v4f env_color(1.0f, 1.0f, 1.0f, 1.0f);
		glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, env_color);
		v4f s_plane(0.04, 0, 0, -timer->get_time()/20.0);
		v4f t_plane(0, 0, 0.04, 0);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGenfv(GL_S, GL_OBJECT_PLANE, s_plane);
		glTexGenfv(GL_T, GL_OBJECT_PLANE, t_plane);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
	}

	v4f fog_color(0.2f, 0.4f, 0.6f, 0.0f);
//	0.2f, 0.6f, 0.9f, 0.0f
	glFogf(GL_FOG_MODE, GL_EXP);
	glFogf(GL_FOG_DENSITY, 0.05f);
	glFogfv(GL_FOG_COLOR, fog_color);
	glEnable(GL_FOG);

	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glFrontFace(GL_CW);
	
//	glColor4f(0.2f, 0.5f, 0.7f, 1.0f);
	glColor4ub(255, 255, 255, 255);
	glInterleavedArrays(GL_V3F, 0, cloud);
	for (int i=0, j=0; i<40; i++, j+=82) {
		glDrawElements(GL_TRIANGLE_STRIP, 82, GL_UNSIGNED_SHORT, gIndex+j);
	}

	glFrontFace(GL_CCW);
	glDisable(GL_BLEND);
	glDisable(GL_FOG);

	if (world->m_multitexture) {
		opengl->ActiveTexture(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		cloudtex->bind(GL_MODULATE);
		v4f s_plane(0.04, 0, 0, -timer->get_time()/20.0);
		v4f t_plane(0, 0, 0.04, 0);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGenfv(GL_S, GL_OBJECT_PLANE, s_plane);
		glTexGenfv(GL_T, GL_OBJECT_PLANE, t_plane);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
	}

	return;
}

//______________________________________________________________
void Terrain::render_ground()
{
	v4f ground_Ka(1, 1, 1, 1);
	v4f ground_Kd(1, 1, 1, 1);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ground_Ka);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, ground_Kd);

	if (!world->m_flat) {
		opengl->ActiveTexture(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		groundtex->bind(GL_MODULATE);
		v4f s_plane(0.2, 0, 0, 1);
		v4f t_plane(0, 0, 0.2, 1);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGenfv(GL_S, GL_OBJECT_PLANE, s_plane);
		glTexGenfv(GL_T, GL_OBJECT_PLANE, t_plane);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
	}

	glInterleavedArrays(GL_N3F_V3F, 0, ground);
	for (int i=0, j=0; i<40; i++, j+=82) {
		glDrawElements(GL_TRIANGLE_STRIP, 82, GL_UNSIGNED_SHORT, gIndex+j);
	}

	return;
}

//______________________________________________________________
void Terrain::render_water()
{
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHTING);

	v4f water_Ka(1, 0, 1, 0.2);
	v4f water_Kd(0, 1, 1, 0.4);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, water_Ka);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, water_Kd);

	if (!world->m_flat) {
		opengl->ActiveTexture(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		watertex->bind(GL_MODULATE);
		v4f s_plane(0.2, 0, 0, 1);
		v4f t_plane(0, 0, 0.2, 1);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGenfv(GL_S, GL_OBJECT_PLANE, s_plane);
		glTexGenfv(GL_T, GL_OBJECT_PLANE, t_plane);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
	}
	glInterleavedArrays(GL_N3F_V3F, 0, water);
	for (int i=0, j=0; i<40; i++, j+=82) {
		glDrawElements(GL_TRIANGLE_STRIP, 82, GL_UNSIGNED_SHORT, gIndex+j);
 	}

	return;
}

//______________________________________________________________
void Terrain::render_normals()
{
	v3d	pos, n;
	f32	x, z, xo, zo, h, r = 0.5f;

	world->getPlayer()->getPosition(pos);

	glBegin(GL_LINES);
	glColor3f(1, 1, 1);
	for (zo=-10; zo<=10; zo+=r) {
		for (xo=-10; xo<=10; xo+=r) {
			x = (int)pos[0]+xo;
			z = (int)pos[2]+zo;
			getNormal(x, z, n);
			h = getHeight(x, z);
			n.scale(0.2);
			glVertex3f(x, h, z);
			glVertex3f(x+n[0], h+n[1], z+n[2]);
		}
	}
	glEnd();
	return;
}

//______________________________________________________________
void Terrain::render_frustum()
{
	for (int u=0; u<8*3; u++) box_vertices[u] = obox_vertices[u];

	v3d t;
	Matrix mat0(4), mat1(4), mat2(4);

	mat0.identity();
	mat0.translate(t.set(0, 0.973, 0));

	mat1.identity();
//	mat1.load(world->getPlayer()->r_camera().r_view());
//	mat1.fastinvert();
//	mat1.translate(t.set(0, 0, -5));
	
	mat2.identity();
	mat2.load(world->getPlayer()->r_camera().r_projection());
	mat2.invert();

	mat1.multiply(mat2);
	mat0.multiply(mat1);
	mat0.transform(box_vertices, 8);

	glEnableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, box_vertices);
	glColor3f(1.0f, 1.0f, 1.0f);
	for (int s=0; s<6; s++) {
		glDrawElements(GL_LINE_LOOP, 4, GL_UNSIGNED_BYTE, box_indices+s*4);
	}
	
	return;
}

//______________________________________________________________

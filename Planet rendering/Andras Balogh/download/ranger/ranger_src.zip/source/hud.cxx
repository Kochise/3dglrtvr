//______________________________________________________________
#include <stdio.h>
#include "opengl.h"
#include "font.h"
#include "timer.h"
#include "world.h"
#include "math.h"
#include "hud.h"

//______________________________________________________________
HUD::HUD() : view(4), projection(4)
{
	view.identity();
	projection.identity().ortho(0, 80, 50, 0, 0, 1);

	active	= true;
	time	= 0.25;

	text	= new char[1024];

	return;
}

//______________________________________________________________
HUD::~HUD()
{
	delete text;
	return;
}

//______________________________________________________________
void HUD::render()
{
	if (active) {
		if (time < 0.25f) {
			time += timer->get_dt();
		}
	} else {
		if (time > 0.0f) {
			time -= timer->get_dt();
		} else {
			return;
		}
	}

	i16 tmp = time*4*255;
	if (tmp < 0) tmp = 0;
	if (tmp > 255) tmp = 255;
	u8 alpha = tmp;

	view.setModelview();
	projection.setProjection();
	font->set_color(255, 255, 255, alpha);

	v3d	pos;
	v3d	vel;
	v3d	n;

	sprintf(
		text, 
		"               experimental terrain rendering and physics engine\n"
		"                 by Andrew \"Bandi\" Balogh (ba127@hszk.bme.hu)"
	);
	font->render(text, 0, 0, 48, 80, 50);

	sprintf(text, "%3d fps", (int)timer->get_fps());
	font->render(text, 0, 73, 0, 80, 1);

	world->getPlayer()->getPosition(pos);
	world->getTerrain()->getNormal(pos[0], pos[2], n);
	
	sprintf(
		text, 
		"Camera:\n"
		"Px=%+7.3f Nx=%+7.3f\n"
		"Py=%+7.3f Ny=%+7.3f\n"
		"Pz=%+7.3f Nz=%+7.3f\n",
		pos[0], n[0],
		pos[1], n[1],
		pos[2], n[2]
	);
	font->render(text, 0, 0, 0, 30, 4);

	world->getBall()->getPosition(pos);
	world->getBall()->getVelocity(vel);

	sprintf(
		text, 
		"Ball:\n"
		"Px=%+7.3f Vx=%+7.3f\n"
		"Py=%+7.3f Vy=%+7.3f\n"
		"Pz=%+7.3f Vz=%+7.3f\n"
		"D =%+7.3f\n",
		pos[0],	vel[0],
		pos[1],	vel[1],
		pos[2],	vel[2],
		world->getBall()->distance()
	);
	font->render(text, 0, 0, 5, 30, 10);

	return;
}
//______________________________________________________________
void HUD::toggle()
{
	active = !active;
	return;
}

//______________________________________________________________

#pragma once

#include "math.h"

class Input
{
private:
	u8	m_keyboard[256];
	u8	m_mouse[3];
	v3f	m_move;
	bool	active;

public:
		Input();
		~Input();
	void	update();
	void	getMove(v3f& move);

	void	keydown(u8 i);
	void	keyup(u8 i);
	bool	keyd(u8 i);
	bool	keyp(u8 i);
	
	void	buttondown(u8 i);
	void	buttonup(u8 i);
	bool	buttond(u8 i);
	bool	buttonu(u8 i);
	bool	buttonp(u8 i);

	bool	toggle();
};

extern Input* input;


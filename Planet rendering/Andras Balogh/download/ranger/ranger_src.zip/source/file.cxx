//______________________________________________________________
#include <stdlib.h>
#include <string.h>
#include <direct.h>
#include "console.h"
#include "file.h"

//______________________________________________________________
File::File()
{
	m_base	= new char[5];
	strcpy(m_base, "data");

	return;
}

//______________________________________________________________
File::~File()
{
	delete [] m_base;
	return;
}

//______________________________________________________________
void
File::set_base
(
	const char* base
)
{
	int length = strlen(base) + 1;
	delete [] m_base;
	m_base = new char[length];
	strcpy(m_base, base);
	return;
}

//______________________________________________________________
char*
File::load
(
	const char* path
)
{
	int	baselen = strlen(m_base);
	int	pathlen = strlen(path);
	char*	realpath = new char[baselen+pathlen+2];
	char*	buffer;

	strcpy(realpath, m_base);
	realpath[baselen]='/';
	realpath[baselen+1]='\0';
	strcat(realpath, path);

	console->write("Loading \"%s\"...", realpath);
	FILE* f = fopen(realpath, "rb");
	delete [] realpath;

	if (f == NULL) {
		char* paqfile = new char[baselen+1+1+3];
		strcpy(paqfile, m_base);
		strcat(paqfile, ".paq");
		f = fopen(paqfile, "rb");
		delete paqfile;
		if (f == NULL) {
			console->write("Failed.\n");
			return NULL;
		}
		buffer = load_paq(path, f);
	} else {
		fseek(f, 0, SEEK_END);
		long size = ftell(f);
		fseek(f, 0, SEEK_SET);
		buffer = new char[size];
		fread(buffer, 1, size, f);
	}

	fclose(f);
	console->write("Done.\n");

	return buffer;
}

//______________________________________________________________
u32
File::save
(
	const char* path, 
	const char* buffer, 
	u32 size
)
{
	int	baselen	= strlen(m_base);
	int	pathlen = strlen(path);
	char*	realpath = new char[baselen+pathlen+2];

	strcpy(realpath, m_base);
	realpath[baselen]='/';
	realpath[baselen+1]='\0';
	strcat(realpath, path);

	console->write("Saving \"%s\"...", realpath);
	FILE* f = fopen(realpath, "wb");
	delete [] realpath;
	
	if (!f) {
		console->write("FAILED!\n");
		return 0;
	}

	u32 result = size - fwrite(buffer, 1, size, f);

	fflush(f);
	fclose(f);
	console->write("Done.\n");

	return result;
}

//______________________________________________________________
u32 
File::append
(
	const char* path, 
	const char* buffer, 
	u32 size
)
{
	int	baselen = strlen(m_base);
	int	pathlen = strlen(path);
	char*	realpath = new char[baselen+pathlen+2];

	strcpy(realpath, m_base);
	realpath[baselen] ='/';
	realpath[baselen+1] ='\0';
	strcat(realpath, path);

	console->write("Saving \"%s\"...", realpath);
	FILE* f = fopen(realpath, "ab");
	delete [] realpath;

	u32 result = size - fwrite(buffer, 1, size, f);

	fflush(f);
	fclose(f);
	console->write("Done.\n");

	return result;
}

//______________________________________________________________
char* 
File::decode
(
	Entry	*FileInfo, 
	char	*path, 
	FILE	*PackFile
)
{
	u8	Ring[RINGSIZE];	// the ring buffer stores previous data 
	u8	Temp[TEXTSIZE];
	u32	TextSize = 0;	// count processed size 
	u32	RingPtr  = 0;	// position in the ring 
	u32	Counter  = 0;	// count items remaining in the chunk 
	u32	Flags    = 0;	// determines which items are compressed 
	u32	Data     = 0;	// store a piece of data temporarly 
	u32	MatchLen = 0;	// match's length to replace item with 
	u32	MatchPos = 0;	// match's position in the ring buffer 
	u32	i;		// general purpose index variable 
	u32	buffer_pos = 0;
	char*	buffer;		// the output file to be generated 

	buffer = new char[FileInfo->TextSize];

	// position packfile to the beginning of coded data 
	fseek(PackFile, FileInfo->Position, SEEK_SET);

	// clear ring buffer 
	for (i=0; i<RINGSIZE; i++) {
		Ring[i] = 0;
	}

	// decode stream 
	for ( ; ; ) {
		if (!Counter) {
			if (!(FileInfo->CodeSize--)) {
				break;
			}
			Flags = getc(PackFile);
			Counter = 8;
		}
	
		if (Flags & 1) {
			MatchPos = getc(PackFile);
			MatchLen = getc(PackFile);
			MatchPos |= (MatchLen & 15) << 8;
			MatchLen >>= 4;
			MatchLen += THRESHOLD;
			FileInfo->CodeSize -= 2;
			for (i=0; i<MatchLen; i++) {
				Data = (u8)Ring[(MatchPos+i) & (RINGSIZE-1)];
				buffer[buffer_pos++] = (char)Data;
				Temp[i] = (u8)Data;
			}
			for (i=0; i<MatchLen; i++) {
				Ring[RingPtr++] = (u8)Temp[i];
				RingPtr &= (RINGSIZE-1);
			}
			TextSize += MatchLen;
		} else {
			if (!(FileInfo->CodeSize--)) {
				break;
			}
			Data = getc(PackFile);
			buffer[buffer_pos++] = (char)Data;
			Ring[RingPtr++] = (u8)Data;
			RingPtr &= (RINGSIZE-1);
			++TextSize;
		}
		Flags >>= 1;
		--Counter;
	}

	return buffer;
}
//______________________________________________________________
char* 
File::load_paq
(
	const char*	path, 
	FILE		*PackFile
)
{
	Entry	*EntryBlock;		// will hold the info about the files 
	char	*PathBlock;
	Boot	Boot;			// boot holds dirmap's position and length 
	char	PackFileID[7];		// this identifies the packfile as valid 
	u32	FilesNbr;		// number of files to decode 
	u32	i;			// general purpose index variable 
	char*	buffer;

	// check id string 
	fread(PackFileID, 1, 6, PackFile);
	PackFileID[6] = '\0';
	if (strcmp(PackFileID, "bndpaq")) {
		return NULL;
	}

	// load boot data 
	fseek(PackFile, -(long)sizeof(Boot), SEEK_END);
	fread(&Boot, 1, sizeof(Boot), PackFile);
	FilesNbr = Boot.EntryBlockLen / sizeof(Entry);

	// load dirmap 
	EntryBlock = new Entry[FilesNbr];
	fseek(PackFile, Boot.EntryBlockPos, SEEK_SET);
	fread(EntryBlock, 1, Boot.EntryBlockLen, PackFile);

	// load pathblock
	PathBlock = new char[Boot.PathBlockLen];
	fseek(PackFile, Boot.PathBlockPos, SEEK_SET);
	fread(PathBlock, 1, Boot.PathBlockLen, PackFile);

	// decode files 
	buffer = NULL;
	for (i=0; i<FilesNbr; i++) {
		if (!strcmp(path, PathBlock + EntryBlock[i].PathPos)) {
			buffer = decode(EntryBlock+i, PathBlock + EntryBlock[i].PathPos, PackFile);
		}
	}

	// close packfile and free memory 
	fclose(PackFile);
	delete EntryBlock;
	delete PathBlock;

	return buffer;
}

//______________________________________________________________




//______________________________________________________________
#include <windows.h>
#include "console.h"
#include "window.h"
#include "opengl.h"
#include "file.h"
#include "input.h"
#include "font.h"
#include "timer.h"
#include "world.h"
#include "main.h"

//______________________________________________________________
Console*	console;
Window*		window;
Font*		font;
OpenGL*		opengl;
File*		file;
Input*		input;
Timer*		timer;
World*		world;

//______________________________________________________________
Main::Main
()
{
	return;
}

//______________________________________________________________
Main::~Main
()
{
	return;
}

//______________________________________________________________
void
Main::init
(
	int	argc, 
	char**	argv
)
{
	console = new Console(80, 49);
	console->write(
		"\n"
		"Ranger: experimental terrain rendering engine by Bandi (c) 2001\n"
		"_______________________________________________________________\n"
		"\n"
	);

	file	= new File;
	input	= new Input;
	window	= new Window;
	window->create(800, 600, true);
	opengl	= new OpenGL;
	timer	= new Timer;
	font	= new Font;
	font->load_font("font.tga", 16, 16);
	world	= new World;
	
	return;
}

//______________________________________________________________
void
Main::kill
()
{
	console->write(
		"\n"
		"shutting down Ranger...\n"
		"\n"
	);
	delete world;	world = 0;
	delete timer;	timer = 0;
	delete font;	font = 0;
	delete window;	window = 0;
	delete input;	input = 0;
	delete console;	console = 0;
	delete opengl;	opengl = 0;
	delete file;	file = 0;

	return;
}

//______________________________________________________________
int 
Main::run
()
{
	MSG	msg;
	
	for(;;) {
		while ( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) ) {
			if ( msg.message == WM_QUIT ) {
				kill();
				return msg.wParam;
			}
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
		world->update();
		world->render();
	}
}

//______________________________________________________________

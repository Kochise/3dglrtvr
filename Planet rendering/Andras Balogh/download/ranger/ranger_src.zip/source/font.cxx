//______________________________________________________________
#include "font.h"

//______________________________________________________________
Font::Font()
{
	m_font	= new Image();
	m_cols	= 0;
	m_rows	= 0;
	m_sizex	= 0;
	m_sizey	= 0;

	m_color[0] = 0;
	m_color[1] = 0;
	m_color[2] = 0;
	m_color[3] = 0;

	return;
}
//______________________________________________________________
Font::~Font()
{
	delete m_font;
	return;
}
//______________________________________________________________
void
Font::load_font
(
	const char* path,
	u16 cols, 
	u16 rows
)
{
	delete m_font;

	m_font = new Image();
	m_font->loadTGA(path);
	m_font->createTexture();
	m_font->free();

	m_cols	= cols;
	m_rows	= rows;
	m_sizex	= 1.0f / cols;
	m_sizey	= 1.0f / rows;

	return;
}

//______________________________________________________________
void 
Font::render
(
	const char* s, 
	u16 i, 
	f32 ulx, 
	f32 uly, 
	f32 lrx, 
	f32 lry
)
{
	f32	map_x;
	f32	map_y;
	f32	x = ulx;
	f32	y = uly;
	int	col = 0;

	glColor4ubv(m_color);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glDisable(GL_DEPTH_TEST);

	opengl->ActiveTexture(GL_TEXTURE0_ARB);
	glEnable(GL_TEXTURE_2D);
	m_font->bind(GL_MODULATE, GL_CLAMP, GL_LINEAR, GL_LINEAR);

	while(s[i] && y < lry) {
		if (s[i] == '\t') {
			x += 8-col%8;
		} else if (s[i] == '\n' || s[i] == '\r' || x >= lrx) {
			y++;
			x = ulx;
			col = 0;
			while (s[i] && s[i] != '\n') {
				s++;
			}
		} else {
			map_x = s[i] % m_cols * m_sizex;
			map_y = 1 - s[i] / m_cols * m_sizex;

			glBegin(GL_QUADS); {
				glTexCoord2f(        map_x,         map_y); glVertex2f(  x,   y);
				glTexCoord2f(        map_x, map_y-m_sizey); glVertex2f(  x, y+1);
				glTexCoord2f(map_x+m_sizex, map_y-m_sizey); glVertex2f(x+1, y+1);
				glTexCoord2f(map_x+m_sizex,         map_y); glVertex2f(x+1,   y);
			}; glEnd();

			x++;
			col++;
		}
		i++;
	}

	opengl->ActiveTexture(GL_TEXTURE0_ARB);
	glDisable(GL_TEXTURE_2D);

	glDisable(GL_BLEND);

	return;
}
//______________________________________________________________
void
Font::set_color
(
	u8 red, 
	u8 green, 
	u8 blue, 
	u8 alpha
)
{
	m_color[0] = red;
	m_color[1] = green;
	m_color[2] = blue;
	m_color[3] = alpha;
	return;
}
//______________________________________________________________

#ifndef	__PLAYER_H__
#define	__PLAYER_H__

#include "math.h"
#include "camera.h"

class Player
{
protected:
	Quaternion	orientation;
	v3d		position;
	v3d		velocity;
	v3d		friction;
	Matrix		model;
	Camera		camera;
	bool		transformed;
public:
			Player();
			~Player();

	void		reset();
	void		move(f64 x, f64 y, f64 z);
	void		turn(f64 heading, f64 pitch, f64 roll);
	void		update();
	Matrix&		transform();
	void		view();
	void		render();
	void		getPosition(v3d& u);
	void		getVelocity(v3d& u);
	Camera&		r_camera();
	Quaternion&	rOrientation();
};

#endif
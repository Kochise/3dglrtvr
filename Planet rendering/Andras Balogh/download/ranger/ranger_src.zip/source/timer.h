#pragma once

#include <windows.h>
#include "def.h"

class Timer
{
private:
	LARGE_INTEGER	freq;
	LARGE_INTEGER	old_time;
	LARGE_INTEGER	new_time;
	f32	meta_time;
	f32	time;
	f32	dt;
	f32	fps;
	f32	acc_time;
	u32	acc_frames;
	u32	frames;
	bool	paused;
public:
		Timer();
		~Timer();
	void	reset();
	void	update();
	void	pause();
	float	get_time() const { return time; }
	float	get_metatime() const {return meta_time; }
	float	get_dt() const { return dt; }
	float	get_fps() const { return fps; }
	float	get_avgfps() const { return (float)frames/meta_time; }
};

extern Timer* timer;


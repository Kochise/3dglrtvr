//______________________________________________________________
#include "world.h"
#include "terrain.h"
#include "timer.h"
#include "math.h"
#include "sphere.h"
#include "ball.h"

using namespace Math;

//______________________________________________________________
Ball::Ball
() : 
m_model(4)
{
	reset();
	m_radius = 0.2f;
	m_tesselation_level = 5;
	m_texture = new Image();
	m_texture->loadTGA("ball.tga");
	m_texture->createTexture();
	m_sphere = new Sphere(m_radius, m_tesselation_level, m_texture);
	m_epsilon_distance = 0.01;
	m_max_depth = 3;
	m_contact = false;
	m_mass = 10.4f;
	return;
}

//______________________________________________________________
Ball::~Ball
()
{
	delete m_sphere;
	delete m_texture;
	return;
}

//______________________________________________________________
void 
Ball::reset
()
{
	m_last_position.set(0, 0, 0);
	m_last_velocity.set(0, 0, 0);
	m_last_orientation.identity();
	m_friction = 1.0f;
	m_transformed = false;
	return;
}

//______________________________________________________________
void 
Ball::move
(
	f64	fwd, 
	f64	up, 
	f64	left
)
{
	m_last_position.set(fwd, up, left);
//	m_last_position.set(m_position);
	return;
}

//______________________________________________________________
void
Ball::move
(
	v3d&	i_position
)
{
	m_last_position = i_position;
	return;
}

//______________________________________________________________
void 
Ball::turn
(
	f64	heading, 
	f64	pitch,
	f64	roll
)
{
	m_orientation.rotate(heading, pitch, roll);
	m_orientation.orient();
	return;
}

//______________________________________________________________
void
Ball::update
()
{
//	m_position[1] = world->getTerrain()->getHeight(m_position[0], m_position[2]) + 0.06f;
	m_transformed = false;

	m_current_time = timer->get_time();
	m_time = m_current_time;

	calculate_position();
	calculate_distance();

	v3d normal;
	world->getTerrain()->getNormal(m_position[0], m_position[2], normal);
	if (normal.dprod(m_velocity) < 0) {
		if (m_distance < -m_epsilon_distance) {
			m_contact = false;
			find_collision(m_current_time, m_last_time, m_max_depth);
		}
		if (m_distance < m_epsilon_distance) {
			calculate_collision_response();
		} else {
			m_contact = false;
		}
	}

	m_last_position = m_position;
	m_last_velocity = m_velocity;
	m_last_time = m_time;

	if (m_last_time != m_current_time) {
		update();
	}

	return;
}

//______________________________________________________________
void
Ball::calculate_position
()
{
	v3d	force_gravity(0, -3.81*m_mass, 0);
	v3d	acceleration;

	if (m_contact) {
		// calculate friction and stuff...
	} else {
		acceleration.set(force_gravity);
		acceleration.scale(1/m_mass);
		acceleration.scale(timer->get_dt());
		m_velocity.set(m_last_velocity);
		m_velocity.translate(acceleration);

		v3d velocity(m_velocity);
		velocity.scale(timer->get_dt());

		m_position.set(m_last_position);
		m_position.translate(velocity);
	}

	return;
}

//______________________________________________________________
void
Ball::calculate_distance
()
{
	m_distance = world->getTerrain()->get_distance(m_position);
	m_distance -= m_radius;
	return;
}

//______________________________________________________________
void
Ball::calculate_collision_response
()
{
	if (m_contact) {
		return;
	}

	v3d	n;
	v3d	i(m_velocity);
	world->getTerrain()->getNormal(m_position[0], m_position[2], n);
	m_velocity.add(n.scale(-2*i.dprod(n)), i).scale(0.9);
	
	f64 d(m_velocity.dprod(n));

	if (d < 0.01) {
		n.scale(d);		
		m_velocity.translate(n.negate());
		m_contact = true;
	}
		
	return;
}

//______________________________________________________________
void
Ball::find_collision
(
	f32 i_time1, 
	f32 i_time2, 
	int i_depth
)
{
	f32 m_time = (i_time1 + i_time2) * 0.5f;
	calculate_position();
	calculate_distance();

	if (i_depth == 0) {
		return;
	}

	if (m_distance > m_epsilon_distance) {
		find_collision(i_time1, m_time, i_depth-1);
	} else if (m_distance < -m_epsilon_distance) {
		find_collision(m_time, i_time2, i_depth-1);
	}


	return;
}

//______________________________________________________________
Matrix& 
Ball::transform
()
{
	if (!m_transformed) {
		m_model.identity();
		m_model.translate(m_position);
		m_model.rotate(m_orientation);
		m_transformed = true;
	}

	return m_model;
}

//______________________________________________________________
void
Ball::view
()
{
	m_camera.load(transform());
	return;
}

//______________________________________________________________
void 
Ball::getPosition
(
	v3d& u
)
{
	u = m_position;
	return;
}

//______________________________________________________________
void 
Ball::getVelocity
(
	v3d& u
)
{
	u = m_velocity;
	return;
}

//______________________________________________________________
void 
Ball::setVelocity
(
	v3d& u
)
{
	m_last_velocity = u;
	m_contact = false;
	return;
}

//______________________________________________________________
Camera& 
Ball::r_camera
()
{
	return m_camera;
}

//______________________________________________________________
Quaternion& 
Ball::rOrientation
()
{
	return m_orientation;
}

//______________________________________________________________
void
Ball::render()
{
	opengl->ActiveTexture(GL_TEXTURE1_ARB);
	v4f s_plane(0.04, 0, 0, -timer->get_time()/20.0+0.04*m_position[0]);
	v4f t_plane(0, 0, 0.04, 0.04*m_position[2]);
	glTexGenfv(GL_S, GL_OBJECT_PLANE, s_plane);
	glTexGenfv(GL_T, GL_OBJECT_PLANE, t_plane);

	transform();
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	opengl->MultTransposeMatrixd(m_model.dump());
//	glRotatef(timer->get_time()*20, 0, 1, 0);
	m_sphere->render(3);
	glPopMatrix();
	return;
}

//______________________________________________________________
f32
Ball::distance
()
{
	return m_distance;
}

//______________________________________________________________

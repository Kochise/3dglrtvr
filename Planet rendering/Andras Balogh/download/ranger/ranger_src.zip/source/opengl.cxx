//______________________________________________________________
#include <stdlib.h>
#include <string.h>
#include "console.h"
#include "opengl.h"

//______________________________________________________________
OpenGL::OpenGL()
{
	int	glInfo[3];

	console->write(
		"OpenGL implementation:\n"
		"\tVendor   : %s\n"
		"\tRenderer : %s\n"
		"\tVersion  : %s\n",
		glGetString(GL_VENDOR),
		glGetString(GL_RENDERER),
		glGetString(GL_VERSION)
	);

	glGetIntegerv(GL_MAX_TEXTURE_SIZE, glInfo);
	console->write("\tMAX_TEXTURESIZE = %d\n", glInfo[0]);

	glGetIntegerv(GL_MAX_TEXTURE_UNITS_ARB, glInfo);
	console->write("\tMAX_TEXTURE_UNITS = %d\n", glInfo[0]);

	console->write("\nSupported extensions :\n");

	GLubyte *extensions = new GLubyte[strlen((char *)glGetString(GL_EXTENSIONS))+1];
	strcpy((char *)extensions, (char *)glGetString(GL_EXTENSIONS));

	unsigned int	a = 0;
	unsigned int	z = 0;

	for (z=0; extensions[z] != '\0'; z++) {
		if (extensions[z] == ' ') {
			extensions[z] = '\0';
			console->write("\t%s\n", (char *)&extensions[a]);
			extensions[z] = ' ';
			a = z+1;
		}
	}

	delete [] extensions;

	console->write(
		"\n"
		"\n"
		"Checking for required extensions :\n"
	);

	if (isExtensionSupported("GL_ARB_transpose_matrix")) {
		glLoadTransposeMatrixfARB = (PFNGLLOADTRANSPOSEMATRIXFARBPROC) wglGetProcAddress("glLoadTransposeMatrixfARB");
		glLoadTransposeMatrixdARB = (PFNGLLOADTRANSPOSEMATRIXDARBPROC) wglGetProcAddress("glLoadTransposeMatrixdARB");
		glMultTransposeMatrixfARB = (PFNGLMULTTRANSPOSEMATRIXFARBPROC) wglGetProcAddress("glMultTransposeMatrixfARB");
		glMultTransposeMatrixdARB = (PFNGLMULTTRANSPOSEMATRIXDARBPROC) wglGetProcAddress("glMultTransposeMatrixdARB");
	}
	if (isExtensionSupported("GL_ARB_multitexture")) {
		glActiveTextureARB = (PFNGLACTIVETEXTUREARBPROC) wglGetProcAddress("glActiveTextureARB");
	}
	if (isExtensionSupported("GL_EXT_draw_range_elements")) {
		glDrawRangeElementsEXT = (PFNGLDRAWRANGEELEMENTSEXTPROC) wglGetProcAddress("glDrawRangeElementsEXT");
	}
	

	console->write("\n\n");

	return;
}
//______________________________________________________________
OpenGL::~OpenGL()
{
	return;
}

//______________________________________________________________
bool OpenGL::isExtensionSupported(const char *string)
{
	unsigned int	a = 0;
	unsigned int	z = 0;
	bool		result = false;

	console->write("\t%s...", string);

	GLubyte* extensions = new GLubyte[strlen((char *)glGetString(GL_EXTENSIONS))+1];
	strcpy((char *)extensions, (char *)glGetString(GL_EXTENSIONS));
	
	for (z=0; extensions[z] != '\0'; z++) {
		if (extensions[z] == ' ') {
			extensions[z] = '\0';

			if (!strcmp(string, (char *)&extensions[a])) {
				result = true;
			}
			extensions[z] = ' ';
			a = z+1;
		}
	}

	delete [] extensions;

	if (result) {
		console->write("OK\n");
	} else {
		console->write("FAILED\n");
	}

	return result;
}

//______________________________________________________________

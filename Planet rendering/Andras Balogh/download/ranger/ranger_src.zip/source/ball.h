#ifndef	__BALL_H__
#define	__BALL_H__

#include "math.h"
#include "camera.h"
#include "image.h"
#include "sphere.h"

class Ball
{
protected:
	Sphere*		m_sphere;
	Image*		m_texture;
	int		m_tesselation_level;
	f32		m_radius;
	bool		m_contact;
	f32		m_mass;

	Quaternion	m_last_orientation;
	v3d		m_last_position;
	v3d		m_last_velocity;
	f32		m_last_time;

	Quaternion	m_orientation;
	v3d		m_position;
	v3d		m_velocity;
	f32		m_time;

	f32		m_friction;
	Matrix		m_model;
	Camera		m_camera;
	bool		m_transformed;

	f32		m_current_time;
	f32		m_distance;
	f32		m_epsilon_distance;
	int		m_max_depth;

	void		calculate_position();
	void		calculate_distance();
	void		calculate_collision_response();
	void		find_collision(f32 i_time1, f32 i_time2, int i_depth);
public:
			Ball();
			~Ball();

	void		reset();
	void		move(f64 x, f64 y, f64 z);
	void		move(v3d& i_position);
	void		turn(f64 heading, f64 pitch, f64 roll);
	void		update();
	Matrix&		transform();
	void		view();
	void		render();

	f32		distance();
	void		getPosition(v3d& u);
	void		getVelocity(v3d& u);
	void		setVelocity(v3d& u);
	Camera&		r_camera();
	Quaternion&	rOrientation();
};

#endif
//______________________________________________________________
#include "opengl.h"
#include "sphere.h"
#include "timer.h"
#include "world.h"

using namespace Math;

const f32	x = .525731112119133606f;
const f32	z = .850650808352039932f;

f32 Sphere::vertices[12][3] = {
	{-x,  0, +z}, {+x,  0, +z}, {-x,  0, -z}, {+x,  0, -z},
	{ 0, +z, +x}, { 0, +z, -x}, { 0, -z, +x}, { 0, -z, -x},
	{+z, +x,  0}, {-z, +x,  0}, {+z, -x,  0}, {-z, -x,  0}
};

u8 Sphere::indices[20][3] = {
	{ 1,  4,  0}, { 4,  9,  0}, { 4,  5,  9}, { 8,  5,  4}, { 1,  8,  4},
	{ 1, 10,  8}, {10,  3,  8}, { 8,  3,  5}, { 3,  2,  5}, { 3,  7,  2},
	{ 3, 10,  7}, {10,  6,  7}, { 6, 11,  7}, { 6,  0, 11}, { 6,  1,  0},
	{10,  1,  6}, {11,  0,  9}, { 2, 11,  9}, { 5,  2,  9}, {11,  2,  7}
};

//______________________________________________________________
Sphere::Sphere
(
	f32	i_scale,
	int	i_depth,
	Image*	i_texture
)
{
	m_scale	= i_scale;
	m_depth	= i_depth;
	m_texture = i_texture;
	dl_sphere = glGenLists(m_depth);

	for (int i=0; i<m_depth; i++) {
		glNewList(dl_sphere+i, GL_COMPILE);
		build(i);
		glEndList();
	}

	return;
}

//______________________________________________________________
Sphere::~Sphere
()
{
	glDeleteLists(dl_sphere, m_depth);
	return;
}

//______________________________________________________________
void 
Sphere::build
(
	int depth
)
{
	glColor4ub(255, 255, 255, 255);
	glDisable(GL_NORMALIZE);
	for (int i=0; i<20; i++) {
		v3f v0(vertices[indices[i][0]]);
		v3f v1(vertices[indices[i][1]]);
		v3f v2(vertices[indices[i][2]]);
		v0.scale(m_scale);
		v1.scale(m_scale);
		v2.scale(m_scale);
		triangle(v0, v1, v2, depth);
	}
	return;
}

//______________________________________________________________
void
Sphere::triangle
(
	v3f v0, 
	v3f v1, 
	v3f v2, 
	int depth
)
{
	if (depth > 0) {
		v3f v01, v12, v20;
		v01.add(v0, v1); v01.setlength(m_scale);
		v12.add(v1, v2); v12.setlength(m_scale);
		v20.add(v2, v0); v20.setlength(m_scale);

		triangle( v0, v01, v20, depth-1);
		triangle(v01,  v1, v12, depth-1);
		triangle(v20, v12,  v2, depth-1);
		triangle(v01, v12, v20, depth-1);
	} else {
		v3f n0(v0);
		v3f n1(v1);
		v3f n2(v2);
		v2f t0;
		v2f t1;
		v2f t2;

		n0.scale(1.0f/m_scale);
		n1.scale(1.0f/m_scale);
		n2.scale(1.0f/m_scale);

		texture_coord(t0, n0); 
		texture_coord(t1, n1); 
		texture_coord(t2, n2); 

		bool nt0 = t0[0] < -0.4f;
		bool nt1 = t1[0] < -0.4f;
		bool nt2 = t2[0] < -0.4f;
		bool pt0 = t0[0] > +0.4f;
		bool pt1 = t1[0] > +0.4f;
		bool pt2 = t2[0] > +0.4f;

		if (nt0 && (pt1 || pt2)) t0[0] += 1.0f;
		if (nt1 && (pt0 || pt2)) t1[0] += 1.0f;
		if (nt2 && (pt0 || pt1)) t2[0] += 1.0f;

		if (fabs(n0[1] - 1) < EPS) t0[0] = (t1[0] + t2[0]) * 0.5f;
		if (fabs(n1[1] - 1) < EPS) t1[0] = (t0[0] + t2[0]) * 0.5f;
		if (fabs(n2[1] - 1) < EPS) t2[0] = (t0[0] + t1[0]) * 0.5f;

		glBegin(GL_TRIANGLES); {
			glTexCoord2fv(t0); glNormal3fv(n0); glVertex3fv(v0);
			glTexCoord2fv(t1); glNormal3fv(n1); glVertex3fv(v1);
			glTexCoord2fv(t2); glNormal3fv(n2); glVertex3fv(v2);
		} glEnd();
	}
	return;
}

//______________________________________________________________
void
Sphere::texture_coord
(
	v2f& t,
	v3f& v
)
{
	f32	phi;
	f32	theta;
	f32	tmp;

	theta = asinf(v[1]);
	tmp = v[0]/cosf(theta);
	clampf(tmp, 1.0f);
	phi = acosf(tmp);
	phi /= PI * 2.0f;

	t[0] = phi; if (v[2] > 0) t[0] *= -1.0f;
	t[1] = theta / PI + 0.5f;
	
	return;
}

//______________________________________________________________
void
Sphere::render
(
	int	i_depth, 
	bool	i_lighting, 
	bool	i_flat
)
{
	if (i_depth >= m_depth) i_depth = m_depth - 1;

	glEnable(GL_DEPTH_TEST);

	if (world->m_flat) {
		glEnable(GL_LIGHTING);
		glShadeModel(GL_FLAT);
	} else {
		if (i_lighting) {
			glEnable(GL_LIGHTING);
			glShadeModel(GL_SMOOTH);
		}
		opengl->ActiveTexture(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		m_texture->bind(GL_MODULATE, GL_REPEAT, GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR);
	}

	glCallList(dl_sphere+i_depth);

	if (world->m_flat) {
		glDisable(GL_LIGHTING);
	} else {
		if (i_lighting) glDisable(GL_LIGHTING);
		opengl->ActiveTexture(GL_TEXTURE0_ARB);
		glDisable(GL_TEXTURE_2D);
	}

	return;
}

//______________________________________________________________

//______________________________________________________________
#include "window.h"
#include "console.h"
#include "input.h"
#include "timer.h"
#include "world.h"

//______________________________________________________________
World::World()
{
	m_player	= new Player;
	m_terrain	= new Terrain;
	m_hud		= new HUD;
	m_ball		= new Ball;

	m_ball->move(0, 2, 0);
//	PlaySound("sound.wav", NULL, SND_FILENAME | SND_LOOP | SND_ASYNC);

	m_normals = false;
	m_flat = false;
	m_multitexture = true;

	return;
}

//______________________________________________________________
World::~World()
{
//	PlaySound(NULL, NULL, 0 );

	delete m_player;	m_player	= 0;
	delete m_terrain;	m_terrain	= 0;
	delete m_hud;		m_hud		= 0;
	delete m_ball;		m_ball		= 0;

        return;
}

//______________________________________________________________
void World::update()
{
	v3f move;

	if (input->keyp(VK_ESCAPE)) PostQuitMessage(0);
	if (input->keyp(123)) m_hud->toggle();
	if (input->buttonp(2)) m_hud->toggle();

	input->getMove(move);
	move.scale(1/200.0f);
	m_player->r_camera().turn(0, -move[2], 0);
	m_player->turn(-move[0], 0, 0);

	if (console->isActive()) {

		if (input->keyd(VK_CONTROL)) {
			if (input->keyp(VK_UP))		console->scroll(-1);
			if (input->keyp(VK_DOWN))	console->scroll(1);
		} else {
			if (input->keyd(VK_UP))		console->scroll(-1, 50.0f);
			if (input->keyd(VK_DOWN))	console->scroll(1, 50.0f);
		}

		if (input->buttond(0))	console->scroll(1, 50.0f);
		if (input->buttond(1))	console->scroll(-1, 50.0f);

		if (input->keyp(33))	console->page(-1);
		if (input->keyp(34))	console->page(1);

		if (input->keyp(36))	console->home();
		if (input->keyp(35))	console->end();
	} else {
		if (input->buttond(0)) {
			v3d pos;
			v3d vel;
			m_player->getPosition(pos);
			m_player->getVelocity(vel);
			vel.translate(0, 1.8, 0);
			pos.translate(0, 0.3, 0);
			m_ball->move(pos);
			m_ball->setVelocity(vel);
		}
		if (input->buttond(1)) {
			m_player->move(-0.05f, 0, 0);
		} else {
			if (input->keyd('W'))	m_player->move(-0.05f, 0, 0);
			if (input->keyd('S'))	m_player->move(0.05f, 0, 0);
		}

		if (input->keyd('A'))	m_player->move(0, 0, -0.05f);
		if (input->keyd('D'))	m_player->move(0, 0, 0.05f);
		if (input->keyd(' '))	m_player->reset();
		
		if (input->keyd('R'))	m_player->r_camera().r_fovy() -= 1.0;
		if (input->keyd('F'))	m_player->r_camera().r_fovy() += 1.0;
		
		if (input->keyp('N'))	m_normals = !m_normals;
		if (input->keyp('B'))	m_flat = !m_flat;
		if (input->keyp('M'))	m_multitexture = !m_multitexture;
	}

	timer->update();
	input->update();
	console->update();
	m_terrain->update();
	m_player->update();
	m_ball->update();

	return;
}

//______________________________________________________________
void World::render()
{
//	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
//	glColor4ub(255, 255, 255, 255);

	m_player->view();
	m_terrain->render();
	m_ball->render();

	opengl->ActiveTexture(GL_TEXTURE1_ARB);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);

	m_hud->render();
	console->render();

	glFlush();
	window->swapbuffers();
	return;
}

//______________________________________________________________

#pragma once

#include "image.h"

class Font
{
private:
	Image*	m_font;
	u8	m_color[4];
	f32	m_sizex;
	f32	m_sizey;
	u16	m_rows;
	u16	m_cols;

public:
		Font();
		~Font();
	void	load_font(const char* path, u16 x, u16 y);
	void	render(const char* s, u16 i, f32 ulx, f32 uly, f32 lrx, f32 lry);
	void	set_color(u8 red, u8 green, u8 blue, u8 alpha);
};

extern Font* font;


#pragma once

#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glext.h>

class OpenGL
{
private:
	PFNGLLOADTRANSPOSEMATRIXFARBPROC glLoadTransposeMatrixfARB;
	PFNGLLOADTRANSPOSEMATRIXDARBPROC glLoadTransposeMatrixdARB;
	PFNGLMULTTRANSPOSEMATRIXFARBPROC glMultTransposeMatrixfARB;
	PFNGLMULTTRANSPOSEMATRIXDARBPROC glMultTransposeMatrixdARB;
	PFNGLDRAWRANGEELEMENTSEXTPROC	glDrawRangeElementsEXT;
	PFNGLACTIVETEXTUREARBPROC glActiveTextureARB;
public:
		OpenGL();
		~OpenGL();
	bool	isExtensionSupported(const char *string);
	void	LoadTransposeMatrixf(const GLfloat* m) {glLoadTransposeMatrixfARB(m);}
	void	LoadTransposeMatrixd(const GLdouble* m) {glLoadTransposeMatrixdARB(m);}
	void	MultTransposeMatrixf(const GLfloat* m) {glMultTransposeMatrixfARB(m);}
	void	MultTransposeMatrixd(const GLdouble* m) {glMultTransposeMatrixdARB(m);}
	void	DrawRangeElements(GLenum mode, GLuint start, GLuint end, GLsizei count, GLenum type, const GLvoid* indices) {glDrawRangeElementsEXT(mode, start, end, count, type, indices);}
	void	ActiveTexture(GLenum unit) {glActiveTextureARB(unit);}
};

extern OpenGL *opengl;


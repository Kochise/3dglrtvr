//______________________________________________________________
#include "world.h"
#include "terrain.h"
#include "timer.h"
#include "math.h"
#include "player.h"

//______________________________________________________________
Player::Player
() : 
model(4)
{
	reset();
	return;
}

//______________________________________________________________
Player::~Player
()
{
	return;
}

//______________________________________________________________
void 
Player::reset
()
{
	position.set(0, 0, 0);
	velocity.set(0, 0, 0);
	friction.set(1, 1, 1);
	orientation.identity();
	transformed = false;
	return;
}

//______________________________________________________________
void 
Player::move
(
	f64	fwd, 
	f64	up, 
	f64	left
)
{
	v3d	v;

	orientation.getFwd(v);
	v.scale(fwd);
	velocity.translate(v);

	orientation.getUp(v);
	v.scale(up);
	velocity.translate(v);

	orientation.getLeft(v);
	v.scale(left);
	velocity.translate(v);

	velocity.maxlength(2.0f);

	return;
}

//______________________________________________________________
void 
Player::turn
(
	f64	heading, 
	f64	pitch,
	f64	roll
)
{
	orientation.rotate(heading, pitch, roll);
	orientation.orient();
	return;
}

//______________________________________________________________
void
Player::update
()
{
	f32	dt = timer->get_dt();
	v3d	v, f, n, up;

	v = velocity;
	f = friction;

	v.scale(dt);
	f.scale(dt);
	position.translate(v);
	velocity.shrink(f);
	position[1] = world->getTerrain()->getHeight(position[0], position[2]) + 0.1f;

	world->getTerrain()->getNormal(position[0], position[2], n);
	orientation.getUp(up);
	f64 t = n.dprod(up);

	if (fabs(t) < 1-Math::EPS) {
		f32 theta = (f32)acos(t);
		v.xprod(up, n);
		v.normalize();
		orientation.rotate(theta, v);
		orientation.orient();
	}

	transformed = false;

	return;
}

//______________________________________________________________
Matrix& 
Player::transform
()
{
	if (!transformed) {
		model.identity();
		model.translate(position);
		model.rotate(orientation);
		transformed = true;
	}

	return model;
}

//______________________________________________________________
void
Player::view
()
{
	camera.load(transform());
	return;
}

//______________________________________________________________
void 
Player::getPosition
(
	v3d& u
)
{
	u = position;
	return;
}

//______________________________________________________________
void 
Player::getVelocity
(
	v3d& u
)
{
	u = velocity;
	return;
}

//______________________________________________________________
Camera& 
Player::r_camera
()
{
	return camera;
}

//______________________________________________________________
Quaternion& 
Player::rOrientation
()
{
	return orientation;
}

//______________________________________________________________

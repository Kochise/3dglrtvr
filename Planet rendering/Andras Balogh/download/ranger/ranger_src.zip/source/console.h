#pragma once

#include "def.h"
#include "math.h"

//______________________________________________________________
class Console
{
private:
	char*	text;
	char*	command;

	u8	cPos;
	u16	dPos;
	u16	wPos;
	u16	cols;
	u16	rows;
	
	f32	speed;
	f32	offset;
	int	target;

	Matrix	view;
	Matrix	projection;

	bool	active;
	f32	time;
public:
		Console(u16 i_cols=80, u16 i_rows=49);
		~Console();
	void	write( const char *format, ... );
	void	load( char *string );
	void	jump( int lines );
	void	scroll( int lines, f32 speed = 10.0f );
	void	page( int pages, f32 speed = 100.0f );
	void	home();
	void	end();
	void	update();
	void	render();
	void	cmd(u8 c);
	bool	isActive();
};

extern Console* console;


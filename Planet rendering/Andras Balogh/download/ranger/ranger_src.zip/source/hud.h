#ifndef	__HUD_H__
#define	__HUD_H__

#include "math.h"

class HUD {
private:
	char*	text;
	Matrix	view;
	Matrix	projection;
	bool	active;
	f32	time;
public:
	HUD();
	~HUD();
	void render();
	void toggle();
};

#endif
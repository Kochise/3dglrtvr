//______________________________________________________________
#include "math.h"
#include "camera.h"
#include "opengl.h"

//______________________________________________________________
Camera::Camera
() : 
m_view(4), 
m_projection(4)
{
	reset();
	return;
}

//______________________________________________________________
Camera::~Camera
()
{
	return;
}

//______________________________________________________________
void 
Camera::reset
()
{
	m_fovy = 90.0f;
	m_aspect = 4.0f/3.0f;
	m_position.set(0, 0, 0);
	m_orientation.identity();
	return;
}

//______________________________________________________________
void 
Camera::turn
(
	f32	heading, 
	f32	pitch, 
	f32	roll
)
{
	m_orientation.rotate(heading, pitch, roll);
	return;
}

//______________________________________________________________
void
Camera::load
(Matrix& model)
{
	m_view.load(model);
	m_view.translate(m_position);
	m_view.rotate(m_orientation);
	m_view.fastinvert();
	m_view.setModelview();

	m_projection.identity();
	m_projection.perspective(m_fovy, m_aspect, 0.02f, 100.0f);
	m_projection.setProjection();

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(90, 4.0/3.0, 0.01, 200.0);

	return;
}

//______________________________________________________________
void
Camera::getPosition
(
	v3d& u
)
{
	u.set(m_position);
	return;
}

//______________________________________________________________

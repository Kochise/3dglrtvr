#include "main.h"

Main		application;

int main( int argc, char **argv )
{
	application.init(argc, argv);
	return application.run();
}

#ifndef	__SPHERE_H__
#define	__SPHERE_H__

#include "math.h"
#include "image.h"

class Sphere
{
protected:
	static f32	vertices[12][3];
	static u8	indices[20][3];
	GLuint		dl_sphere;
	f32		m_scale;
	int		m_depth;
	Image*		m_texture;

	void	build(int depth);
	void	triangle(v3f v0, v3f v1, v3f v2, int depth);
	void	texture_coord(v2f& t, v3f& v);
public:
		Sphere(f32 i_scale, int i_depth, Image* i_texture);
		~Sphere();
	void	render(int i_depth, bool i_lighting = false, bool i_flat = false);
};

#endif
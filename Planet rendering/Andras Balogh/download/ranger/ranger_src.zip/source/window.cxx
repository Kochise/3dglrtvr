//______________________________________________________________
#include "console.h"
#include "world.h"
#include "input.h"
#include "window.h"

//______________________________________________________________
Window::Window
()
{
	m_hInstance	= GetModuleHandle(NULL);
	m_hWnd		= 0;
	m_hDC		= 0;
	m_hRC		= 0;

	WNDCLASS	wc;
	wc.style	= CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc	= dispatcher;
	wc.cbClsExtra	= 0;
	wc.cbWndExtra	= 0;
	wc.hInstance	= m_hInstance;
	wc.hIcon	= NULL;
	wc.hCursor	= NULL;
	wc.hbrBackground= NULL;
	wc.lpszMenuName	= NULL;
	wc.lpszClassName= "OpenGL";
	RegisterClass(&wc);

	sysinfo();
	return;
}

//______________________________________________________________
Window::~Window
()
{
	destroy();
	UnregisterClass("OpenGL", m_hInstance);

	return;
}

//______________________________________________________________
void 
Window::create
(
	int width,
	int height,
	bool fullscreen
)
{
	m_width		= width;
	m_height	= height;
	m_fullscreen	= fullscreen;

	m_color		= 32;
	m_depth		= 24;
	m_stencil	= 0;
	m_alpha		= 0;

	int	i;

	DISPLAY_DEVICE	dd;
	dd.cb = sizeof(DISPLAY_DEVICE);

	console->write("Display devices:\n");
	for (i=0; EnumDisplayDevices(NULL, i, &dd, 0); i++) {
		console->write("\t%s: %s", dd.DeviceName, dd.DeviceString);
		if (dd.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE) {
			console->write(" *\n");
		} else {
			console->write("\n");
		}
	}
	console->write("\n");

	DEVMODE	dm;
	dm.dmSize = sizeof(dm);
	dm.dmDriverExtra = 0;

	DEVMODE	sdm;
	sdm.dmSize		= sizeof(sdm);
	sdm.dmDriverExtra	= 0;
	sdm.dmDisplayFrequency	= 0;
	sdm.dmPelsWidth		= m_width;
	sdm.dmPelsHeight	= m_height;
	sdm.dmBitsPerPel	= m_color;

	console->write("Display modes:\n");
	for (i=0; EnumDisplaySettings(NULL, i, &dm); i++) {
		if (
			dm.dmPelsWidth == sdm.dmPelsWidth &&
			dm.dmPelsHeight == sdm.dmPelsHeight &&
			dm.dmBitsPerPel == sdm.dmBitsPerPel &&
			dm.dmDisplayFrequency > sdm.dmDisplayFrequency
		) {
			EnumDisplaySettings(NULL, i, &sdm);
		}

		if (dm.dmBitsPerPel >= 24 ) {
			console->write(
				"\t%dx%dx%d@%d\n",
				dm.dmPelsWidth,
				dm.dmPelsHeight,
				dm.dmBitsPerPel,
				dm.dmDisplayFrequency	
			);
		}
	}
	console->write("\n");

	if (m_fullscreen) {
		sdm.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT | DM_DISPLAYFREQUENCY;
		ChangeDisplaySettingsEx(NULL, &sdm, NULL, 0, NULL);
	}

	ShowCursor(FALSE);
	
	m_hWnd = CreateWindow(
		"OpenGL",
		"Ranger",
		(m_fullscreen ? WS_POPUP : WS_OVERLAPPEDWINDOW) | 
		WS_VISIBLE | 
		WS_CLIPCHILDREN | 
		WS_CLIPSIBLINGS,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		m_width,
		m_height,
		NULL,
		NULL,
		m_hInstance,
		NULL
	);

	PIXELFORMATDESCRIPTOR	pfd;
	pfd.nSize		= sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion		= 1;
	pfd.dwFlags		= PFD_SUPPORT_OPENGL | PFD_DRAW_TO_WINDOW | PFD_DOUBLEBUFFER;
	pfd.iPixelType		= PFD_TYPE_RGBA;
	pfd.cColorBits		= m_color;
	pfd.cRedBits		= 0;
	pfd.cRedShift		= 0;
	pfd.cGreenBits		= 0;
	pfd.cGreenShift		= 0;
	pfd.cBlueBits		= 0;
	pfd.cBlueShift		= 0;
	pfd.cAlphaBits		= m_alpha;
	pfd.cAlphaShift		= 0;
	pfd.cAccumBits		= 0;
	pfd.cAccumRedBits	= 0;
	pfd.cAccumGreenBits	= 0;
	pfd.cAccumBlueBits	= 0;
	pfd.cAccumAlphaBits	= 0;
	pfd.cDepthBits		= m_depth;
	pfd.cStencilBits	= m_stencil;
	pfd.cAuxBuffers		= 0;
	pfd.iLayerType		= 0;
	pfd.bReserved		= 0;
	pfd.dwLayerMask		= 0;
	pfd.dwVisibleMask	= 0;
	pfd.dwDamageMask	= 0;

	m_hDC = GetDC(m_hWnd);
	int pf = ChoosePixelFormat(m_hDC, &pfd);
	DescribePixelFormat(m_hDC, pf, sizeof(PIXELFORMATDESCRIPTOR), &pfd);
	SetPixelFormat(m_hDC, pf, &pfd);
	m_hRC = wglCreateContext(m_hDC);
	wglMakeCurrent(m_hDC, m_hRC);
	SetCapture(m_hWnd);

	console->write(
		"Creating window :\n"
		"\tType    : %s\n"
		"\tWidth   : %d\n"
		"\tHeight  : %d\n"
		"\tColor   : %d\n"
		"\tDepth   : %d\n"
		"\tStencil : %d\n"
		"\tAlpha   : %d\n"
		"\n",
		m_fullscreen ? "fullscreen" : "windowed",
		m_width,
		m_height,
		pfd.cColorBits,
		pfd.cDepthBits,
		pfd.cStencilBits,
		pfd.cAlphaBits
	);

	return;
}

//______________________________________________________________
void
Window::destroy
()
{
	if (m_hRC) {
		wglMakeCurrent(NULL, NULL);
		wglDeleteContext(m_hRC);
	}
	if (m_hDC) {
		ReleaseDC(m_hWnd, m_hDC);
	}

	if (m_hWnd) {
		ReleaseCapture();
		DestroyWindow(m_hWnd);
	}

	if (m_fullscreen) {
		ChangeDisplaySettings(NULL, 0);
	}

	ShowCursor(TRUE);

	return;
}

//______________________________________________________________
void 
Window::resize
()
{
	if (m_hWnd) {
		RECT	rect;

		GetClientRect(m_hWnd, &rect);

		m_width	 = rect.right - rect.left;
		m_height = rect.bottom - rect.top;
	}

	glViewport(0, 0, m_width, m_height);

	return;
}

//______________________________________________________________
void 
Window::swapbuffers
()
{
	SwapBuffers(m_hDC);
	return;
}

//______________________________________________________________
void
Window::sysinfo()
{
	char		buffer[255];
	u32		size;
	SYSTEM_INFO	sysinfo;

	console->write("System information\n");

	size = 255;
	GetComputerName(buffer, &size);
	console->write("\tComputer name: %s\n", buffer);

	size = 255;
	GetUserName(buffer, &size);
	console->write("\tUser name    : %s\n", buffer);

	GetSystemInfo(&sysinfo);
	console->write("\tCPU SMP      : %s\n", sysinfo.dwNumberOfProcessors > 1 ? "yes" : "no");
	console->write("\tCPU Level    : %d\n", sysinfo.wProcessorLevel);
	console->write("\tCPU Model    : %d\n", sysinfo.wProcessorRevision >> 8);
	console->write("\tCPU Stepping : %d\n", sysinfo.wProcessorRevision & 0x00ff);

	MEMORYSTATUS	memory;
	GlobalMemoryStatus(&memory);
	console->write("\tTotal memory : %luMB\n", memory.dwTotalPhys >> 20);
	console->write("\tFree memory  : %luMB\n", memory.dwAvailPhys >> 20);
	console->write("\n");
	return;
}

//______________________________________________________________
LRESULT CALLBACK 
Window::dispatcher
(
	HWND	hWnd,
	UINT	uMsg,
	WPARAM	wParam,
	LPARAM	lParam
)
{
	switch (uMsg) {

	case WM_CLOSE:		PostQuitMessage(0);	break;
	case WM_SIZE:		window->resize();	return 0;
	case WM_CHAR:		console->cmd(wParam);	return 0;
	case WM_KEYDOWN:	input->keydown(wParam); return 0;
	case WM_KEYUP:		input->keyup(wParam);	return 0;
	case WM_LBUTTONDOWN:	input->buttondown(0);	break;
	case WM_LBUTTONUP:	input->buttonup(0);	break;	
	case WM_RBUTTONDOWN:	input->buttondown(1);	break;
	case WM_RBUTTONUP:	input->buttonup(1);	break;
	case WM_MBUTTONDOWN:	input->buttondown(2);	break;
	case WM_MBUTTONUP:	input->buttonup(2);	break;
	case WM_ACTIVATE:	input->toggle();	return 0;
	case WM_SYSCOMMAND:	if (wParam == SC_SCREENSAVE) return 0;
	default:
		break;
	
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

//______________________________________________________________

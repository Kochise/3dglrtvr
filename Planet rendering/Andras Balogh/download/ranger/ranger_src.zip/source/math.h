//______________________________________________________________
#pragma once

//______________________________________________________________
#include <math.h>
#include "def.h"

//______________________________________________________________
template <class T> class Vector2;
template <class T> class Vector3;
template <class T> class Vector4;
class Quaternion;
class Matrix;

//______________________________________________________________
typedef	Vector2<f32>	v2f;
typedef	Vector3<f32>	v3f;
typedef	Vector4<f32>	v4f;
typedef	Vector3<f64>	v2d;
typedef	Vector3<f64>	v3d;
typedef	Vector4<f64>	v4d;
typedef	Quaternion	q;
typedef	Matrix		m;

//______________________________________________________________
namespace Math
{
const	f32	PI	= 3.141592653589793238462643383279502884197169399375105820974944f;
const	f32	DEG2RAD	= 3.141592653589793238462643383279502884197169399375105820974944f / 180.0f;
const	f32	RAD2DEG	= 180.0f / 3.141592653589793238462643383279502884197169399375105820974944f;
const	f32	INF	= 1.0e+10f;
const	f32	EPS	= 1.0e-10f;
const	f32	ZERO	= 0.0f;
const	f32	ONE	= 1.0f;

inline	int	sgn(f64 f) {return f >= 0 ? 1:-1;}
inline	int	sgnf(f32 f) {return f >= 0 ? 1:-1;}
inline	void	clamp(f64& a, f64 b) {a = (a>0) ? (a>b ? b:a) : (a<-b ? -b:a);}
inline	void	clampf(f32& a, f32 b) {a = (a>0) ? (a>b ? b:a) : (a<-b ? -b:a);}
inline	void	shrink(f64& a, f64 b) {a -= (a>0) ? (a>b ? b:a) : (a<-b ? -b:a);}
inline	f64	c(f64 f) { return cos(f*DEG2RAD); }
inline	f64	s(f64 f) { return sin(f*DEG2RAD); }
}

//______________________________________________________________
#pragma pack(push, 1)

template <class T>
class Vector2
{
private:
	T	v[2];
public:
			Vector2() {}
			Vector2(T f) {v[0]=f, v[1]=f;}
			Vector2(T* f) {v[0]=f[0], v[1]=f[1];}
			Vector2(Vector2& u) {v[0]=u[0], v[1]=u[1];}
			Vector2(T x, T y) {v[0]=x, v[1]=y;}
			~Vector2() {}

			operator T* () {return v;}
	T&		operator[] (int i) {return v[i];}
	T&		operator[] (u32 i) {return v[i];}
	Vector2&	set(T f) {v[0]=f, v[1]=f; return *this;}
	Vector2&	set(Vector2& u) {v[0]=u[0], v[1]=u[1]; return *this;}
	Vector2&	set(T x, T y) {v[0]=x, v[1]=y; return *this;}
	Vector2&	clamp(Vector2& u) {Math::clamp(v[0], u[0]), Math::clamp(v[1], u[1]); return *this;}
	Vector2&	negate() {v[0]=-v[0], v[1]=-v[1]; return *this;}
	Vector2&	scale(T f) {v[0]*=f, v[1]*=f; return *this;}
	Vector2&	scale(Vector2& u) {v[0]*=u[0], v[1]*=u[1]; return *this;}
	Vector2&	translate(T x, T y) {v[0]+=x, v[1]+=y; return *this;}
	Vector2&	translate(Vector2& u) {v[0]+=u[0], v[1]+=u[1]; return *this;}
	Vector2&	add(Vector2& a, Vector2& b) {v[0]=a[0]+b[0], v[1]=a[1]+b[1]; return *this;}
	Vector2&	sub(Vector2& a, Vector2& b) {v[0]=a[0]-b[0], v[1]=a[1]-b[1]; return *this;}
	T		dprod(Vector2& u) {return v[0]*u[0] + v[1]*u[1];}
	T		length() {return (T)sqrt(dprod(*this));}
	Vector2&	normalize() {scale(1/length()); return *this;}
	Vector2&	setlength(T f) {scale(f/length()); return *this;}
	Vector2&	minlength(T f) {T l=length(); scale((l>f?l:f)/l); return *this;}
	Vector2&	maxlength(T f) {T l=length(); scale((l<f?l:f)/l); return *this;}
	Vector2&	normal(Vector2& a) {v[0]=-a[1]; v[1]=a[0]; return *this;}
	Vector2&	shrink(Vector2& u) {Math::shrink(v[0], u[0]); Math::shrink(v[1], u[1]); return *this;}
	Vector2&	print( const char *s = "vector") {printf("%s: %f %f\n", s, v[0], v[1]); return *this;}
};

template <class T>
class Vector3
{
private:
	T	v[3];
public:
			Vector3() {}
			Vector3(T f) {v[0]=f, v[1]=f, v[2]=f;}
			Vector3(T* f) {v[0]=f[0], v[1]=f[1], v[2]=f[2];}
			Vector3(Vector3& u) {v[0]=u[0], v[1]=u[1], v[2]=u[2];}
			Vector3(T x, T y, T z) {v[0]=x, v[1]=y, v[2]=z;}
			~Vector3() {}

			operator T* () {return v;}
	T&		operator[] (int i) {return v[i];}
	T&		operator[] (u32 i) {return v[i];}
	Vector3&	set(T f) {v[0]=f, v[1]=f, v[2]=f; return *this;}
	Vector3&	set(Vector3& u) {v[0]=u[0], v[1]=u[1], v[2]=u[2]; return *this;}
	Vector3&	set(T x, T y, T z) {v[0]=x, v[1]=y, v[2]=z; return *this;}
	Vector3&	clamp(Vector3& u) {Math::clamp(v[0], u[0]), Math::clamp(v[1], u[1]), Math::clamp(v[2], u[2]); return *this;}
	Vector3&	negate() {v[0]=-v[0], v[1]=-v[1], v[2]=-v[2]; return *this;}
	Vector3&	scale(T f) {v[0]*=f, v[1]*=f, v[2]*=f; return *this;}
	Vector3&	scale(Vector3& u) {v[0]*=u[0], v[1]*=u[1], v[2]*=u[2]; return *this;}
	Vector3&	translate(T x, T y, T z) {v[0]+=x, v[1]+=y, v[2]+=z; return *this;}
	Vector3&	translate(Vector3& u) {v[0]+=u[0], v[1]+=u[1], v[2]+=u[2]; return *this;}
	Vector3&	add(Vector3& a, Vector3& b) {v[0]=a[0]+b[0], v[1]=a[1]+b[1], v[2]=a[2]+b[2]; return *this;}
	Vector3&	sub(Vector3& a, Vector3& b) {v[0]=a[0]-b[0], v[1]=a[1]-b[1], v[2]=a[2]-b[2]; return *this;}
	T		dprod(Vector3& u) {return v[0]*u[0] + v[1]*u[1] + v[2]*u[2];}
	Vector3&	xprod(Vector3& a, Vector3& b) {v[0] = a[1]*b[2] - a[2]*b[1]; v[1] = a[2]*b[0] - a[0]*b[2]; v[2] = a[0]*b[1] - a[1]*b[0]; return *this;}
	T		length() {return (T)sqrt(dprod(*this));}
	Vector3&	normalize() {scale(1/length()); return *this;}
	Vector3&	setlength(T f) {scale(f/length()); return *this;}
	Vector3&	minlength(T f) {T l=length(); scale((l>f?l:f)/l); return *this;}
	Vector3&	maxlength(T f) {T l=length(); scale((l<f?l:f)/l); return *this;}
	Vector3&	normal(Vector3& a, Vector3& b, Vector3& c) {Vector3 d1, d2; d1.sub(a, b); d2.sub(a, c); return xprod(d1, d2);}
	Vector3&	shrink(Vector3& u) {Math::shrink(v[0], u[0]); Math::shrink(v[1], u[1]); Math::shrink(v[2], u[2]); return *this;}
	Vector3&	print( const char *s = "vector") {printf("%s: %f %f %f\n", s, v[0], v[1], v[2]); return *this;}
};

template <class T>
class Vector4
{
private:
	T	v[4];
public:
			Vector4() {}
			Vector4(T f) {v[0]=f, v[1]=f, v[2]=f, v[3]=f;}
			Vector4(Vector4& u) {v[0]=u[0], v[1]=u[1], v[2]=u[2], v[3]=u[3];}
			Vector4(T x, T y, T z, T w) {v[0]=x, v[1]=y, v[2]=z, v[3]=w;}
			~Vector4() {}

			operator T* () {return v;}
	T&		operator[] (int i) {return v[i];}
	T&		operator[] (u32 i) {return v[i];}
	Vector4&	set(T f) {v[0]=f, v[1]=f, v[2]=f, v[3]=f; return *this;}
	Vector4&	set(Vector4& u) {v[0]=u[0], v[1]=u[1], v[2]=u[2], v[3]=u[3]; return *this;}
	Vector4&	set(T x, T y, T z, T w) {v[0]=x, v[1]=y, v[2]=z, v[3]=w; return *this;}
	Vector4&	clamp(Vector4& u) {Math::clamp(v[0], u[0]), Math::clamp(v[1], u[1]), Math::clamp(v[2], u[2]), Math::clamp(v[3], u[3]); return *this;}
	Vector4&	negate() {v[0]=-v[0], v[1]=-v[1], v[2]=-v[2], v[3]=-v[3]; return *this;}
	Vector4&	scale(T f) {v[0]*=f, v[1]*=f, v[2]*=f, v[3]*=f; return *this;}
	Vector4&	scale(Vector4& u) {v[0]*=u[0], v[1]*=u[1], v[2]*=u[2], v[3]*=v[3]; return *this;}
	Vector4&	translate(T x, T y, T z, T w) {v[0]+=x, v[1]+=y, v[2]+=z, v[3]+=w; return *this;}
	Vector4&	translate(Vector4& u) {v[0]+=u[0], v[1]+=u[1], v[2]+=u[2], v[3]+=u[3]; return *this;}
	Vector4&	add(Vector4& a, Vector4& b) {v[0]=a[0]+b[0], v[1]=a[1]+b[1], v[2]=a[2]+b[2], v[3]=a[3]+b[3]; return *this;}
	Vector4&	sub(Vector4& a, Vector4& b) {v[0]=a[0]-b[0], v[1]=a[1]-b[1], v[2]=a[2]-b[2], v[3]=a[3]-b[3]; return *this;}
	T		dprod(Vector4& u) {return v[0]*u[0] + v[1]*u[1] + v[2]*u[2] + v[3]*u[3];}
	T		length() {return (T)sqrt(dprod(*this));}
	Vector4&	normalize() {scale(1/length()); return *this;}
	Vector4&	setlength(T f) {scale(f/length()); return *this;}
	Vector4&	minlength(T f) {T l=length(); scale((l>f?l:f)/l); return *this;}
	Vector4&	maxlength(T f) {T l=length(); scale((l<f?l:f)/l); return *this;}
	Vector4&	shrink(Vector4& u) {Math::shrink(v[0], u[0]); Math::shrink(v[1], u[1]); Math::shrink(v[2], u[2]), Math::shrink(v[3], u[3]); return *this;}
	Vector4&	print( const char *s = "vector") {printf("%s: %f %f %f %f\n", s, v[0], v[1], v[2], v[3]); return *this;}
};

#pragma pack(pop)

//______________________________________________________________
class Quaternion
{
private:
	v4d	h;
	v3d	fwd;
	v3d	up;
	v3d	left;
public:
			Quaternion();
			Quaternion( Quaternion& q );
			~Quaternion();
	Quaternion&	identity();
	Quaternion&	conjugate();
	Quaternion&	rotate( f64 angle, v3d& v );
	Quaternion&	rotate( f64 heading, f64 pitch, f64 roll );
	Quaternion&	orient();
	Quaternion&	orient( f64 heading, f64 pitch, f64 roll );
	Quaternion	SLERP( Quaternion& q, f64 t );
	Quaternion&	getH( f64& x, f64& y, f64& z, f64& w );
	Quaternion&	getFwd(v3d& a) {a = fwd; return *this;}
	Quaternion&	getUp(v3d& a) {a = up; return *this;}
	Quaternion&	getLeft(v3d& a) {a = left; return *this;}
	void		print( const char *string = "Quaternion" );
};

//______________________________________________________________
class Matrix
{
private:
	u32	n;
	u32	nn;
	f64	*data;
public:
		Matrix( u32 n = 4 );
		Matrix( Matrix &m );
		~Matrix();
	f64&	cell( u32 i, u32 j );
	f64*	dump();
	Matrix&	load( f64 f );
	Matrix&	load( f64 *m );
	Matrix&	load( Matrix &m );
	Matrix&	identity();
	Matrix&	add( f64 f );
	Matrix&	add( Matrix &m );
	Matrix&	multiply( f64 f );
	Matrix&	multiply( Matrix &m );
	f64*	multiply( f64 *v );
	v3d&	multiply(v3d& u);
	void	transform(f32* u, u32 n);
	Matrix&	addRow( u32 i1, u32 i2, f64 f );
	Matrix&	addCol( u32 j1, u32 j2, f64 f );
	Matrix&	swpRow( u32 i1, u32 i2 );
	Matrix&	swpCol( u32 j1, u32 j2 );
	Matrix&	transpose();
	Matrix&	fastinvert();
	Matrix&	invert();
	Matrix&	apply( f64 (*func)( f64 ) );
	Matrix&	scale( v3d u );
	Matrix&	translate( v3d u );
	Matrix&	rotate( Quaternion& q );
	Matrix&	ortho(f64 l, f64 r, f64 b, f64 t, f64 n, f64 f);
	Matrix&	perspective(f64 l, f64 r, f64 b, f64 t, f64 n, f64 f);
	Matrix&	perspective(f64 fovy, f64 aspect, f64 n, f64 f);
	Matrix&	setModelview();
	Matrix&	setProjection();
	Matrix&	setTexture();
	Matrix&	setColor();
	void	print( const char *string = "Matrix" );
};

//______________________________________________________________


Use the mouse to look around!
Right click to move forward!
Left click to throw ball!
Middle button to toggle HUD on/off!

Keyboard commands:

W - move forward
S - move backwards
A - strafe left
D - strafe right

B - toggle flat shading
N - toggle normal vectors
M - toggle multitexturing
~ - console
F12 - HUD

when the console is down,
use the arrows, pagedown/pageup, 
or the mouse buttons to navigate!


Have fun!


	Bandi (bandi@info98.hu)
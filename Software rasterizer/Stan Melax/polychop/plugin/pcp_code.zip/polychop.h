//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by polychop.RC
//
#define IDS_POLYCHOP                    1
#define IDS_POLYCHOPMOD                 2
#define IDS_MAXADDITIONAL               3
#define IDS_PARAMETERS                  4
#define IDS_PERCENT                     5
#define IDS_POLYCHOPTITLE               6
#define IDS_GEOMORPH                    7
#define IDS_GEOMORPHBASE                8
#define IDD_POLYCHOP                    101
#define IDB_BITMAP2                     104
#define IDB_BITMAP1                     106
#define IDC_USEEDGELENGTH               1002
#define IDC_USECURVATURE                1003
#define IDC_PROTECTTEXTURE              1004
#define IDC_PROTECTSMOOTH               1005
#define IDC_GENTEXTURE                  1006
#define IDC_MAINTAINSMOOTH              1008
#define IDC_PROTECTVC                   1009
#define IDC_LOCKBORDER                  1010
#define IDC_LOCKSELECTED                1011
#define IDC_PERCENT_SPIN                1027
#define IDC_PERCENT                     1028
#define IDC_GEOMORPHBASE_SPIN           1029
#define IDC_GEOMORPHBASE                1030
#define IDC_GEOMORPH_SPIN               1031
#define IDC_GEOMORPH                    1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

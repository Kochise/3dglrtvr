
	Polygon Reduction Plugin
	  for 3DS MAX Modeller

	by Stan Melax 
	of Bioware Corp (C) 1998
	http://www.bioware.com/

Put the file polychop.dlm into the "PLUGINS" subfolder
of the "3DSMAX2" folder.  When you run MAX next time
you should find another modifier plugin called PolyChop.

This software is an unsupported demo version.  
It can be a bit slow with huge models.  It doesn't
export the progressive mesh information required for
doing level of detail within a game engine.  



Disclaimer:

While we have done our best to keep this implementation
free of bugs or other malfunctions, 
this software is provided as is.  It comes with
no guarantees or promises of meeting any specifications.

Use at your own risk, or dont use it at all.


/*

   PLASPAL.C - Written by Phil Inch for Game Developers Magazine (Issue 4)
   Contributed to the public domain.

   This program written and compiled with Borland C++ v3.1
   Compatibility with other compilers is not guaranteed.

   Usage of this program is subject to the disclaimer printed
   in the magazine.  You assume all risks associated with the use
   of this program.

*/


#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <dos.h>
#include <time.h>
#include "vga.h"

#define MAX_PALETTE 192
#define MAX_X 319
#define MAX_Y 199

unsigned char palette[MAX_PALETTE][3];

void set_palette(void) {
	unsigned char c;

  for ( c = 0; c < 64; c++ ) {
    palette[c][0] = c;
    palette[c][1] = 63-c;
    palette[c][2] = 0;

    palette[c+64][0] = 63-c;
    palette[c+64][1] = 0;
    palette[c+64][2] = c;

    palette[c+128][0] = 0;
    palette[c+128][1] = c;
    palette[c+128][2] = 63-c;
    }
  SetBlock( 1, &palette[0][0], MAX_PALETTE );
}

void draw_lines(void) {
  int c;

  for (c=1; c<=192; c++)
    VLine(c,0,199,c);
}

void main(int argc, char **argv) {
  int c;
  char c1, c2, c3, c4;

	SetGraphicsMode();
  set_palette();
  draw_lines();

  if (*argv[1]=='C')
    /* Cycle the palette until a key is pressed */
    while ( !kbhit() ) {
      c1 = palette[0][0];
      c2 = palette[0][1];
      c3 = palette[0][2];
      for ( c = 0; c < MAX_PALETTE-1; c++ ) {
			  palette[c][0] = palette[c+1][0];
			  palette[c][1] = palette[c+1][1];
			  palette[c][2] = palette[c+1][2];
        }
      palette[MAX_PALETTE-1][0] = c1;
      palette[MAX_PALETTE-1][1] = c2;
      palette[MAX_PALETTE-1][2] = c3;
	    SetBlock( 1, &palette[0][0], MAX_PALETTE );
      delay(10);
      }
  else getch();

  SetTextMode();
}

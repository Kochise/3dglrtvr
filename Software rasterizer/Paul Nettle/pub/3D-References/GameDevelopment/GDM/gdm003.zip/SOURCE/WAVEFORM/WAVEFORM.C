#include <stdio.h>
#include <dos.h>
#include <mem.h>
#include <string.h>
#include <stdlib.h>

void	SetGraphicsMode( void ) {
	asm {
		mov	ax,0x13
    int	0x10
	  }
}

void	SetTextMode( void ) {
	asm {
  	mov	ax,0x03
    int	0x10;
    }
}

void SetPoint( int X, int Y, unsigned char C ) {
  if ( X < 0 || X > 319 ) return;
  if ( Y < 0 || Y > 199 ) return;
  *(char far*)MK_FP(0xA000,(Y*320)+X)=C;
}

unsigned char GetPoint( int X, int Y ) {
  return(*(char far*)MK_FP(0xA000,(Y*320)+X));
}

void DrawAxes(void) {
  int x;
  for ( x = 0; x < 320; x++ ) SetPoint( x, 100, 2 );
  for ( x = 0; x < 200; x++ ) SetPoint( 0, x, 2 );
}

void main( int argc, char **argv ) {
  FILE *f;
  int x,y,z;

  f = fopen(argv[1], "rb");

  while ( !feof(f) ) {
    SetGraphicsMode();  // quick way of clearing the graphics screen
    DrawAxes();
    x = 0;
    while ( x < 320 && !feof(f) ) {
       y=fgetc(f)-128;
       if (y==0) SetPoint(x,100,15);
       else if (y<0) for (z=100+y;z<=100;z++) SetPoint(x,z,15);
       else for (z=y+100;z>=100;z--) SetPoint(x,z,15);
       x++;
       }
    if ( getch() == 27 ) break;
    }

  SetTextMode();
  fclose(f);
}






/* boolean.h - a trivial boolean type.
 * $Id: boolean.h,v 1.3 96/02/11 21:29:42 leech Exp $
 */
#ifndef boolean_h
#define boolean_h

#ifndef __GNUG__
typedef unsigned boolean;
static const unsigned false = 0;
static const unsigned true = 1;
#else
typedef bool boolean;
#endif

#endif /*!boolean_h*/

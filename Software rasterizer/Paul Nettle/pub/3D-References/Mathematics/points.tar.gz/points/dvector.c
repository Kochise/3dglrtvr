#include "dvector.h"

CartesianVectorImplement(double);

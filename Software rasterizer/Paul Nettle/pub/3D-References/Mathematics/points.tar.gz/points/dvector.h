#ifndef _jpl_dvector_h
#define _jpl_dvector_h

// Declare a double-precision Cartesian vector

#include <cvector.h>
CartesianVectorDeclare(double);

typedef CVec(double) dvector;

#endif /*_jpl_dvector_h*/

#include "sphigs.h"

#define CUBE 1
#define VIEW 0

void main(int argc, char *argv[])
{
  point		  vertex_cube[] = {
			{0.0, 0.0, 0.0},
			{0.0, 0.0, 1.0},
			{1.0, 0.0, 1.0},
			{1.0, 0.0, 0.0},
			{0.0, 1.0, 0.0},
			{0.0, 1.0, 1.0},
			{1.0, 1.0, 1.0},
			{1.0, 1.0, 0.0}};
  vertex_index	  face_cube[] = {
			0, 3, 2, 1, -1,
			4, 5, 6, 7, -1,
			0, 1, 5, 4, -1,
			1, 2, 6, 5, -1,
			2, 3, 7, 6, -1,
			3, 0, 4, 7, -1};
  point		  vrp, prp;
  vector	  vpn, vup;
  matrix	  mat1, mat2, vo_mat, vm_mat;
  int		  i;
  
  SPH_begin(300, 300, 7, 64);
  SPH_openStructure(CUBE);
    SPH_rotateY(0.0, mat1);
    SPH_setModelingTransformation(mat1, ASSIGN);
    SPH_rotateZ(0.0, mat2);
    SPH_setModelingTransformation(mat2, POSTCONCATENATE);
    SPH_setEdgeColor(1);
    /* SPH_setInteriorColor(7); */
    SPH_polyhedron(8, 6, vertex_cube, face_cube);
  SPH_closeStructure();
  SPH_setViewBackgroundColor(VIEW, 0);
  SPH_setRenderingMode(VIEW, WIREFRAME);
  SPH_setDoubleBufferingFlag(1);
  SPH_evaluateViewOrientationMatrix(
    SPH_defPoint(&vrp, 3.0, 0.0, 0.0),
    SPH_defPoint(&vpn, 1.0, 0.0, 0.0),
    SPH_defPoint(&vup, 0.0, 1.0, 0.0), vo_mat);
  SPH_evaluateViewMappingMatrix(
    -1.0, 1.0, -1.0, 1.0, PERSPECTIVE,
    SPH_defPoint(&prp, 0.0, 0.0, 1.0),
    -0.001, -1000.0,
    0.0, 1.0, 0.0, 1.0, 0.0, 1.0, vm_mat);
  SPH_setViewRepresentation(VIEW, vo_mat, vm_mat,
    0.0, 1.0, 0.0, 1.0, 0.0, 1.0);
  SPH_postRoot(CUBE, VIEW);
  for (i = 0; i < 2 * 360; i += 4)
  {
    SPH_openStructure(CUBE);
      SPH_deleteElementsInRange(1, 2);
      SPH_setElementPointer(0);
      SPH_rotateY((double) i, mat1);
      SPH_setModelingTransformation(mat1, ASSIGN);
      SPH_rotateZ((double) (i) / 3.0, mat2);
      SPH_setModelingTransformation(mat2, POSTCONCATENATE);
    SPH_closeStructure();
  }
  SPH_end();
}

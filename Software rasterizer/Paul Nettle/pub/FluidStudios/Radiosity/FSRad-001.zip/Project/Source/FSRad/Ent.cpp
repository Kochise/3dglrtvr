// ----------------------------------------------------------------------------
// -
// -	Copyright (c) 1998 Terminal Reality Inc.  All Rights Reserved.
// -
// -	[Ent.cpp] - Entropy's .ENT file class
// -
// -	Revision History
// -
// -	01/21/98 PDN Initial version
// -
// ----------------------------------------------------------------------------

#include "stdafx.h"
#include "FSRad.h"
#include "RadPrim.h"
#include "GeomDB.h"
#include "Ent.h"

// ----------------------------------------------------------------------------

	EntFile::EntFile(const char *filename)
{
	memset(fName, 0, sizeof(fName));
	strncpy(fName, filename, MAX_FILENAME_LEN);

	memset(locationStack, 0, sizeof(locationStack));
	locationStackPointer = 0;

	// Open the output file

	pFile = fopen(fName, "rb");
	if (!pFile) throw "Unable to open file for read";
}

// ----------------------------------------------------------------------------

	EntFile::~EntFile()
{
	if (pFile) fclose(pFile);
}

// ----------------------------------------------------------------------------
// VALUES
// ----------------------------------------------------------------------------

void	EntFile::readValue(char *value) const
{
	unsigned int	length = 0;
	readValue(length);
	if (fread(value, length, 1, pFile) != 1) throw "Unable to read string characters";
}

// ----------------------------------------------------------------------------

void	EntFile::readValue(bool &value) const
{
	char	temp;
	if (fread(&temp, sizeof(temp), 1, pFile) != 1) throw "Unable to read boolean";

	value = temp ? true : false;
}

// ----------------------------------------------------------------------------

void	EntFile::readValue(unsigned int &value) const
{
	if (fread(&value, sizeof(value), 1, pFile) != 1) throw "Unable to read integer";
}

// ----------------------------------------------------------------------------

void	EntFile::readValue(float &value) const
{
	if (fread(&value, sizeof(value), 1, pFile) != 1) throw "Unable to read 32-bit float";
}

// ----------------------------------------------------------------------------

void	EntFile::readValue(double &value) const
{
	if (fread(&value, sizeof(value), 1, pFile) != 1) throw "Unable to read 64-bit float";
}

// ----------------------------------------------------------------------------

void	EntFile::readValue(geom::Point2 &value) const
{
	double	x, y;
	if (fread(&x, sizeof(x), 1, pFile) != 1) throw "Unable to read xy.x";
	if (fread(&y, sizeof(y), 1, pFile) != 1) throw "Unable to read xy.y";
	value.x() = x;
	value.y() = y;
}

// ----------------------------------------------------------------------------

void	EntFile::readValue(geom::Point3 &value) const
{
	double	x, y, z;
	if (fread(&x, sizeof(x), 1, pFile) != 1) throw "Unable to read xyz.x";
	if (fread(&y, sizeof(y), 1, pFile) != 1) throw "Unable to read xyz.y";
	if (fread(&z, sizeof(z), 1, pFile) != 1) throw "Unable to read xyz.z";
	value.x() = x;
	value.y() = y;
	value.z() = z;
}

// ----------------------------------------------------------------------------

void	EntFile::readValue(geom::Matrix3 &value) const
{
	if (fread(&value, sizeof(value), 1, pFile) != 1) throw "Unable to read matrix";
}

// ----------------------------------------------------------------------------

void	EntFile::readValue(entColor &value) const
{
	if (fread(&value, sizeof(value), 1, pFile) != 1) throw "Unable to read color";
}

// ----------------------------------------------------------------------------
// TAGS
// ----------------------------------------------------------------------------

void	EntFile::readTag(unsigned int &tag) const
{
	readValue(tag);
}

// ----------------------------------------------------------------------------

void	EntFile::skipTag(const unsigned int tag) const
{
	// First, determine if we have a specific length to skip

	if ((tag & 0xff) == 0)
	{
		unsigned int	length = 0;
		readValue(length);
		fseek(pFile, length, SEEK_CUR);
		return;
	}

	// No length, use the tagID to determine how much to skip

	switch(tag & 0xff)
	{
		case ENT_TYPE_STRING:
		{
			char	str[256];
			readValue(str);
			break;
		}

		case ENT_TYPE_BOOLEAN:
			fseek(pFile, sizeof(char), SEEK_CUR);
			break;

		case ENT_TYPE_INTEGER:
			fseek(pFile, sizeof(int), SEEK_CUR);
			break;

		case ENT_TYPE_FLOAT32:
			fseek(pFile, sizeof(float), SEEK_CUR);
			break;

		case ENT_TYPE_FLOAT64:
			fseek(pFile, sizeof(double), SEEK_CUR);
			break;

		case ENT_TYPE_XY:
			fseek(pFile, sizeof(double) * 2, SEEK_CUR);
			break;

		case ENT_TYPE_XYZ:
			fseek(pFile, sizeof(double) * 3, SEEK_CUR);
			break;

		case ENT_TYPE_MATRIX:
			fseek(pFile, sizeof(double) * 9, SEEK_CUR);
			break;

		case ENT_TYPE_RGB:
			fseek(pFile, sizeof(double) * 3, SEEK_CUR);
			break;

		default:
			throw "Unknown tag data type -- cannot skip";
	}
}

// ----------------------------------------------------------------------------

void	EntFile::ignoreSkipLength(const unsigned int tag) const
{
	// If there is a length, then read it and throw it away

	if ((tag & 0xff) == 0)
	{
		unsigned int	length = 0;
		readValue(length);
	}
}

// ----------------------------------------------------------------------------
// HEADERS
// ----------------------------------------------------------------------------

void	EntFile::readSignature() const
{
	char	temp[ENT_SIGNATURE_LEN];
	if (fread(temp, ENT_SIGNATURE_LEN, 1, pFile) != 1) throw "Unable to read signature";
}

// ----------------------------------------------------------------------------

bool	EntFile::verifyTerminator() const
{
	unsigned int	tag;
	readTag(tag);
	return tag == ETAG_TERMINATOR;
}

// ----------------------------------------------------------------------------
// READ
// ----------------------------------------------------------------------------

void	EntFile::readGeometry(entObjectArray & objects)
{
	bool	done = false;

	while(!done)
	{
		unsigned int	tag;
		readTag(tag);

		switch(tag)
		{
			case ETAG_GEOMETRY_OBJECT_COUNT:
				ignoreSkipLength(tag);
				readObjects(objects);
				break;

			case ETAG_TERMINATOR:
				done = true;
				break;

			default:
				skipTag(tag);
				break;
		}
	}
}

// ----------------------------------------------------------------------------

void	EntFile::readObjects(entObjectArray & objects)
{
	unsigned int	count = 0;
	readValue(count);

	for (unsigned int i = 0; i < count; i++)
	{
		bool	done = false;

		entObject	obj;

		while(!done)
		{
			unsigned int	tag;
			readTag(tag);

			switch(tag)
			{
				case ETAG_GEOMETRY_OBJECT_VERTEX_COUNT:
					ignoreSkipLength(tag);
					readVertices(obj);
					break;

				case ETAG_GEOMETRY_OBJECT_POLY_COUNT:
					ignoreSkipLength(tag);
					readPolygons(obj);
					break;

				case ETAG_TERMINATOR:
					done = true;
					break;

				default:
					skipTag(tag);
					break;
			}
		}

		objects += obj;
	}

	if (!verifyTerminator()) throw "Invalid termination";
}

// ----------------------------------------------------------------------------

void	EntFile::readVertices(entObject &object)
{
	unsigned int	count = 0;
	readValue(count);

	for (unsigned int i = 0; i < count; i++)
	{
		bool	done = false;

		while(!done)
		{
			unsigned int	tag;
			readTag(tag);

			switch(tag)
			{
				case ETAG_GEOMETRY_OBJECT_VERTEX_LOCATION:
				{
					ignoreSkipLength(tag);
					geom::Point3	xyz;
					readValue(xyz);
					object.verts += xyz;
					break;
				}

				case ETAG_TERMINATOR:
					done = true;
					break;

				default:
					skipTag(tag);
					break;
			}
		}
	}

	if (!verifyTerminator()) throw "Invalid termination";
}

// ----------------------------------------------------------------------------

void	EntFile::readPolygons(entObject &object)
{
	unsigned int	count = 0;
	readValue(count);

	unsigned int	temp = 0;

	for (unsigned int i = 0; i < count; i++)
	{
		bool	done = false;

		entPoly	poly;

		while(!done)
		{
			unsigned int	tag;
			readTag(tag);

			switch(tag)
			{
				case ETAG_GEOMETRY_OBJECT_POLY_MATERIAL:
					ignoreSkipLength(tag);
					readValue(temp);

					// Set the material to the proper indexing

					object.materialID = temp + nextMaterialID;
					break;

				case ETAG_GEOMETRY_OBJECT_POLY_VERTEX_COUNT:
					ignoreSkipLength(tag);
					readPolygonVerts(poly);
					break;

				case ETAG_TERMINATOR:
					done = true;
					break;

				default:
					skipTag(tag);
					break;
			}
		}

		// Add the poly

		object.polys += poly;
	}

	if (!verifyTerminator()) throw "Invalid termination";
}

// ----------------------------------------------------------------------------

void	EntFile::readPolygonVerts(entPoly &poly)
{
	unsigned int	count = 0;
	readValue(count);

	if (count != 3) throw "Polygon not 3-sided";

	for (unsigned int i = 0; i < count; i++)
	{
		bool	done = false;

		while(!done)
		{
			unsigned int	tag;
			readTag(tag);

			switch(tag)
			{
				case ETAG_GEOMETRY_OBJECT_POLY_VERTEX_INDEX:
					ignoreSkipLength(tag);
					readValue(poly.verts[i]);
					break;

				case ETAG_TERMINATOR:
					done = true;
					break;

				default:
					skipTag(tag);
					break;
			}
		}
	}

	if (!verifyTerminator()) throw "Invalid termination";
}

// ----------------------------------------------------------------------------

void	EntFile::readMaterials(entMaterialArray & materials)
{
	unsigned int	tag;
	readTag(tag);
	ignoreSkipLength(tag);
	if (tag != ETAG_MATERIAL_COUNT) throw "Unable to read materials";

	unsigned int	count = 0;
	readValue(count);

	for (unsigned int i = 0; i < count; i++)
	{
		// Default material

		entMaterial	mat;
		mat.illuminationColor.r = 0;
		mat.illuminationColor.g = 0;
		mat.illuminationColor.b = 0;
		mat.reflectanceColor.r = 0;
		mat.reflectanceColor.g = 0;
		mat.reflectanceColor.b = 0;
		mat.illuminationMultiplier = 1;
		mat.reflectanceMultiplier = 1;

		bool	done = false;

		while(!done)
		{
			unsigned int	tag;
			readTag(tag);

			switch(tag)
			{
				case ETAG_MATERIAL_ILLUMINATION_COLOR:
					ignoreSkipLength(tag);
					readValue(mat.illuminationColor);
					break;

				case ETAG_MATERIAL_ILLUMINATION_MULTIPLIER:
					ignoreSkipLength(tag);
					readValue(mat.illuminationMultiplier);
					break;

				case ETAG_MATERIAL_REFLECTANCE_COLOR:
					ignoreSkipLength(tag);
					readValue(mat.reflectanceColor);
					break;

				case ETAG_MATERIAL_REFLECTANCE_MULTIPLIER:
					ignoreSkipLength(tag);
					readValue(mat.reflectanceMultiplier);
					break;

				case ETAG_TERMINATOR:
					done = true;
					break;

				default:
					skipTag(tag);
					break;
			}
		}

		// Add it

		materials += mat;
	}

	if (!verifyTerminator()) throw "Invalid termination";
}

// ----------------------------------------------------------------------------
// FILE I/O
// ----------------------------------------------------------------------------

void	EntFile::read()
{
	if (!pFile) throw "file pointer null";

	readSignature();

	// Get the material index

	nextMaterialID = 0;

	// Verify the file type

	unsigned int	tag;
	readTag(tag);
	if (tag != ETAG_IDENTIFIER) throw "Invalid format";
	
	// Skip the file length & version

	unsigned int	unused;
	readValue(unused);
	readValue(unused);

	// Parse the file tags

	bool	done = false;

	while(!done)
	{
		readTag(tag);

		switch(tag)
		{
			case ETAG_FILEINFO:
				skipTag(tag);
				break;

			case ETAG_PARAMETERS:
				skipTag(tag);
				break;

			case ETAG_GEOMETRY:
				ignoreSkipLength(tag);
				readGeometry(objects);
				break;

			case ETAG_MATERIAL:
				ignoreSkipLength(tag);
				readMaterials(materials);
				break;

			case ETAG_TERMINATOR:
				done = true;
				break;

			default:
				skipTag(tag);
				break;
		}
	}
}

// ----------------------------------------------------------------------------
// -	[Ent.cpp] - End Of File
// ----------------------------------------------------------------------------


// ----------------------------------------------------------------------------
// -
// -	Copyright (c) 1998 Terminal Reality Inc.  All Rights Reserved.
// -
// -	[Ent.h] - Entropy's .ENT file class
// -
// -	Revision History
// -
// -	01/21/98 PDN Initial version
// -
// ----------------------------------------------------------------------------

#ifndef	_H_ENT
#define	_H_ENT

// ----------------------------------------------------------------------------

class	GeomDB;
class	RadPoly;

// ----------------------------------------------------------------------------

typedef	struct	tag_ent_color
{
	float	b, g, r;
} entColor;
typedef	fstl::array<entColor>		entColorArray;

// ----------------------------------------------------------------------------

typedef	struct	tag_ent_material
{
	entColor	illuminationColor;
	float		illuminationMultiplier;
	entColor	reflectanceColor;
	float		reflectanceMultiplier;
} entMaterial;
typedef	fstl::array<entMaterial>	entMaterialArray;

// ----------------------------------------------------------------------------

typedef	struct	tag_ent_poly
{
	unsigned int		verts[3];
	geom::Point2		tex[3];
} entPoly;
typedef	fstl::array<entPoly>		entPolyArray;

// ----------------------------------------------------------------------------

typedef	struct	tag_ent_object
{
	geom::Point3Array	verts;
	entPolyArray		polys;
	unsigned int		materialID;
} entObject;
typedef	fstl::array<entObject>		entObjectArray;

// ----------------------------------------------------------------------------

class	EntFile
{
public:
	enum		{MAX_FILENAME_LEN = 255};
	enum		{STACK_SIZE = 256};

	// File signature

	#define		ENT_SIGNATURE		"KAGE Entropy data file (ENT), Copyright 1998 Terminal Reality Inc.\n\x1a"
	#define		ENT_SIGNATURE_LEN	128

	// File Version

	enum		{ENT_VERSION = 0x00010000};

	// Entropy file data types

	enum		{ENT_TYPE_STRING  = 0x01};
	enum		{ENT_TYPE_BOOLEAN = 0x02};
	enum		{ENT_TYPE_INTEGER = 0x03};
	enum		{ENT_TYPE_FLOAT32 = 0x04};
	enum		{ENT_TYPE_FLOAT64 = 0x05};
	enum		{ENT_TYPE_XY      = 0x06};
	enum		{ENT_TYPE_XYZ     = 0x07};
	enum		{ENT_TYPE_MATRIX  = 0x08};
	enum		{ENT_TYPE_RGB     = 0x09};

	// Entropy file tags

	enum		{  ETAG_TERMINATOR					= 0x00000000			};
	enum		{  ETAG_IDENTIFIER					= 0xBAAADF00			};
	enum		{   ETAG_FILEINFO					= 0x10000000			};
	enum		{    ETAG_FILEINFO_CREATION_DATE			= 0x11000000 + ENT_TYPE_INTEGER	};
	enum		{    ETAG_FILEINFO_CREATION_TIME			= 0x12000000 + ENT_TYPE_INTEGER	};
	enum		{   ETAG_PARAMETERS					= 0x20000000			};
	enum		{    ETAG_PARAMETERS_SELGROUP_COUNT			= 0x21000000			};
	enum		{     ETAG_PARAMETERS_SELGROUP_NAME			= 0x21010000 + ENT_TYPE_STRING	};
	enum		{    ETAG_PARAMETERS_CONSTRUCTION_ORIGIN		= 0x22000000 + ENT_TYPE_XYZ	};
	enum		{    ETAG_PARAMETERS_VIEW_COUNT				= 0x23000000			};
	enum		{     ETAG_PARAMETERS_VIEW_BACKFACEFLAG			= 0x23010000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_BACKFACEVISANGLE		= 0x23020000 + ENT_TYPE_FLOAT64 };
	enum		{     ETAG_PARAMETERS_VIEW_BACKFACECULLANGLE		= 0x23030000 + ENT_TYPE_FLOAT64 };
	enum		{     ETAG_PARAMETERS_VIEW_VERTEXTICKSFLAG		= 0x23040000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_VERTEXMARKSFLAG		= 0x23050000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_GRIDSPACING			= 0x23060000 + ENT_TYPE_XYZ	};
	enum		{     ETAG_PARAMETERS_VIEW_GRIDDIVISIONS		= 0x23070000 + ENT_TYPE_XYZ	};
	enum		{     ETAG_PARAMETERS_VIEW_GRIDFLAG			= 0x23080000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_DIVISIONFLAG			= 0x23090000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_SUBDIVISIONFLAG		= 0x230A0000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_CONSTRUCTIONCENTERFLAG	= 0x230B0000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_WIREFRAMEFLAG		= 0x230C0000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_ZBUFFERFLAG			= 0x230D0000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_POLYGONFLAG			= 0x230E0000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_TEXTUREDFLAG			= 0x230F0000 + ENT_TYPE_BOOLEAN	};
	enum		{     ETAG_PARAMETERS_VIEW_WIREFRAMESHADING		= 0x23100000 + ENT_TYPE_INTEGER	};
	enum		{     ETAG_PARAMETERS_VIEW_POLYGONSHADING		= 0x23110000 + ENT_TYPE_INTEGER	};
	enum		{     ETAG_PARAMETERS_VIEW_RATIOLEFT			= 0x23120000 + ENT_TYPE_FLOAT64 };
	enum		{     ETAG_PARAMETERS_VIEW_RATIOTOP			= 0x23130000 + ENT_TYPE_FLOAT64 };
	enum		{     ETAG_PARAMETERS_VIEW_RATIORIGHT			= 0x23140000 + ENT_TYPE_FLOAT64 };
	enum		{     ETAG_PARAMETERS_VIEW_RATIOBOTTOM			= 0x23150000 + ENT_TYPE_FLOAT64 };
	enum		{     ETAG_PARAMETERS_VIEW_ZOOM				= 0x23160000 + ENT_TYPE_FLOAT64 };
	enum		{     ETAG_PARAMETERS_VIEW_CENTER3D			= 0x23170000 + ENT_TYPE_XYZ	};
	enum		{     ETAG_PARAMETERS_VIEW_MATRIX			= 0x23180000 + ENT_TYPE_MATRIX	};
	enum		{     ETAG_PARAMETERS_VIEW_TYPE				= 0x23190000 + ENT_TYPE_INTEGER	};
	enum		{     ETAG_PARAMETERS_VIEW_COMPLEXITYFLAG		= 0x231A0000 + ENT_TYPE_BOOLEAN	};
	enum		{   ETAG_GEOMETRY					= 0x30000000			};
	enum		{    ETAG_GEOMETRY_OBJECT_COUNT				= 0x31000000			};
	enum		{     ETAG_GEOMETRY_OBJECT_COLOR			= 0x31010000 + ENT_TYPE_INTEGER	};
	enum		{     ETAG_GEOMETRY_OBJECT_WORKBITS			= 0x31020000 + ENT_TYPE_INTEGER	};
	enum		{     ETAG_GEOMETRY_OBJECT_VERTEX_COUNT			= 0x31030000			};
	enum		{      ETAG_GEOMETRY_OBJECT_VERTEX_WORKBITS		= 0x31030100 + ENT_TYPE_INTEGER	};
	enum		{      ETAG_GEOMETRY_OBJECT_VERTEX_SELECTBITS		= 0x31030200 + ENT_TYPE_INTEGER	};
	enum		{      ETAG_GEOMETRY_OBJECT_VERTEX_LOCATION		= 0x31030300 + ENT_TYPE_XYZ	};
	enum		{     ETAG_GEOMETRY_OBJECT_POLY_COUNT			= 0x31040000			};
	enum		{      ETAG_GEOMETRY_OBJECT_POLY_WORKBITS		= 0x31040100 + ENT_TYPE_INTEGER	};
	enum		{      ETAG_GEOMETRY_OBJECT_POLY_MATERIAL		= 0x31040200 + ENT_TYPE_INTEGER	};
	enum		{      ETAG_GEOMETRY_OBJECT_POLY_VERTEX_COUNT		= 0x31040300			};
	enum		{       ETAG_GEOMETRY_OBJECT_POLY_VERTEX_INDEX		= 0x31040400 + ENT_TYPE_INTEGER	};
	enum		{       ETAG_GEOMETRY_OBJECT_POLY_VERTEX_TEXUV		= 0x31040500 + ENT_TYPE_XY	};
	enum		{   ETAG_MATERIAL	      				= 0x40000000			};
	enum		{    ETAG_MATERIAL_COUNT      				= 0x41000000			};
	enum		{     ETAG_MATERIAL_MATERIAL_NAME			= 0x41010000 + ENT_TYPE_STRING	};
	enum		{     ETAG_MATERIAL_TEXTURE_NAME			= 0x41020000 + ENT_TYPE_STRING	};
	enum		{     ETAG_MATERIAL_TEXTURE_ID				= 0x41030000 + ENT_TYPE_INTEGER	};
	enum		{     ETAG_MATERIAL_ILLUMINATION_COLOR			= 0x41040000 + ENT_TYPE_RGB	};
	enum		{     ETAG_MATERIAL_ILLUMINATION_MULTIPLIER		= 0x41050000 + ENT_TYPE_FLOAT32 };
	enum		{     ETAG_MATERIAL_REFLECTANCE_COLOR			= 0x41060000 + ENT_TYPE_RGB	};
	enum		{     ETAG_MATERIAL_REFLECTANCE_MULTIPLIER		= 0x41070000 + ENT_TYPE_FLOAT32	};
	enum		{     ETAG_MATERIAL_TEXTURE_TPU_U			= 0x41080000 + ENT_TYPE_FLOAT32	};
	enum		{     ETAG_MATERIAL_TEXTURE_TPU_V			= 0x41090000 + ENT_TYPE_FLOAT32	};
private:
	char		fName[MAX_FILENAME_LEN + 1];
	FILE *		pFile;
	unsigned int	locationStack[STACK_SIZE], locationStackPointer;
	unsigned int	nextMaterialID;

	// VALUES

	void		readValue(char *value) const;
	void		readValue(bool &value) const;
	void		readValue(unsigned int &value) const;
	void		readValue(float &value) const;
	void		readValue(double &value) const;
	void		readValue(geom::Point2 &value) const;
	void		readValue(geom::Point3 &value) const;
	void		readValue(geom::Matrix3 &value) const;
	void		readValue(entColor &value) const;

	// TAGS

	void		readTag(unsigned int &tag) const;
	void		skipTag(const unsigned int tag) const;
	void		ignoreSkipLength(const unsigned int tag) const;

	// HEADERS

	void		readSignature() const;
	bool		verifyTerminator() const;

	// READ

	void		readGeometry(entObjectArray & objects);
	void		readObjects(entObjectArray & objects);
	void		readVertices(entObject &object);
	void		readPolygons(entObject &object);
	void		readPolygonVerts(entPoly &poly);
	void		readMaterials(entMaterialArray &materials);

public:
			EntFile(const char *filename);
virtual			~EntFile();
virtual	void		read();

	entMaterialArray	materials;
	entObjectArray		objects;

};

#endif
// ----------------------------------------------------------------------------
// -	[Ent.h] - End Of File
// ----------------------------------------------------------------------------


// ---------------------------------------------------------------------------------------------------------------------------------
//   _____               _ _    _      _                            
//  / ____|             | | |  | |    | |                           
// | |     _ __ ___   __| | |__| | ___| |_ __       ___ _ __  _ __  
// | |    | '_ ` _ \ / _` |  __  |/ _ \ | '_ \     / __| '_ \| '_ \ 
// | |____| | | | | | (_| | |  | |  __/ | |_) | _ | (__| |_) | |_) |
//  \_____|_| |_| |_|\__,_|_|  |_|\___|_| .__/ (_) \___| .__/| .__/ 
//                                      | |            | |   | |    
//                                      |_|            |_|   |_|    
//
// Description:
//
//   Lightmap parameters
//
// Notes:
//
//   Best viewed with 8-character tabs and (at least) 132 columns
//
// History:
//
//   10/16/2001 by Paul Nettle: Original creation
//
// Restrictions & freedoms pertaining to usage and redistribution of this software:
//
//   This software is 100% free. If you use this software (in part or in whole) you must credit the author. This software may not be
//   re-distributed (in part or in whole) in a modified form without clear documentation on how to obtain a copy of the original
//   work. You may not use this software to directly or indirectly cause harm to others. This software is provided as-is and without
//   warrantee -- Use at your own risk. For more information, visit HTTP://www.FluidStudios.com/
//
// Copyright 2001, Fluid Studios, Inc., all rights reserved.
// ---------------------------------------------------------------------------------------------------------------------------------

#include "stdafx.h"
#include "FSRad.h"
#include "CmdHelp.h"

// ---------------------------------------------------------------------------------------------------------------------------------

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// ---------------------------------------------------------------------------------------------------------------------------------

BEGIN_MESSAGE_MAP(CmdHelp, CDialog)
	//{{AFX_MSG_MAP(CmdHelp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// ---------------------------------------------------------------------------------------------------------------------------------

	CmdHelp::CmdHelp(CWnd* pParent /*=NULL*/)
	: CDialog(CmdHelp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CmdHelp)
	//}}AFX_DATA_INIT
}

// ---------------------------------------------------------------------------------------------------------------------------------

void	CmdHelp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CmdHelp)
	DDX_Control(pDX, IDC_HELPBROWSE, helpBrowser);
	//}}AFX_DATA_MAP
}

// ---------------------------------------------------------------------------------------------------------------------------------

BOOL	CmdHelp::OnInitDialog() 
{
	CDialog::OnInitDialog();

	char	buf[90];
	GetTempPath(sizeof(buf) - 1, buf);

	fstl::string	tempFileName = fstl::string(buf) + "FSRadCommandLineHelp.html";

	FILE *	fp = fopen(tempFileName.asArray(), "w");
	if (fp)
	{
		fprintf
		(
			fp,
			"<HTML>\n"
			"<HEAD>\n"
			"	<STYLE type=\"text/css\">\n"
			"		BODY { color: 404040; font-style: normal; font-family: verdana, tahoma, helvetica; font-size: 12px; text-decoration: none; font-weight: normal; margin-top: 0px; margin-bottom: 0px; }\n"
			"		TD   { color: 404040; font-style: normal; font-family: verdana, tahoma, helvetica; font-size: 12px; text-decoration: none; font-weight: normal; margin-top: 0px; margin-bottom: 0px; }\n"
			"		A       { color: 000040; font-weight: normal; font-size: 13; text-decoration: none; }\n"
			"		A:hover { text-decoration: underline; }\n"
			"		font.s  { font-style: normal; font-size: 11px; font-weight: normal; }\n"
			"		font.sb { font-style: normal; font-size: 11px; font-weight: bold;   }\n"
			"		font.si { font-style: italic; font-size: 11px; font-weight: normal; }\n"
			"		font.m  { font-style: normal; font-size: 14px; font-weight: normal; }\n"
			"		font.mb { font-style: normal; font-size: 14px; font-weight: bold;   }\n"
			"		font.mi { font-style: italic; font-size: 14px; font-weight: normal; }\n"
			"		font.l  { font-style: normal; font-size: 20px; font-weight: normal; }\n"
			"		font.lb { font-style: normal; font-size: 20px; font-weight: bold;   }\n"
			"		font.li { font-style: italic; font-size: 20px; font-weight: normal; }\n"
			"		font.copyright { color: a0a0a0; }\n"
			"	</STYLE>\n"
			"</HEAD>\n"
			"\n"
			"<BODY>\n"
			"	<FONT class=lb><CENTER>Command-line help for FSRad</CENTER></FONT>\n"
			"	<HR>\n"
			"	<P>\n"
			"	<B>The Command-line:</B>\n"
			"		<UL>\n"
			"			Here's an example:\n"
			"			<P>\n"
			"			<UL><CODE>FSRad lw=128 lh=128 infile=foo1.oct outfile=foo2.oct gamma=2.2</CODE></UL>\n"
			"			<P>\n"
			"			As you can see, it's <I><CODE>parameter_name=value</CODE></I> pairs. Parameter names are <B>case sensitive</B>\n"
			"			and <B>must not contain spaces</B> (long filenames are okay, but not long filenames with spaces in them. Sorry.)\n"
			"			<p>\n"
			"			The software will first load all default parameters (as shown in the GUI normally) and then the command-line parameters\n"
			"			will be used to override those defaults. The command-line will not modify the defaults stored in the registry -- only\n"
			"			the UI affects what's stored in the registry.\n"
			"		</UL>\n"
			"	<P>\n"
			"	<B>The Commands:</B>\n"
			"		<UL>\n"
			"			<table CELLPADDING=3>\n"
			"				<tr><td><B>lw</B></TD><TD>Lightmap width</TD></TR>\n"
			"				<tr><td><B><B>lh</B></TD><TD>Lightmap height</TD></TR> \n"
			"				<tr><td><B><B>utpu</B></TD><TD>Texels Per Unit (U)</TD></TR> \n"
			"				<tr><td><B><B>vtpu</B></TD><TD>Texels Per Unit (V)</TD></TR> \n"
			"				<tr><td><B><B>otthresh</B></TD><TD>Octree threshold</TD></TR> \n"
			"				<tr><td><B><B>otmaxdepth</B></TD><TD>Octree max depth</TD></TR> \n"
			"				<tr><td><B><B>otminradius</B></TD><TD>Octree minimum radius</TD></TR> \n"
			"				<tr><td><B><B>reflectr</B></TD><TD>Default surface reflectivity (red)</TD></TR> \n"
			"				<tr><td><B><B>reflectg</B></TD><TD>Default surface reflectivity (green)</TD></TR> \n"
			"				<tr><td><B><B>reflectb</B></TD><TD>Default surface reflectivity (blue)</TD></TR> \n"
			"				<tr><td><B><B>bspminsplit</B></TD><TD>BSP min split range</TD></TR> \n"
			"				<tr><td><B><B>bspgaus</B></TD><TD>BSP Gaussian resolution</TD></TR> \n"
			"				<tr><td><B><B>rawfolder</B></TD><TD>Folder for writing RAW lightmap files (enable <B>writeraw</B>, too)</TD></TR> \n"
			"				<tr><td><B><B>writeraw</B></TD><TD>Set to 1/0 to enable/disable writing RAW lightmap files (set <B>rawfolder</B>, too)</TD></TR> \n"
			"				<tr><td><B><B>writeoct</B></TD><TD>Set to 1/0 to enable/disable writing OCT files for final output (set <B>octfile</B>, too) </TD></TR> \n"
			"				<tr><td><B><B>octfile</B></TD><TD>Filename for the output OCT file (enable <B>writeoct</B>, too)</TD></TR> \n"
			"				<tr><td><B><B>infile</B></TD><TD>Input filename (OCT or ENT)</TD></TR> \n"
			"				<tr><td><B><B>convergence</B></TD><TD>Convergence (percentage of light to distribute)</TD></TR> \n"
			"				<tr><td><B><B>usemaxiterations</B></TD><TD>Set to 1/0 to enable/disable the maximum interations limiter (set </B>maxiterations</B>, too)</TD></TR> \n"
			"				<tr><td><B><B>maxiterations</B></TD><TD>Maximum number of iterations (set <B>usemaxiterations</B>, too)</TD></TR> \n"
			"				<tr><td><B><B>areamult</B></TD><TD>Area light multiplier (for ENT input files)</TD></TR> \n"
			"				<tr><td><B><B>pointmult</B></TD><TD>Point light multiplier (for OCT input files)</TD></TR> \n"
			"				<tr><td><B><B>subu</B></TD><TD>Initial patch subdivision (U)</TD></TR> \n"
			"				<tr><td><B><B>subv</B></TD><TD>Initial patch subdivision (V)</TD></TR> \n"
			"				<tr><td><B><B>useambterm</B></TD><TD>Set to 1/0 to enable/disable the use of the <I>Ambient term</I> for treating unshot energy as ambient light.</TD></TR> \n"
			"				<tr><td><B><B>usenusselt</B></TD><TD>Set to 1/0 to enable/disable the use of the Nusselt Analogy (about 5%% slower, but more accurate results, usually a good idea.)</TD></TR> \n"
			"				<tr><td><B><B>directonly</B></TD><TD>Set to 1/0 to enable/disable &quot;direct light only&quot; -- turning this on, disables the iterative radiosity process.</TD></TR> \n"
			"				<tr><td><B><B>adaptmaxu</B></TD><TD>Set the maximum horizontal (U) size for adaptive patch subdivision (set <B>useadapt</B>, too)</TD></TR> \n"
			"				<tr><td><B><B>adaptmaxv</B></TD><TD>Set the maximum vertical (V) size for adaptive patch subdivision (set <B>useadapt</B>, too)</TD></TR> \n"
			"				<tr><td><B><B>useadapt</B></TD><TD>Set to 1/0 to enable/disable the adaptive patch subdivision (set <B>adaptmaxu</B> and <b>adaptmaxv</B>, too)</TD></TR> \n"
			"				<tr><td><B><B>adaptthresh</B></TD><TD>Set the adaptive patch threshold (set <b>useadapt</B>, too)</TD></TR> \n"
			"				<tr><td><B><B>gamma</B></TD><TD>Gamma correction (most commonly should be set to 2.2)</TD></TR> \n"
			"				<tr><td><B><B>ambr</B></TD><TD>Standard ambient light (red) - if you use this, you are LAME!</TD></TR> \n"
			"				<tr><td><B><B>ambg</B></TD><TD>Standard ambient light (green) - if you use this, you are LAME!</TD></TR> \n"
			"				<tr><td><B><B>ambb</B></TD><TD>Standard ambient light (blue) - if you use this, you are LAME!</TD></TR>\n"
			"				<tr><td><B><B>clampretain</B></TD><TD>Set clamping to retain color ratio - recommended</TD></TR>\n"
			"				<tr><td><B><B>clampsaturate</B></TD><TD>Set clamping to saturation (simply clamps to black/white)</TD></TR>\n"
			"				<tr><td><B><B>clampnone</B></TD><TD>Set clamping to none (may cause strange color-wrap-around effects)</TD></TR>\n"
			"			</TABLE>\n"
			"		</UL>\n"
			"	<P>\n"
			"	<BR>\n"
			"	<font class=copyright><CENTER>Copyright 2001 Fluid Studios. All Rights Reserved.</CENTER></FONT>\n"
			"	<BR>\n"
			"	<BR>\n"
			"</BODY>\n"
			"</HTML>\n"
		);

		fclose(fp);

		COleVariant varEmpty;
		fstl::string	url("file://");
		url += tempFileName;
		helpBrowser.Navigate(tempFileName.asArray(), &varEmpty, &varEmpty, &varEmpty, &varEmpty);
	}

	
	return TRUE;
}

// ---------------------------------------------------------------------------------------------------------------------------------
// CmdHelp.cpp - End of file
// ---------------------------------------------------------------------------------------------------------------------------------

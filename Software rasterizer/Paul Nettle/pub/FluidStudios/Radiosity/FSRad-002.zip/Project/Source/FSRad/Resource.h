//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FSRad.rc
//
#define IDR_MAINFRAME                   128
#define IDD_DATABASE_PAGE               133
#define IDD_PROGRESS                    134
#define IDD_RAD_SHEET                   137
#define IDD_POST_PAGE                   138
#define IDD_GENERAL_PAGE                140
#define IDD_LIGHTMAP_PAGE               144
#define IDD_HELP_DIALOG                 147
#define IDR_HELP                        149
#define IDR_RT_HELP                     151
#define IDC_CURRENT_TASK_PROGRESS       1034
#define IDC_CURRENT_TASK_TEXT           1035
#define IDC_CURRENT_TASK_PERCENT        1036
#define IDC_STOP                        1037
#define IDC_RUNTIME_TEXT                1038
#define IDC_TEXT1                       1039
#define IDC_TEXT2                       1040
#define IDC_TEXT3                       1041
#define IDC_TEXT4                       1042
#define IDC_TEXT5                       1043
#define IDC_GAUSSIAN_RESOLUTION         1044
#define IDC_TEXT10                      1044
#define IDC_MIN_SPLIT_RANGE             1045
#define IDC_TEXT9                       1045
#define IDC_LEAVE_RESULTS               1046
#define IDC_TEXT8                       1046
#define IDC_THRESHOLD                   1047
#define IDC_TEXT7                       1047
#define IDC_MIN_RADIUS                  1048
#define IDC_TEXT6                       1048
#define IDC_MAX_DEPTH                   1049
#define IDC_LABEL5                      1049
#define IDC_OUTPUT_RAW_FLAG             1050
#define IDC_LABEL4                      1050
#define IDC_OUTPUT_RAW_DIRECTORY        1051
#define IDC_LABEL3                      1051
#define IDC_OUTPUT_OCT_FLAG             1052
#define IDC_LABEL2                      1052
#define IDC_OUTPUT_RAW_BROWSE           1053
#define IDC_LABEL1                      1053
#define IDC_EXIT_WHEN_FINISHED          1054
#define IDC_LABEL10                     1054
#define IDC_OUTPUT_OCT_FILENAME         1055
#define IDC_LABEL9                      1055
#define IDC_OUTPUT_OCT_BROWSE           1056
#define IDC_LABEL8                      1056
#define IDC_INPUT_FILENAME              1057
#define IDC_LABEL7                      1057
#define IDC_INPUT_BROWSE                1058
#define IDC_LABEL6                      1058
#define IDC_GAMMA                       1063
#define IDC_GAMMA_VALUE                 1064
#define IDC_AMBIENT_R                   1067
#define IDC_AMBIENT_G                   1069
#define IDC_AMBIENT_B                   1070
#define IDC_CLAMPING                    1071
#define IDC_SUBDIVISION_U               1073
#define IDC_SUBDIVISION_V               1074
#define IDC_CONVERGENCE                 1075
#define IDC_AREA_LIGHT_MULTIPLIER       1076
#define IDC_MAX_ITERATIONS              1077
#define IDC_MAX_ITERATIONS_COUNT        1078
#define IDC_AMBIENT_R_BOX               1078
#define IDC_AMBIENT_G_BOX               1079
#define IDC_ADAPTIVE_MAX_U              1079
#define IDC_AMBIENT_B_BOX               1080
#define IDC_ENABLE_AMBIENT_TERM         1080
#define IDC_AMBIENT_COLOR_BOX           1081
#define IDC_ADAPTIVE_MAX_V              1081
#define IDC_GO                          1082
#define IDC_PAUSE                       1083
#define IDC_POINT_LIGHT_MULTIPLIER      1083
#define IDC_ADAPTIVE_THRESHOLD          1084
#define IDC_ENABLE_NUSSELT              1085
#define IDC_DIRECT_LIGHT_ONLY           1086
#define IDC_ADAPTIVE_PATCHES            1087
#define IDC_ADAPTIVE_THRESHOLD_STATIC   1088
#define IDC_ADAPTIVE_PERCENT_STATIC     1089
#define IDC_ADAPTIVE_MAX_STATIC         1090
#define IDC_ADAPTIVE_X_STATIC           1091
#define IDC_LIGHTMAP_TPU_U              1092
#define IDC_LIGHTMAP_TPU_V              1093
#define IDC_REFLECTIVITY_R              1093
#define IDC_LIGHTMAP_WIDTH              1094
#define IDC_REFLECTIVITY_G              1094
#define IDC_HELPBROWSE                  1094
#define IDC_LIGHTMAP_HEIGHT             1095
#define IDC_REFLECTIVITY_B              1095

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        154
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1096
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

-------------------------------------------------------------------------------
 _____                 _ __  __        _        _
|  __ \               | |  \/  |      | |      | |
| |__) | ___  __ _  __| | \  / | ___  | |___  __ |_
|  _  / / _ \/ _` |/ _` | |\/| |/ _ \ | __\ \/ / __|
| | \ \|  __/ (_| | (_| | |  | |  __/_| |_ >  <| |_
|_|  \_\\___|\__,_|\__,_|_|  |_|\___(_)\__/_/\_\\__|

                           Fluid Studios, Inc.
                       HTTP://www.FluidStudios.com/

-------------------------------------------------------------------------------

Restrictions & freedoms pertaining to usage and redistribution of this software:

 * This software is 100% free
 * If you use this software (in part or in whole) you must credit the author.
 * This software may not be re-distributed (in part or in whole) in a modified
   form without clear documentation on how to obtain a copy of the original work.
 * You may not use this software to directly or indirectly cause harm to others.
 * This software is provided as-is and without warrantee. Use at your own risk.

For more information, visit HTTP://www.FluidStudios.com

-------------------------------------------------------------------------------
What to expect from this demo:
-------------------------------------------------------------------------------

The viewer application is just a simplified 3D engine with the purpose of
showing the results from the Fluid Studios collision detection algorithm.

In this demo, your collision detection entity is a very all ellipsoid. The
dimensions of the ellipsoid are shown on screen with next to "RADIUS". You can
use the function keys to change the size and shape of this ellipsoid. Note that
the viewpoint posision is near the top of the ellipsoid, which can cause it to
act differently than you might expect.

Also, the friction is set somewhat high, so you can only move at a normal
walking pace. The reason for this is to highlight the smooth way in which the
ellipsoid "rolls" around corners and over stairs.

-------------------------------------------------------------------------------
A few notes about running this demo:
-------------------------------------------------------------------------------

Some of the larger maps will run rather slowly (theruins.oct, for example) due
to the lack of visibility and software rendering.

Also, some of the maps will place the viewpoint below the ground, or embedded
in geometry. If you find yourself falling immediately upon loading a map (such
as house5.oct), press G to turn off gravity, then F to allow you to fly around.
Once you're above stable ground, press G and F again to return to a normal
running state.

-------------------------------------------------------------------------------
About this release
-------------------------------------------------------------------------------

This public release is intended as a demonstration of Fluid Studios' collision
detection algorithm. Source code is available on the Fluid Studios' website at:

                       HTTP://www.FluidStudios.com/

This is not a demonstration of high-performance graphics. On the contrary, it
was designed so that it could be easily understood by those trying to implement
the technique in their own work. Because of this, the graphics pipeline is
simplified.

This demonstration also provides a few other benefits. It makes use of 4x4
homogenous perspective transforms, 3D clipping, software rendering of
perpsective correct textured polygons, software font rendering, and a modified
version of WU's anti-aliased line drawing algorithm that is not limited to
lines that begin or end on integer coordinates.

The font files (*.f) were created using the FontGen tool, also available on
the Fluid Studios website. This demonstration serves as a guide on rendering
fonts generated with that tool.

-------------------------------------------------------------------------------
External credits
-------------------------------------------------------------------------------

The OctMap.* source files were provided courtesy of Jason Zisk at nFusion
Interactive.  These files were based on the bspconv tool by Nate Miller.  Visit
http://nate.scuzzy.net for more information on bspconv.

The *.OCT data files were provided courtesy of Jason Zisk at nFusion
Interactive. Visit HTTP://www.n-fusion.com/

-------------------------------------------------------------------------------
ReadMe.txt - End of file
-------------------------------------------------------------------------------


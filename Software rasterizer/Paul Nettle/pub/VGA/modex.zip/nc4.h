#ifndef __NC4_H
#define __NC4_H


#define NC4MODE_320x200 1
#define NC4MODE_320x240 2
#define NC4MODE_320x400 3
#define NC4MODE_320x480 4


extern unsigned int StartAddr;
extern unsigned int ScrWidth;


#ifdef __cplusplus
extern "C" {
#endif


void SetNC4Mode(int ModeNum);
void DrawPixel(int X, int Y, unsigned char Color);
unsigned char ReadPixel(int X, int Y);
void SetScrStart(unsigned int StartAddress);
void WaitDE(void);
void WaitVR(void);


#ifdef __cplusplus
}
#endif


#endif
#include <conio.h>
#include <stdlib.h>
#include "nc4.h"


int main(void)
{
    int		i;
    unsigned char c;
    unsigned int a;

		SetNC4Mode(NC4MODE_320x200);

		for (i=0; i<800; i++) {
	DrawPixel(i, i, i);
	c = ReadPixel(i, i);
	DrawPixel(i+1, i, c);
	}

		getch();

		WaitDE();
		SetScrStart(32767);

		getch();

		StartAddr=32767;

		for (i=0; i<800; i++) {
	DrawPixel(i, i, i);
	c = ReadPixel(i, i);
	DrawPixel(i+1, i, c);
	}

		getch();

		a = 32768;

		while (!kbhit()) {
	WaitDE();
	SetScrStart(a);
	a += 80;
	WaitVR();
	}

		getch();


asm {	mov	ax,0003h
	int	10h
}
		return 0;
}
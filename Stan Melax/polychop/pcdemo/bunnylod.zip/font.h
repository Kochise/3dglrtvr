#ifndef FONT_H
#define FONT_H

void PrintString(char *s,int x=0,int y=-1);
void PostString(char *_s,int _x,int _y,float _life=5.0);
void RenderStrings();

#endif


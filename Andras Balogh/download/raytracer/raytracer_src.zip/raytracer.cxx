//______________________________________________________________
#include "raytrace.h"

//______________________________________________________________
Raytracer::Raytracer() :
active_lights(1),
animate_objects(true),
animate_lights(true),
filtering(true),
ambient_light(0.3f),
time(0)
{
	// setup scene (spheres, planes, lights)

	for (i=0; i<10; i++) {
		obj[i] = new Sphere(0.18f);
		obj[i]->color.random(1.0f);
		obj[i]->amplitude.set(0.5f, 0.5f, 2.2f);
		obj[i]->frequency.set(1.0f, 1.0f, 0.3f);
		obj[i]->phase.set((10-i)*0.6f, (10-i)*0.6f, (10-i)*0.3f);
		obj[i]->offset.set(0.0f, 0.0f, 3.0f);
	}

	obj[i] = new Plane(v3f(0, 0, 6), v3f(1, 0, -4));
	obj[i]->color.set(0, 0.2f, 0.4f);
	i++;

	obj[i] = new Plane(v3f(0, 0, 6), v3f(-1, 0, -4));
	obj[i]->color.set(0.8f, 0.5f, 0);
	i++;

	obj[i] = new Plane(v3f(0, -1, 6), v3f(0, 2, -1));
	obj[i]->color.set(0, 0.5f, 0);
	i++;

	for (i=0; i<8; i++) {
		light[i] = new Object;
		light[i]->amplitude.random(1.0f, 1.0f, 0.5f);
		light[i]->frequency.random(0.5f);
		light[i]->phase.random(1.0f, 1.0f, 1.0f);
		light[i]->offset.set(0.0f, 2.0f, 0.0f);
	}

};

//______________________________________________________________
Raytracer::~Raytracer()
{
	for (i=0; i<13; i++) {
		delete obj[i];
	}

	for (i=0; i<8; i++) {
		delete light[i];
	}

}

//______________________________________________________________
void Raytracer::setup_view(int width, int height)
{
	hi_cx = width;
	hi_cy = height;

	lo_cx = (hi_cx >> 2) + 1;
	lo_cy = (hi_cy >> 2) + 1;

	view_vectors.create(hi_cy+1, hi_cx+1);
	lo.create(lo_cy, lo_cx);
	lo_object.create(lo_cy, lo_cx);

	// precalculate normalized viewing vectors for each pixel
	for (j=0; j<=hi_cy; j++) {
		for (i=0; i<=hi_cx; i++) {
			view_vectors.cell().set(
				+4.0f*(i-width*0.5f)/width, 
				-3.0f*(j-height*0.5f)/height, 
				2.5f
			);
			view_vectors.cell().normalize();
			view_vectors++;
		}
	}

}

//______________________________________________________________
void Raytracer::animate()
{
	time += 0.2f;

	if (animate_objects) {
		for (i=0; i<10; i++) {
			obj[i]->move(time);
		}
	}

	if (animate_lights) {
		for (i=0; i<active_lights; i++) {
			light[i]->move(time);
		}
	}
}

//______________________________________________________________
void Raytracer::find_closest_object()

// finds closest object (object_index), 
// and contact distance (impact_distance)

{
	for (i=0; i<13; i++) {
		obj[i]->intersect(viewing_vector, impact_distance, object_index);
	}
}

//______________________________________________________________
void Raytracer::calculate_impact_properties()

// calculate impact position (impact_position), 
// normal (impact_normal), and color (object_color)

{
	impact_position.set(viewing_vector).scale(impact_distance);
	obj[object_index]->get_impact_properties(impact_position, impact_normal, object_color);
}

//______________________________________________________________
void Raytracer::calculate_lighting()
{
	for (i=0; i<active_lights; i++) {

		is_shadowed = false;

		light_vector.sub(light[i]->position, impact_position);
		light_vector.normalize();

		float f = impact_normal.dprod(light_vector);

		if(f > 0) {
			for (j=0; !is_shadowed && j<10; j++) {
				is_shadowed = obj[j]->intersect(light_vector, impact_position);
			}

			if (!is_shadowed) {
				accumulated_light.translate(0.7f*f/active_lights);
				contributing_lights++;
			}
		}
	}
}

//______________________________________________________________
void Raytracer::trace_light(v3f& pixel, int& o)
{
	viewing_vector.set(view_vectors.cell(hi_x, hi_y));
	impact_distance = 1000.0f;
	object_index = 0;			
	accumulated_light.set(ambient_light);
	contributing_lights = 0;

	find_closest_object();
	calculate_impact_properties();
	calculate_lighting();

	accumulated_light.clamp(1.0f);
	object_color.scale(accumulated_light);

	pixel = object_color.scale(255.0f);
	o = contributing_lights | ((object_index) << 16);
	return;
}

//______________________________________________________________
DWORD Raytracer::trace_fine()
{
	viewing_vector.set(view_vectors.cell(hi_x, hi_y));
	impact_distance = 1000.0f;
	object_index = 0;			
	accumulated_light.set(ambient_light);
	contributing_lights = 0;

	find_closest_object();
	calculate_impact_properties();
	calculate_lighting();

	accumulated_light.clamp(1.0f);
	object_color.scale(accumulated_light);
	object_color.scale(255.0f);
	return ++object_color;
}

//______________________________________________________________
void Raytracer::render_lo()
{
	lo.set_pos(0, 0);
	lo_object.set_pos(0, 0);
	for (hi_y=0; hi_y<=hi_cy; hi_y+=4) {
		for (hi_x=0; hi_x<=hi_cx; hi_x+=4) {
			trace_light(lo.cell(), lo_object.cell());
			lo++;
			lo_object++;
		}
	}
}

//______________________________________________________________
void Raytracer::render_scene(DWORD* vs, DWORD lf)
{
	mi& o = lo_object;

	if (filtering) {
		render_lo();
		lo.set_pos(0, 0);
		o.set_pos(0, 0);
	}

	for (lo_y=0; lo_y<lo_cy-1; lo_y++) {
		for (lo_x=0; lo_x<lo_cx-1; lo_x++) {
			if (filtering && o.quad_equal()) {

				v3f& f00 = lo.cell();
				v3f& f04 = lo.get_nxt_row();
				lo++;
				v3f& f40 = lo.cell();
				v3f& f44 = lo.get_nxt_row();

				// 4x4 (5x5, last row and column discarded) bilinear interpolation,
				// unrolled for best performance

				*vs++=++(f00*1.0000f);
				*vs++=++(f00*0.7500f + f40*0.2500f);
				*vs++=++(f00*0.5000f + f40*0.5000f);
				*vs++=++(f00*0.2500f + f40*0.7500f);
				vs += lf-4;
				
				*vs++=++(f00*0.7500f + f04*0.2500f);
				*vs++=++(f00*0.5625f + f40*0.1875f + f04*0.1875f + f44*0.0625f);
				*vs++=++(f00*0.3750f + f40*0.3750f + f04*0.1250f + f44*0.1250f);
				*vs++=++(f00*0.1875f + f40*0.5625f + f04*0.0625f + f44*0.1875f);
				vs += lf-4;

				*vs++=++(f00*0.5000f + f04*0.5000f);
				*vs++=++(f00*0.3750f + f40*0.1250f + f04*0.3750f + f44*0.1250f);
				*vs++=++(f00*0.2500f + f40*0.2500f + f04*0.2500f + f44*0.2500f);
				*vs++=++(f00*0.1250f + f40*0.3750f + f04*0.1250f + f44*0.3750f);
				vs += lf-4;

				*vs++=++(f00*0.2500f + f04*0.7500f);
				*vs++=++(f00*0.1875f + f40*0.0625f + f04*0.5625f + f44*0.1875f);
				*vs++=++(f00*0.1250f + f40*0.1250f + f04*0.3750f + f44*0.3750f);
				*vs++=++(f00*0.0625f + f40*0.1875f + f04*0.1875f + f44*0.5625f);
				vs -= 3*lf;

			} else {
				int kx=lo_x<<2;
				int ky=lo_y<<2;
				for (hi_y=ky; hi_y<ky+4; hi_y++) {
					for (hi_x=kx; hi_x<kx+4; hi_x++) { 
						*vs++= trace_fine();
					}
					vs += lf - 4;
				}
				vs -= (lf<<2) - 4;
				lo++;
			}
			o++;

		}

		vs += (lf<<2) - hi_cx;
		lo++;
		o++;
	}

}

//______________________________________________________________
// toggling and adjustment functions

void Raytracer::toggle_object_animation() {animate_objects = !animate_objects;}
void Raytracer::toggle_light_animation() {animate_lights = !animate_lights;}
void Raytracer::toggle_filter() {filtering = !filtering;}

void Raytracer::change_light_number(int i)
{
	active_lights += i; 
	minmax(active_lights, 0, 8);
}


//______________________________________________________________

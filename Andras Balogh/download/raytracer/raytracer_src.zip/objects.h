//______________________________________________________________
#pragma once
#include "math.h"

//______________________________________________________________
class Object
{
private:
	static int	visible_id;
public:
	int	id;
	v3f	color;
	v3f	position;
	v3f	offset;
	v3f	amplitude;
	v3f	frequency;
	v3f	phase;

	Object();
	void move(float t);
	virtual void intersect(v3f& v, float& t, int& j) {}
	virtual bool intersect(v3f& v, v3f& e) {return false;}
	virtual void get_impact_properties(v3f& r, v3f& n, v3f& c) {}
};

//______________________________________________________________
class Plane : public Object
{
private:
	v3f	normal;
	float RN;
public:
	Plane(v3f& i_position, v3f& i_normal);
	void intersect(v3f& v, float& t, int& j);
	bool intersect(v3f& v, v3f& e);
	void get_impact_properties(v3f& r, v3f& n, v3f& c);
};

//______________________________________________________________
class Sphere : public Object
{
private:
	float	m_radius;
	float	m_radius_sqr;	// m_radius^2
	float	m_radius_inv;	// m_radius^-1
public:
	Sphere(float i_radius);
	void intersect(v3f& v, float& t, int& j);
	bool intersect(v3f& v, v3f& e);
	void get_impact_properties(v3f& r, v3f& n, v3f& c);
};

//______________________________________________________________

//______________________________________________________________
#pragma once
#include "objects.h"
#include "math.h"

typedef unsigned long int	DWORD;
//______________________________________________________________
class Raytracer
{
private:
Object*	obj[13];			// array of objects in scene
Object*	light[8];			// array of lights

mv3f	view_vectors;		// precomputed viewing vectors for hi-res tracing
mv3f	lo;					// low resolution color buffer (for draft tracing)
mi		lo_object;			// low resolution object buffer

int		hi_cx;				// hires width
int		hi_cy;				// hires height
int		lo_cx;				// lores width
int		lo_cy;				// lores height

int		active_lights;		// only active lights are enabled

bool	animate_objects;	// toggle object animation on/off
bool	animate_lights;		// toggle light animation on/off
bool	filtering;			// toggle bilinear filter on homogeneous surface

v3f		viewing_vector;		// actual viewing vector (eye->window, normalized)
v3f		light_vector;		// normalized vector from impact pos to light
int		object_index;		// index of impact sphere
v3f		object_center;
v3f		object_color;
float	impact_distance;
v3f		impact_position;
v3f		impact_normal;		// surface normal at impact position
v3f		ambient_light;
v3f		accumulated_light;	// accumulated ligth at a given pixel
int		contributing_lights;	// no. of lights contributing to given pixel
bool	is_shadowed;		
float	time;

int		hi_x;
int		hi_y;
int		lo_x;
int		lo_y;
int		i;
int		j;

public:
	Raytracer();
	~Raytracer();
	void setup_view(int width, int height);
	void animate();
	void find_closest_object();
	void calculate_impact_properties();
	void calculate_lighting();
	void trace_light(v3f& pixel, int& o);
	DWORD trace_fine();
	void render_lo();
	void render_scene(DWORD* vs, DWORD lf);
	void toggle_object_animation();
	void toggle_light_animation();
	void toggle_filter();
	void change_light_number(int i);
};

//______________________________________________________________

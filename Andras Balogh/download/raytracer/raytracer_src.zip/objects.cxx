#include "objects.h"

//______________________________________________________________
int Object::visible_id = 0;

//______________________________________________________________
Object::Object()
{
	id = Object::visible_id;
	Object::visible_id++;
}

void Object::move(float t)
{
	position[0] = (float)cos(frequency[0]*t + phase[0]);
	position[1] = (float)sin(frequency[1]*t + phase[1]);
	position[2] = (float)sin(frequency[2]*t + phase[2]);
	position.scale(amplitude);
	position.translate(offset);
}

//______________________________________________________________
Plane::Plane(v3f& i_position, v3f& i_normal)
{
	position = i_position;
	normal = i_normal; 
	normal.normalize(); 
	RN = position.dprod(normal);
}

void Plane::intersect(v3f& v, float& t, int& j)
{
	float	VN = v.dprod(normal);
	float	d = RN / VN;
	if (d<t && d>0) {
		t = d;
		j = id;
	}
	return;
}

bool Plane::intersect(v3f& v, v3f& e)
{
	return false;
}

void Plane::get_impact_properties(v3f& r, v3f& n, v3f& c)
{
	n = normal;
	c = color;
}

//______________________________________________________________
Sphere::Sphere(float i_radius = 0.18f)
{
	m_radius		= i_radius;
	m_radius_sqr	= m_radius * m_radius; 
	m_radius_inv	= 1.0f / m_radius;
}

void Sphere::intersect(v3f& v, float& t, int& j)
{
	float	dv = position.dprod(v);
	float	D = m_radius_sqr - position.dprod(position) + dv*dv;

	if (D > 0) {	// two contacts, first needed
		float d = dv - (float)sqrt(D);
		if (d<t) {
			t = d;
			j = id;
		}
	}
	return;
}

bool Sphere::intersect(v3f& v, v3f& e)
// for shadow rays only
// check to see if there's a contact or not
// v : light vector
// e : impact position
{
	v3f	d; d.sub(position, e);
	float	dv = d.dprod(v);

	if (dv > 0) {	// sphere in front
		float	D = m_radius_sqr - d.dprod(d) + dv*dv;
		if (D > 0) {	// contact
			return true;
		}
	}
	return false;
}

void Sphere::get_impact_properties(v3f& r, v3f& n, v3f& c)
{
	n.sub(r, position).scale(m_radius_inv);
	c = color;
}

//______________________________________________________________

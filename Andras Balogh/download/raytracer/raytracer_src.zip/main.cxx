//______________________________________________________________
#include <stdio.h>
#include <ddraw.h>
#include "raytrace.h"

//______________________________________________________________
LPDIRECTDRAW7			dd		= 0;
LPDIRECTDRAWSURFACE7	ddsf	= 0;
LPDIRECTDRAWSURFACE7	dds		= 0;
DDSURFACEDESC2			ddsd;
DDBLTFX					ddfx;

LARGE_INTEGER freq;
LARGE_INTEGER begin_time;
LARGE_INTEGER end_time;

int	frames;

int	resolution_x;
int	resolution_y;

Raytracer*	engine;

//______________________________________________________________
void render_scene()
{
	engine->animate();
	while (dds->Lock(0, &ddsd, DDLOCK_WAIT, 0) != DD_OK);
	DWORD* virtual_screen = (DWORD*)(ddsd.lpSurface);
	DWORD lf = (ddsd.lPitch >> 2);
	engine->render_scene(virtual_screen, lf);
	dds->Unlock(0);
	ddsf->Blt(0, dds, 0, DDBLT_WAIT, &ddfx);
	frames++;
}

//______________________________________________________________
void setup_virtualscreen(int width, int height)
{
	if (width >= 80 && width <= 1024)	resolution_x = width;
	if (height >= 60 && height <= 768)	resolution_y = height;
	if (dds != NULL) dds->Release();
	ddsd.dwWidth = resolution_x;
	ddsd.dwHeight = resolution_y;
	ddsd.ddsCaps.dwCaps = 0;
	ddsd.dwFlags = DDSD_WIDTH | DDSD_HEIGHT;
	dd->CreateSurface(&ddsd, &dds, 0);
	engine->setup_view(resolution_x, resolution_y);
}

//______________________________________________________________
void create(HWND hWnd)
{
	QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&begin_time);

	DirectDrawCreateEx(0, (VOID**)&dd, IID_IDirectDraw7, 0);
	dd->SetCooperativeLevel(hWnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN);
//	dd->SetDisplayMode(640, 480, 32, 0, 0);
	ddfx.dwSize = sizeof(ddfx);
	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);
	ddsd.ddsCaps.dwCaps =  DDSCAPS_PRIMARYSURFACE;
	ddsd.dwFlags = DDSD_CAPS;
	dd->CreateSurface(&ddsd, &ddsf, 0);
	setup_virtualscreen(640, 480);
	return;
}

//______________________________________________________________
void destroy(HWND hWnd)
{
	delete engine;
	ddsf->Release();
	dds->Unlock(0);
	dds->Release();
	dd->Release();
	DestroyWindow(hWnd);
	UnregisterClass("DirectDraw", ::GetModuleHandle(NULL));
	return;
}

//______________________________________________________________
LRESULT CALLBACK dispatcher(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
	case WM_CREATE: create(hWnd); break;
	case WM_CLOSE: destroy(hWnd); break;
	case WM_DESTROY: PostQuitMessage(0); break;
	case WM_CHAR:
		switch (wParam) {
		case VK_ESCAPE: destroy(hWnd); break;
		case VK_SPACE: engine->toggle_object_animation(); break;
		case VK_RETURN: engine->toggle_light_animation(); break;
		case '*': engine->toggle_filter(); break;
		case ',': engine->change_light_number(-1); break;
		case '.': engine->change_light_number(+1); break;
		case '=':
		case '+': setup_virtualscreen(resolution_x<<1, resolution_y<<1); break;
		case '-': setup_virtualscreen(resolution_x>>1, resolution_y>>1); break;
		default: break;
		}
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

//______________________________________________________________
int WINAPI WinMain(HINSTANCE hInstance,	HINSTANCE hPrvInstance, LPSTR lpCmdLine, int nCmdShow)
{
	engine = new Raytracer;

	WNDCLASS wc = {0, dispatcher, 0, 0, hInstance, 0, 0, 0, 0, "DirectDraw"};
	RegisterClass(&wc);
	HWND hWnd = CreateWindow("DirectDraw", 0, WS_POPUP, 0, 0, 0, 0, 0, 0, hInstance,	0);
	ShowWindow(hWnd, nCmdShow);
	ShowCursor(FALSE);

	MSG	msg;
	for(;;) {
		while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
			if (msg.message == WM_QUIT) {
				QueryPerformanceCounter(&end_time);
				float fps=frames/((float)(end_time.QuadPart-begin_time.QuadPart)/freq.QuadPart);
				char str[64];
				sprintf(str, "%f FPS", fps);
				MessageBox(NULL, str, "Performace:", MB_OK);
				return (int)msg.wParam;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		render_scene();
	}

}

//______________________________________________________________

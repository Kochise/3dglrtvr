#pragma once
#include <math.h>
#include <stdlib.h>

template <class T> class Vector;
template <class T> class Matrix;

typedef Vector<float>	v3f;
typedef Matrix<v3f>		mv3f;
typedef Matrix<int>		mi;

inline float rnd(float max) { return (rand() % 7000 + 3000) * 0.0001f * max; }
inline void minmax(int& n, int min, int max) {n = n < min ? min : n; n = n > max ? max : n;}
inline void clamp(float& a, float b) {a = (a>0) ? (a>b ? b:a) : (a<-b ? -b:a);}

#pragma pack(push, 1)

template <class T>
class Vector
{
private:
	T	v[3];
public:
	Vector() {}
	Vector(T f) {v[0]=f, v[1]=f, v[2]=f;}
	Vector(T* f) {v[0]=f[0], v[1]=f[1], v[2]=f[2];}
	Vector(Vector& u) {v[0]=u[0], v[1]=u[1], v[2]=u[2];}
	Vector(T x, T y, T z) {v[0]=x, v[1]=y, v[2]=z;}
	~Vector() {}

			operator T* () {return v;}
	T&	operator[] (int i) {return v[i];}
	Vector&	set(T f) {v[0]=f, v[1]=f, v[2]=f; return *this;}
	Vector&	set(Vector& u) {v[0]=u[0], v[1]=u[1], v[2]=u[2]; return *this;}
	Vector&	set(T x, T y, T z) {v[0]=x, v[1]=y, v[2]=z; return *this;}
	Vector&	clamp(T u) {::clamp(v[0], u), ::clamp(v[1], u), ::clamp(v[2], u); return *this;}
	Vector&	negate() {v[0]=-v[0], v[1]=-v[1], v[2]=-v[2]; return *this;}
	Vector&	scale(T f) {v[0]*=f, v[1]*=f, v[2]*=f; return *this;}
	Vector&	scale(Vector& u) {v[0]*=u[0], v[1]*=u[1], v[2]*=u[2]; return *this;}
	Vector&	translate(T f) {v[0]+=f, v[1]+=f, v[2]+=f; return *this;}
	Vector&	translate(T x, T y, T z) {v[0]+=x, v[1]+=y, v[2]+=z; return *this;}
	Vector&	translate(Vector& u) {v[0]+=u[0], v[1]+=u[1], v[2]+=u[2]; return *this;}
	Vector&	add(Vector& a, Vector& b) {v[0]=a[0]+b[0], v[1]=a[1]+b[1], v[2]=a[2]+b[2]; return *this;}
	Vector&	sub(Vector& a, Vector& b) {v[0]=a[0]-b[0], v[1]=a[1]-b[1], v[2]=a[2]-b[2]; return *this;}
	T	dprod(Vector& u) {return v[0]*u[0] + v[1]*u[1] + v[2]*u[2];}
	Vector&	xprod(Vector& a, Vector& b) {v[0] = a[1]*b[2] - a[2]*b[1]; v[1] = a[2]*b[0] - a[0]*b[2]; v[2] = a[0]*b[1] - a[1]*b[0]; return *this;}
	T	length() {return (T)sqrt(dprod(*this));}
	Vector&	normalize() {scale(1/length()); return *this;}
	Vector&	setlength(T f) {scale(f/length()); return *this;}
	Vector&	normal(Vector& a, Vector& b, Vector& c) {Vector d1, d2; d1.sub(a, b); d2.sub(a, c); return xprod(d1, d2);}
	Vector& random(T max) {v[0]=rnd(max), v[1]=rnd(max), v[2]=rnd(max); return *this;}
	Vector& random(T x, T y, T z) {v[0]=rnd(x), v[1]=rnd(y), v[2]=rnd(z); return *this;}

	Vector	operator*(float f) {return Vector(v[0]*f, v[1]*f, v[2]*f);}
	Vector	operator+(Vector& u) {return Vector(v[0]+u[0], v[1]+u[1], v[2]+u[2]);}
	operator++() {return (DWORD)(v[0])<<16 | (DWORD)(v[1])<<8 | (DWORD)(v[2]);}
};

#pragma pack(pop)

template <class T>
class Matrix
{
private:

	T*				m_data;
	unsigned int	m_rows;
	unsigned int	m_cols;

	unsigned int	m_p;

public:

	Matrix() : m_data(0) {}
	~Matrix() { destroy(); };

	void create(unsigned int i_rows, unsigned int i_cols)
	{
		destroy();
		m_p = 0;
		m_rows = i_rows;
		m_cols = i_cols;
		m_data = new T[m_rows*m_cols];
	}

	void destroy()
	{
		if (m_data) delete [] m_data;
	}

	T&		cell() { return m_data[m_p]; }
	T&		cell(unsigned int i_x, unsigned int i_y) { return m_data[i_y*m_cols+i_x]; }
	void	set_pos(unsigned int i_x, unsigned int i_y) { m_p = i_y*m_cols+i_x; }

	T&		get_nxt_col() { return m_data[m_p+1]; }
	T&		get_nxt_row() { return m_data[m_p+m_cols]; }

	bool	quad_equal() { 
		return 
			m_data[m_p] == m_data[m_p+1] &&
			m_data[m_p] == m_data[m_p+m_cols] &&
			m_data[m_p+1] == m_data[m_p+1+m_cols];
	}

	void	operator++(int) { m_p++; }
};


//______________________________________________________________
#include <GL/glut.h>
#include <math.h>
#include "journal.hpp"
#include "extension.hpp"
#include "random.hpp"
#include "fountain.hpp"
#include "timer.hpp"
//______________________________________________________________
const float	pi = 3.14159265358979323846f;

const GLfloat	reflection[] = {
	1, 0, 0, 0,
	0,-1, 0, 0,
	0, 0, 1, 0,
	0, 0, 0, 1
};

const float	max_thrust	= 12.0f;
const float	min_thrust	= 2.0f;
const float	max_spread	= 4.0f;
const float	min_spread	= 0.1f;
const float	max_dps		= 5000;
const float	min_dps		= 0.0f;
const float	max_boost	= 1.0f;
const float	gravity		= 9.81f;
//______________________________________________________________
Fountain::Fountain(int number_of_drops, float drops_per_sec)
{
	journal << "init: Fountain\t";
	this->number_of_drops = number_of_drops;
	this->drops_per_sec = drops_per_sec;
	active_drops = 0;
	queue = 0.0;
	boost = 0.0;

	thrust	= 6.0f;
	spread	= 0.9f;

	position = new GLfloat[number_of_drops][3];
	velocity = new GLfloat[number_of_drops][3];
	color    = new GLubyte[number_of_drops][4];

	journal << "OK\n";

	return;
}
//______________________________________________________________
Fountain::~Fountain()
{
	journal << "kill: Fountain\t";
	delete [] position;
	delete [] velocity;
	delete [] color;
	journal << "OK\n";
	return;
}
//______________________________________________________________
void Fountain::update()
{
	int	i;
	int	j;
	int	new_drops;
	float	dt = timer->get(DT);

	if (boost > 0.0) {
		boost -= dt;
		queue += 3000*dt;
	}

	queue += drops_per_sec * dt;
	new_drops = floor(queue);
	queue -= new_drops;

	for (i=active_drops-1; i>=0; i--) {
		position[i][0] += velocity[i][0]*dt;
		position[i][1] += velocity[i][1]*dt;
		position[i][2] += velocity[i][2]*dt;

		velocity[i][1] -= gravity*dt;
		color[i][3] -= 0.3*dt;
		
		if (
			position[i][1] < 0.001 ||
			color[i][3] < 0.001
		) {
			if (new_drops) {
				createDrop(i);
				new_drops--;
			} else { 
				j = active_drops - 1;

				position[i][0] = position[j][0];
				position[i][1] = position[j][1];
				position[i][2] = position[j][2];

				velocity[i][0] = velocity[j][0];
				velocity[i][1] = velocity[j][1];
				velocity[i][2] = velocity[j][2];

				color[i][0] = color[j][0];
				color[i][1] = color[j][1];
				color[i][2] = color[j][2];
				color[i][3] = color[j][3];

				active_drops--;
			}
		}
	}

	while(new_drops) {
		if (active_drops < number_of_drops) {
			createDrop(active_drops++);
		} else {
			break;
		}
		new_drops--;
	}

	return;
}
//______________________________________________________________
void Fountain::createDrop(int i)
{
	position[i][0] = 0.0;
	position[i][1] = 1.2 + random(0.2);
	position[i][2] = 0.0;
	
	velocity[i][0] = random(2*spread) - spread;
	velocity[i][1] = thrust + random(random(3));
	velocity[i][2] = random(2*spread) - spread;

	color[i][0] = 255*(0.1 + random(0.4f));
	color[i][1] = 255*(0.3 + random(0.4f));
	color[i][2] = 255*(0.7 + random(0.3f));
	color[i][3] = 255*(0.9);

	return;
}
//______________________________________________________________
void Fountain::render(unsigned int type, GLfloat x, GLfloat y, GLfloat z)
{
	GLfloat quadratic[3] = { 0.25, 0.0, 1/60.0 };

	glEnable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);

	glPointSize(4.0);

	if (glPointParameterfEXT) {
		glPointParameterfEXT(GL_POINT_FADE_THRESHOLD_SIZE_EXT, 1.0);
	}
	if (glPointParameterfvEXT) {
		glPointParameterfvEXT(GL_DISTANCE_ATTENUATION_EXT, quadratic);
	}

	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glTranslatef(x, y, z);

	if (type == REFLECTION) {
		glMultMatrixf(reflection);
	}

	glVertexPointer(3, GL_FLOAT, 0, position);
	glColorPointer(4, GL_UNSIGNED_BYTE, 0, color);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_COLOR_ARRAY);
	glDrawArrays(GL_POINTS, 0, active_drops);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);

	glPopMatrix();

	return;
}
//______________________________________________________________
void Fountain::set(unsigned int type, float value)
{
	float	dt = timer->get(DT);
	
	switch (type) {
	case FOUNTAIN_THRUST:
		thrust += value;
		if (thrust > max_thrust) {
			thrust = max_thrust;
		} else if (thrust < min_thrust) {
			thrust = min_thrust;
		}
		break;
	case FOUNTAIN_SPREAD:
		spread += value;
		if (spread > max_spread) {
			spread = max_spread;
		} else if (spread < min_spread) {
			spread = min_spread;
		}
		break;
	case FOUNTAIN_DPS:
		drops_per_sec += value*dt;
		if (drops_per_sec > max_dps) {
			drops_per_sec = max_dps;
		} else if (drops_per_sec < min_dps) {
			drops_per_sec = min_dps;
		}
		break;
	case FOUNTAIN_CLOSE:
		drops_per_sec = min_dps;
		boost = 0.0;
		break;
	case FOUNTAIN_OPEN:
		drops_per_sec = max_dps;
		break;
	case FOUNTAIN_BOOST:
		boost += value;
		if (boost > max_boost) {
			boost = max_boost;
		}
		break;
	default:
		break;
	}
	return;
}
//______________________________________________________________
float Fountain::get(unsigned int type)
{
	switch (type) {
	case FOUNTAIN_DPS:
		return drops_per_sec;
		break;
	case FOUNTAIN_ACTIVE:
		return active_drops;
		break;
	case FOUNTAIN_BOOST:
		return boost;
		break;
	default:
		return 0;
		break;
	}
	return 0;
}
//______________________________________________________________

#ifndef	BND_Journal_H
#define	BND_Journal_H

#include <stdio.h>

class Journal;

class Journal {
private:
	FILE	*f;
public:
	Journal(const char *path);
	~Journal();
	Journal& operator<<(const char *string);
	Journal& operator<<(const unsigned char *string);
	Journal& operator<<(float value);
	Journal& operator<<(int value);
};

extern Journal	journal;

#endif
#ifndef	BND_PETAL_H
#define	BND_PETAL_H
//______________________________________________________________
#define	NORMAL		0
#define	REFLECTION	1
//______________________________________________________________
class Petal;
class Petal_1;
class Petal_2;
//______________________________________________________________
class Petal 
{
protected:
	GLfloat		(*vertices)[3];
	GLfloat		(*colors)[4];
	unsigned int	number_of_vertices;
	bool		transparent;
public:
	Petal(unsigned int number_of_vertices = 100);
	~Petal();
	virtual void update() = 0;
	void render(unsigned int type = NORMAL, GLfloat x = 0, GLfloat y = 0, GLfloat z = 0);
};
//______________________________________________________________
class Petal_1 : public Petal 
{
public:
	Petal_1(unsigned int number_of_vertices = 100);
	void update();
};
//______________________________________________________________
class Petal_2 : public Petal 
{
public:
	Petal_2(unsigned int number_of_vertices = 100);
	void update();
};
//______________________________________________________________
class Petal_3 : public Petal 
{
public:
	Petal_3(unsigned int number_of_vertices = 100);
	void update();
};
//______________________________________________________________
extern Petal	*petal_1;
extern Petal	*petal_2;
extern Petal	*petal_3;
//______________________________________________________________

#endif

#ifndef	BND_GLUT_H
#define	BND_GLUT_H

extern void display();
extern void idle();
extern void keyboard(unsigned char key, int x, int y);
extern void special(int key, int x, int y);
extern void reshape(int width, int height);
extern void mouse(int button, int state, int x, int y);
extern void motion(int x, int y);

#endif

//______________________________________________________________
#include <GL/glut.h>
#include <math.h>
#include "journal.hpp"
#include "petal.hpp"
#include "fountain.hpp"
#include "timer.hpp"
//______________________________________________________________
const float	pi = 3.14159265358979323846;

const GLfloat	reflection[] = {
	1, 0, 0, 0,
	0,-1, 0, 0,
	0, 0, 1, 0,
	0, 0, 0, 1
};
//______________________________________________________________
Petal::Petal(unsigned int number_of_vertices)
{
	journal << "init: Petal\t";

	this->number_of_vertices = number_of_vertices;

	vertices = new GLfloat[number_of_vertices][3];
	colors = new GLfloat[number_of_vertices][4];
	transparent = false;

	journal << "OK\n";

	return;
}
//______________________________________________________________
Petal::~Petal()
{
	journal << "kill: Petal\tOK\n";
	return;
}
//______________________________________________________________
void Petal::render(unsigned int type, GLfloat x, GLfloat y, GLfloat z)
{
	glEnable(GL_DEPTH_TEST);

	if (transparent) {
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glDepthMask(GL_FALSE);
	} else {
		glDisable(GL_BLEND);
		glDepthMask(GL_TRUE);
	}

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();

	glTranslatef(x, y, z);

	if (type == REFLECTION) {
		glMultMatrixf(reflection);
	}

	glVertexPointer(3, GL_FLOAT, 0, vertices);
	glColorPointer(4, GL_FLOAT, 0, colors);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_COLOR_ARRAY);
	glDrawArrays(GL_TRIANGLE_FAN, 0, number_of_vertices);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);

	glPopMatrix();

	return;
}
//______________________________________________________________
Petal_1::Petal_1(unsigned int number_of_vertices):
Petal(number_of_vertices) 
{
	return;
};
//______________________________________________________________
void Petal_1::update()
{
	unsigned int	i;
	GLfloat		u;
	GLfloat		t;
	GLfloat		time = timer->get(TIME);

	t = u = 2 * pi / (number_of_vertices - 2);

	vertices[0][0] = 0.0;
	vertices[0][1] = 1.0;
	vertices[0][2] = 0.0;

	colors[0][0] = 1.0;
	colors[0][1] = 1.0;
	colors[0][2] = 1.0;
	colors[0][3] = 1.0;

	for (i=1; i<number_of_vertices; i++) {
		vertices[i][0] = 2.0 * sin(1.2*time + t);
		vertices[i][1] = 1.0 + 0.3*sin(8*t)*sin(3.1*time) + 0.4*sin(6.2*time - pi/2);
		vertices[i][2] = 2.0 * cos(1.2*time + t);

		colors[i][0] = sin(4.2*time + 5*t);
		colors[i][1] = sin(4*t);
		colors[i][2] = sin(3*t);
		colors[i][3] = 1.0;

		t += u;
	}

	return;
}
//______________________________________________________________
Petal_2::Petal_2(unsigned int number_of_vertices):
Petal(number_of_vertices) 
{
	return;
};
//______________________________________________________________
void Petal_2::update()
{
	unsigned int	i;
	GLfloat		u;
	GLfloat		t;
	GLfloat		time = timer->get(TIME);

	t = u = 2 * pi / (number_of_vertices - 2);

	vertices[0][0] = 0.0;
	vertices[0][1] = 1.0;
	vertices[0][2] = 0.0;

	colors[0][0] = 1.0;
	colors[0][1] = 1.0;
	colors[0][2] = 1.0;
	colors[0][3] = 1.0;

	for (i=1; i<number_of_vertices; i++) {
		vertices[i][0] = 0.4 * sin(t);
		vertices[i][1] = 1.8 + 0.2*cos(6*time + 7*t);
		vertices[i][2] = 0.4 * cos(t);

		colors[i][0] = sin(5*t);
		colors[i][1] = sin(4*t);
		colors[i][2] = sin(3*t);
		colors[i][3] = 1.0;

		t += u;
	}

	return;
}
//______________________________________________________________
Petal_3::Petal_3(unsigned int number_of_vertices):
Petal(number_of_vertices) 
{
	transparent = true;
	return;
};
//______________________________________________________________
void Petal_3::update()
{
	unsigned int	i;
	GLfloat		u;
	GLfloat		t;
	GLfloat		time = timer->get(TIME);

	t = u = 2 * pi / (number_of_vertices - 2);

	vertices[0][0] = 0.0;
	vertices[0][1] = 2.0;
	vertices[0][2] = 0.0;

	colors[0][0] = 1.0;
	colors[0][1] = 1.0;
	colors[0][2] = 1.0;
	colors[0][3] = 1.0;

	for (i=1; i<number_of_vertices; i++) {
		vertices[i][0] = 0.3 * sin(t);
		vertices[i][1] = 0.01;
		vertices[i][2] = 0.3 * cos(t);

		colors[i][0] = 0.0;
		colors[i][1] = sin(4*t);
		colors[i][2] = 0.5;
		colors[i][3] = 0.1;

		t += u;
	}

	return;
}
//______________________________________________________________

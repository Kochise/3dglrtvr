//______________________________________________________________
#include <GL/glut.h>
#include <math.h>
#include "journal.hpp"
#include "timer.hpp"
#include "camera.hpp"
//______________________________________________________________
const float	pi = 3.14159265358979323846f;

const float	max_spin     = 1.0;
const float	max_angle_v  = 0.4*pi;
const float	min_angle_v  = -0.4*pi;
const float	max_distance = 30.0;
const float	min_distance = 1.0;
//______________________________________________________________
Camera::Camera()
{
	journal << "init: Camera\t";
	reset();
	journal << "OK\n";
	return;
}
//______________________________________________________________
Camera::~Camera()
{
	journal << "kill: Camera\tOK\n";
	return;
}
//______________________________________________________________
void Camera::reset()
{
	distance = 6.0;
	angle_v  = -0.03;
	angle_h  = 0.0;
	spin     = 0.0;

	automagic = true;

	return;
}
//______________________________________________________________
void Camera::eye()
{
	GLfloat	distance;
	float	dt   = timer->get(DT);
	float	time = timer->get(METATIME);

	if (automagic) {
		eye_y = 4.3+4.2*sin(time);
		eye_x = 20*sin(3*time/5);
		eye_z = 20*cos(2*time/5);
	} else {
		distance = this->distance;
		eye_y = distance * sin(angle_v) + 2;

		if (eye_y < 1) {
			eye_y = 1;
			distance = -1 / sin(angle_v);
		}

		distance = distance * cos(angle_v);
		eye_x = distance * sin(angle_h);
		eye_z = distance * cos(angle_h);
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(
		eye_x, eye_y, eye_z,
		    0,     2,     0,
		    0,     1,     0 
	);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(90, aspect, 0.1, 100);

	angle_h += spin * dt;

	return;
}
//______________________________________________________________
void Camera::skybox()
{
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(
		     0,      0,      0,       
		-eye_x, -eye_y+2, -eye_z,
		     0,      1,      0 
	);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(90, aspect, 0.1, 2);

	return;
}
//______________________________________________________________
void Camera::set(unsigned int type, float value)
{
	switch (type) {
	case CAMERA_DISTANCE:
		distance += value;
		if (distance > max_distance) {
			distance = max_distance;
		} else if (distance < min_distance) {
			distance = min_distance;
		}
		break;
	case CAMERA_ANGLE_V:
		angle_v += value;
		if (angle_v > max_angle_v) {
			angle_v = max_angle_v;
		} else if (angle_v < min_angle_v) {
			angle_v = min_angle_v;
		}
		break;
	case CAMERA_ANGLE_H:
		angle_h -= value;
		break;
	case CAMERA_SPIN:
		spin = value;
		if (spin > max_spin) {
			spin = max_spin;
		} else if (spin < -max_spin) {
			spin = -max_spin;
		}
		break;
	case CAMERA_ASPECT:
		aspect = value;
		break;
	case CAMERA_CONTROL:
		automagic = !automagic;
		break;
	default:
		break;
	}

	return;
}
//______________________________________________________________
float Camera::get(unsigned int type)
{
	switch (type) {
	case CAMERA_X:
		return eye_x;
		break;
	case CAMERA_Y:
		return eye_y;
		break;
	case CAMERA_Z:
		return eye_z;
		break;
	default:
		break;
	}

	return 0;
}
//______________________________________________________________

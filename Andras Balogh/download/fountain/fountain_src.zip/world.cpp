//______________________________________________________________
#include <GL/glut.h>
#include "journal.hpp"
#include "fountain.hpp"
#include "surface.hpp"
#include "petal.hpp"
#include "grid.hpp"
#include "skybox.hpp"
#include "world.hpp"
#include "camera.hpp"
#include "help.hpp"
#include "hud.hpp"
#include "timer.hpp"
//______________________________________________________________
static GLfloat	x[] = {-10.0, +10.0, 0.0, -10.0, +10.0};
static GLfloat	z[] = {-10.0, -10.0, 0.0, +10.0, +10.0};

static unsigned char order[4][5] = {
	{0, 2, 1, 3, 4},
	{3, 2, 0, 4, 1},
	{4, 2, 3, 1, 0},
	{1, 2, 4, 0, 3}
};
//______________________________________________________________
World::World()
{
	journal << "init: World\t";

	frozen		= false;
	draw_reflection = true;

	number_of_fountains = 5;

	journal << "OK\n";

	return;
}
//______________________________________________________________
World::~World()
{
	journal << "kill: World\tOK\n";
	return;
}
//______________________________________________________________
void World::render()
{
	unsigned int	i;
	unsigned int	j;
	unsigned int	angle;
	float	eye_x = camera->get(CAMERA_X);
	float	eye_z = camera->get(CAMERA_Z);

	if (eye_x>0) {
		if (eye_z>0) {
			angle = 0;
		} else {
			angle = 1;
		}
	} else {
		if (eye_z>0) {
			angle = 3;
		} else {
			angle = 2;
		}
	}

	timer->update();

	if (!frozen) {
		fountain->update();
		petal_1->update();
		petal_2->update();
		petal_3->update();
	}

	glDepthMask(GL_TRUE);
	glClear(GL_DEPTH_BUFFER_BIT);

	camera->skybox();
	skybox->render();
	camera->eye();

	surface->render2();

	if (draw_reflection) {
		for (i=0; i<number_of_fountains; i++) {
			j = order[angle][i];
			petal_1->render(REFLECTION, x[j], 0, z[j]);
			petal_2->render(REFLECTION, x[j], 0, z[j]);
			petal_3->render(REFLECTION, x[j], 0, z[j]);
		}
		for (i=0; i<number_of_fountains; i++) {
			j = order[angle][i];
			fountain->render(REFLECTION, x[j], 0, z[j]);
		}
	}

	surface->render();

	for (i=0; i<number_of_fountains; i++) {
		j = order[angle][i];
		petal_1->render(NORMAL, x[j], 0, z[j]);
		petal_2->render(NORMAL, x[j], 0, z[j]);
		petal_3->render(NORMAL, x[j], 0, z[j]);
	}

	for (i=0; i<number_of_fountains; i++) {
		j = order[angle][i];
		fountain->render(NORMAL, x[j], 0, z[j]);
	}

	grid->update();
	hud->update();
	help->update();

	return;
}
//______________________________________________________________
void World::set(unsigned int type, bool value)
{
	switch (type) {
	case FREEZE:
		frozen = !frozen;
		timer->pause();
		break;
	case REFLECTION:
		draw_reflection = !draw_reflection;
		break;
	default:
		break;
	}
	return;
}
//______________________________________________________________

#ifndef BND_RANDOM_H
#define	BND_RANDOM_H

extern float random(float range);

#endif

#ifndef	BND_WORLD_H
#define	BND_WORLD_H

#define	FREEZE		0
#define	REFLECTION	1

class World;

class World {
private:
	bool		frozen;
	bool		draw_reflection;
	bool		draw_grid;
	bool		draw_help;
	bool		draw_HUD;
	unsigned int	number_of_fountains;
public:
	World();
	~World();
	void render();
	void set(unsigned int type, bool value = true);
};

extern	World	*world;

#endif
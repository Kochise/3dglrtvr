#ifndef	BND_TGA
#define	BND_TGA

extern void loadTGA(const char *path, GLuint &id, GLint wrap_type);

#endif
//______________________________________________________________
#include <stdio.h>
#include <string.h>
#include "journal.hpp"
//______________________________________________________________
#define PATHSIZE    64              /* the maximum length for a file's path */
#define RINGSIZE    4096            /* ring buffer's size (12 bits) */
#define THRESHOLD   3               /* decides wether is it worth coding */
#define TEXTSIZE    16+THRESHOLD-1  /* maximum length of match (4 bits) */
#define CODESIZE    1+2*8           /* buffer length for coded output */
//______________________________________________________________
typedef	unsigned char		byte;
typedef	unsigned short int	word;
typedef	unsigned long int	dword;
//______________________________________________________________
#pragma pack(push,pak)
#pragma pack(1)
struct Entry
{
	char	Path[PATHSIZE];
	dword	Position;
	dword	TextSize;
	dword	CodeSize;
};
struct Boot
{
	dword	Position;
	dword	TextSize;
};
#pragma pack(pop,pak)
//______________________________________________________________
byte *load(const char *FileName, const char *PackFileName);
static byte *decode(struct Entry *FileInfo, FILE *PackFile);
//______________________________________________________________
byte *load(const char *FileName, const char *PackFileName)
{
	Entry	*DirMap;	/* will hold the info about the files */
	Boot	Boot;		/* boot holds dirmap's position and length */

	char	PackFileID[7];	/* this identifies the packfile as valid */
	dword	FilesNbr;	/* number of files to decode */
	dword	i;		/* general purpose index variable */
	FILE	*PackFile;	/* packfile's handler */
	byte	*File = NULL;

	/* print some info */
	journal << "\tLoading \"" << FileName << "\"...";

	/* open packfile */
	PackFile = fopen(PackFileName, "rb");
	if (!PackFile) {
		journal << "Error: Couldn't open " << PackFileName << "\n";
		return NULL;
	}

	/* check id string */
	fread(PackFileID, 1, 6, PackFile);
	PackFileID[6] = '\0';
	if (strcmp(PackFileID, "bndPAK")) {
		journal << "Error: " << PackFileName << " is not a valid packfile.\n";
		return NULL;
	}

	/* load boot data */
	fseek(PackFile, -(long)sizeof(Boot), SEEK_END);
	fread(&Boot, 1, sizeof(Boot), PackFile);

	/* load dirmap */
	FilesNbr = Boot.TextSize / sizeof(Entry);
	DirMap = new Entry[FilesNbr];
	fseek(PackFile, Boot.Position, SEEK_SET);
	fread(DirMap, 1, Boot.TextSize, PackFile);

	/* decode files */
	for (i=0; i<FilesNbr; i++) {
		if (!strcmp(DirMap[i].Path, FileName)) {
			File = decode(DirMap+i, PackFile);
			break;
		}
	}

	/* close packfile and free memory */
	fclose(PackFile);
	delete [] DirMap;

	/* we're done with the decoding */
	journal << "Done\n";

	return File;
}
//______________________________________________________________
static byte *decode(struct Entry *FileInfo, FILE *PackFile)
{
	byte	Ring[RINGSIZE]; /* the ring buffer stores previous data */
	byte	Temp[TEXTSIZE];
	dword	RingPtr  = 0;   /* position in the ring */
	dword	Counter  = 0;   /* count items remaining in the chunk */
	dword	Flags    = 0;   /* determines which items are compressed */
	dword	Data     = 0;   /* store a piece of data temporarly */
	dword	MatchLen = 0;   /* match's length to replace item with */
	dword	MatchPos = 0;   /* match's position in the ring buffer */
	dword	i;              /* general purpose index variable */
	dword	j = 0;          /* general purpose index variable */
	byte	*File;          /* the output file to be generated */


	/* position packfile to the beginning of coded data */
	fseek(PackFile, FileInfo->Position, SEEK_SET);

	/* create destination file */
	File = new byte[FileInfo->TextSize];

	/* clear ring buffer */
	for (i=0; i<RINGSIZE; i++) {
		Ring[i] = 0;
	}

	/* decode stream */
	for (;;) {
		if (!Counter) {
			if (!(FileInfo->CodeSize--)) {
				break;
			}
			Flags = getc(PackFile);
			Counter = 8;
		}
		if (Flags & 1) {
			MatchPos = getc(PackFile);
			MatchLen = getc(PackFile);
			MatchPos |= (MatchLen & 15) << 8;
			MatchLen >>= 4;
			MatchLen += THRESHOLD;
			FileInfo->CodeSize -= 2;
			for (i=0; i<MatchLen; i++) {
				Data = (byte)Ring[(MatchPos+i) & (RINGSIZE-1)];
				File[j++] = (byte)Data;
				Temp[i] = (byte)Data;
			}
			for (i=0; i<MatchLen; i++) {
				Ring[RingPtr++] = Temp[i];
				RingPtr &= (RINGSIZE-1);
			}
		} else {
			if (!(FileInfo->CodeSize--)) {
				break;
			}
			Data = getc(PackFile);
			File[j++] = (byte)Data;
			Ring[RingPtr++] = (byte)Data;
			RingPtr &= (RINGSIZE-1);
		}
		Flags >>= 1;
		--Counter;
	}

	return File;
}
//______________________________________________________________


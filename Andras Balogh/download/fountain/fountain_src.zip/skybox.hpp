#ifndef	BND_SKYBOX_H
#define	BND_SKYBOX_H

#include <GL/glut.h>

class Skybox;

class Skybox
{
private:
	GLuint	tx_skybox[6];
public:
	Skybox();
	~Skybox();
	void render();
};

extern Skybox	*skybox;

#endif
#ifndef	BND_HELP_H
#define	BND_HELP_H

class Help;

class Help {
private:
	bool	active;
	bool	visible;
	float	position;
public:
	Help();
	~Help();
	void toggle();
	void update();
	void render();
};

extern Help	*help;

#endif
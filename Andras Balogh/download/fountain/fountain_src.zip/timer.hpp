#ifndef	BND_TIMER_H
#define	BND_TIMER_H

#include <time.h>

#define	TIME		0
#define	DT		1
#define	FPS		2
#define	METATIME	3

class Timer;

class Timer {
private:
	clock_t		old_time;
	clock_t		new_time;
	float		meta_time;
	float		time;
	float		dt;
	unsigned int	frames;
	bool		paused;
public:
	Timer();
	~Timer();
	void reset();
	void update();
	void pause();
	float get(unsigned int type);
};

extern Timer	*timer;

#endif
#ifndef	BND_FONT_H
#define	BND_FONT_H

class Font;

class Font
{
private:
	GLuint		tx_font;
	GLfloat		color[4];
	unsigned int	rows;
	unsigned int	cols;
public:
	Font(const char *path, unsigned int x, unsigned int y);
	~Font();
	void render(const char *s, float col, float row);
	void setColor(float red, float green, float blue, float alpha);
};

extern Font	*font;

#endif
#ifndef BND_EXTENSION_H
#define BND_EXTENSION_H

#include <GL/glext.h>

extern PFNGLPOINTPARAMETERFEXTPROC glPointParameterfEXT;
extern PFNGLPOINTPARAMETERFVEXTPROC glPointParameterfvEXT;

extern void initExtensions(void);

#endif

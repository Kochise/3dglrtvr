#ifndef	BND_PAK_H
#define	BND_PAK_H

extern unsigned char *load(const char *file_path, const char *pak_path);

#endif
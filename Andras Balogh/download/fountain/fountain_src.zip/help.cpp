//______________________________________________________________
#include <GL/glut.h>
#include <math.h>
#include "journal.hpp"
#include "timer.hpp"
#include "font.hpp"
#include "help.hpp"
//______________________________________________________________
const float	pi = 3.14159265358979323846;

char *text=
//	"0123456789012345678901234567890123456789"
	"                  HELP\n"
	"\n"
	" F1    - display this help screen\n"
	" TAB   - manual or automatic camera\n"
	" SPACE - freeze fountains\n"
	" UP    - increase water thrust\n"
	" DOWN  - decrease water thrust\n"
	" LEFT  - decrease water spread\n"
	" RIGHT - increase water spread\n"
	" ENTER - boost water generation\n"
	" +     - increase water generation\n"
	" -     - decrease water generation\n"
	" *     - maximum water generation\n"
	" /     - no water generation\n"
	" h     - head up display on/off\n"
	" g     - volumetric grid on/off\n"
	" r     - reflection on/off\n"
	" ESC   - exit program\n"
	"\n"
	" In manual camera control mode you can\n"
	" use the mouse to move the camera.";
//	"0123456789012345678901234567890123456789"
//______________________________________________________________
Help::Help()
{
	journal << "init: Help\t";

	position = 1;
	active	 = false;
	visible	 = false;
	
	journal << "OK\n";

	return;
}
//______________________________________________________________
Help::~Help()
{
	journal << "kill: Help\tOK\n";
	return;
}
//______________________________________________________________
void Help::update()
{
	float	dt = timer->get(DT);

	visible = true;

	if (active) {
		position -= dt;
		if (position < 0) {
			position = 0;
		}
	} else {
		position += dt;
		if (position > 1) {
			position = 1;
			visible = false;
		}
	}

	if (visible) {
		render();
	}

	return;
}
//______________________________________________________________
void Help::render()
{
	float	time = timer->get(METATIME);
	float	t1;
	float	t2;
	float	t3;

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(0, 27*(1-cos(position*pi/2)), 0);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-5, +45, -30, 5, -1, +1);

	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	t1 = 0.5+0.5*sin(2*time+2);
	t2 = 0.5+0.5*sin(3*time+4);
	t3 = 0.5+0.5*sin(3*time+1);

	glColor4f(0.0, 0.0, 0.0, 0.4);
	glRectf(4, 0, 6 ,6);
	glRectf(34, 0, 36 ,6);

	glBegin(GL_QUADS); {
		glColor4f(t1,  0,  0, 0.8); glVertex3f( 0,   0, 0);
		glColor4f( 0, t2,  0, 0.2); glVertex3f( 0, -22, 0);
		glColor4f( 0,  0, t3, 0.2); glVertex3f(40, -22, 0);
		glColor4f(t2,  0, t1, 0.8); glVertex3f(40,   0, 0);
	} glEnd();

	font->setColor(1.0, 1.0, 1.0, 1.0);
	font->render(text, 0, 0);

	return;
}
//______________________________________________________________
void Help::toggle()
{
	active = !active;
	return;
}
//______________________________________________________________

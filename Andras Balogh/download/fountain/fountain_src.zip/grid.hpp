#ifndef	BND_GRID_H
#define	BND_GRID_H

#include <GL/glut.h>

class Grid;

class Grid {
private:
	GLfloat	(*vertices)[3];
	bool	active;
public:
	Grid();
	~Grid();
	void update();
	void render();
	void toggle();
};

extern Grid	*grid;

#endif

//______________________________________________________________
#include <GL/glut.h>
//#include <stdlib.h>
#include "journal.hpp"
#include "glut.hpp"
#include "extension.hpp"
#include "font.hpp"
#include "skybox.hpp"
#include "surface.hpp"
#include "timer.hpp"
#include "fountain.hpp"
#include "petal.hpp"
#include "grid.hpp"
#include "help.hpp"
#include "hud.hpp"
#include "camera.hpp"
#include "world.hpp"
#include "main.hpp"
//______________________________________________________________
Journal		journal("journal.txt");
Font		*font;
Skybox		*skybox;
Surface		*surface;
Timer		*timer;
Fountain	*fountain;
Petal		*petal_1;
Petal		*petal_2;
Petal		*petal_3;
Grid		*grid;
Help		*help;
HUD		*hud;
Camera		*camera;
World		*world;
//______________________________________________________________
int main(int argc, char **argv)
{
	parse(argc, argv);
	initMouse();
	initWindow(&argc, argv);
	initExtensions();
	init();
	initGLUT();
	glutMainLoop();
	return 0;
}
//______________________________________________________________
void parse(int argc, char **argv)
{
	journal << "Parsing command-line {\n";
	for (int i=0; i<argc; i++) {
		journal << "\t[" << i << "] " << argv[i] << "\n";
	}
	journal << "}\n\n";

	return;
}
//______________________________________________________________
void initMouse()
{
	journal << "Mouse: ";
	if (glutGet(GLUT_HAS_MOUSE)) {
		journal << glutDeviceGet(GLUT_NUM_MOUSE_BUTTONS) << " button mouse found.\n\n";
	} else {
		journal << "Not detected.\n\n";
	}

	return;
}
//______________________________________________________________
void initWindow(int *argc, char **argv)
{
	journal << "Creating window {\n";
	glutInit(argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
	glutCreateWindow("fountain by bandi");
	glutSetCursor(GLUT_CURSOR_CROSSHAIR);
	glutFullScreen();
	journal 
	<< "\twidth    = " << glutGet(GLUT_SCREEN_WIDTH) << "\n"
	<< "\theight   = " << glutGet(GLUT_SCREEN_HEIGHT) << "\n"
	<< "\tbpp      = " << glutGet(GLUT_WINDOW_BUFFER_SIZE) << "\n"
	<< "\tz-buffer = " << glutGet(GLUT_WINDOW_DEPTH_SIZE) << "\n"
	<< "}\n\n";

	return;
	}
//______________________________________________________________
void initGLUT()
{
	journal << "\nBinding GLUT callbacks...";
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutIdleFunc(idle);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(special);
	glutMouseFunc(mouse);
	glutMotionFunc(motion);
	journal << "Done\n\n";

	return;
}
//______________________________________________________________
void init()
{
	font	 = new Font("font/font.tga", 16, 16);
	skybox	 = new Skybox;
	surface  = new Surface;
	timer	 = new Timer;
	fountain = new Fountain(30000, 1000.0);
	petal_1  = new Petal_1(100);
	petal_2  = new Petal_2(100);
	petal_3  = new Petal_3(100);
	grid	 = new Grid;
	hud	 = new HUD;
	help	 = new Help;
	camera   = new Camera;
	world	 = new World;

	return;
}
//______________________________________________________________
void shutdown()
{
	journal 
	<< "Average FPS: " << (int)timer->get(FPS) << "\n\n";

	delete world;
	delete camera;
	delete help;
	delete hud;
	delete grid;
	delete petal_3;
	delete petal_2;
	delete petal_1;
	delete fountain;
	delete timer;
	delete surface;
	delete skybox;
	delete font;
	
	exit(0);
	return;
}
//______________________________________________________________

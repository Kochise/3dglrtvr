#ifndef	BND_HUD_H
#define	BND_HUD_H

class HUD;

class HUD {
private:
	GLuint	tx_HUD;
	float	acc_time;
	float	acc_frames;
	float	avg_fps;
	bool	active;
public:
	HUD();
	~HUD();
	void render();
	void update();
	void toggle();
};

extern HUD	*hud;

#endif
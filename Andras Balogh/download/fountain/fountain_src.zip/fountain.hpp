#ifndef	BND_FOUNTAIN_H
#define	BND_FOUNTAIN_H

#include <GL/glut.h>

#define	NORMAL		0
#define	REFLECTION	1

#define	FOUNTAIN_THRUST	0
#define	FOUNTAIN_SPREAD	1
#define	FOUNTAIN_DPS	2
#define	FOUNTAIN_CLOSE	3
#define	FOUNTAIN_OPEN	4
#define	FOUNTAIN_BOOST	5
#define	FOUNTAIN_ACTIVE	6

class Fountain;

class Fountain {
private:
	GLfloat	(*position)[3];
	GLfloat	(*velocity)[3];
	GLubyte	(*color)[4];
	int	number_of_drops;
	int	active_drops;
	float	drops_per_sec;
	float	queue;
	float	boost;

	float	thrust;
	float	spread;
	
	void createDrop(int i);
public:
	Fountain(int number_of_drops = 2000, float drops_per_sec = 100.0);
	~Fountain();
	void update();
	void render(unsigned int type = NORMAL, GLfloat x = 0, GLfloat y = 0, GLfloat z = 0);
	void set(unsigned int type, float value = 0.0);
	float get(unsigned int type);
};

extern Fountain	*fountain;

#endif

#ifndef	BND_MAIN_H
#define	BND_MAIN_H

extern int main(int argc, char **argv);
extern void parse(int argc, char **argv);
extern void initMouse();
extern void initWindow(int *argc, char **argv);
extern void initGLUT();
extern void init();
extern void shutdown();

#endif

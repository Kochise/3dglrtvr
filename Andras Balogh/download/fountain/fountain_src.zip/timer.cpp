//______________________________________________________________
#include <windows.h>
#include "journal.hpp"
#include "timer.hpp"
//______________________________________________________________
Timer::Timer()
{
	journal << "init: Timer\t";
	reset();
	journal << "OK\n";
	return;
}
//______________________________________________________________
Timer::~Timer()
{
	journal << "kill: Timer\tOK\n";
	return;
}
//______________________________________________________________
void Timer::reset()
{
	paused	  = false;
	frames	  = 0;
	time	  = 0;
	dt	  = 0;
	meta_time = 0;
	old_time  = timeGetTime();
	return;
}
//______________________________________________________________
void Timer::update()
{
	new_time = timeGetTime();
	dt = (float)(new_time - old_time) / 1000;
	meta_time += dt;
	frames++;

	if (!paused) {
		time += dt;
	}

	old_time = new_time;
	return;
}
//______________________________________________________________
void Timer::pause()
{
	paused = !paused;
	return;
}
//______________________________________________________________
float Timer::get(unsigned int type)
{
	switch (type) {
	case TIME:
		return time;
		break;
	case DT:
		return dt;
		break;
	case FPS:
		return (float)frames/meta_time;
		break;
	case METATIME:
		return meta_time;
		break;
	default:
		break;
	}

	return 0.0;
}


//______________________________________________________________
#include <GL/glut.h>
#include "journal.hpp"
#include "grid.hpp"
//______________________________________________________________
const unsigned int	number_of_vertices = 2*3*7*7;
//______________________________________________________________
Grid::Grid()
{
	GLfloat	x;
	GLfloat	y;
	unsigned int	i;
	unsigned int	j;
	
	journal << "init: Grid\t";

	vertices = new GLfloat[number_of_vertices][3];
	active = false;

	i = 0;

	for (j=0; j<3; j++) {
		for (x=-15.1; x<15; x+=5) {
			for(y=-15.1; y<15; y+=5) {
				vertices[i][(j+0)%3] = x;
				vertices[i][(j+1)%3] = y;
				vertices[i][(j+2)%3] = -15.1;
				i++;
				vertices[i][(j+0)%3] = x;
				vertices[i][(j+1)%3] = y;
				vertices[i][(j+2)%3] = +14.9;
				i++;
			}
		}
	}

	journal << "OK\n";
	
	return;
}
//______________________________________________________________
Grid::~Grid()
{
	journal << "kill: Grid\t";
	delete [] vertices;
	journal << "OK\n";
	return;
}
//______________________________________________________________
void Grid::update()
{
	if (active) {
		render();
	}
	return;
}
//______________________________________________________________
void Grid::render()
{
	glColor4f(0.0, 1.0, 0.0, 0.4);
	glVertexPointer(3, GL_FLOAT, 0, vertices);
	glEnableClientState(GL_VERTEX_ARRAY);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glDrawArrays(GL_LINES, 0, number_of_vertices);
	glDisableClientState(GL_VERTEX_ARRAY);
	return;
}
//______________________________________________________________
void Grid::toggle()
{
	active = !active;
	return;
}
//______________________________________________________________

#include "Journal.hpp"
//______________________________________________________________
Journal::Journal(const char *path)
{
	f = fopen(path, "wt");

	if (f==NULL) {
		f = stdout;
	}

	fprintf(f, "Fountain Journal created.\n\n");
	return;
}
//______________________________________________________________
Journal::~Journal()
{
	journal << "\nClosing Journal.\n";

	fflush(f);
	fclose(f);
	return;
}
//______________________________________________________________
Journal& Journal::operator<<(const char *string)
{
	fprintf(f, "%s", string);
	return *this;
}
//______________________________________________________________
Journal& Journal::operator<<(const unsigned char *string)
{
	fprintf(f, "%s", string);
	return *this;
}
//______________________________________________________________
Journal& Journal::operator<<(float value)
{
	fprintf(f, "%f", value);
	return *this;
}
//______________________________________________________________
Journal& Journal::operator<<(int value)
{
	fprintf(f, "%d", value);
	return *this;
}
//______________________________________________________________

//______________________________________________________________
#include <GL/glut.h>
#include "tga.hpp"
#include "journal.hpp"
#include "font.hpp"
//______________________________________________________________
Font::Font(const char *path, unsigned int cols, unsigned int rows)
{
	journal << "init: Font {\n";

	loadTGA(path, tx_font, GL_CLAMP);
	this->cols   = cols;
	this->rows   = rows;
	color[0] = 1.0;
	color[1] = 1.0;
	color[2] = 1.0;
	color[3] = 1.0;

	journal << "}\n\n";

	return;
}
//______________________________________________________________
Font::~Font()
{
	journal << "kill: Font\t";
	glDeleteTextures(1, &tx_font);
	journal << "OK\n";
	return;
}
//______________________________________________________________
void Font::render(const char *s, float ulx, float uly)
{
	GLfloat width  = (GLfloat) 1 / cols;
	GLfloat	height = (GLfloat) 1 / rows;
	GLfloat	map_x;
	GLfloat	map_y;
	GLfloat	x = ulx;
	GLfloat	y = uly;

	glColor4fv(color);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, tx_font);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	while(*s) {
		if (*s == '\n') {
			y++;
			x = ulx;
		} else {
			map_x = *s % cols * width;
			map_y = 1 - *s / cols * width;

			glBegin(GL_QUADS); {
				glTexCoord2f(      map_x,        map_y); glVertex2f(  x,   -y);
				glTexCoord2f(      map_x, map_y-height); glVertex2f(  x, -y-1);
				glTexCoord2f(map_x+width, map_y-height); glVertex2f(x+1, -y-1);
				glTexCoord2f(map_x+width,        map_y); glVertex2f(x+1,   -y);
			}; glEnd();

			x++;
		}
		s++;
	}

	glDisable(GL_TEXTURE_2D);

	return;
}
//______________________________________________________________
void Font::setColor(float red, float green, float blue, float alpha)
{
	color[0] = red;
	color[1] = green;
	color[2] = blue;
	color[3] = alpha;
	return;
}
//______________________________________________________________

#ifndef	BND_SURFACE_H
#define	BND_SURFACE_H

#include <GL/glut.h>

class Surface;

class Surface {
private:
	GLuint	tx_surface;
public:
	Surface();
	~Surface();
	void render();
	void render2();
};

extern Surface	*surface;

#endif

//______________________________________________________________
#include <GL/glut.h>
#include <stdio.h>
#include "journal.hpp"
#include "timer.hpp"
#include "fountain.hpp"
#include "font.hpp"
#include "hud.hpp"
//______________________________________________________________
HUD::HUD()
{
	journal << "init: HUD\t";

	acc_time   = 0;
	acc_frames = 0;
	avg_fps    = 0;
	active     = true;

	journal << "OK\n";

	return;
}
//______________________________________________________________
HUD::~HUD()
{
	journal << "kill: HUD\tOK\n";
	return;
}
//______________________________________________________________
void HUD::update()
{
	acc_time += timer->get(DT);
	acc_frames++;

	if (acc_time > 0.1) {
		avg_fps = acc_frames / acc_time;
		acc_time = acc_frames = 0;
	}

	if (active) {
		render();
	}

	return;
}
//______________________________________________________________
void HUD::render()
{
	char	text[80*50];

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, +80, -50, 0, -1, +1);

	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glColor4f(0, 0, 0, 0.2);
	glRectf(0, 0, 80, -3);
	glRectf(0, -47, 80, -50);

	font->setColor(1.0, 1.0, 1.0, 1.0);
	sprintf(
		text, 
		"%s\n"
		"%s\n"
		"%s",
		glGetString(GL_VENDOR),
		glGetString(GL_RENDERER),
		glGetString(GL_VERSION)
	); 
	font->render(text, 0, 0);

	sprintf(
		text, 
		"%5d fps\n"
		"%5d dps\n"
		"%5d dpf\n"
		"%9s",
		(int)avg_fps,
		(int)fountain->get(FOUNTAIN_DPS),
		(int)fountain->get(FOUNTAIN_ACTIVE),
		fountain->get(FOUNTAIN_BOOST) > 0.0 ? "BOOST" : ""
	); 
	font->render(text, 71, 0);

	sprintf(
		text, 
		"Fountain v0.7 developed by Andrew \"Bandi\" Balogh (ba127@hszk.bme.hu)"
	);
	font->render(text, 5, 48);

	if (fountain->get(FOUNTAIN_BOOST) > 0.0) {
		font->setColor(1.0, 1.0, 1.0, 1.0);
	} else {
		font->setColor(0.0, 0.0, 0.0, 0.2);
	}
	sprintf(text,"BOOST"); 
	font->render(text, 75, 3);

	return;
}
//______________________________________________________________
void HUD::toggle()
{
	active = !active;
	return;
}
//______________________________________________________________

//______________________________________________________________
#include <GL/glut.h>
#include <math.h>
#include "journal.hpp"
#include "random.hpp"
#include "surface.hpp"
#include "tga.hpp"
//______________________________________________________________
Surface::Surface()
{
	journal << "init: Surface {\n";
	loadTGA("surface/surface.tga", tx_surface, GL_REPEAT);
	journal << "}\n\n";
	
	return;
}
//______________________________________________________________
Surface::~Surface()
{
	journal << "kill: Surface\t";
	glDeleteTextures(1, &tx_surface);
	journal << "OK\n";
	return;
}
//______________________________________________________________
void Surface::render()
{
	GLfloat vertices[][3] = {
		{-500.0, 0.0, +500.0},
		{+500.0, 0.0, +500.0},
		{+500.0, 0.0, -500.0},
		{-500.0, 0.0, -500.0}
	};
	GLfloat colors[][4] = {
		{1.0, 1.0, 1.0, 0.7},
		{1.0, 1.0, 1.0, 0.7},
		{1.0, 1.0, 1.0, 0.7},
		{1.0, 1.0, 1.0, 0.7}
	};
	GLfloat texcoords[][2] = {
		{0.0, 0.0},
		{5.0, 0.0},
		{5.0, 5.0},
		{0.0, 5.0}
	};

	glVertexPointer(3, GL_FLOAT, 0, vertices);
	glColorPointer(4, GL_FLOAT, 0, colors);
	glTexCoordPointer(2, GL_FLOAT, 0, texcoords);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_TEXTURE_2D);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glBindTexture(GL_TEXTURE_2D, tx_surface);
	glDrawArrays(GL_QUADS, 0, 4);
	glDisable(GL_TEXTURE_2D);

	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);

	return;
}
//______________________________________________________________
void Surface::render2()
{

	GLfloat vertices[][3] = {
		{-500.0, 0.0, +500.0},
		{+500.0, 0.0, +500.0},
		{+500.0, 0.0, -500.0},
		{-500.0, 0.0, -500.0}
	};

	glColor3f(0.0, 0.0, 0.0);

	glVertexPointer(3, GL_FLOAT, 0, vertices);
	glEnableClientState(GL_VERTEX_ARRAY);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);	
	glDrawArrays(GL_QUADS, 0, 4);
	glDisableClientState(GL_VERTEX_ARRAY);

	return;
}

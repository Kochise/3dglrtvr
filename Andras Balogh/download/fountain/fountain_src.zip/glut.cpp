//______________________________________________________________
#include <GL/glut.h>
#include "main.hpp"
#include "fountain.hpp"
#include "camera.hpp"
#include "world.hpp"
#include "grid.hpp"
#include "hud.hpp"
#include "help.hpp"
//______________________________________________________________
#define	ESC		27
#define	TAB		'\t'
#define	ENTER		13
#define	SPACE		32
#define	BACKSPACE	8
//______________________________________________________________
static int	mbutton;
static int	start_x;
static int	start_y;
static int	spin;
//______________________________________________________________
void display()
{
	world->render();
	glutSwapBuffers();
	return;
}
//______________________________________________________________
void reshape(int width, int height)
{
	glViewport(0, 0, width, height);
	camera->set(CAMERA_ASPECT, (float)width/height);
	return;
}
//______________________________________________________________
void idle()
{
	glutPostRedisplay();
	return;
}
//______________________________________________________________
void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case ESC:
		shutdown();
		break;
	case SPACE:
		world->set(FREEZE);
		break;
	case TAB:
		camera->set(CAMERA_CONTROL);
		break;
	case ENTER:
		fountain->set(FOUNTAIN_BOOST, 0.3f);
		break;
	case '/':
	case BACKSPACE:
		fountain->set(FOUNTAIN_CLOSE);
		break;
	case '*':
		fountain->set(FOUNTAIN_OPEN);
		break;
	case '_':
	case '-':
		fountain->set(FOUNTAIN_DPS, -1000.0f);
		break;
	case '+':
	case '=':
		fountain->set(FOUNTAIN_DPS, +1000.0f);
		break;
	case 'R':		
	case 'r':
		world->set(REFLECTION);
		break;
	case 'G':
	case 'g':
		grid->toggle();
		break;
	case 'H':
	case 'h':
		hud->toggle();
		break;
	default:
		break;
	}

	return;
}
//______________________________________________________________
void special(int key, int x, int y)
{
	switch (key) {
	case GLUT_KEY_F1:
		help->toggle();
		break;
	case GLUT_KEY_UP:
		fountain->set(FOUNTAIN_THRUST, +0.1f);
		break;
	case GLUT_KEY_DOWN:
		fountain->set(FOUNTAIN_THRUST, -0.1f);
		break;
	case GLUT_KEY_LEFT:
		fountain->set(FOUNTAIN_SPREAD, -0.1f);
		break;
	case GLUT_KEY_RIGHT:
		fountain->set(FOUNTAIN_SPREAD, +0.1f);
		break;
	default:
		break;
	}
	return;
}
//______________________________________________________________
void mouse(int button, int state, int x, int y)
{
	if (state == GLUT_DOWN) {
		mbutton = button;
		start_x = x;
		start_y = y;
	} else if (state == GLUT_UP) {
		camera->set(CAMERA_SPIN, spin*-0.1f);
	}
	return;
}
//______________________________________________________________
void motion(int x, int y)
{
	if (mbutton == GLUT_LEFT_BUTTON) {
		camera->set(CAMERA_ANGLE_H, (x-start_x)*0.01f);
		camera->set(CAMERA_ANGLE_V, (y-start_y)*0.01f);
		camera->set(CAMERA_SPIN, 0.0f);
		spin = x-start_x;
	} else if (mbutton == GLUT_MIDDLE_BUTTON) {
		camera->set(CAMERA_DISTANCE, (y-start_y)*0.02f);
	}

	start_x = x;
	start_y = y;

	return;
}
//______________________________________________________________

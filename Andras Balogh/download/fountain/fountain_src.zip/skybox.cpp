//______________________________________________________________
#include <GL/glut.h>
#include "journal.hpp"
#include "tga.hpp"
#include "skybox.hpp"
//______________________________________________________________
#define	N	-1.0
#define	O	0.0
#define	P	1.0
//______________________________________________________________
Skybox::Skybox()
{
	journal << "init: Skybox {\n";

	loadTGA("skybox/snowbk.tga", tx_skybox[0], GL_CLAMP);
	loadTGA("skybox/snowft.tga", tx_skybox[1], GL_CLAMP);
	loadTGA("skybox/snowup.tga", tx_skybox[2], GL_CLAMP);
	loadTGA("skybox/snowdn.tga", tx_skybox[3], GL_CLAMP);
	loadTGA("skybox/snowrt.tga", tx_skybox[4], GL_CLAMP);
	loadTGA("skybox/snowlf.tga", tx_skybox[5], GL_CLAMP);

	journal << "}\n\n";

	return;
}
//______________________________________________________________
Skybox::~Skybox()
{
	journal << "kill: Skybox\t";
	glDeleteTextures(6, tx_skybox);
	journal << "OK\n";
	return;
}
//______________________________________________________________
void Skybox::render()
{
	unsigned int	i;

	GLfloat vertices[][3] = {
		{P,N,N},{P,N,P},{P,P,P},{P,P,N}, // right
		{N,N,P},{N,N,N},{N,P,N},{N,P,P}, // left
		{P,P,P},{N,P,P},{N,P,N},{P,P,N}, // top
		{P,N,N},{N,N,N},{N,N,P},{P,N,P}, // bottom
		{P,N,P},{N,N,P},{N,P,P},{P,P,P}, // back
		{N,N,N},{P,N,N},{P,P,N},{N,P,N}  // front
	};

	GLfloat texcoords[][2] = {
		{O,O},{P,O},{P,P},{O,P},
		{O,O},{P,O},{P,P},{O,P},
		{O,O},{P,O},{P,P},{O,P},
		{O,O},{P,O},{P,P},{O,P},
		{O,O},{P,O},{P,P},{O,P},
		{O,O},{P,O},{P,P},{O,P}
	};

	glVertexPointer(3, GL_FLOAT, 0, vertices);
	glTexCoordPointer(2, GL_FLOAT, 0, texcoords);
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	for (i=0; i<6; i++) {
		glBindTexture(GL_TEXTURE_2D, tx_skybox[i]);
		glDrawArrays(GL_QUADS, i*4, 4);
	}
	glDisable(GL_TEXTURE_2D);
	
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);

	return;
}
//______________________________________________________________

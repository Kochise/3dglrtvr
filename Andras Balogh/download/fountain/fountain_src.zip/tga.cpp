//______________________________________________________________
#include <GL/glut.h>
#include <stdio.h>
#include "pak.hpp"
#include "tga.hpp"
//______________________________________________________________
typedef	unsigned char		u8;
typedef	unsigned short int	u16;
typedef	unsigned long int	u32;
//______________________________________________________________
void loadTGA(const char *path, GLuint &id, GLint wrap_type)
{
	u8	*code;
	GLubyte	*text;
	GLenum	format;
	u16	width;
	u16	height;
	u16	bpp;
	u32	size;
	u32	i;

	code = load(path, "fountain.paq");
	
	if (code == NULL) {
		return;
	}

	width	= (code[12] + code[13]) << 8;
	height	= (code[14] + code[15]) << 8;
	bpp	= code[16];

	size = width * height * bpp / 8;
	text = new GLubyte[size];

	code += 18;
	if (bpp == 24) {
		format = GL_RGB;
		for (i=0; i<size; i+=3) {
			text[i+0] = code[i+2];
			text[i+1] = code[i+1];
			text[i+2] = code[i+0];
		}
	} else if (bpp == 32) {
		format = GL_RGBA;
		for (i=0; i<size; i+=4) {
			text[i+0] = code[i+2];
			text[i+1] = code[i+1];
			text[i+2] = code[i+0];
			text[i+3] = code[i+3];
		}
	} else {
		return;
	}
	code -= 18;
	
	glGenTextures(1, &id);
	glBindTexture(GL_TEXTURE_2D, id);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrap_type);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrap_type);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexImage2D(GL_TEXTURE_2D, 0, bpp/8, width, height, 0, format, GL_UNSIGNED_BYTE, text);

	delete [] code;
	delete [] text;

	return;
}
//______________________________________________________________

//______________________________________________________________
#include <GL/glut.h>
//#include <stdlib.h>
#include <string.h>
#include "journal.hpp"
#include "extension.hpp"
//______________________________________________________________
PFNGLPOINTPARAMETERFEXTPROC glPointParameterfEXT;
PFNGLPOINTPARAMETERFVEXTPROC glPointParameterfvEXT;
//______________________________________________________________
void initExtensions(void)
{
	GLubyte		*extensions;
	unsigned int	a = 0;
	unsigned int	z = 0;

	journal
	<< "OpenGL implementation {\n"
	<< "\tVendor   : " << glGetString(GL_VENDOR)   << "\n"
	<< "\tRenderer : " << glGetString(GL_RENDERER) <<"\n"
	<< "\tVersion  : " << glGetString(GL_VERSION)  <<"\n"
	<< "}\n\n"
	<< "Supported extensions {\n";

	extensions = new GLubyte[strlen((char *)glGetString(GL_EXTENSIONS))];
	strcpy((char *)extensions, (char *)glGetString(GL_EXTENSIONS));

	for (z=0; extensions[z] != '\0'; z++) {
		if (extensions[z] == ' ') {
			extensions[z] = '\0';
			journal << "\t" << &extensions[a] << "\n";
			extensions[z] = ' ';
			a = z+1;
		}
	}

	journal
	<< "}\n\n"
	<< "Checking for required extensions {\n"
	<< "\tGL_EXT_point_parameters...";

	glPointParameterfEXT = NULL;
	glPointParameterfvEXT = NULL;

	if (glutExtensionSupported("GL_EXT_point_parameters")) {
		
		glPointParameterfEXT = (PFNGLPOINTPARAMETERFEXTPROC) wglGetProcAddress("glPointParameterfEXT");
		glPointParameterfvEXT = (PFNGLPOINTPARAMETERFVEXTPROC) wglGetProcAddress("glPointParameterfvEXT");

		if (glPointParameterfEXT && glPointParameterfvEXT) {
			journal << "OK\n";
		} else {
			journal << "FAILED\n";
		}

	} else {
		journal << "FAILED\n";
	}

	journal << "}\n\n";

	return;
}
//______________________________________________________________

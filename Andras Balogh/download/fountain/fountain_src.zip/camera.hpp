#ifndef	BND_CAMERA_H
#define	BND_CAMERA_H

#include <GL/glut.h>

#define	CAMERA_DISTANCE	0
#define	CAMERA_ANGLE_V	1
#define	CAMERA_ANGLE_H	2
#define	CAMERA_SPIN	3
#define	CAMERA_ASPECT	5
#define	CAMERA_CONTROL	6
#define	CAMERA_X	7
#define	CAMERA_Y	8
#define	CAMERA_Z	9

class Camera;

class Camera {
private:
	GLfloat	distance;
	GLfloat	angle_h;
	GLfloat	angle_v;
	GLfloat	spin;
	GLfloat	FOV;
	GLfloat	aspect;
	GLfloat	eye_x;
	GLfloat	eye_y;
	GLfloat	eye_z;
	bool	automagic;
public:
	Camera();
	~Camera();
	void reset();
	void eye();
	void skybox();
	void set(unsigned int type, float value = 0.0);
	float get(unsigned int type);
};

extern Camera	*camera;

#endif

-- Terrain dataset configuration file

if (Terrain == nil) then Terrain = {} end

Terrain.name = "noise_land"
Terrain.map_bits = 17
Terrain.base_bits = 10
Terrain.detail_bits = 10
Terrain.horizontal_resolution = 160.0
Terrain.vertical_resolution = 0.18
Terrain.vertical_bias = 0.0
Terrain.detail_vertical_resolution = 0.001;
Terrain.irradiance = "test"
Terrain.walk = 1

Log("Noise Land configuration loaded.\n");

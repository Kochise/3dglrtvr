-- Terrain dataset configuration file

if (Terrain == nil) then Terrain = {} end

Terrain.name = "puget_sound_1k"
Terrain.map_bits = 16
Terrain.base_bits = 10
Terrain.detail_bits = 10
Terrain.horizontal_resolution = 160.0
Terrain.vertical_resolution = 0.1
Terrain.vertical_bias = 0
Terrain.detail_vertical_resolution = 0.0012;
Terrain.irradiance = "simple"
Terrain.animation = "demos/flythrough.demo"

Log("Puget Sound configuration loaded.\n");

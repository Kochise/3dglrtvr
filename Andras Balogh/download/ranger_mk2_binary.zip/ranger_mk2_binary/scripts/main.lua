System.Info();			-- Report system information
--Display.SetMode(1600, 1200);
Display.SetMode(0, 0);		-- Use desktop resolution
--Display.SetMode(640, 480);		-- Use desktop resolution
Window.Create(0, 0, 0, 24, 0);	-- Create fullscreen window with 24bit Z-buffer
--OpenGL.SetVSync(1);		-- Vertical syncronization
System.SetBasePath("./");
Console.SelectFont("Comic Sans MS");
--Overlay.SelectFont("Verdana");
Overlay.SelectFont("Monotype Corsiva");
--Sound.EnumACM();
--Sound.LoadMP3("sound/suspense.mp3", 170);
--Sound.Play();
Input.SetMouseSensitivity(30, 30);
